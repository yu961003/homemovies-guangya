package com.example.localmovielibrarz.ui.cloud.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * 网盘统一搜索栏（115 / 光鸭共用）。
 *
 * - 搜索框：40dp 高，12dp 圆角，与操作栏按钮等高
 * - 范围切换：两个 FilterChip（当前目录 / 全局），仅 115 显示（光鸭无 cid 概念时隐藏）
 * - 防抖：由调用方在 onQueryChange 回调中实现 350ms 防抖
 */
@Composable
fun CloudSearchRow(
    query: String,
    onQueryChange: (String) -> Unit,
    isSearching: Boolean,
    searchScope: CloudSearchScope,
    onScopeChange: (CloudSearchScope) -> Unit,
    showScopeSwitcher: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 搜索框
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier
                .weight(1f)
                .height(40.dp),
            placeholder = { Text("搜索文件…", style = MaterialTheme.typography.bodySmall) },
            leadingIcon = {
                Icon(
                    Icons.Rounded.Search,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "清除",
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onQueryChange("") }
                    )
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                unfocusedIndicatorColor = MaterialTheme.colorScheme.outlineVariant
            ),
            textStyle = MaterialTheme.typography.bodySmall,
            singleLine = true
        )

        // 范围切换（仅 115）
        if (showScopeSwitcher) {
            FilterChip(
                selected = searchScope == CloudSearchScope.CurrentDirectory,
                onClick = { onScopeChange(CloudSearchScope.CurrentDirectory) },
                label = { Text("当前目录", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.height(32.dp)
            )
            FilterChip(
                selected = searchScope == CloudSearchScope.Global,
                onClick = { onScopeChange(CloudSearchScope.Global) },
                label = { Text("全局", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.height(32.dp)
            )
        }

        // 搜索态退出提示
        if (isSearching) {
            TextButton(onClick = { onQueryChange("") }) {
                Text("取消", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/** 网盘搜索范围（115 / 光鸭共用）。 */
enum class CloudSearchScope(val label: String) {
    Global("全局"),
    CurrentDirectory("当前目录")
}
