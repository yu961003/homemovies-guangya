package com.example.localmovielibrarz.ui.cloud.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/**
 * 网盘页统一操作栏（115 / 光鸭共用）。
 *
 * 左侧：返回上级（仅可返回时显示，带入场动画）+ 根目录
 * 右侧：主操作按钮（工具箱 / 离线下载），由 [primaryAction] 指定
 *
 * 所有按钮统一 40dp 高度、12dp 圆角，消除原有的 TextButton(36dp) 与
 * OutlinedButton(48dp) 高度差导致的错位。
 */
@Composable
fun CloudOperationBar(
    canGoBack: Boolean,
    onGoBack: () -> Unit,
    onGoRoot: () -> Unit,
    primaryAction: CloudPrimaryAction,
    modifier: Modifier = Modifier,
    onToolbox: (() -> Unit)? = null
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ===== 左侧：导航按钮组 =====
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 返回上级：带动画显隐，避免布局跳变
            AnimatedVisibility(
                visible = canGoBack,
                enter = fadeIn() + slideInHorizontally(initialOffsetX = { -it / 4 }),
                exit = fadeOut() + slideOutHorizontally(targetOffsetX = { -it / 4 })
            ) {
                CloudSecondaryButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    label = "返回上级",
                    onClick = onGoBack
                )
            }
            // 根目录：始终显示（不可在加载中点击）
            CloudSecondaryButton(
                icon = Icons.Rounded.Home,
                label = "根目录",
                onClick = onGoRoot,
                enabled = primaryAction !is CloudPrimaryAction.Loading
            )
        }

        // ===== 右侧：主操作按钮（光鸭可附带次操作「工具箱」） =====
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onToolbox != null) {
                CloudSecondaryButton(
                    icon = Icons.Rounded.Build,
                    label = "工具箱",
                    onClick = onToolbox
                )
            }
            when (primaryAction) {
                is CloudPrimaryAction.Toolbox -> {
                    CloudPrimaryButton(
                        icon = Icons.Rounded.Build,
                        label = "工具箱",
                        onClick = primaryAction.onClick
                    )
                }
                is CloudPrimaryAction.OfflineDownload -> {
                    CloudPrimaryButton(
                        icon = Icons.Rounded.CloudDownload,
                        label = "离线下载",
                        onClick = primaryAction.onClick
                    )
                }
                is CloudPrimaryAction.Loading -> {
                    // 加载中：显示不可点击的占位按钮，保持布局高度不变
                    CloudPrimaryButton(
                        icon = Icons.Rounded.CloudOff,
                        label = "加载中",
                        onClick = {},
                        enabled = false
                    )
                }
            }
        }
    }
}

/** 主操作按钮的密封配置（115 传 Toolbox，光鸭传 OfflineDownload）。 */
sealed class CloudPrimaryAction {
    data class Toolbox(val onClick: () -> Unit) : CloudPrimaryAction()
    data class OfflineDownload(val onClick: () -> Unit) : CloudPrimaryAction()
    data object Loading : CloudPrimaryAction()
}

/** 主操作按钮：Button(filled)，40dp 高，12dp 圆角。 */
@Composable
private fun CloudPrimaryButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .height(40.dp)
            .wrapContentWidth(),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

/** 次操作按钮：OutlinedButton，40dp 高，12dp 圆角。 */
@Composable
private fun CloudSecondaryButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .height(40.dp)
            .wrapContentWidth(),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = MaterialTheme.colorScheme.primary
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
