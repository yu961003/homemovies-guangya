package com.example.localmovielibrarz.ui.guangya

import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import org.json.JSONObject
import java.util.Locale

/**
 * 批量重命名 v3：四类操作（删除/替换、插入、全新命名、自定义正则）+ 正则增强 + 模板。
 * 纯函数实现，便于单测；所有「位置」语义均为 1 基（第 1 位 = 首字符）。
 * 语义示例统一用主名 "ABCDEF-123"（共 10 位）。
 */

// ==================== 配置模型 ====================

/** 批量重命名配置（四类操作统一入口）。 */
sealed interface BatchRenameConfig {
    /** 删除/替换字符：replacement 为空 = 纯删除；xxAsRegex=true 时 XX 按正则解释、替换为支持 $ 分组。 */
    data class DeleteReplace(
        val range: RenameDeleteRange,
        val replacement: String = "",
        val xxAsRegex: Boolean = false
    ) : BatchRenameConfig

    /** 新增/插入字符。 */
    data class Insert(
        val position: RenameInsertPosition,
        val text: String,
        val markerAsRegex: Boolean = false
    ) : BatchRenameConfig

    /** 全新命名：{name}=原主名，{n}=序号（startNumber 起、digits 位补零）。 */
    data class NewNaming(
        val template: String,
        val startNumber: Int = 1,
        val digits: Int = 2
    ) : BatchRenameConfig

    /** 自定义正则查找替换（完全自由 pattern，replacement 支持 $1/$2 分组）。 */
    data class CustomRegex(
        val pattern: String,
        val replacement: String,
        val ignoreCase: Boolean = false,
        val firstOnly: Boolean = false,
        val applyToExtension: Boolean = false
    ) : BatchRenameConfig
}

// ============ 删除/替换范围（示例主名 ABCDEF-123） ============

sealed interface RenameDeleteRange {
    /** 指定字符串 XX（字面模式：所有出现处；正则模式：XX 即 pattern）。XX="DEF" → ABC-123 */
    data class SpecifiedString(val text: String) : RenameDeleteRange

    /** 前 N 个字符。N=6 → -123 */
    data class FirstN(val n: Int) : RenameDeleteRange

    /** 后 N 个字符。N=3 → ABCDEF- */
    data class LastN(val n: Int) : RenameDeleteRange

    /** 第 M 位之后的 N 个字符。M=6,N=4 → 删第 7~10 位("-123") → ABCDEF */
    data class AfterPositionMN(val m: Int, val n: Int) : RenameDeleteRange

    /** 倒数第 M 位之前的 N 个字符（不含倒数第 M 位本身）。M=4,N=2 → 倒数第4位是"-"，删其前"EF" → ABCD-123 */
    data class BeforeEndPositionMN(val m: Int, val n: Int) : RenameDeleteRange

    /** XX 之后的全部字符。XX="-" → ABCDEF-（includeMarker=true 连 XX 一起删 → ABCDEF） */
    data class AfterStringAll(val text: String, val includeMarker: Boolean = false) : RenameDeleteRange

    /** XX 之前的全部字符。XX="-" → -123（includeMarker=true → 123） */
    data class BeforeStringAll(val text: String, val includeMarker: Boolean = false) : RenameDeleteRange

    /** XX 之后的 N 个字符。XX="-",N=2 → ABCDEF-3 */
    data class AfterStringN(val text: String, val n: Int, val includeMarker: Boolean = false) : RenameDeleteRange
}

// ==================== 插入位置（示例插入文本 "[HD]"） ====================

sealed interface RenameInsertPosition {
    /** 开头 → [HD]ABCDEF-123 */
    data object Start : RenameInsertPosition
    /** 末尾 → ABCDEF-123[HD] */
    data object End : RenameInsertPosition
    /** 第 N 个字符之后。N=6 → ABCDEF[HD]-123 */
    data class AfterNth(val n: Int) : RenameInsertPosition
    /** 倒数第 N 个字符之前。N=3 → ABCDEF-[HD]123 */
    data class BeforeLastNth(val n: Int) : RenameInsertPosition
    /** XX 字符串之后（字面模式：第一处；正则模式：每一处命中）。XX="-" → ABCDEF-[HD]123 */
    data class AfterString(val text: String) : RenameInsertPosition
    /** XX 字符串之前。XX="-" → ABCDEF[HD]-123 */
    data class BeforeString(val text: String) : RenameInsertPosition
}

// ==================== 纯函数实现 ====================

object RenameOps {

    val ILLEGAL_NAME_CHARS = charArrayOf('/', '\\', ':', '*', '?', '"', '<', '>', '|')

    /** 统一分发：xxAsRegex=false 走字面实现，true 走自动编译的正则实现。 */
    fun deleteOrReplace(
        base: String,
        range: RenameDeleteRange,
        replacement: String,
        xxAsRegex: Boolean = false
    ): String? {
        if (replacement.any { it in ILLEGAL_NAME_CHARS }) return null
        return if (xxAsRegex) regexDeleteOrReplace(base, range, replacement)
        else literalDeleteOrReplace(base, range, replacement)
    }

    /** 统一分发：markerAsRegex 仅对 XX 定位类位置有意义，纯位置类两模式行为一致。 */
    fun insert(
        base: String,
        position: RenameInsertPosition,
        text: String,
        markerAsRegex: Boolean = false
    ): String? {
        if (text.isEmpty() || text.any { it in ILLEGAL_NAME_CHARS }) return null
        return if (markerAsRegex) regexInsert(base, position, text)
        else literalInsert(base, position, text)
    }

    // ---------------- 字面实现 ----------------

    private fun literalDeleteOrReplace(base: String, range: RenameDeleteRange, replacement: String): String? {
        /** 处理 base 的 [start,end) 区间：start 越界=参数错误返回 null；end 自动收敛。 */
        fun cut(start: Int, end: Int): String? {
            if (start < 0 || start > base.length) return null
            val e = end.coerceIn(start, base.length)
            return base.replaceRange(start, e, replacement)
        }
        return when (range) {
            is RenameDeleteRange.SpecifiedString ->
                if (range.text.isEmpty()) null else base.replace(range.text, replacement)

            is RenameDeleteRange.FirstN ->
                if (range.n <= 0) null else cut(0, range.n)

            is RenameDeleteRange.LastN ->
                if (range.n <= 0) null else cut(base.length - range.n, base.length)

            is RenameDeleteRange.AfterPositionMN ->
                if (range.m < 0 || range.n <= 0) null else cut(range.m, range.m + range.n)

            is RenameDeleteRange.BeforeEndPositionMN ->
                if (range.m <= 0 || range.m > base.length || range.n <= 0) null
                else cut(base.length - range.m - range.n, base.length - range.m)

            is RenameDeleteRange.AfterStringAll -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() -> null
                    idx < 0 -> base
                    else -> cut(if (range.includeMarker) idx else idx + range.text.length, base.length)
                }
            }

            is RenameDeleteRange.BeforeStringAll -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() -> null
                    idx < 0 -> base
                    else -> cut(0, if (range.includeMarker) idx + range.text.length else idx)
                }
            }

            is RenameDeleteRange.AfterStringN -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() || range.n <= 0 -> null
                    idx < 0 -> base
                    else -> {
                        val start = if (range.includeMarker) idx else idx + range.text.length
                        cut(start, start + range.n)
                    }
                }
            }
        }
    }

    private fun literalInsert(base: String, position: RenameInsertPosition, text: String): String? {
        val at: Int = when (position) {
            RenameInsertPosition.Start -> 0
            RenameInsertPosition.End -> base.length
            is RenameInsertPosition.AfterNth -> position.n.coerceIn(0, base.length)
            is RenameInsertPosition.BeforeLastNth -> (base.length - position.n).coerceIn(0, base.length)
            is RenameInsertPosition.AfterString ->
                if (position.text.isEmpty()) return null
                else base.indexOf(position.text).takeIf { it >= 0 }
                    ?.let { it + position.text.length } ?: return base
            is RenameInsertPosition.BeforeString ->
                if (position.text.isEmpty()) return null
                else base.indexOf(position.text).takeIf { it >= 0 } ?: return base
        }
        return StringBuilder(base).insert(at, text).toString()
    }

    // ---------------- 正则实现（下拉选项自动编译为 pattern） ----------------

    /**
     * 分组约定（正则模式）：
     * - SpecifiedString：$1.. = 用户在 XX 中自己写的分组；
     * - FirstN/LastN/AfterPositionMN/BeforeEndPositionMN：$1 = 被替换的目标字符；
     * - AfterStringAll：pattern=(XX)[\s\S]*，$1 = XX 匹配内容（替换为 $1 = 保留 XX 删其后，留空 = 连 XX 一起删）；
     * - BeforeStringAll：pattern=[\s\S]*?(XX)，$1 = XX 匹配内容（替换为 $1 = 删其前保留 XX，留空 = 连 XX 一起删）；
     * - AfterStringN：pattern=(XX)([\s\S]{1,N})，$1 = XX，$2 = 其后 N 个字符。
     * XX 定位类对每一处命中生效（字面模式只作用于第一处）。
     */
    private fun regexDeleteOrReplace(base: String, range: RenameDeleteRange, replacement: String): String? {
        // runCatching 同时兜底「pattern 非法」与「replacement 引用了不存在的分组」
        fun apply(pattern: String): String? = runCatching {
            Regex(pattern).replace(base, replacement)
        }.getOrNull()

        return when (range) {
            is RenameDeleteRange.SpecifiedString ->
                if (range.text.isEmpty()) null else apply(range.text)

            is RenameDeleteRange.FirstN ->
                if (range.n <= 0) null else apply("^([\\s\\S]{1,${range.n}})")

            is RenameDeleteRange.LastN ->
                if (range.n <= 0) null else apply("([\\s\\S]{1,${range.n}})\$")

            is RenameDeleteRange.AfterPositionMN ->
                if (range.m < 0 || range.n <= 0) null
                else apply("(?<=^[\\s\\S]{${range.m}})([\\s\\S]{1,${range.n}})")

            is RenameDeleteRange.BeforeEndPositionMN ->
                if (range.m <= 0 || range.n <= 0) null
                else apply("([\\s\\S]{1,${range.n}})(?=[\\s\\S]{${range.m}}\$)")

            is RenameDeleteRange.AfterStringAll ->
                if (range.text.isEmpty()) null else apply("(${range.text})[\\s\\S]*")

            is RenameDeleteRange.BeforeStringAll ->
                if (range.text.isEmpty()) null else apply("[\\s\\S]*?(${range.text})")

            is RenameDeleteRange.AfterStringN ->
                if (range.text.isEmpty() || range.n <= 0) null
                else apply("(${range.text})([\\s\\S]{1,${range.n}})")
        }
    }

    private fun regexInsert(base: String, position: RenameInsertPosition, text: String): String? {
        // 插入文本中的 $ 需转义为 $$，避免被当作分组引用
        val safeText = text.replace("$", "$$")
        return when (position) {
            // 纯位置类：正则无增益，直接字面处理
            RenameInsertPosition.Start, RenameInsertPosition.End,
            is RenameInsertPosition.AfterNth, is RenameInsertPosition.BeforeLastNth ->
                literalInsert(base, position, text)

            is RenameInsertPosition.AfterString ->
                if (position.text.isEmpty()) null
                else runCatching {
                    Regex("(${position.text})").replace(base, "$1" + safeText)
                }.getOrNull()

            is RenameInsertPosition.BeforeString ->
                if (position.text.isEmpty()) null
                else runCatching {
                    Regex("(${position.text})").replace(base, safeText + "$1")
                }.getOrNull()
        }
    }

    // ---------------- 全新命名 / 自定义正则 ----------------

    /** 全新命名模板。{name}=原主名，{n}=序号。 */
    fun fromTemplate(template: String, base: String, index: Int, startNumber: Int, digits: Int): String? {
        val t = template.trim()
        if (t.isEmpty() || t.any { it in ILLEGAL_NAME_CHARS }) return null
        if (startNumber < 0 || digits !in 1..6) return null
        val seq = String.format(Locale.ROOT, "%0${digits}d", startNumber + index)
        return t.replace("{n}", seq).replace("{name}", base).trim().ifEmpty { null }
    }

    /** 自定义正则替换。pattern 为空或非法、replacement 引用不存在分组 → null。 */
    fun regexReplace(
        base: String,
        pattern: String,
        replacement: String,
        ignoreCase: Boolean,
        firstOnly: Boolean
    ): String? {
        if (pattern.isEmpty()) return null
        if (replacement.any { it in ILLEGAL_NAME_CHARS }) return null   // ★ 新增：堵住 P1-C 漏洞
        val regex = runCatching {
            Regex(pattern, if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet())
        }.getOrNull() ?: return null
        return runCatching {
            if (firstOnly) regex.replaceFirst(base, replacement) else regex.replace(base, replacement)
        }.getOrNull()
    }
}

// ==================== 批量结果计算 ====================

/**
 * names：与 files 一一对应的新名列表（元素可空，跳过项为 null）。
 * 全部失败或批内重名时 names = null。
 * ⚠️ names 元素类型由 String 变为 String?，属破坏性变更，见指南兼容性说明。
 */
data class BatchRenameResult(
    val names: List<String?>?,
    val error: String?,
    val skippedIndices: Set<Int> = emptySet(),
    val skippedReasons: Map<Int, String> = emptyMap()
)

/**
 * 对选中文件统一应用配置，自动保留扩展名（自定义正则的 applyToExtension=true 除外）。
 * 校验链：入口参数合法性 → 结果非空 →（非法字符已在 RenameOps 入口拦截，继承字符放行）→ 批内不重名。
 * startIndex：P2 多规则场景下 NewNaming {n} 序号的全局偏移，单规则路径保持默认 0（行为不变）。
 */
fun buildBatchRenameNames(
    files: List<GuangyaFileItem>,
    config: BatchRenameConfig,
    startIndex: Int = 0
): BatchRenameResult {
    val names = mutableListOf<String?>()
    val skippedReasons = mutableMapOf<Int, String>()

    files.forEachIndexed { index, item ->
        val dot = item.name.lastIndexOf('.')
        val hasExt = dot > 0
        val base = if (hasExt) item.name.substring(0, dot) else item.name
        val ext = if (hasExt) item.name.substring(dot) else ""

        /** ★ 第九轮：变换结果 trim 首尾空格（服务端 rename 拒绝空格首尾名）；trim 后为空返回 ""，走既有「生成结果为空」跳过分支 */
        fun composeName(stem: String?): String? {
            if (stem == null) return null
            val trimmed = stem.trim()
            return if (trimmed.isEmpty()) "" else trimmed + ext
        }

        val newFullName: String? = when (config) {
            is BatchRenameConfig.DeleteReplace ->
                composeName(RenameOps.deleteOrReplace(base, config.range, config.replacement, config.xxAsRegex))

            is BatchRenameConfig.Insert ->
                composeName(RenameOps.insert(base, config.position, config.text, config.markerAsRegex))

            is BatchRenameConfig.NewNaming ->
                composeName(RenameOps.fromTemplate(config.template, base, startIndex + index, config.startNumber, config.digits))

            is BatchRenameConfig.CustomRegex ->
                if (config.applyToExtension) {
                    // 整名替换：同样 trim；trim 后为空命中 isBlank 跳过，null（正则非法）保持 null
                    RenameOps.regexReplace(
                        item.name, config.pattern, config.replacement, config.ignoreCase, config.firstOnly
                    )?.trim()
                } else {
                    composeName(RenameOps.regexReplace(
                        base, config.pattern, config.replacement, config.ignoreCase, config.firstOnly
                    ))
                }
        }

        when {
            newFullName == null ->
                { skippedReasons[index] = "规则参数不合法（N/M/XX/正则输入有误）"; names += null }
            newFullName.isBlank() ->
                { skippedReasons[index] = "生成结果为空"; names += null }
            else -> names += newFullName
            // 非法字符不再整名校验：用户输入已在 RenameOps 入口拦截，
            // 剩余非法字符继承自原文件名（服务端存量数据已含这些字符），原样放行。
        }
    }

    // 全部失败才返回 null
    if (skippedReasons.size == files.size) {
        return BatchRenameResult(
            null, "所有文件均无法重命名，请检查规则参数", skippedReasons.keys, skippedReasons
        )
    }

    // 批内重名：保留 fail-fast（见 3.2 P1-B 思路说明）
    val validNames = names.filterNotNull()
    if (validNames.toSet().size != validNames.size) {
        return BatchRenameResult(
            null, "生成结果存在重名：可用全新命名的 {n} 序号或正则捕获组区分",
            skippedReasons.keys, skippedReasons
        )
    }

    val error = if (skippedReasons.isEmpty()) null
        else "已跳过 ${skippedReasons.size} 个文件（${skippedReasons.values.take(3).joinToString("、")}）"
    return BatchRenameResult(names.toList(), error, skippedReasons.keys, skippedReasons)
}

// ==================== 生成名完整校验（批次 6b，对齐参考实现 validateGuangyaName） ====================

/** Windows 保留名（带或不带扩展名均不可用）。 */
private val WINDOWS_RESERVED_NAMES: Set<String> =
    setOf("CON", "PRN", "AUX", "NUL") +
        (1..9).map { "COM$it" } +
        (1..9).map { "LPT$it" }

/**
 * 校验「新生成的问题名」：返回 null 表示合法，否则返回拒绝原因。
 * 保持第六轮「继承自原名的非法字符放行」决策——本函数只拦新生成名，
 * 服务端存量数据里已有的非法字符（原样保留的文件）不在此列。
 */
fun validateGeneratedName(name: String): String? {
    if (name.isBlank()) return "名称为空"
    if (name.length > 255) return "名称超过 255 字符"
    if (name.startsWith(' ') || name.endsWith(' ')) return "名称不能以空格开头或结尾"
    if (name.startsWith('.') || name.endsWith('.')) return "名称不能以点开头或结尾"
    if (name.contains("..")) return "名称不能包含连续点"
    if (name.any { it.isISOControl() }) return "名称包含控制字符"
    if (name.any { it in RenameOps.ILLEGAL_NAME_CHARS }) return "名称包含非法字符"
    val base = name.substringBeforeLast('.', name).uppercase(Locale.ROOT)
    if (base in WINDOWS_RESERVED_NAMES) return "名称是系统保留名"
    return null
}

/** 重名 auto-suffix：与目录内既有文件撞名时补 " (n)"，返回最终不冲突名（防御上限 1000，极端兜底加用户可辨后缀）。 */
fun dedupeNameAgainst(candidate: String, existingNames: Set<String>): String {
    if (candidate !in existingNames) return candidate
    val ext = candidate.substringAfterLast('.', "")
    val stem = if (ext.isNotEmpty()) candidate.substringBeforeLast('.') else candidate
    var n = 1
    while (n <= 1000) {
        val next = if (ext.isNotEmpty()) "${stem} ($n).$ext" else "$stem ($n)"
        if (next !in existingNames) return next
        n++
    }
    return "${stem}-dup-$n$ext" // 理论上不可达（1000 个冲突名），纯防御
}

// ==================== 多规则批量重命名（P2） ====================

/**
 * 一条重命名规则：绑定一个 BatchRenameConfig + 目标文件匹配条件。
 * matchMode 决定哪些文件会被这条规则处理。
 */
data class RenameRuleEntry(
    val id: Long = nextRuleId(),   // v6：原子自增，避免同毫秒重复
    val config: BatchRenameConfig,
    val matchMode: RuleMatchMode,
    val enabled: Boolean = true
) {
    companion object {
        private val ID = java.util.concurrent.atomic.AtomicLong(0)
        fun nextRuleId(): Long = ID.incrementAndGet()
    }
}

/**
 * 规则匹配模式：
 * - All: 匹配所有选中文件（默认，兼容现有行为）
 * - Contains: 文件名包含指定关键词时匹配
 * - RegexPattern: 文件名匹配正则时匹配
 * - Manual: 用户手动勾选的文件 ID 集合（首版 UI 不暴露，待补文件选择器后开放）
 */
sealed interface RuleMatchMode {
    data object All : RuleMatchMode
    data class Contains(val keyword: String) : RuleMatchMode
    data class RegexPattern(val pattern: String) : RuleMatchMode
    data class Manual(val fileIds: Set<String>) : RuleMatchMode
}

/**
 * 多规则批量重命名结果。
 * skippedFiles 与 unassignedFiles 互斥（v6：attempted 标记保证一个文件最多归入其一）。
 */
data class MultiRuleBatchResult(
    val renamePairs: List<Pair<GuangyaFileItem, String>>,  // (文件, 新名)
    val skippedFiles: List<Pair<GuangyaFileItem, String>>,  // (文件, 跳过原因)
    val unassignedFiles: List<GuangyaFileItem>,             // 未被任何规则尝试匹配的文件
    val errors: List<String>
)

/**
 * 多规则批量重命名：按规则顺序逐条匹配文件并计算新名。
 * 已被某条规则尝试过（无论成败）的文件不会被后续规则重复处理。
 * 合并后做跨规则重名校验，重名则整体失败（重名多为规则设计问题，静默跳过会造成意外覆盖）。
 */
fun buildMultiRuleRenameNames(
    files: List<GuangyaFileItem>,
    rules: List<RenameRuleEntry>
): MultiRuleBatchResult {
    val renamePairs = mutableListOf<Pair<GuangyaFileItem, String>>()
    val skippedFiles = mutableListOf<Pair<GuangyaFileItem, String>>()
    val attempted = mutableSetOf<String>()   // v6：含失败项，保证 skipped/unassigned 互斥
    val errors = mutableListOf<String>()
    var namingOffset = 0                     // v6：NewNaming {n} 序号跨规则接续

    for (rule in rules.filter { it.enabled }) {
        val targets = files.filter { item ->
            item.fileId !in attempted && matchRule(item, rule.matchMode)
        }
        if (targets.isEmpty()) continue

        // NewNaming 序号全局接续：规则 1 编到 05，规则 2 从 06 开始
        val result = buildBatchRenameNames(targets, rule.config, startIndex = namingOffset)
        if (rule.config is BatchRenameConfig.NewNaming) {
            namingOffset += targets.size
        }

        val names = result.names
        if (names == null) {
            errors.add("规则「${describeRule(rule)}」失败：${result.error}")
            // 规则整体失败：这些文件标记为已尝试并计入跳过（v6：同时加入 attempted，
            // 修复 v5 中它们又被重复计入 unassignedFiles 的双重计数问题）
            targets.forEach { target ->
                attempted.add(target.fileId)
                skippedFiles.add(target to "规则失败：${result.error}")
            }
            continue
        }

        targets.zip(names).forEach { (item, name) ->
            attempted.add(item.fileId)       // v6：失败项也标记，防止后续规则重复处理
            if (name != null) {
                renamePairs.add(item to name)
            } else {
                skippedFiles.add(item to "生成失败")
            }
        }
    }

    // v6：跨规则重名校验（各规则内部重名已在 buildBatchRenameNames 中 fail-fast）
    val allNames = renamePairs.map { it.second }
    if (allNames.toSet().size != allNames.size) {
        return MultiRuleBatchResult(
            emptyList(),
            skippedFiles,
            files.filter { it.fileId !in attempted },
            errors + "不同规则生成了相同的新文件名：请调整匹配条件，或为各规则的 {n} 检查起始序号/接续设置"
        )
    }

    val unassigned = files.filter { it.fileId !in attempted }
    return MultiRuleBatchResult(renamePairs, skippedFiles, unassigned, errors)
}

/** 判断文件是否匹配规则的目标条件。 */
private fun matchRule(item: GuangyaFileItem, mode: RuleMatchMode): Boolean = when (mode) {
    is RuleMatchMode.All -> true
    is RuleMatchMode.Contains -> item.name.contains(mode.keyword, ignoreCase = true)
    is RuleMatchMode.RegexPattern -> runCatching {
        Regex(mode.pattern).containsMatchIn(item.name)
    }.getOrDefault(false)
    is RuleMatchMode.Manual -> item.fileId in mode.fileIds
}

/** 规则类型的可读描述（供 UI 展示）。 */
fun describeRule(rule: RenameRuleEntry): String {
    return when (rule.config) {
        is BatchRenameConfig.DeleteReplace -> "删除/替换"
        is BatchRenameConfig.Insert -> "插入"
        is BatchRenameConfig.NewNaming -> "全新命名"
        is BatchRenameConfig.CustomRegex -> "自定义正则"
    }
}

/** 匹配模式的可读描述（供 UI 展示）。 */
fun describeMatchMode(mode: RuleMatchMode): String = when (mode) {
    RuleMatchMode.All -> "全部选中文件"
    is RuleMatchMode.Contains -> "文件名包含「${mode.keyword}」"
    is RuleMatchMode.RegexPattern -> "文件名匹配正则 /${mode.pattern}/"
    is RuleMatchMode.Manual -> "手动指定 ${mode.fileIds.size} 个文件"
}

// ==================== 模板（全操作类型） ====================

/**
 * 批量重命名模板：镜像对话框表单的扁平参数集，JSON 序列化存 SharedPreferences StringSet。
 * opType：0=删除/替换 1=插入 2=全新命名 3=自定义正则。
 */
data class BatchRenameTemplate(
    val id: Long,                    // System.currentTimeMillis()
    val name: String,                // 展示名（保存时自动生成）
    val opType: Int,
    // —— 删除/替换 ——
    val rangeIndex: Int = 0,
    val xxText: String = "",
    val m: Int = 0,
    val n: Int = 0,
    val includeMarker: Boolean = false,
    val replacement: String = "",
    val xxAsRegex: Boolean = false,
    // —— 插入 ——
    val insertIndex: Int = 0,
    val insertText: String = "",
    val insertN: Int = 0,
    val insertMarker: String = "",
    val insertMarkerAsRegex: Boolean = false,
    // —— 全新命名 ——
    val namingTemplate: String = "{name}-{n}",
    val startNumber: Int = 1,
    val digits: Int = 2,
    // —— 自定义正则 ——
    val pattern: String = "",
    val regexReplacement: String = "",
    val ignoreCase: Boolean = false,
    val firstOnly: Boolean = false,
    val applyToExtension: Boolean = false
) {
    fun toJson(): String = JSONObject().apply {
        put("id", id); put("name", name); put("opType", opType)
        put("rangeIndex", rangeIndex); put("xxText", xxText); put("m", m); put("n", n)
        put("includeMarker", includeMarker); put("replacement", replacement); put("xxAsRegex", xxAsRegex)
        put("insertIndex", insertIndex); put("insertText", insertText); put("insertN", insertN)
        put("insertMarker", insertMarker); put("insertMarkerAsRegex", insertMarkerAsRegex)
        put("namingTemplate", namingTemplate); put("startNumber", startNumber); put("digits", digits)
        put("pattern", pattern); put("regexReplacement", regexReplacement)
        put("ignoreCase", ignoreCase); put("firstOnly", firstOnly); put("applyToExtension", applyToExtension)
    }.toString()

    companion object {
        fun fromJson(s: String): BatchRenameTemplate? = runCatching {
            val o = JSONObject(s)
            BatchRenameTemplate(
                id = o.optLong("id"), name = o.optString("name"), opType = o.optInt("opType"),
                rangeIndex = o.optInt("rangeIndex"), xxText = o.optString("xxText"),
                m = o.optInt("m"), n = o.optInt("n"),
                includeMarker = o.optBoolean("includeMarker"), replacement = o.optString("replacement"),
                xxAsRegex = o.optBoolean("xxAsRegex"),
                insertIndex = o.optInt("insertIndex"), insertText = o.optString("insertText"),
                insertN = o.optInt("insertN"), insertMarker = o.optString("insertMarker"),
                insertMarkerAsRegex = o.optBoolean("insertMarkerAsRegex"),
                namingTemplate = o.optString("namingTemplate", "{name}-{n}"),
                startNumber = o.optInt("startNumber", 1), digits = o.optInt("digits", 2),
                pattern = o.optString("pattern"), regexReplacement = o.optString("regexReplacement"),
                ignoreCase = o.optBoolean("ignoreCase"), firstOnly = o.optBoolean("firstOnly"),
                applyToExtension = o.optBoolean("applyToExtension")
            )
        }.getOrNull()
    }
}