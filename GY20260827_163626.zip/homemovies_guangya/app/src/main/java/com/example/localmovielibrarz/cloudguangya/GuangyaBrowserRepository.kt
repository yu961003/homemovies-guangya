package com.example.localmovielibrarz.cloudguangya

import com.example.localmovielibrarz.ui.guangya.dedupeNameAgainst
import com.example.localmovielibrarz.ui.guangya.renameNameKey
import com.example.localmovielibrarz.ui.guangya.validateGeneratedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 光鸭云盘浏览业务编排（镜像 Cloud115Client 薄封装）。 */
class GuangyaBrowserRepository(
    private val apiClient: GuangyaApiClient
) {
    /** parentId="" 为根目录（115 用 Long 类型的 ROOT_CID，光鸭用空串，P2-3）。 */
    suspend fun listFiles(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFiles(parentId)
    }

    /** 列出某目录下的一级子文件夹（离线下载目标文件夹选择）。 */
    suspend fun listFolders(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFolders(parentId)
    }

    /** 全局搜索文件夹（离线下载目标文件夹搜索）。 */
    suspend fun searchFolders(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFolders(keyword)
    }

    /** 需求 2：全局搜索文件+目录（列表页搜索）。 */
    suspend fun searchFiles(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFiles(keyword)
    }

    /**
     * 单批回收（≤50）：提交 + 等终态。供执行器与外部逐批调用。
     * 不加 withContext(Dispatchers.IO)——trashItems/waitTask 内部已通过
     * postUserres → withContext(Dispatchers.IO) 执行，不会阻塞主线程。
     */
    suspend fun trashItemsBatch(batch: List<String>) {
        val taskId = apiClient.trashItems(batch)
        apiClient.waitTask(taskId)
    }

    /** 批量移入回收站：分批提交 delete_file 并等待每批任务终态；部分失败聚合报错。 */
    suspend fun recycleFiles(fileIds: List<String>) {
        if (fileIds.isEmpty()) return
        var ok = 0; var fail = 0; var lastError: String? = null
        fileIds.chunked(50).forEach { batch ->
            runCatching { trashItemsBatch(batch) }.onSuccess { ok += batch.size }
                .onFailure { fail += batch.size; lastError = it.message }
        }
        // 改抛 GuangyaApiException——若抛 IOException，ViewModel 的错误映射
        // （is IOException -> "网络连接失败"）会把业务失败误标为网络问题
        if (fail > 0) throw GuangyaApiException("回收站部分失败：成功 $ok / 失败 $fail" +
            (lastError?.let { "（$it）" } ?: ""))
    }

    /** 批量移动：分批提交并等待终态。 */
    suspend fun moveFiles(fileIds: List<String>, targetParentId: String) {
        if (fileIds.isEmpty()) return
        fileIds.chunked(50).forEach { batch ->
            val taskId = apiClient.moveItems(batch, targetParentId)
            apiClient.waitTask(taskId)
        }
    }

    /** 重命名（同步）。 */
    suspend fun renameFile(fileId: String, newName: String) = apiClient.renameItem(fileId, newName)

    /**
     * 需求 3：批量重命名文件/目录（扩展名由调用方保留）。
     *
     * 第十一轮修复（D-1 拓扑排序 + 环中转 / D-2 失败重试）：
     * - D-1：renames 按依赖拓扑排序（目标名撞后执行项旧名者排到其后）；
     *   环形依赖（A↔B 互换名）先改临时名腾位，再按目标名依次执行。
     * - D-2：主循环结束后，对失败原因含「已存在/重名」的项再重试一轮（外部并发兜底）。
     * - 保留第十轮 A-1（旧名腾出/失败加回）、A-3（autoSuffixed 计数）、C-2（- 开头拦截）。
     */
    suspend fun batchRenameFiles(
        renames: List<Pair<String, String>>,
        parentId: String = ""
    ): BatchRenameResult {
        val succeeded = mutableListOf<Pair<String, String>>()
        val failed = mutableListOf<BatchRenameFailure>()
        var autoSuffixed = 0
        // fileId → 当前名（旧名）；listFiles 失败则退化为无冲突规避（仅靠校验兜底）
        val namesById = if (parentId.isNotBlank()) {
            runCatching { apiClient.listFiles(parentId).associate { it.fileId to it.name } }
                .getOrDefault(emptyMap())
        } else emptyMap()
        val pendingIds = renames.map { it.first }.toSet()
        // ★ A-1 旧名腾出：待改名文件的旧名即将释放，不占坑；
        // 跳过/失败项不会真正改名，其旧名须加回（对齐参考实现 occupancy 语义）
        val renamingOldNames = pendingIds.mapNotNull { namesById[it] }.toSet()
        val existingNames = (namesById.values - renamingOldNames).toMutableSet()

        // ★ D-1：拓扑排序 + 环检测
        val (orderedRenames, ringMembers) = orderRenamesByDependency(renames, namesById)

        // ① 环成员先改到互不冲突的临时名（对齐参考实现 batchRename.ts:403 temporaryName）
        if (ringMembers.isNotEmpty()) {
            val occupiedKeys = mutableSetOf<String>().apply {
                addAll(existingNames.map { it.renameNameKey() })
                addAll(renames.mapNotNull { it.second.renameNameKey() }) // 目标名也占位，防临时名撞目标
            }
            ringMembers.forEach { (fileId, newName) ->
                val oldName = namesById[fileId] ?: return@forEach
                validateGeneratedName(newName)?.let { reason ->
                    failed.add(BatchRenameFailure(fileId, newName, reason))
                    existingNames.add(oldName)
                    return@forEach
                }
                val temp = uniqueTempName(oldName, occupiedKeys)
                runCatching { apiClient.renameItem(fileId, temp) }
                    .onSuccess {
                        occupiedKeys.add(temp.renameNameKey())
                        existingNames.add(temp) // 临时名占位，防后续项撞
                    }
                    .onFailure { error ->
                        existingNames.add(oldName) // 临时名失败 → 旧名未腾出
                        failed.add(BatchRenameFailure(fileId, newName,
                            error.message ?: error::class.java.simpleName))
                    }
            }
            // 环成员临时名化后，按目标名依次执行（此时旧名全部腾出）
        }

        // ② 按 orderedRenames + 环成员目标名 顺序执行 A-1 循环
        val executeQueue = orderedRenames + ringMembers
        executeQueue.forEach { (fileId, newName) ->
            val oldName = namesById[fileId]
            // 跳过已被环阶段计入 failed 的项
            if (failed.any { it.fileId == fileId && it.newName == newName }) return@forEach
            val skip: (String) -> Unit = { reason ->
                oldName?.let { existingNames.add(it) }
                failed.add(BatchRenameFailure(fileId, newName, reason))
            }
            if (fileId.isBlank() || newName.isBlank()) { skip("名称为空"); return@forEach }
            validateGeneratedName(newName)?.let { skip(it); return@forEach }
            val finalName = dedupeNameAgainst(newName, existingNames)
            if (finalName != newName) autoSuffixed++
            runCatching { apiClient.renameItem(fileId, finalName) }
                .onSuccess {
                    existingNames.add(finalName)
                    succeeded.add(fileId to finalName)
                }
                .onFailure { error ->
                    oldName?.let { existingNames.add(it) }
                    failed.add(BatchRenameFailure(fileId, newName,
                        error.message ?: error::class.java.simpleName))
                }
        }

        // ★ D-2：失败项「已存在/重名」全后重试一轮（外部并发兜底）
        val retryables = failed.filter {
            it.reason.contains("已存在") || it.reason.contains("重名")
        }.also { failed.removeAll(it) }
        retryables.forEach { failure ->
            val finalName = dedupeNameAgainst(failure.newName, existingNames)
            if (finalName != failure.newName) autoSuffixed++
            runCatching { apiClient.renameItem(failure.fileId, finalName) }
                .onSuccess {
                    existingNames.add(finalName)
                    succeeded.add(failure.fileId to finalName)
                }
                .onFailure { failed.add(failure) } // 重试仍失败才最终计入
        }

        return BatchRenameResult(succeeded, failed, autoSuffixed)
    }

    /** 解析离线下载链接（磁力链/.torrent/ed2k）。 */
    suspend fun resolveOfflineUrl(url: String) = apiClient.resolveOfflineUrl(url)

    /** 创建云下载任务（离线下载）。 */
    suspend fun createOfflineTask(url: String, parentId: String) = apiClient.createOfflineTask(url, parentId)
}

/** 单条批量重命名失败信息（服务端拒绝原因透传，如「文件名不能以空格开头或结尾」）。 */
data class BatchRenameFailure(
    val fileId: String,
    val newName: String,
    val reason: String
)

/** 批量重命名整体结果：逐条容错，一条被拒不中断队列其余请求。 */
data class BatchRenameResult(
    val succeeded: List<Pair<String, String>>, // (fileId, 实际最终名)
    val failed: List<BatchRenameFailure>,
    val autoSuffixed: Int = 0 // ★ A-3：因撞名被自动加后缀的项数（让用户察觉「静默改名不符预期」）
)

/**
 * D-1：依赖拓扑排序（Kahn 贪心）。
 * 每轮挑出「目标名不占用任何待执行项旧名」的项；剩余无法挑出的即环形依赖（A↔B 互换名）。
 * 返回 (有序执行列表, 环成员)。
 */
internal fun orderRenamesByDependency(
    renames: List<Pair<String, String>>,
    namesById: Map<String, String>
): Pair<List<Pair<String, String>>, List<Pair<String, String>>> {
    val pending = renames.toMutableList()
    val ordered = mutableListOf<Pair<String, String>>()
    while (pending.isNotEmpty()) {
        val pendingOldKeys = pending.mapNotNull { (id, _) -> namesById[id]?.renameNameKey() }.toSet()
        val ready = pending.filter { (_, newName) -> newName.renameNameKey() !in pendingOldKeys }
        if (ready.isEmpty()) return ordered to pending.toList() // 剩余全为环
        ordered.addAll(ready)
        pending.removeAll(ready.toSet())
    }
    return ordered to emptyList()
}

/** D-1 临时名生成：原名 stem + "-tmp-n"，确保不撞 occupiedKeys（n 递增，上限防御）。 */
private fun uniqueTempName(oldName: String, occupiedKeys: MutableSet<String>): String {
    val ext = oldName.substringAfterLast('.', "")
    val stem = if (ext.isNotEmpty()) oldName.substringBeforeLast('.') else oldName
    var n = 1
    while (n <= 1000) {
        val next = if (ext.isNotEmpty()) "${stem}-tmp-$n.$ext" else "$stem-tmp-$n"
        if (next.renameNameKey() !in occupiedKeys) return next
        n++
    }
    return "${stem}-tmp-$n$ext"
}
