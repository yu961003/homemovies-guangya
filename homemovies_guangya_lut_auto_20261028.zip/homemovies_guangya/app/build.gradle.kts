plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

val purgeStaleRoomGeneratedSources by tasks.registering(Delete::class) {
    delete(
        layout.buildDirectory.dir("generated/ksp/debug/java/com/example/localmovielibrarz/data/local"),
        layout.buildDirectory.dir("kspCaches/debug/backups/java/byRounds")
    )
}

android {
    namespace = "com.example.localmovielibrarz"
    compileSdk = 35

    // libmpv JNI 封装层（app/src/main/cpp）用 NDK 编译成 libplayer.so。
    // 显式 pin NDK 版本：不写的话 AGP 会取自身默认版本，CI 与本机可能不一致。
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.example.localmovielibrarz"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "3.2"

        // CMakeLists 只编 JNI 封装层；libmpv.so 本身是外部预编译产物，
        // 由 scripts/fetch-libmpv.sh（或 CI artifact）放进 jniLibs/<abi>/。
        // 找不到 libmpv.so 时 CMake 退化为 stub 版 libplayer.so，
        // 运行期 MpvPlaybackEngine 判定不可用并回退 ExoPlayer——所以这里不需要
        // 条件开关，两种情况都必须能 assemble 成功。
        externalNativeBuild {
            cmake {
                // 用静态 STL：封装层是纯 JNI C 风格代码（CMakeLists 里已 -fno-exceptions
                // -fno-rtti），静态链接可以少打包一个 libc++_shared.so，也不会和
                // libmpv.so 自带的 C++ 运行时在同一个进程里撞符号。
                arguments += listOf("-DANDROID_STL=c++_static")
                cppFlags += listOf("-std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Kotlin 2.3 已移除 kotlinOptions.jvmTarget，改用 compilerOptions DSL。
    // 用全限定名避免 JvmTarget 在 .kts 顶级作用域未解析的问题。
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }
}

// 导出 Room schema（5.6 优化）：追踪数据库 schema 变更历史，便于生成迁移测试
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

tasks.matching { task ->
    task.name in setOf("kspDebugKotlin", "compileDebugKotlin")
}.configureEach {
    dependsOn(purgeStaleRoomGeneratedSources)
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.05.00") // 跟随 Kotlin 2.3 的 Compose 编译器版本
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06") // 光鸭令牌加密存储 (P1-2)
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.zxing:core:3.5.3") // 需求 11：光鸭扫码登录二维码渲染

    implementation("androidx.media3:media3-exoplayer:1.9.1")
    implementation("androidx.media3:media3-ui:1.9.1")
    // 双核心 v5：移除 nextlib-media3ext（minCompileSdk 冲突 / 维护成本高），
    // Exo 软解短板改由 mpv 核心兜底（§5.4）。ExoPlayer 回归原生解码 + 解码器回退。

    implementation("androidx.room:room-ktx:2.8.4") // 升 2.8.4 以兼容 Kotlin 2.3 / KSP 2.3.x（2.6.1 的 KSP 处理器跟不上）
    ksp("androidx.room:room-compiler:2.8.4")

    testImplementation("junit:junit:4.13.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
