# mpv 双核心 · 原生库（libmpv.so / libplayer.so）

`HomeMovie-Guangya` 集成 mpv 需要两个预编译动态库，按 ABI 放入本目录（当前仅打包 `arm64-v8a`）：

```
app/src/main/jniLibs/arm64-v8a/
├── libmpv.so       # mpv 核心（含内置 ffmpeg 软解）
├── libplayer.so    # JNI 桥接层（源码见 app/src/main/jni/）
└── libswscale.so / libswresample / libav* / libpostproc   # JNI 依赖的 ffmpeg 库
```

## 如何生成这些库

它们必须用 NDK 交叉编译。参考项目 `mpv-android` 的构建脚本：

```
cd <mpv-android>/buildscripts
# 先 buildall.sh 编译 mpv + ffmpeg 各 ABI（会下载工具链，耗时较长）
# 然后 ndk-build 用 app/src/main/jni/Android.mk 编译 libplayer.so
```

编译产物（`build/.../jni/arm64-v8a/*.so`）复制到本目录 `arm64-v8a/` 即可。

## 占位说明

- 未放入 .so 前，`MpvPlayerCore` 首次 `System.loadLibrary("mpv")` 会抛 `UnsatisfiedLinkError`。
- 为确保双核心架构当前可构建、且旧 ExoPlayer 播放不受影响：
  - `MpvPlayerCoreImpl.ensureInitialized()` 已在 `runCatching` 内捕获 `UnsatisfiedLinkError`
    （见下方「运行时降级」）。
  - 默认核心仍为 ExoPlayer。
- 若你不编译原生库，请将 `app/build.gradle.kts` 中 mpv 相关源码目录从打包中排除，或保留但确保降级路径可用。

## 运行时降级（推荐实现）

```kotlin
// MpvPlayerCoreImpl.ensureInitialized() 中
if (!runCatching { System.loadLibrary("mpv"); System.loadLibrary("player") }.isSuccess) {
    Log.w(TAG, "mpv 原生库缺失，禁用 mpv 核心")
    throw MpvUnavailableException()
}
```