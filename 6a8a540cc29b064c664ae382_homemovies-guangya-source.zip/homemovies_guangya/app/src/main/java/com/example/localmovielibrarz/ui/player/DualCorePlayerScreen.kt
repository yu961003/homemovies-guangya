package com.example.localmovielibrarz.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrarz.player.core.PlayerCoreType
import com.example.localmovielibrarz.player.core.TrackHint
import com.example.localmovielibrarz.player.core.TrackInfo
import com.example.localmovielibrarz.player.host.PlayerCoreHost
import java.util.Locale

/**
 * 双核心播放器屏幕（v5 §9）。
 *
 * 用 [PlayerCoreHost] 承载 PlayerHost 注入的渲染容器；控制层通过 VM 转发到当前核心。
 * 独立于既有 [PlayerScreen]：默认 Exo 行为不受影响，仅经双核心路由进入。
 */
@Composable
fun DualCorePlayerScreen(
    viewModel: DualCorePlayerViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val host = viewModel.currentHost

    // 播放时常亮（与既有播放页一致）
    DisposableEffect(activity) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // ---------- 渲染容器 / 加载 / 错误 ----------
        when {
            host != null -> {
                PlayerCoreHost(
                    playerHost = host,
                    modifier = Modifier.fillMaxSize()
                )
            }
            uiState.errorMessage != null -> {
                Text(
                    text = uiState.errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
            }
            else -> {
                CircularProgressIndicator(
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(48.dp)
                )
                Text(
                    text = uiState.loadingMessage ?: "正在启动...",
                    color = Color.White.copy(alpha = 0.78f),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(top = 120.dp)
                )
            }
        }

        // ---------- 顶栏 ----------
        Surface(
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "返回",
                        tint = Color.White
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = uiState.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    )
                    uiState.coreType?.let { core ->
                        Text(
                            text = "核心：${core.label()}",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                TrackMenu(
                    enabled = host != null,
                    hasAudio = uiState.tracks.audioTracks.isNotEmpty(),
                    audioTracks = uiState.tracks.audioTracks,
                    hasSubtitle = uiState.tracks.subtitleTracks.isNotEmpty(),
                    subtitleTracks = uiState.tracks.subtitleTracks,
                    onSelectAudio = { viewModel.selectAudioTrack(it) },
                    onDisableAudio = { viewModel.disableAudioTrack() },
                    onSelectSubtitle = { viewModel.selectSubtitleTrack(it) },
                    onDisableSubtitle = { viewModel.selectSubtitleTrack(null, disable = true) }
                )
                Spacer(Modifier.width(8.dp))
                CoreSwitcher(
                    enabled = host != null,
                    canSwitchToMpv = viewModel.canSwitchToMpv,
                    current = uiState.coreType ?: PlayerCoreType.EXOPLAYER,
                    switching = uiState.switchInProgress,
                    onSwitch = { viewModel.switchCore(it) }
                )
            }
        }

        // ---------- 底部控制 ----------
        Surface(
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "${formatTime(uiState.positionMs)} / ${formatTime(uiState.durationMs)}"
                        + if (uiState.buffering) "（缓冲中）" else "",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium
                )
                if (uiState.durationMs > 0L) {
                    Slider(
                        value = uiState.positionMs.toFloat().coerceIn(0f, uiState.durationMs.toFloat()),
                        onValueChange = { viewModel.tempSeek(it.toLong()) },
                        onValueChangeFinished = { viewModel.commitTempSeek() },
                        valueRange = 0f..uiState.durationMs.toFloat(),
                        enabled = host != null,
                        colors = androidx.compose.material3.SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White.copy(alpha = 0.9f),
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ControlIconButton(
                        onClick = { viewModel.seekBy(-10_000L) },
                        icon = { Icon(Icons.Rounded.Replay10, "后退10秒", tint = Color.White) },
                        enabled = host != null
                    )
                    ControlIconButton(
                        onClick = { viewModel.togglePlayPause() },
                        icon = {
                            Icon(
                                if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (uiState.isPlaying) "暂停" else "播放",
                                tint = Color.White
                            )
                        },
                        enabled = host != null
                    )
                    ControlIconButton(
                        onClick = { viewModel.seekBy(10_000L) },
                        icon = { Icon(Icons.Rounded.Forward10, "前进10秒", tint = Color.White) },
                        enabled = host != null
                    )
                    Spacer(Modifier.weight(1f))
                    ControlIconButton(
                        onClick = { viewModel.cycleSpeed() },
                        icon = { Icon(Icons.Rounded.Speed, "倍速", tint = Color.White) },
                        enabled = host != null,
                        label = "x${formatSpeed(viewModel.selectedSpeed)}"
                    )
                }
            }
        }
    }
}

@Composable
private fun ControlIconButton(
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    enabled: Boolean,
    label: String? = null
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, enabled = enabled) {
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { icon() }
        }
        label?.let {
            Text(it, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun CoreSwitcher(
    enabled: Boolean,
    canSwitchToMpv: Boolean,
    current: PlayerCoreType,
    switching: Boolean,
    onSwitch: (PlayerCoreType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (switching) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(20.dp)
            )
        } else {
            IconButton(onClick = { if (enabled) expanded = true }, enabled = enabled) {
                Icon(Icons.Rounded.SwapHoriz, "切换核心", tint = Color.White)
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { Text("ExoPlayer") },
                onClick = {
                    expanded = false
                    if (current != PlayerCoreType.EXOPLAYER) onSwitch(PlayerCoreType.EXOPLAYER)
                }
            )
            DropdownMenuItem(
                text = { Text(if (canSwitchToMpv) "mpv" else "mpv（不可用）") },
                enabled = canSwitchToMpv,
                onClick = {
                    expanded = false
                    if (canSwitchToMpv && current != PlayerCoreType.MPV) onSwitch(PlayerCoreType.MPV)
                }
            )
        }
    }
}

private fun PlayerCoreType.label(): String = when (this) {
    PlayerCoreType.EXOPLAYER -> "ExoPlayer"
    PlayerCoreType.MPV -> "mpv"
}

@Composable
private fun TrackMenu(
    enabled: Boolean,
    hasAudio: Boolean,
    audioTracks: List<TrackInfo>,
    hasSubtitle: Boolean,
    subtitleTracks: List<TrackInfo>,
    onSelectAudio: (TrackHint?) -> Unit,
    onDisableAudio: () -> Unit,
    onSelectSubtitle: (TrackHint?) -> Unit,
    onDisableSubtitle: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var audioDialog by remember { mutableStateOf(false) }
    var subtitleDialog by remember { mutableStateOf(false) }
    IconButton(onClick = { if (enabled) expanded = true }, enabled = enabled) {
        Icon(Icons.Rounded.ClosedCaption, "轨道", tint = Color.White)
    }
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        DropdownMenuItem(
            text = { Text("音轨（${audioTracks.size}）") },
            enabled = hasAudio,
            onClick = { expanded = false; audioDialog = true }
        )
        DropdownMenuItem(
            text = { Text("字幕（${subtitleTracks.size}）") },
            enabled = hasSubtitle,
            onClick = { expanded = false; subtitleDialog = true }
        )
    }
    if (audioDialog) {
        TrackListDialog(
            title = "选择音轨",
            tracks = audioTracks,
            onDismiss = { audioDialog = false },
            onSelect = { hint -> onSelectAudio(hint); audioDialog = false }
        )
    }
    if (subtitleDialog) {
        TrackListDialog(
            title = "选择字幕",
            tracks = subtitleTracks,
            onDismiss = { subtitleDialog = false },
            onSelect = { hint -> onSelectSubtitle(hint); subtitleDialog = false }
        )
    }
}

@Composable
private fun TrackListDialog(
    title: String,
    tracks: List<TrackInfo>,
    onDismiss: () -> Unit,
    onSelect: (TrackHint?) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                tracks.forEach { info ->
                    ListItem(
                        headlineContent = { Text(info.label ?: "轨道", maxLines = 1) },
                        trailingContent = if (info.selected) {
                            { Text("✓", color = Color.White) }
                        } else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(info.hint) }
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } }
    )
}

private fun formatTime(ms: Long): String {
    val absMs = if (ms < 0) -ms else ms
    val totalSec = absMs / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) String.format(Locale.ROOT, "%02d:%02d:%02d", h, m, s)
    else String.format(Locale.ROOT, "%02d:%02d", m, s)
}

private fun formatSpeed(v: Float): String =
    try {
        if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()
    } catch (_: Throwable) {
        v.toString()
    }

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}