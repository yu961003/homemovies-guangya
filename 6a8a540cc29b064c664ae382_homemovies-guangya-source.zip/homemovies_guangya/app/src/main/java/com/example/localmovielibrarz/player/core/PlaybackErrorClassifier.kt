package com.example.localmovielibrarz.player.core

/**
 * 错误分类（§12.3）。
 *
 * 决定错误是可恢复、推荐回退 mpv、还是致命。自动回退仅 Exo → mpv。
 */
object PlaybackErrorClassifier {
    fun classify(type: PlaybackErrorType): ErrorSeverity = when (type) {
        PlaybackErrorType.DECODE_INIT_FAILED,
        PlaybackErrorType.DECODE_FAILED,
        PlaybackErrorType.FORMAT_UNSUPPORTED,
        PlaybackErrorType.CONTAINER_UNSUPPORTED ->
            ErrorSeverity.FALLBACK_RECOMMENDED

        PlaybackErrorType.SOURCE_UNREADABLE ->
            // 本地文件最多一次，网络流不回退（是否回退交给 FallbackController 判定）
            ErrorSeverity.FALLBACK_RECOMMENDED

        PlaybackErrorType.SUBTITLE_UNSUPPORTED ->
            // 优先禁用字幕而非回退
            ErrorSeverity.RECOVERABLE

        PlaybackErrorType.NETWORK_ERROR,
        PlaybackErrorType.TIMEOUT,
        PlaybackErrorType.HTTP_ERROR,
        PlaybackErrorType.DRM_ERROR,
        PlaybackErrorType.FILE_NOT_FOUND,
        PlaybackErrorType.PERMISSION_DENIED,
        PlaybackErrorType.USER_CANCELED ->
            ErrorSeverity.FATAL

        PlaybackErrorType.UNKNOWN ->
            ErrorSeverity.RECOVERABLE
    }

    fun classify(error: PlaybackError): ErrorSeverity = classify(error.type)
}

/**
 * 是否「允许」自动回退 mpv（§12.2）。
 *
 * @param isNetwork 该请求是否为网络流；网络流仅限解码/格式类，本地文件允许 SOURCE_UNREADABLE / UNKNOWN 谨慎回退一次。
 */
fun shouldFallbackToMpv(errorType: PlaybackErrorType, isNetwork: Boolean): Boolean = when (errorType) {
    PlaybackErrorType.DECODE_INIT_FAILED,
    PlaybackErrorType.DECODE_FAILED,
    PlaybackErrorType.FORMAT_UNSUPPORTED,
    PlaybackErrorType.CONTAINER_UNSUPPORTED -> true

    PlaybackErrorType.SOURCE_UNREADABLE,
    PlaybackErrorType.UNKNOWN -> !isNetwork // 本地最多一次，网络不回退

    else -> false
}