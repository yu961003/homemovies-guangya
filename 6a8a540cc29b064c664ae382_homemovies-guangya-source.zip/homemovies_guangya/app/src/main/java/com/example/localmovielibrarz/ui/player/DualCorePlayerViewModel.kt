package com.example.localmovielibrarz.ui.player

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.data.repository.DirectLinkRepository
import com.example.localmovielibrarz.data.repository.GuangyaDirectLinkResolver
import com.example.localmovielibrarz.data.repository.PlaybackProgressRepository
import com.example.localmovielibrarz.playback.PlaybackRequest
import com.example.localmovielibrarz.playback.PlaybackResolver
import com.example.localmovielibrarz.player.core.PlaybackError
import com.example.localmovielibrarz.player.core.PlaybackState
import com.example.localmovielibrarz.player.core.PlayerCoreLauncher
import com.example.localmovielibrarz.player.core.PlayerCoreListener
import com.example.localmovielibrarz.player.core.PlayerCoreType
import com.example.localmovielibrarz.player.core.TrackModel
import com.example.localmovielibrarz.player.core.TrackHint
import com.example.localmovielibrarz.player.core.TrackSelection
import com.example.localmovielibrarz.player.core.TrackType
import com.example.localmovielibrarz.player.host.PlayerHost
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * 双核心播放器专用 ViewModel（v5 §4 / §10.4）。
 *
 * 独立于既有 [PlayerViewModel]：默认 Exo 播放路径完全不变（回滚保证）。
 * 本 VM 走 PlayerCoreLauncher + PlayerHost + PlayerCoreHost 组合。
 */
class DualCorePlayerViewModel(
    application: Application,
    private val videoUri: Uri,
    private val title: String,
    private val fileName: String,
    directLinkRepository: DirectLinkRepository,
    guangyaDirectLinkResolver: GuangyaDirectLinkResolver,
    private val settingsRepository: AppSettingsRepository,
    private val playbackProgressRepository: PlaybackProgressRepository
) : AndroidViewModel(application) {

    private val launcher = PlayerCoreLauncher(application, settingsRepository)
    private val resolver = PlaybackResolver(
        application.contentResolver,
        directLinkRepository,
        guangyaDirectLinkResolver
    )
    private val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f, 4.0f)
    private var speedIndex = 1

    @Volatile
    private var host: PlayerHost? = null

    private val _uiState = MutableStateFlow(
        DualCorePlayerUiState(
            isLoading = true,
            loadingMessage = "正在解析播放地址...",
            title = title.ifBlank { "Movie" }
        )
    )
    val uiState: StateFlow<DualCorePlayerUiState> = _uiState

    val currentHost: PlayerHost? get() = host

    /** mpv 是否可用（原生库缺失时为 false，此时只能切到 Exo）。 */
    val canSwitchToMpv: Boolean get() = launcher.isMpvAvailable()

    private val coreListener = object : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) {
            _uiState.update { it.copy(state = state, isPlaying = state == PlaybackState.PLAYING) }
        }
        override fun onPositionChanged(positionMs: Long, durationMs: Long) {
            _uiState.update { s ->
                s.copy(
                    positionMs = positionMs.coerceAtLeast(0L),
                    durationMs = durationMs.coerceAtLeast(0L)
                )
            }
        }
        override fun onVideoSizeChanged(width: Int, height: Int) {}
        override fun onTracksChanged(tracks: TrackModel) {
            _uiState.update { it.copy(tracks = tracks) }
        }
        override fun onError(error: PlaybackError) {
            // 自动回退已由 PlayerHost 内部处理（§12.4）；这里仅展示残余错误
            _uiState.update { it.copy(errorMessage = error.message ?: error.type.name) }
        }
        override fun onBufferingChanged(buffering: Boolean) {
            _uiState.update { it.copy(buffering = buffering) }
        }
        override fun onPlaybackEnded() {
            _uiState.update { it.copy(isPlaying = false) }
        }
    }

    private val switchCallback: (PlayerHost.SwitchState) -> Unit = { state ->
        _uiState.update { it.copy(switchInProgress = state != PlayerHost.SwitchState.IDLE) }
    }

    init {
        viewModelScope.launch {
            resolveLegacy()?.let { legacy ->
                val resume = playbackProgressRepository
                    .getResumePosition(videoUri.toString())
                    .takeIf { it > 0L }
                val (request, coreType) = launcher.toPlaybackRequest(legacy, startPositionMs = resume)
                val h = launcher.buildHost(coreListener).apply {
                    setSwitchCallback(switchCallback)
                }
                host = h
                _uiState.value = DualCorePlayerUiState(
                    title = (legacy.title?.takeIf { it.isNotBlank() } ?: title).ifBlank { "Movie" },
                    coreType = coreType,
                    state = PlaybackState.PREPARING
                )
                h.play(request, coreType)
                pollProgress()
            } ?: run {
                _uiState.value = DualCorePlayerUiState(
                    title = title.ifBlank { "Movie" },
                    errorMessage = "解析播放地址失败"
                )
            }
        }
    }

    private suspend fun resolveLegacy(): PlaybackRequest? =
        try {
            withTimeout(30_000L) {
                resolver.resolve(videoUri.toString(), title, fileName, forceRefresh = false)
                    .getOrThrow()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            null
        }

    private suspend fun pollProgress() {
        while (true) {
            val h = host ?: return
            delay(if (_uiState.value.durationMs <= 0L) 250L else 600L)
            val snap = runCatching { h.getSnapshot() }.getOrNull() ?: continue
            _uiState.update { s ->
                s.copy(
                    positionMs = snap.positionMs.coerceAtLeast(0L),
                    durationMs = if (snap.durationMs > 0L) snap.durationMs else s.durationMs,
                    isPlaying = snap.wasPlaying,
                    coreType = h.currentCoreType ?: s.coreType
                )
            }
        }
    }

    // ---------------- 控制转发 ----------------

    fun togglePlayPause() { host?.togglePlay() }
    fun seekTo(positionMs: Long) { host?.seekTo(positionMs) }
    fun seekBy(deltaMs: Long) {
        host?.seekBy(deltaMs)
        _uiState.update { s -> s.copy(positionMs = (s.positionMs + deltaMs).coerceAtLeast(0L)) }
    }
    private var pendingSeekMs: Long? = null

    /** 拖动进度条时的临时位置（仅更新 UI，不真正 seek）。 */
    fun tempSeek(positionMs: Long) {
        pendingSeekMs = positionMs
        _uiState.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    /** 拖动结束：提交实际 seek。 */
    fun commitTempSeek() {
        val target = pendingSeekMs
        pendingSeekMs = null
        if (target != null) host?.seekTo(target)
    }
    fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speeds.size
        host?.setSpeed(speeds[speedIndex])
    }
    val selectedSpeed: Float get() = speeds[speedIndex]

    fun switchCore(target: PlayerCoreType, onDone: (Boolean) -> Unit = {}) {
        host?.switchCore(target) { r -> onDone(r.isSuccess) }
    }

    // ---------------- 轨道选择（§6.10 / Phase 7 对齐） ----------------

    fun selectAudioTrack(hint: TrackHint?) {
        host?.selectTrack(TrackSelection(TrackType.AUDIO, hint))
    }

    fun disableAudioTrack() {
        host?.selectTrack(TrackSelection(TrackType.AUDIO, hint = null, disable = true))
    }

    fun selectSubtitleTrack(hint: TrackHint?, disable: Boolean = false) {
        host?.selectTrack(TrackSelection(TrackType.SUBTITLE, hint, disable = disable))
    }

    companion object {
        fun factory(
            application: Application,
            videoUri: Uri,
            title: String,
            fileName: String,
            directLinkRepository: DirectLinkRepository,
            guangyaDirectLinkResolver: GuangyaDirectLinkResolver,
            settingsRepository: AppSettingsRepository,
            playbackProgressRepository: PlaybackProgressRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return DualCorePlayerViewModel(
                    application = application,
                    videoUri = videoUri,
                    title = title,
                    fileName = fileName,
                    directLinkRepository = directLinkRepository,
                    guangyaDirectLinkResolver = guangyaDirectLinkResolver,
                    settingsRepository = settingsRepository,
                    playbackProgressRepository = playbackProgressRepository
                ) as T
            }
        }
    }
}

/** 双核心播放 UI 状态容器。 */
data class DualCorePlayerUiState(
    val isLoading: Boolean = false,
    val loadingMessage: String? = null,
    val title: String = "Movie",
    val coreType: PlayerCoreType? = null,
    val state: PlaybackState = PlaybackState.IDLE,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val errorMessage: String? = null,
    val switchInProgress: Boolean = false,
    val tracks: TrackModel = TrackModel.EMPTY
)