package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import `is`.xyz.mpv.MPVLib

/**
 * 精简版 mpv SurfaceView（§8.2 / §9.3）。
 *
 * 移植自 mpv-android 的 BaseMPVView，仅保留把画面画到屏幕所需的核心逻辑。
 * 生命周期：
 *  - [initialize] 在首次显示前调用，初始化 libmpv 并注册 Surface 回调。
 *  - [destroy] 在移除视图 / 释放核心前调用，确保 detachSurface 后再销毁。
 *  - Compose 中由 MpvPlayerCore 在 AndroidView onRelease / DisposableEffect 中调用。
 */
abstract class BaseMpvView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    private var filePath: String? = null

    /**
     * 初始化 libmpv。
     * @param configDir mpv 配置目录（通常 filesDir.path）
     * @param cacheDir 缓存目录（gpu-shader 等）
     */
    fun initialize(configDir: String, cacheDir: String) {
        MPVLib.create(context.applicationContext)

        MPVLib.setOptionString("config", "yes")
        MPVLib.setOptionString("config-dir", configDir)
        for (opt in arrayOf("gpu-shader-cache-dir", "icc-cache-dir"))
            MPVLib.setOptionString(opt, cacheDir)

        initOptions()
        MPVLib.init()

        postInitOptions()
        MPVLib.setOptionString("force-window", "no")
        MPVLib.setOptionString("idle", "once")

        holder.addCallback(this)
        observeProperties()
    }

    fun destroy() {
        holder.removeCallback(this)
        MPVLib.destroy()
    }

    protected abstract fun initOptions()
    protected abstract fun postInitOptions()
    protected abstract fun observeProperties()

    /** 设置首个要播放的文件，待播放器就绪后触发。 */
    fun playFile(filePath: String) {
        this.filePath = filePath
    }

    private var voInUse: String = "gpu"

    fun setVo(vo: String) {
        voInUse = vo
        MPVLib.setOptionString("vo", vo)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        MPVLib.setPropertyString("android-surface-size", "${width}x$height")
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.d(TAG, "attaching surface")
        MPVLib.attachSurface(holder.surface)
        MPVLib.setOptionString("force-window", "yes")

        filePath?.let {
            MPVLib.command(arrayOf("loadfile", it))
            filePath = null
        } ?: MPVLib.setPropertyString("vo", voInUse)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.d(TAG, "detaching surface")
        MPVLib.setPropertyString("vo", "null")
        MPVLib.setPropertyString("force-window", "no")
        MPVLib.detachSurface()
    }

    private companion object {
        const val TAG = "MpvView"
    }
}