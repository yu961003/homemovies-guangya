package com.example.localmovielibrarz.player.core

import android.content.Context
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.player.host.PlayerHost

/**
 * 双核心播放器启动/接入层（§10.4 / §10.5）。
 *
 * 将现有 [com.example.localmovielibrarz.playback.PlaybackRequest]（来自 PlaybackResolver）转换为核心统一的
 * [PlaybackRequest]，结合用户设置决定默认核心与是否允许自动回退，并构建 [PlayerHost]。
 *
 * 原则：
 *  - 双核心总开关关闭时，强制走 ExoPlayer 并禁用 mpv（行为与改动前完全一致，§17.2 回滚策略）。
 *  - 默认核心仍为 ExoPlayer（§10.1），仅本地怪格式 / 显式 FORCE_MPV 才倾向 mpv。
 *  - 自动回退仅 Exo → mpv，且仅在开关开启时生效。
 */
class PlayerCoreLauncher(
    private val context: Context,
    private val settings: AppSettingsRepository
) {
    private val registry = PlayerCoreRegistry(context.applicationContext)
    private val fallbackController = FallbackController()

    /** 双核心功能是否启用（内置总开关，默认开启，见 \u00a717.2 可整体回滚到纯 Exo）。 */
    fun isDualCoreEnabled(): Boolean = settings.isDualCoreEnabled()

    /** mpv 是否实际可用（依赖原生库，缺失则自动退化到 Exo）。 */
    fun isMpvAvailable(): Boolean = registry.mpvAvailable

    /**
     * 将 legacy PlaybackResolver 输出转换为核心统一的 [PlaybackRequest]。
     *
     * @param legacy 现有 PlaybackResolver 解析结果（此处不改动其实现，§10.4）
     * @param startPositionMs 续播 / 快照恢复位置
     * @param externalSubtitle 外挂字幕
     * @param preferredCore 用户在本会话显式选择的核心（none = 跟随默认核心）
     */
    fun toPlaybackRequest(
        legacy: com.example.localmovielibrarz.playback.PlaybackRequest,
        startPositionMs: Long? = null,
        externalSubtitle: com.example.localmovielibrarz.subtitle.LocalSubtitleFile? = null,
        preferredCore: PlayerCoreType? = null
    ): Pair<PlaybackRequest, PlayerCoreType> {
        val base = PlaybackRequestMapper.fromLegacy(legacy, startPositionMs, externalSubtitle)

        var policy = FallbackPolicy.AUTO
        var request = base
        when (preferredCore) {
            PlayerCoreType.MPV -> { policy = FallbackPolicy.FORCE_MPV }
            PlayerCoreType.EXOPLAYER -> { policy = FallbackPolicy.FORCE_EXOPLAYER }
            null -> Unit
        }
        if (!settings.isAutoFallbackEnabled()) policy = FallbackPolicy.DISABLED

        request = request.copy(fallbackPolicy = policy)

        val coreType = resolveInitialCore(request, preferredCore)
        return request to coreType
    }

    /**
     * 解析本会话初始核心（§10.3 / §10.4）。
     *
     * 双核心关闭 → ExoPlayer；显式 FORCE_* → 对应核心；否则结合用户【默认播放核心】设置
     * （exoplayer/mpv/ask/smart）与智能路由。决策顺序：用户显式选择 > fallbackPolicy >
     * 默认核心设置 > 智能路由。
     */
    fun resolveInitialCore(
        request: PlaybackRequest,
        requestedCore: PlayerCoreType? = null
    ): PlayerCoreType {
        if (!isDualCoreEnabled()) return PlayerCoreType.EXOPLAYER

        val typed = when (requestedCore) {
            PlayerCoreType.MPV -> request.copy(fallbackPolicy = FallbackPolicy.FORCE_MPV)
            PlayerCoreType.EXOPLAYER -> request.copy(fallbackPolicy = FallbackPolicy.FORCE_EXOPLAYER)
            null -> request
        }

        // 用户持久化的默认播放核心：mpv 显式偏好（可用时）；exoplayer 显式偏好；ask/smart → 智能路由。
        val defaultCore = when (settings.getDefaultPlayerCore()) {
            "mpv" -> PlayerCoreType.MPV.takeIf { registry.isCoreAvailable(PlayerCoreType.MPV) }
            else -> null // exoplayer / ask / smart 均交给智能路由
        }

        val resolved = registry.resolveDefaultCore(
            typed,
            requestedCore ?: defaultCore,
            preferMpvForComplexLocal = settings.isSmartCoreRoutingEnabled()
        )
        return if (registry.isCoreAvailable(resolved)) resolved else PlayerCoreType.EXOPLAYER
    }

    /**
     * 构建 [PlayerHost]（含容器注入、核心切换、自动回退连线）。
     *
     * host 内部在错误回调时自动评估 Exo → mpv 回退（\u00a712.4），同一会话最多一次。
     */
    fun buildHost(listener: PlayerCoreListener? = null): PlayerHost =
        PlayerHost(context.applicationContext, registry, fallbackController, listener)
}