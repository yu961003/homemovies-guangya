package com.example.localmovielibrarz.player.core.exo

import android.content.Context
import android.net.Uri
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.localmovielibrarz.player.core.*
import com.example.localmovielibrarz.playback.DEFAULT_USER_AGENT

/**
 * ExoPlayer 核心实现（§7）。
 *
 * 复用既有 ExoPlayer.Builder 创建逻辑，但移除 nextlib（§5.1/5.4）：使用原生
 * DefaultRenderersFactory + setEnableDecoderFallback(true)。
 * 所有 PlayerCore 调用顺序化到专用 CoreExecutor，避免与 UI 线程并发冲突。
 */
@OptIn(UnstableApi::class)
class ExoPlayerCoreImpl(context: Context) : ExoPlayerCore {

    @Volatile
    private var applicationContext: Context = context.applicationContext

    private val executor = CoreExecutor("exo").apply {
        setErrorHandler { e ->
            android.util.Log.e(TAG, "ExoPlayerCore executor error", e)
        }
        start()
    }

    @Volatile
    private var player: ExoPlayer? = null

    @Volatile
    private var request: PlaybackRequest? = null

    @Volatile
    private var cachedTracks: TrackModel = TrackModel.EMPTY

    @Volatile
    private var surfaceView: SurfaceHolderView? = null

    @Volatile
    override var playbackState: PlaybackState = PlaybackState.IDLE
        private set

    @Volatile
    private var listener: PlayerCoreListener? = null

    private val positionPusher = object : Thread("exo-position-pusher") {
        override fun run() {
            while (!isInterrupted) {
                runCatching {
                    Thread.sleep(500)
                    val exo = player ?: continue
                    val pos = exo.currentPosition.coerceAtLeast(0L)
                    val dur = exo.duration.coerceAtLeast(0L)
                    if (exo.isPlaying || dur > 0L) {
                        listener?.onPositionChanged(pos, dur)
                    }
                }
            }
        }
    }.also { it.isDaemon = true }

    init {
        positionPusher.start()
    }

    override val type: PlayerCoreType = PlayerCoreType.EXOPLAYER

    override val staticCapabilities: Set<PlayerCapability> = setOf(
        PlayerCapability.ADAPTIVE_STREAM,
        PlayerCapability.DRM,
        PlayerCapability.SUBTITLE_DELAY
    )

    override fun supportsCapability(capability: PlayerCapability): Boolean =
        capability in staticCapabilities

    // ---------------- 视图 ----------------

    override fun getOrCreateView(context: Context): View =
        surfaceView ?: SurfaceHolderView(context.applicationContext).also { surfaceView = it }

    override fun setListener(listener: PlayerCoreListener?) {
        this.listener = listener
    }

    override fun removeListener(listener: PlayerCoreListener) {
        if (this.listener === listener) this.listener = null
    }

    // ---------------- 生命周期 ----------------

    override fun load(request: PlaybackRequest) {
        executor.execute {
            this.request = request
            val exo = ensurePlayer()
            val mediaItem = createMediaItem(request)
            val start = request.startPositionMs ?: 0L
            publishState(PlaybackState.PREPARING)
            exo.setMediaItem(mediaItem, start.coerceAtLeast(0L))
            exo.prepare()
            if (request.autoplay) exo.playWhenReady = true
        }
    }

    override fun play() {
        executor.post { player?.play() }
    }

    override fun pause() {
        executor.post { player?.pause() }
    }

    override fun togglePlay() {
        executor.execute {
            player?.playWhenReady = !(player?.playWhenReady ?: false)
        }
    }

    override fun stop() {
        executor.execute {
            player?.let { if (it.playbackState != Player.STATE_IDLE) it.stop() }
        }
    }

    override fun release() {
        executor.execute {
            player?.release()
            player = null
            surfaceView = null
        }
        executor.shutdown()
        positionPusher.interrupt()
    }

    // ---------------- 控制 ----------------

    override fun seekTo(positionMs: Long) {
        executor.execute { player?.seekTo(positionMs.coerceAtLeast(0L)) }
    }

    override fun seekBy(deltaMs: Long) {
        executor.execute {
            player?.let {
                it.seekTo((it.currentPosition.coerceAtLeast(0L) + deltaMs).coerceAtLeast(0L))
            }
        }
    }

    override fun setSpeed(speed: Float) {
        executor.execute { player?.setPlaybackSpeed(speed.coerceIn(0.25f, 8f)) }
    }

    override fun setVolume(volume: Float) {
        executor.execute { player?.volume = volume.coerceIn(0f, 1f) }
    }

    override fun setMuted(muted: Boolean) {
        executor.execute { player?.volume = if (muted) 0f else 1f }
    }

    // ---------------- 轨道 ----------------

    override fun getTracks(): TrackModel = cachedTracks

    override fun selectTrack(selection: TrackSelection) {
        executor.execute {
            val exo = player ?: return@execute
            if (selection.disable) {
                // media3 无按类型清空 override 的公开 API，退化为清空全部 override 还原自动选择
                exo.setTrackSelectionParameters(
                    exo.trackSelectionParameters.buildUpon().clearOverrides().build()
                )
                return@execute
            }
            val params = exo.trackSelectionParameters.buildUpon()
            val hint = selection.hint ?: return@execute
            val track = exo.currentTracks.groups.firstOrNull { g ->
                groupMatches(g, selection.type, hint)
            } ?: return@execute
            val index = hint.exoTrackIndex?.takeIf { it >= 0 } ?: 0
            exo.setTrackSelectionParameters(
                params.setOverrideForType(TrackSelectionOverride(track.mediaTrackGroup, index)).build()
            )
        }
    }

    private fun groupMatches(group: Tracks.Group, type: TrackType, hint: TrackHint): Boolean {
        val typeOk = when (type) {
            TrackType.AUDIO -> group.type == C.TRACK_TYPE_AUDIO
            TrackType.VIDEO -> group.type == C.TRACK_TYPE_VIDEO
            TrackType.SUBTITLE -> group.type == C.TRACK_TYPE_TEXT
        }
        if (!typeOk) return false
        val format = runCatching { group.getTrackFormat(0) }.getOrNull() ?: return true
        return hint.language == null || format.language == hint.language
    }

    // ---------------- 快照 ----------------

    override fun getSnapshot(): PlaybackSnapshot {
        var positionMs = 0L
        var durationMs = 0L
        var speed = 1f
        var wasPlaying = false
        var volume = 1f
        executor.execute {
            player?.let {
                positionMs = it.currentPosition.coerceAtLeast(0L)
                durationMs = it.duration.coerceAtLeast(0L)
                speed = it.playbackParameters.speed
                wasPlaying = it.isPlaying
                volume = it.volume
            }
        }
        val req = request
        return PlaybackSnapshot(
            request = req ?: PlaybackRequest(uri = Uri.EMPTY, sourceType = SourceType.UNKNOWN),
            coreType = type,
            positionMs = positionMs,
            durationMs = durationMs,
            speed = speed,
            wasPlaying = wasPlaying,
            volume = volume,
            muted = volume == 0f,
            audioTrackHint = req?.audioTrackHint,
            subtitleTrackHints = req?.subtitleTrackHints ?: emptyList(),
            subtitleDelayMs = null,
            audioDelayMs = null,
            fallbackUsed = false,
            lastError = null,
            createdAt = System.currentTimeMillis()
        )
    }

    override fun getExoPlayer(): Any = player ?: ensurePlayer()

    @Synchronized
    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val headers = request?.headers.orEmpty()
        val userAgent = headers["User-Agent"] ?: DEFAULT_USER_AGENT
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setDefaultRequestProperties(headers)
            .setAllowCrossProtocolRedirects(true)
        val dataSourceFactory = DefaultDataSource.Factory(applicationContext, httpDataSourceFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 2_500, 5_000)
            .build()

        // 移除 nextlib，使用原生渲染器 + 使能解码器回退（§5.4）
        val renderersFactory = DefaultRenderersFactory(applicationContext)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val exo: ExoPlayer = ExoPlayer.Builder(applicationContext)
            .setRenderersFactory(renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(10_000L)
            .setSeekForwardIncrementMs(10_000L)
            .build()

        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_ALL)
                .build(),
            true
        )

        surfaceView?.let {
            exo.setVideoSurfaceView(it)
        }

        exo.addListener(playerListener)
        player = exo
        return exo
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            val state = when (playbackState) {
                Player.STATE_IDLE -> PlaybackState.IDLE
                Player.STATE_BUFFERING -> PlaybackState.BUFFERING
                Player.STATE_READY -> PlaybackState.READY
                Player.STATE_ENDED -> PlaybackState.ENDED
                else -> PlaybackState.IDLE
            }
            publishBuffering()
            publishState(if (state == PlaybackState.READY && player?.isPlaying == true) PlaybackState.PLAYING else state)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                listener?.onPlaybackStateChanged(PlaybackState.PLAYING)
            } else if (player?.playbackState == Player.STATE_READY) {
                listener?.onPlaybackStateChanged(PlaybackState.PAUSED)
            }
            listener?.onBufferingChanged(player?.playbackState == Player.STATE_BUFFERING)
            publishBuffering()
        }

        private fun publishBuffering() {
            listener?.onBufferingChanged(player?.playbackState == Player.STATE_BUFFERING)
        }

        override fun onTracksChanged(tracks: Tracks) {
            cachedTracks = mapTracks(tracks)
            listener?.onTracksChanged(cachedTracks)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            listener?.onVideoSizeChanged(videoSize.width, videoSize.height)
        }

        override fun onPlayerError(error: PlaybackException) {
            val mapped = ExoErrorMapper.mapError(error)
            listener?.onError(mapped)
        }

        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            listener?.onPositionChanged(
                newPosition.positionMs.coerceAtLeast(0L),
                player?.duration?.coerceAtLeast(0L) ?: 0L
            )
        }

        override fun onRenderedFirstFrame() {
            listener?.onVideoSizeChanged(
                player?.videoSize?.width ?: 0,
                player?.videoSize?.height ?: 0
            )
        }
    }

    private fun publishState(state: PlaybackState) {
        playbackState = state
        listener?.onPlaybackStateChanged(state)
    }

    private fun createMediaItem(request: PlaybackRequest): MediaItem {
        val builder = MediaItem.Builder().setUri(request.uri)
        if (request.subtitleSources.isNotEmpty()) {
            val configs = request.subtitleSources.map { src ->
                MediaItem.SubtitleConfiguration.Builder(src.uri)
                    .setMimeType(src.mimeType ?: defaultSubMime(src))
                    .setLanguage(src.language ?: "zh")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
            }
            builder.setSubtitleConfigurations(configs)
        }
        return builder.build()
    }

    private fun defaultSubMime(src: SubtitleSource): String {
        val ext = src.uri.path?.substringAfterLast('.', "").orEmpty().lowercase()
        return when (ext) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun mapTracks(tracks: Tracks): TrackModel {
        val video = mutableListOf<TrackInfo>()
        val audio = mutableListOf<TrackInfo>()
        val sub = mutableListOf<TrackInfo>()
        tracks.groups.forEachIndexed { groupIndex, group ->
            val type = when (group.type) {
                C.TRACK_TYPE_VIDEO -> TrackType.VIDEO
                C.TRACK_TYPE_AUDIO -> TrackType.AUDIO
                C.TRACK_TYPE_TEXT -> TrackType.SUBTITLE
                else -> null
            } ?: return@forEachIndexed
            val format = runCatching { group.getTrackFormat(0) }.getOrNull()
            val hint = TrackHint(
                type = type,
                exoTrackGroupIndex = groupIndex,
                exoTrackIndex = 0,
                language = format?.language,
                title = format?.label,
                mimeType = format?.sampleMimeType,
                channels = format?.channelCount,
                isDefault = format?.selectionFlags?.and(C.SELECTION_FLAG_DEFAULT) != 0,
                isForced = format?.selectionFlags?.and(C.SELECTION_FLAG_FORCED) != 0
            )
            val label = buildString {
                append(format?.id ?: "轨道")
                format?.language?.let { append(" · ").append(it) }
                format?.label?.let { append(" · ").append(it) }
            }
            val info = TrackInfo(hint, label, group.isSelected, group.isSupported)
            when (type) {
                TrackType.VIDEO -> video.add(info)
                TrackType.AUDIO -> audio.add(info)
                TrackType.SUBTITLE -> sub.add(info)
                else -> Unit
            }
        }
        return TrackModel(video, audio, sub)
    }

    companion object {
        private const val TAG = "ExoPlayerCore"
    }
}

/** 简单 SurfaceView 容器，作为 Exo 渲染目标。 */
private class SurfaceHolderView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    init {
        holder.addCallback(this)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {}
}