package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_DOUBLE
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_NONE
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_FLAG
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_INT64
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_STRING
import com.example.localmovielibrarz.player.core.TrackType

/**
 * 具体 mpv 视图（§8.6 默认值）。
 *
 * 硬解优先（mediacodec,mediacodec-copy），vo=gpu，覆盖手机默认值。
 */
open class MpvView(context: Context) : BaseMpvView(context) {

    private val tracksMap: MutableMap<String, MutableList<Track>> = linkedMapOf(
        "audio" to mutableListOf(),
        "video" to mutableListOf(),
        "sub" to mutableListOf()
    )

    override fun initOptions() {
        MPVLib.setOptionString("profile", "fast")
        setVo("gpu")
        MPVLib.setOptionString("hwdec", HWDECS)
        MPVLib.setOptionString("hwdec-codecs", "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1")
        MPVLib.setOptionString("ao", "audiotrack,opensles")
        MPVLib.setOptionString("audio-set-media-role", "yes")
        MPVLib.setOptionString("tls-verify", "yes")
        MPVLib.setOptionString("input-default-bindings", "yes")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("opengl-es", "yes")
        // 限制 demuxer 缓存，适配移动端内存
        MPVLib.setOptionString("demuxer-max-bytes", "${64 * 1024 * 1024}")
        MPVLib.setOptionString("demuxer-max-back-bytes", "${64 * 1024 * 1024}")
        MPVLib.setOptionString("save-position-on-quit", "no")
        MPVLib.setOptionString("keep-open", "yes")
    }

    override fun postInitOptions() {
        // 本处可在 init 后设置不可在 init 前设置的选项
    }

    override fun observeProperties() {
        data class Property(val name: String, val format: Int = MPV_FORMAT_NONE)
        val p = arrayOf(
            Property("time-pos", MPV_FORMAT_INT64),
            Property("duration", MPV_FORMAT_DOUBLE),
            Property("pause", MPV_FORMAT_FLAG),
            Property("paused-for-cache", MPV_FORMAT_FLAG),
            Property("speed", MPV_FORMAT_STRING),
            Property("track-list"),
            Property("current-tracks/video/image"),
            Property("media-title", MPV_FORMAT_STRING),
            Property("hwdec-current"),
            Property("mute", MPV_FORMAT_FLAG),
            Property("current-tracks/audio/selected")
        )
        for ((name, format) in p) MPVLib.observeProperty(name, format)
    }

    /** 从 mpv track-list 重新加载轨道，填充 [TracksMap]。 */
    fun loadTracks() {
        for (list in tracksMap.values) {
            list.clear()
            list.add(Track(-1, "关闭"))
        }
        val count = MPVLib.getPropertyInt("track-list/count") ?: 0
        for (i in 0 until count) {
            val type = MPVLib.getPropertyString("track-list/$i/type") ?: continue
            val list = tracksMap[type] ?: continue
            val id = MPVLib.getPropertyInt("track-list/$i/id") ?: continue
            val lang = MPVLib.getPropertyString("track-list/$i/lang")
            val title = MPVLib.getPropertyString("track-list/$i/title")
            val label = when {
                !lang.isNullOrEmpty() && !title.isNullOrEmpty() -> "$id · $title · $lang"
                !lang.isNullOrEmpty() || !title.isNullOrEmpty() -> "$id · ${lang ?: ""}${title ?: ""}"
                else -> "$id"
            }
            list.add(Track(id, label))
        }
    }

    /** 供核心读取轨道列表（audio/video/sub）。 */
    fun tracksFor(type: TrackType): List<Track> = tracksMap[type.mapKey()].orEmpty().toList()

    private fun TrackType.mapKey(): String = when (this) {
        TrackType.AUDIO -> "audio"
        TrackType.VIDEO -> "video"
        TrackType.SUBTITLE -> "sub"
    }

    // ---------------- 属性 ----------------

    var paused: Boolean
        get() = MPVLib.getPropertyBoolean("pause") ?: false
        set(value) = MPVLib.setPropertyBoolean("pause", value)

    var timePos: Double?
        get() = MPVLib.getPropertyDouble("time-pos/full")
        set(value) {
            value?.let { MPVLib.setPropertyDouble("time-pos", it) }
        }

    var playbackSpeed: Double
        get() = MPVLib.getPropertyDouble("speed") ?: 1.0
        set(value) = MPVLib.setPropertyDouble("speed", value)

    var volume: Double
        get() = MPVLib.getPropertyDouble("volume") ?: 100.0
        set(value) = MPVLib.setPropertyDouble("volume", value)

    var muted: Boolean
        get() = MPVLib.getPropertyBoolean("mute") ?: false
        set(value) = MPVLib.setPropertyBoolean("mute", value)

    // ---------------- 命令 ----------------

    fun cyclePause() = MPVLib.command(arrayOf("cycle", "pause"))

    private inner class TrackDelegate(private val name: String) {
        operator fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>): Int {
            return MPVLib.getPropertyString(name)?.toIntOrNull() ?: -1
        }
        operator fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: Int) {
            if (value == -1) MPVLib.setPropertyString(name, "no")
            else MPVLib.setPropertyInt(name, value)
        }
    }

    var vid: Int by TrackDelegate("vid")
    var sid: Int by TrackDelegate("sid")
    var aid: Int by TrackDelegate("aid")

    data class Track(val mpvId: Int, val name: String)

    companion object {
        private const val HWDECS = "mediacodec,mediacodec-copy"
    }
}