package com.example.localmovielibrarz.player.host

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import com.example.localmovielibrarz.player.core.*

/**
 * 播放器宿主（§4 / §9.2）：负责渲染容器注入、状态协调、切换调度。
 *
 * Compose 通过 [attachContainer] 注入 FrameLayout；切换核心时按「先释放旧视图 → 注入新视图」顺序处理 Surface 生命周期冲突（§9.3）。
 */
class PlayerHost(
    private val context: Context,
    private val registry: PlayerCoreRegistry,
    private val fallbackController: FallbackController,
    private val listener: PlayerCoreListener? = null
) {

    @Volatile
    private var container: FrameLayout? = null

    @Volatile
    private var currentCore: PlayerCore? = null

    @Volatile
    private var switchState: SwitchState = SwitchState.IDLE

    /** 当前请求：用于错误回调时触发自动回退（\u00a712）。 */
    @Volatile
    private var currentRequest: PlaybackRequest? = null

    /** 界面侧当前核心类型（供 UI 显示）。 */
    @Volatile
    var currentCoreType: PlayerCoreType? = null
        private set

    private var switchCallback: ((SwitchState) -> Unit)? = null

    fun setSwitchCallback(cb: ((SwitchState) -> Unit)?) {
        switchCallback = cb
    }

    val availableCoreTypes: Set<PlayerCoreType> = setOf(PlayerCoreType.EXOPLAYER, PlayerCoreType.MPV)

    // ---------------- 容器 ----------------

    /** 由 Compose AndroidView factory / update 调用，注入渲染容器（幂等）。 */
    fun attachContainer(container: FrameLayout) {
        // 同一容器已附加且有子视图：recompose 场景直接跳过，避免反复销毁/重建 Surface（§9.3）
        if (this.container === container && container.childCount > 0) return
        this.container = container
        container.removeAllViews()
        currentCore?.let { attachCore(it) }
    }

    fun detachContainer() {
        this.container = null
    }

    private fun attachCore(core: PlayerCore) {
        val c = container ?: return
        c.removeAllViews()
        val view: View = core.getOrCreateView(context)
        c.addView(view, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
    }

    // ---------------- 初始播放 ----------------

    fun play(request: PlaybackRequest, requestedCore: PlayerCoreType? = null) {
        currentRequest = request
        val coreType = registry.resolveDefaultCore(request, requestedCore)
        val core = registry.create(coreType)
        core.setListener(innerListener)
        currentCore?.let { old ->
            // 若已有核心先释放（正常切换流程）
            with(old) { stop(); release() }
        }
        currentCore = core
        currentCoreType = coreType
        attachCore(core)
        core.load(request)
    }

    // ---------------- 核心切换（伪实时） ----------------

    /**
     * 伪实时切换（§11）：记录快照 → 停止/释放旧核心 → 创建新核心 → 注入 → 恢复。
     *
     * @param target 目标核心类型
     * @param onSwitched 切换完成回调（成功/失败）
     */
    fun switchCore(target: PlayerCoreType, onSwitched: (Result<Unit>) -> Unit = {}) {
        val oldCore = currentCore ?: run { onSwitched(Result.failure(IllegalStateException("无当前核心"))); return }
        if (oldCore.type == target || switchState != SwitchState.IDLE) {
            onSwitched(Result.failure(IllegalStateException("正在切换或目标核心相同")))
            return
        }
        setState(SwitchState.SNAPSHOT_TAKEN)
        val snapshot = runCatching { oldCore.getSnapshot() }.getOrNull() ?: return

        switchCoreInternal(oldCore, target, snapshot, onSwitched)
    }

    private fun switchCoreInternal(
        oldCore: PlayerCore,
        target: PlayerCoreType,
        snapshot: PlaybackSnapshot,
        onSwitched: (Result<Unit>) -> Unit
    ) {
        // 1. 停止并释放旧核心（先 release 再移除视图，确保 Surface 正确销毁，§9.3）
        setState(SwitchState.OLD_CORE_RELEASED)
        runCatching { oldCore.stop() }
        runCatching { oldCore.release() }

        // 2. 创建并注入新核心
        val newCore = registry.create(target)
        newCore.setListener(innerListener)
        currentCore = newCore
        currentCoreType = target
        attachCore(newCore)
        setState(SwitchState.NEW_CORE_LOADING)

        // 3. 用修改后的 PlaybackRequest 加载；READY 后恢复速度/音量/播放态
        val resumeRequest = snapshot.toResumeRequest(PlaybackOrigin.INTERNAL_SWITCH)
        var restored = false
        newCore.setListener(object : PlayerCoreListener by (listener ?: NullListener) {
            override fun onPlaybackStateChanged(state: PlaybackState) {
                if (!restored && state == PlaybackState.READY) {
                    restored = true
                    resumeAfterReady(newCore, snapshot)
                }
                listener?.onPlaybackStateChanged(state)
            }
        })
        newCore.load(resumeRequest)
        setState(SwitchState.SWITCH_COMPLETED)
        onSwitched(Result.success(Unit))
    }

    private fun resumeAfterReady(newCore: PlayerCore, snapshot: PlaybackSnapshot) {
        newCore.setSpeed(snapshot.speed.coerceIn(0.25f, 8f))
        newCore.setVolume(snapshot.volume.coerceIn(0f, 1f))
        newCore.setMuted(snapshot.muted)
        if (snapshot.wasPlaying) newCore.play() else newCore.pause()
        listener?.let {
            it.onPositionChanged(snapshot.positionMs, snapshot.durationMs)
        }
    }

    /**
     * 自动回退：Exo → mpv（§12.4）。
     * 由宿主监听核心错误触发，且仅在满足条件时切换。
     */
    fun onCoreError(request: PlaybackRequest, error: PlaybackError) {
        val current = currentCore ?: return
        if (current.type != PlayerCoreType.EXOPLAYER) return // 仅 Exo → mpv
        if (switchState != SwitchState.IDLE) return

        if (!fallbackController.shouldAutoFallback(request, error.type)) {
            listener?.onError(error)
            return
        }
        fallbackController.markAutoFallback(request)
        switchCore(PlayerCoreType.MPV)
    }

    // ---------------- 转发到当前核心 ----------------

    fun getSnapshot(): PlaybackSnapshot? = currentCore?.getSnapshot()

    fun play() = currentCore?.play()
    fun pause() = currentCore?.pause()
    fun togglePlay() = currentCore?.togglePlay()
    fun seekTo(positionMs: Long) = currentCore?.seekTo(positionMs)
    fun seekBy(deltaMs: Long) = currentCore?.seekBy(deltaMs)
    fun setSpeed(speed: Float) = currentCore?.setSpeed(speed)
    fun setVolume(volume: Float) = currentCore?.setVolume(volume)
    fun setMuted(muted: Boolean) = currentCore?.setMuted(muted)
    fun getTracks(): TrackModel = currentCore?.getTracks() ?: TrackModel.EMPTY
    fun selectTrack(selection: TrackSelection) = currentCore?.selectTrack(selection)

    fun release() {
        val old = currentCore
        container?.removeAllViews()
        old?.release()
        currentCore = null
        currentCoreType = null
        currentRequest = null
        container = null
    }

    private val innerListener = object : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) { listener?.onPlaybackStateChanged(state) }
        override fun onPositionChanged(positionMs: Long, durationMs: Long) { listener?.onPositionChanged(positionMs, durationMs) }
        override fun onVideoSizeChanged(width: Int, height: Int) { listener?.onVideoSizeChanged(width, height) }
        override fun onTracksChanged(tracks: TrackModel) { listener?.onTracksChanged(tracks) }
        override fun onError(error: PlaybackError) {
            currentRequest?.let { req -> onCoreError(req, error) } ?: listener?.onError(error)
        }
        override fun onBufferingChanged(buffering: Boolean) { listener?.onBufferingChanged(buffering) }
        override fun onPlaybackEnded() { listener?.onPlaybackEnded() }
    }

    private fun setState(state: SwitchState) {
        switchState = state
        switchCallback?.invoke(state)
    }

    enum class SwitchState {
        IDLE,
        SNAPSHOT_TAKEN,
        OLD_CORE_RELEASED,
        NEW_CORE_LOADING,
        SWITCH_COMPLETED
    }

    private object NullListener : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) {}
        override fun onPositionChanged(positionMs: Long, durationMs: Long) {}
        override fun onVideoSizeChanged(width: Int, height: Int) {}
        override fun onTracksChanged(tracks: TrackModel) {}
        override fun onError(error: PlaybackError) {}
        override fun onBufferingChanged(buffering: Boolean) {}
        override fun onPlaybackEnded() {}
    }
}