package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import android.view.View
import `is`.xyz.mpv.MPVLib
import com.example.localmovielibrarz.player.core.*

/**
 * mpv 核心实现（§8）。
 *
 * 线程模型（§8.3）：所有 PlayerCore 方法与 mpv 命令调用均转发到专用 CoreExecutor 单线程执行，
 * 避免与 UI 线程并发冲突。SurfaceView 生命周期由 [MpvView] 管理，核心 release 时先销毁视图。
 *
 * 注意：libmpv.so / libplayer.so 是跨平台编译产物（见实现报告构建说明），需放入 jniLibs 相应 ABI 目录。
 */
class MpvPlayerCoreImpl(context: Context) : MpvPlayerCore {

    @Volatile
    private var appContext: Context = context.applicationContext

    private val executor = CoreExecutor("mpv").apply {
        setErrorHandler { e ->
            android.util.Log.e(TAG, "MpvPlayerCore executor error", e)
        }
        start()
    }

    @Volatile
    private var view: MpvView? = null

    @Volatile
    private var initialized = false

    @Volatile
    private var loadedRequest: PlaybackRequest? = null

    @Volatile
    private var cachedTracks: TrackModel = TrackModel.EMPTY

    @Volatile
    override var playbackState: PlaybackState = PlaybackState.IDLE
        private set

    @Volatile
    private var listener: PlayerCoreListener? = null

    /** 当前播放的核心标志（用于快照）。 */
    @Volatile
    private var wasPlayingMpv = false

    private val eventObserver = object : MPVLib.EventObserver {
        override fun eventProperty(property: String) {}
        override fun eventProperty(property: String, value: Long) {
            if (property == "time-pos") {
                val dur = MPVLib.getPropertyDouble("duration") ?: 0.0
                listener?.onPositionChanged(value.coerceAtLeast(0L), (dur * 1000L).toLong())
            }
        }
        override fun eventProperty(property: String, value: Boolean) {
            when (property) {
                "pause" -> {
                    wasPlayingMpv = !value
                    publishState(if (value) PlaybackState.PAUSED else PlaybackState.PLAYING)
                }
                "paused-for-cache" -> listener?.onBufferingChanged(value)
                "mute" -> Unit
            }
        }
        override fun eventProperty(property: String, value: String) {
            if (property == "speed") {
                listener?.onPositionChanged(0L, 0L)
            }
        }
        override fun eventProperty(property: String, value: Double) {}
        override fun event(eventId: Int) {
            when (eventId) {
                MPVLib.MpvEvent.MPV_EVENT_START_FILE -> publishState(PlaybackState.PREPARING)
                MPVLib.MpvEvent.MPV_EVENT_FILE_LOADED -> {
                    refreshTracksFromView()
                    publishState(PlaybackState.READY)
                    if (wasPlayingMpv) {
                        view?.let { it.paused = false }
                        publishState(PlaybackState.PLAYING)
                    } else {
                        publishState(PlaybackState.PAUSED)
                    }
                }
                MPVLib.MpvEvent.MPV_EVENT_END_FILE -> publishState(PlaybackState.ENDED)
            }
        }
    }

    override val type: PlayerCoreType = PlayerCoreType.MPV

    override val staticCapabilities: Set<PlayerCapability> = setOf(
        PlayerCapability.ADVANCED_SUB_STYLE,
        PlayerCapability.SECONDARY_SUBTITLE,
        PlayerCapability.SCREENSHOT,
        PlayerCapability.SCALER_DEBAND,
        PlayerCapability.SUBTITLE_DELAY,
        PlayerCapability.AUDIO_DELAY
    )

    override fun supportsCapability(capability: PlayerCapability): Boolean =
        capability in staticCapabilities

    // ---------------- 视图 ----------------

    override fun getOrCreateView(context: Context): View {
        return view ?: MpvView(context.applicationContext).also { v ->
            view = v
        }
    }

    @Synchronized
    private fun ensureInitialized() {
        if (initialized) return
        val v = view ?: MpvView(appContext).also { view = it }
        v.initialize(appContext.filesDir.path, appContext.cacheDir.path)
        MPVLib.addObserver(eventObserver)
        initialized = true
    }

    override fun setListener(listener: PlayerCoreListener?) {
        this.listener = listener
    }

    override fun removeListener(listener: PlayerCoreListener) {
        if (this.listener === listener) this.listener = null
    }

    // ---------------- 生命周期 ----------------

    override fun load(request: PlaybackRequest) {
        executor.execute {
            loadedRequest = request
            ensureInitialized()
            resumeFromRequest(request)
        }
    }

    private fun resumeFromRequest(request: PlaybackRequest) {
        val v = view ?: return
        // 处理字幕（外部字幕转 mpv sub-file）
        request.subtitleSources.forEachIndexed { index, src ->
            MPVLib.command(arrayOf("sub-add", src.uri.toString(), "select"))
        }
        // 暂停态以便设置起始位置
        v.paused = true
        v.playFile(request.uri.toString())
        // loadfile 立即执行
        MPVLib.command(arrayOf("loadfile", request.uri.toString()))
        request.startPositionMs?.takeIf { it > 0L }?.let { pos ->
            v.timePos = pos / 1000.0
        }
        request.audioTrackHint?.let { selectMpvTrackByHint(it) }
        request.subtitleTrackHints.forEach { selectMpvTrackByHint(it) }
        val wantPlay = request.autoplay
        wasPlayingMpv = wantPlay
        v.paused = !wantPlay
        if (!wantPlay) publishState(PlaybackState.PAUSED)
    }

    private fun selectMpvTrackByHint(hint: TrackHint) {
        val id = hint.mpvTrackId ?: return
        when (hint.type) {
            TrackType.VIDEO -> view?.vid = id
            TrackType.AUDIO -> view?.aid = id
            TrackType.SUBTITLE -> view?.sid = id
        }
    }

    override fun play() {
        executor.post {
            view?.let {
                wasPlayingMpv = true
                it.paused = false
            }
        }
    }

    override fun pause() {
        executor.post {
            view?.let {
                wasPlayingMpv = false
                it.paused = true
            }
        }
    }

    override fun togglePlay() {
        executor.execute {
            view?.let {
                wasPlayingMpv = it.paused
                it.cyclePause()
            }
        }
    }

    override fun stop() {
        executor.execute {
            MPVLib.command(arrayOf("stop"))
            publishState(PlaybackState.IDLE)
        }
    }

    override fun release() {
        executor.execute {
            MPVLib.removeObserver(eventObserver)
            view?.destroy()
            view = null
            initialized = false
        }
        executor.shutdown()
    }

    // ---------------- 控制 ----------------

    override fun seekTo(positionMs: Long) {
        executor.execute {
            view?.timePos = positionMs.coerceAtLeast(0L) / 1000.0
        }
    }

    override fun seekBy(deltaMs: Long) {
        executor.execute {
            MPVLib.command(arrayOf("seek", (deltaMs / 1000.0).toString(), "relative"))
        }
    }

    override fun setSpeed(speed: Float) {
        executor.execute {
            view?.playbackSpeed = speed.coerceIn(0.25f, 8f).toDouble()
        }
    }

    override fun setVolume(volume: Float) {
        executor.execute {
            view?.volume = (volume.coerceIn(0f, 1f) * 100.0)
        }
    }

    override fun setMuted(muted: Boolean) {
        executor.execute {
            view?.muted = muted
        }
    }

    // ---------------- 轨道 ----------------

    override fun getTracks(): TrackModel = cachedTracks

    private fun refreshTracksFromView() {
        val v = view ?: run { cachedTracks = TrackModel.EMPTY; return }
        v.loadTracks()
        val video = v.tracksFor(TrackType.VIDEO).map { toTrackInfo(it, TrackType.VIDEO, v.vid) }
        val audio = v.tracksFor(TrackType.AUDIO).map { toTrackInfo(it, TrackType.AUDIO, v.aid) }
        val sub = v.tracksFor(TrackType.SUBTITLE).map { toTrackInfo(it, TrackType.SUBTITLE, v.sid) }
        cachedTracks = TrackModel(video, audio, sub)
        listener?.onTracksChanged(cachedTracks)
    }

    private fun toTrackInfo(track: MpvView.Track, type: TrackType, selectedId: Int): TrackInfo {
        val hint = TrackHint(
            type = type,
            mpvTrackId = track.mpvId.takeIf { it >= 0 },
            language = null,
            title = track.name
        )
        return TrackInfo(
            hint = hint,
            label = track.name,
            selected = track.mpvId == selectedId,
            selectable = true
        )
    }

    override fun selectTrack(selection: TrackSelection) {
        executor.execute {
            val v = view ?: return@execute
            if (selection.disable) {
                when (selection.type) {
                    TrackType.AUDIO -> v.aid = -1
                    TrackType.VIDEO -> v.vid = -1
                    TrackType.SUBTITLE -> v.sid = -1
                }
                return@execute
            }
            selection.hint?.mpvTrackId?.let { id ->
                when (selection.type) {
                    TrackType.AUDIO -> v.aid = id
                    TrackType.VIDEO -> v.vid = id
                    TrackType.SUBTITLE -> v.sid = id
                }
            }
        }
    }

    // ---------------- 快照 ----------------

    override fun getSnapshot(): PlaybackSnapshot {
        var positionMs = 0L
        var durationMs = 0L
        var speed = 1f
        var volume = 1f
        executor.execute {
            view?.let {
                positionMs = ((it.timePos ?: 0.0) * 1000L).toLong().coerceAtLeast(0L)
                durationMs = ((MPVLib.getPropertyDouble("duration") ?: 0.0) * 1000L).toLong().coerceAtLeast(0L)
                speed = it.playbackSpeed.toFloat()
                volume = (it.volume / 100.0).toFloat()
            }
        }
        val req = loadedRequest
        return PlaybackSnapshot(
            request = req ?: PlaybackRequest(uri = android.net.Uri.EMPTY, sourceType = SourceType.UNKNOWN),
            coreType = type,
            positionMs = positionMs,
            durationMs = durationMs,
            speed = speed,
            wasPlaying = wasPlayingMpv,
            volume = volume,
            muted = view?.muted ?: false,
            audioTrackHint = view?.let { TrackHint(TrackType.AUDIO, mpvTrackId = it.aid.takeIf { id -> id >= 0 }) },
            subtitleTrackHints = emptyList(),
            subtitleDelayMs = null,
            audioDelayMs = null,
            fallbackUsed = false,
            lastError = null,
            createdAt = System.currentTimeMillis()
        )
    }

    // ---------------- mpv 专属 ----------------

    override fun command(args: List<String>) {
        executor.post { MPVLib.command(args.toTypedArray()) }
    }

    override fun observeMpvProperty(name: String) {
        executor.post { MPVLib.observeProperty(name, MPVLib.MpvFormat.MPV_FORMAT_STRING) }
    }

    override fun setMpvOption(name: String, value: String): Int {
        return executor.executeWithResult { MPVLib.setOptionString(name, value) } ?: -1
    }

    private fun publishState(state: PlaybackState) {
        playbackState = state
        listener?.onPlaybackStateChanged(state)
    }

    companion object {
        private const val TAG = "MpvPlayerCore"

        /**
         * 检测 mpv 原生库是否可用。
         * 注意：MPVLib 的 init{} 会立即 System.loadLibrary，一旦首次引用 MPVLib 就会尝试加载；
         * 因此此处预先、独立地探活，避免把核心标记为可用但运行时崩溃。
         */
        val isNativeAvailable: Boolean by lazy {
            try {
                System.loadLibrary("mpv")
                System.loadLibrary("player")
                true
            } catch (_: UnsatisfiedLinkError) {
                android.util.Log.w(TAG, "mpv 原生库缺失/加载失败，mpv 核心不可用")
                false
            } catch (_: Throwable) {
                false
            }
        }
    }
}

/** 让 [CoreExecutor] 支持返回结果的同步执行。 */
private fun CoreExecutor.executeWithResult(block: () -> Int): Int? {
    return java.util.concurrent.atomic.AtomicReference<Int?>().let { ref ->
        execute { ref.set(block()) }
        ref.get()
    }
}