package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_DOUBLE
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_NONE
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_FLAG
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_INT64
import `is`.xyz.mpv.MPVLib.MpvFormat.MPV_FORMAT_STRING
import com.example.localmovielibrarz.player.core.TrackType

/**
 * 具体 mpv 视图（§8.6 默认值）。
 *
 * 硬解：固定 mediacodec-copy（仍走 MediaCodec 硬件解码，帧拷贝回 GL 渲染），
 * 规避窗口 Resize / surface pin 重连时硬解 surface 重开导致的解码器反复重开与降级卡顿；vo=gpu。
 */
open class MpvView(context: Context) : BaseMpvView(context) {

    private val tracksMap: MutableMap<String, MutableList<Track>> = linkedMapOf(
        "audio" to mutableListOf(),
        "video" to mutableListOf(),
        "sub" to mutableListOf()
    )

    override fun initOptions() {
        // ---- 性能档（mpv 移动端性能优先组合，见调优报告 §3.2）----
        MPVLib.setOptionString("profile", "fast")
        MPVLib.setOptionString("vd-lavc-fast", "yes")
        MPVLib.setOptionString("vd-lavc-skiploopfilter", "nonkey")
        // 胶片颗粒走 CPU，规避部分设备 GPU/hevc 灰粒问题
        MPVLib.setOptionString("vd-lavc-film-grain", "cpu")
        // 解码失败回退软解，避免硬解出错直接黑屏
        MPVLib.setOptionString("vd-lavc-software-fallback", "1")
        setVo("gpu")
        MPVLib.setOptionString("hwdec", HWDECS)
        MPVLib.setOptionString("hwdec-codecs", "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1")
        MPVLib.setOptionString("ao", "audiotrack,opensles")
        MPVLib.setOptionString("audio-set-media-role", "yes")
        // 网络串流（115/光鸭 直链）：关掉严格证书校验，避免 TLS/证书问题导致无法拉流 → 黑屏
        MPVLib.setOptionString("tls-verify", "no")
        MPVLib.setOptionString("network-timeout", NETWORK_TIMEOUT_OPT)
        // 直链常用协议族放行（http/https/rtsp/tcp 等）
        MPVLib.setOptionString(
            "protocol-whitelist",
            "file,http,https,rtp,tcp,udp,tls,crypto,httpproxy"
        )
        // 流式：短探测拿编码信息，避免长时间开播黑屏
        MPVLib.setOptionString("demuxer-lavf-probesize", "${2 * 1024 * 1024}")
        MPVLib.setOptionString("demuxer-lavf-analyzeduration", "3")
        // 解复用缓存：前向上限 + 后向为一半（调优报告 §4.1）
        MPVLib.setOptionString("demuxer-max-bytes", "${DEMUXER_MAX_BYTES}")
        MPVLib.setOptionString("demuxer-max-back-bytes", "${DEMUXER_MAX_BYTES / 2}")
        // 缓存时长（秒）：网络流缓冲更足，减少因缓存不足暂停
        MPVLib.setOptionString("cache-secs", CACHE_SECS_OPT)
        MPVLib.setOptionString("demuxer-readahead-secs", "2")
        // ---- 容器级优化（调优报告 §3.4 / §4.2）：MKV 快开 + MOV 交错预热 + 弱网重连 ----
        MPVLib.setOptionString("demuxer-mkv-skip-tags", "yes")
        MPVLib.setOptionString("demuxer-mkv-skip-chapters", "no")
        MPVLib.setOptionString("demuxer-mkv-defer-cues", "no")
        MPVLib.setOptionString("demuxer-lavf-o", buildDemuxerLavfOptions())
        MPVLib.setOptionString("input-default-bindings", "yes")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("opengl-es", "yes")
        MPVLib.setOptionString("save-position-on-quit", "no")
        MPVLib.setOptionString("keep-open", "yes")
        // 诊断用：verbosity 仅针对渲染/解码路径，其余 info，避免刷屏但能定位黑屏原因
        MPVLib.setOptionString(
            "msg-level", "all=info,vo=debug,vd=debug,video=debug,hwdec=v,ao=info,demux=info"
        )
    }

    /**
     * 拼出 demuxer-lavf-o（调优报告 §4.2）：
     * 弱网/私有源默认常开重连串 + 大文件 seek 优化(short_seek_size=16MB) + MOV 交错预热。
     */
    private fun buildDemuxerLavfOptions(): String = buildList {
        add("reconnect=1")
        add("reconnect_streamed=1")
        add("reconnect_on_network_error=1")
        add("reconnect_delay_max=31")
        add("multiple_requests=1")
        add("short_seek_size=16777216") // 16MB 短跳转缓冲，拖拽更跟手
        add("interleave_strategy=bounded")
        add("interleave_preload_duration=${MOV_PRELOAD_SECONDS}s")
        add("interleave_preload_max_bytes=${MOV_PRELOAD_MAX_BYTES}")
    }.joinToString(",")

    override fun postInitOptions() {
        // 本处可在 init 后设置不可在 init 前设置的选项
    }

    override fun observeProperties() {
        data class Property(val name: String, val format: Int = MPV_FORMAT_NONE)
        val p = arrayOf(
            Property("time-pos", MPV_FORMAT_INT64),
            Property("duration", MPV_FORMAT_INT64),
            Property("video-params/w", MPV_FORMAT_INT64),
            Property("video-params/h", MPV_FORMAT_INT64),
            Property("video-params/rotate", MPV_FORMAT_INT64),
            Property("pause", MPV_FORMAT_FLAG),
            Property("paused-for-cache", MPV_FORMAT_FLAG),
            Property("speed", MPV_FORMAT_STRING),
            Property("track-list"),
            Property("current-tracks/video/image"),
            Property("media-title", MPV_FORMAT_STRING),
            Property("hwdec-current"),
            Property("vo-configured", MPV_FORMAT_FLAG),
            Property("mute", MPV_FORMAT_FLAG),
            Property("current-tracks/audio/selected")
        )
        for ((name, format) in p) MPVLib.observeProperty(name, format)
    }

    /** 从 mpv track-list 重新加载轨道，填充 [TracksMap]。 */
    fun loadTracks() {
        for (list in tracksMap.values) {
            list.clear()
            list.add(Track(-1, "关闭"))
        }
        val count = MPVLib.getPropertyInt("track-list/count") ?: 0
        for (i in 0 until count) {
            val type = MPVLib.getPropertyString("track-list/$i/type") ?: continue
            val list = tracksMap[type] ?: continue
            val id = MPVLib.getPropertyInt("track-list/$i/id") ?: continue
            val lang = MPVLib.getPropertyString("track-list/$i/lang")
            val title = MPVLib.getPropertyString("track-list/$i/title")
            val label = when {
                !lang.isNullOrEmpty() && !title.isNullOrEmpty() -> "$id · $title · $lang"
                !lang.isNullOrEmpty() || !title.isNullOrEmpty() -> "$id · ${lang ?: ""}${title ?: ""}"
                else -> "$id"
            }
            list.add(Track(id, label))
        }
    }

    /** 供核心读取轨道列表（audio/video/sub）。 */
    fun tracksFor(type: TrackType): List<Track> = tracksMap[type.mapKey()].orEmpty().toList()

    private fun TrackType.mapKey(): String = when (this) {
        TrackType.AUDIO -> "audio"
        TrackType.VIDEO -> "video"
        TrackType.SUBTITLE -> "sub"
    }

    // ---------------- 属性 ----------------

    var paused: Boolean
        get() = MPVLib.getPropertyBoolean("pause") ?: false
        set(value) = MPVLib.setPropertyBoolean("pause", value)

    var timePos: Double?
        get() = MPVLib.getPropertyDouble("time-pos/full")
        set(value) {
            value?.let { MPVLib.setPropertyDouble("time-pos", it) }
        }

    var playbackSpeed: Double
        get() = MPVLib.getPropertyDouble("speed") ?: 1.0
        set(value) = MPVLib.setPropertyDouble("speed", value)

    var volume: Double
        get() = MPVLib.getPropertyDouble("volume") ?: 100.0
        set(value) = MPVLib.setPropertyDouble("volume", value)

    var muted: Boolean
        get() = MPVLib.getPropertyBoolean("mute") ?: false
        set(value) = MPVLib.setPropertyBoolean("mute", value)

    // ---------------- 命令 ----------------

    fun cyclePause() = MPVLib.command(arrayOf("cycle", "pause"))

    private inner class TrackDelegate(private val name: String) {
        operator fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>): Int {
            return MPVLib.getPropertyString(name)?.toIntOrNull() ?: -1
        }
        operator fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: Int) {
            if (value == -1) MPVLib.setPropertyString(name, "no")
            else MPVLib.setPropertyInt(name, value)
        }
    }

    var vid: Int by TrackDelegate("vid")
    var sid: Int by TrackDelegate("sid")
    var aid: Int by TrackDelegate("aid")

    data class Track(val mpvId: Int, val name: String)

    companion object {
        // 固定为 mediacodec-copy：不尝试直接渲染到 surface 的 mediacodec 模式，
        // 帧始终拷贝回 GL（gpu）渲染，避免 Resize/重排时 surface 失效导致解码器反复重开、丢帧降级。
        private const val HWDECS = "mediacodec-copy"
        // 解复用前向缓存上限（字节）：64MB；后向 = 前向 ÷ 2（调优报告 §4.1）
        private const val DEMUXER_MAX_BYTES = 64 * 1024 * 1024
        // 网络流缓存时长（秒），对应 cache-secs
        private const val CACHE_SECS_OPT = "8"
        // 网络超时（秒）
        private const val NETWORK_TIMEOUT_OPT = "30"
        // MOV 交错预加载：预热 2s / 上限 32MB，大文件 seek 更跟手
        private const val MOV_PRELOAD_SECONDS = 2
        private const val MOV_PRELOAD_MAX_BYTES = 32 * 1024 * 1024
    }
}