package com.example.localmovielibrarz.player.core

import android.net.Uri
import com.example.localmovielibrarz.subtitle.LocalSubtitleFile

/**
 * 将现有 [com.example.localmovielibrarz.playback.PlaybackRequest] 输出映射为核心统一的 [PlaybackRequest]。
 *
 * 保持既有 PlaybackResolver / PlaybackRequest 不变（§10.4），在接入层做转换。
 */
object PlaybackRequestMapper {

    fun fromLegacy(
        legacy: com.example.localmovielibrarz.playback.PlaybackRequest
    ): PlaybackRequest =
        PlaybackRequest(
            uri = Uri.parse(legacy.mediaUri),
            sourceType = SourceTypeResolver.resolve(Uri.parse(legacy.mediaUri)),
            title = legacy.title,
            headers = legacy.headers,
            origin = PlaybackOrigin.USER
        )

    fun fromLegacy(
        legacy: com.example.localmovielibrarz.playback.PlaybackRequest,
        startPositionMs: Long?,
        externalSubtitle: LocalSubtitleFile?
    ): PlaybackRequest {
        val base = fromLegacy(legacy)
        return base.copy(
            startPositionMs = startPositionMs,
            subtitleSources = externalSubtitle?.let {
                listOf(
                    SubtitleSource(
                        uri = it.uri,
                        label = it.name,
                        isExternal = true,
                        isAutoSelect = true
                    )
                )
            } ?: emptyList()
        )
    }
}