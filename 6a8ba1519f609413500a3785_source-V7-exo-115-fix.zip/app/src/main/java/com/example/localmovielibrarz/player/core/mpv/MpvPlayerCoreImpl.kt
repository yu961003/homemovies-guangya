package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import android.view.View
import `is`.xyz.mpv.MPVLib
import com.example.localmovielibrarz.player.core.*

/**
 * mpv 核心实现（§8）。
 *
 * 线程模型（§8.3）：所有 PlayerCore 方法与 mpv 命令调用均转发到专用 CoreExecutor 单线程执行，
 * 避免与 UI 线程并发冲突。SurfaceView 生命周期由 [MpvView] 管理，核心 release 时先销毁视图。
 *
 * 注意：libmpv.so / libplayer.so 是跨平台编译产物（见实现报告构建说明），需放入 jniLibs 相应 ABI 目录。
 */
class MpvPlayerCoreImpl(context: Context) : MpvPlayerCore {

    @Volatile
    private var appContext: Context = context.applicationContext

    private val executor = CoreExecutor("mpv").apply {
        setErrorHandler { e ->
            android.util.Log.e(TAG, "MpvPlayerCore executor error", e)
        }
        start()
    }

    @Volatile
    private var view: MpvView? = null

    @Volatile
    private var initialized = false

    @Volatile
    private var loadedRequest: PlaybackRequest? = null

    @Volatile
    private var cachedTracks: TrackModel = TrackModel.EMPTY

    @Volatile
    override var playbackState: PlaybackState = PlaybackState.IDLE
        private set

    @Volatile
    private var listener: PlayerCoreListener? = null

    /** 当前播放的核心标志（用于快照）。 */
    @Volatile
    private var wasPlayingMpv = false

    /** mpv 是否已真正渲染出第一帧（vo-configured=true）。作为"非黑屏"判据。 */
    @Volatile
    private var videoOutputReady = false

    /** 由播放进度轮询更新的缓存位置与时长（供 getSnapshot 直接读取，避免阻塞 executor 与事件竞态）。 */
    @Volatile
    private var cachedPositionMs = 0L
    @Volatile
    private var cachedDurationMs = 0L

    /** 专用位置轮询线程（与 Exo 的 positionPusher 对齐）：独立线程定时读 time-pos/full(毫秒)，不阻塞 executor。 */
    private var positionPusher: Thread? = null

    /** 视频有效显示宽高（已按旋转角归一）。0 = 未知。 */
    @Volatile
    private var videoWidth = 0
    @Volatile
    private var videoHeight = 0

    /** 幂等释放守卫：仅 mpv 被切为当前核心后由 PlayerHost 释放一次；防止多重 release 触发 native crash。 */
    @Volatile
    private var released = false

    private val eventObserver = object : MPVLib.EventObserver {
        override fun eventProperty(property: String) {}
        override fun eventProperty(property: String, value: Long) {
            when (property) {
                "time-pos", "duration" -> {
                    // time-pos 以 INT64 观测时返回的是整秒，勿当毫秒；位置统一由 positionPusher 读 time-pos/full(毫秒) 维护
                    // 这里仅触发一次即时刷新，拉高 UI 更新频率，但以毫秒精度为准
                    val pos = MPVLib.getPropertyDouble("time-pos/full")
                    if (pos != null && pos >= 0.0) cachedPositionMs = (pos * 1000.0).toLong().coerceAtLeast(0L)
                    val dur = MPVLib.getPropertyDouble("duration")
                    if (dur != null && dur > 0.0) cachedDurationMs = (dur * 1000.0).toLong().coerceAtLeast(0L)
                    val l = listener
                    if (l != null && cachedDurationMs > 0L) {
                        l.onPositionChanged(cachedPositionMs, cachedDurationMs)
                    }
                }
                "video-params/w", "video-params/h", "video-params/rotate" -> readVideoSize()
                else -> Unit
            }
        }
        override fun eventProperty(property: String, value: Boolean) {
            when (property) {
                "pause" -> {
                    wasPlayingMpv = !value
                    publishState(if (value) PlaybackState.PAUSED else PlaybackState.PLAYING)
                }
                "paused-for-cache" -> listener?.onBufferingChanged(value)
                "mute" -> Unit
                // vo 已配置 = 视频渲染输出就绪；未出现 → 黑屏
                "vo-configured" -> videoOutputReady = value
            }
        }
        override fun eventProperty(property: String, value: String) {
            // speed 变化不再清零进度（原实现会误发 onPositionChanged(0,0)，导致进度条跳 0）
        }
        override fun eventProperty(property: String, value: Double) {}
        override fun event(eventId: Int) {
            when (eventId) {
                MPVLib.MpvEvent.MPV_EVENT_START_FILE -> publishState(PlaybackState.PREPARING)
                MPVLib.MpvEvent.MPV_EVENT_FILE_LOADED -> {
                    refreshTracksFromView()
                    readVideoSize()
                    publishState(PlaybackState.READY)
                    if (wasPlayingMpv) {
                        view?.let { it.paused = false }
                        publishState(PlaybackState.PLAYING)
                    } else {
                        publishState(PlaybackState.PAUSED)
                    }
                }
                MPVLib.MpvEvent.MPV_EVENT_END_FILE -> publishState(PlaybackState.ENDED)
            }
        }
    }

    override val type: PlayerCoreType = PlayerCoreType.MPV

    override val videoOutputRendered: Boolean get() = videoOutputReady

    override val staticCapabilities: Set<PlayerCapability> = setOf(
        PlayerCapability.ADVANCED_SUB_STYLE,
        PlayerCapability.SECONDARY_SUBTITLE,
        PlayerCapability.SCREENSHOT,
        PlayerCapability.SCALER_DEBAND,
        PlayerCapability.SUBTITLE_DELAY,
        PlayerCapability.AUDIO_DELAY
    )

    override fun supportsCapability(capability: PlayerCapability): Boolean =
        capability in staticCapabilities

    // ---------------- 视图 ----------------

    override fun getOrCreateView(context: Context): View {
        return view ?: MpvView(context.applicationContext).also { v ->
            view = v
        }
    }

    @Synchronized
    private fun ensureInitialized() {
        if (initialized) return
        val v = view ?: MpvView(appContext).also { view = it }
        v.initialize(appContext.filesDir.path, appContext.cacheDir.path)
        MPVLib.addObserver(eventObserver)
        MPVLib.addLogObserver(logObserver)
        startPositionPusher()
        initialized = true
        android.util.Log.i(TAG, "mpv 核心初始化完成")
    }

    /** 启动位置轮询线程：独立线程以固定间隔读 time-pos/full(毫秒) 更新缓存并回调，避免阻塞 executor 与事件精度问题。 */
    private fun startPositionPusher() {
        if (positionPusher?.isAlive == true) return
        val t = Thread {
            while (!Thread.currentThread().isInterrupted) {
                runCatching {
                    Thread.sleep(500)
                    if (initialized) {
                        // time-pos/full 返回毫秒精度；未播放(无文件)时为 null
                        val pos = MPVLib.getPropertyDouble("time-pos/full")
                        if (pos != null && pos >= 0.0) cachedPositionMs = (pos * 1000.0).toLong().coerceAtLeast(0L)
                        val dur = MPVLib.getPropertyDouble("duration")
                        if (dur != null && dur > 0.0) cachedDurationMs = (dur * 1000.0).toLong().coerceAtLeast(0L)
                    }
                    val l = listener
                    if (l != null && cachedDurationMs > 0L) {
                        l.onPositionChanged(cachedPositionMs, cachedDurationMs)
                    }
                }.onFailure { e ->
                    android.util.Log.w(TAG, "mpv 位置轮询异常", e)
                }
            }
        }
        t.isDaemon = true
        t.name = "$TAG-position-pusher"
        positionPusher = t
        t.start()
    }

    /** 把 mpv 内部日志同时转发到 Logcat 与应用内缓冲（MpvLogBuffer），真机无需连电脑即可查看。 */
    private val logObserver = object : MPVLib.LogObserver {
        override fun logMessage(prefix: String, level: Int, text: String) {
            val levelName = when {
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_ERROR -> "ERR"
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_WARN -> "WRN"
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_INFO -> "INF"
                else -> "DBG"
            }
            val tag = "$TAG/$prefix"
            when {
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_ERROR -> android.util.Log.e(tag, text)
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_WARN -> android.util.Log.w(tag, text)
                level >= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_INFO -> android.util.Log.i(tag, text)
                else -> android.util.Log.d(tag, text)
            }
            com.example.localmovielibrarz.diagnostics.MpvLogBuffer.append(prefix, levelName, text)
        }
    }

    override fun setListener(listener: PlayerCoreListener?) {
        this.listener = listener
    }

    override fun removeListener(listener: PlayerCoreListener) {
        if (this.listener === listener) this.listener = null
    }

    // ---------------- 生命周期 ----------------

    override fun load(request: PlaybackRequest) {
        android.util.Log.i(TAG, "mpv -> load uri=${request.uri}")
        executor.execute {
            loadedRequest = request
            ensureInitialized()
            resumeFromRequest(request)
        }
    }

    private fun resumeFromRequest(request: PlaybackRequest) {
        val v = view ?: return
        // 光鸭/115 直链依赖 HTTP 请求头（UA/Referer/Cookie），mpv 需显式注入，否则拿不到流 → 黑屏
        applyRequestHeaders(request)
        // 自动探测并应用系统 HTTP 代理（调优报告 §5.1 第 5 点）：无需用户手动填代理
        applySystemProxy(request)
        // 处理字幕（外部字幕转 mpv sub-file）
        request.subtitleSources.forEachIndexed { index, src ->
            MPVLib.command(arrayOf("sub-add", src.uri.toString(), "select"))
        }
        // 暂停态以便设置起始位置
        v.paused = true
        // 统一走 playFile：仅登记路径，由 surface 就绪后触发真正 loadfile（防无输出窗口黑屏，避免双重加载）
        v.playFile(request.uri.toString())
        request.startPositionMs?.takeIf { it > 0L }?.let { pos ->
            v.timePos = pos / 1000.0
        }
        request.audioTrackHint?.let { selectMpvTrackByHint(it) }
        request.subtitleTrackHints.forEach { selectMpvTrackByHint(it) }
        val wantPlay = request.autoplay
        wasPlayingMpv = wantPlay
        videoOutputReady = false // 新一次播放：重置"已出帧"标记，供看门狗判断黑屏
        cachedPositionMs = 0L
        cachedDurationMs = 0L
        videoWidth = 0
        videoHeight = 0
        v.paused = !wantPlay
        if (!wantPlay) publishState(PlaybackState.PAUSED)
    }

    /** 读取视频有效显示尺寸（已按旋转角归一），回调给 UI 用于自动转屏。 */
    private fun readVideoSize() {
        runCatching {
            val rawW = MPVLib.getPropertyInt("video-params/w") ?: 0
            val rawH = MPVLib.getPropertyInt("video-params/h") ?: 0
            if (rawW <= 0 || rawH <= 0) return
            val rot = MPVLib.getPropertyInt("video-params/rotate") ?: 0
            // rotate=90/270 时画面横纵互换；mpv 会自动应用旋转元数据，因此这里给 UI 的是"旋转后有效宽高"
            val effW = if (rot == 90 || rot == 270) rawH else rawW
            val effH = if (rot == 90 || rot == 270) rawW else rawH
            videoWidth = effW
            videoHeight = effH
            android.util.Log.i(TAG, "mpv 视频尺寸=$rawW x $rawH (rotate=$rot) -> 有效 ${effW} x ${effH}")
            listener?.onVideoSizeChanged(effW, effH)
        }.onFailure { e ->
            android.util.Log.w(TAG, "读取 mpv 视频尺寸失败", e)
        }
    }

    private fun selectMpvTrackByHint(hint: TrackHint) {
        val id = hint.mpvTrackId ?: return
        when (hint.type) {
            TrackType.VIDEO -> view?.vid = id
            TrackType.AUDIO -> view?.aid = id
            TrackType.SUBTITLE -> view?.sid = id
        }
    }

    /** 把 PlaybackRequest 的请求头注入 mpv（UA/Referer/Cookie），适配光鸭/115 网络直链。 */
    private fun applyRequestHeaders(request: PlaybackRequest) {
        runCatching {
            val ua = request.headers["User-Agent"] ?: request.headers.entries.firstOrNull { it.key.equals("user-agent", true) }?.value
            if (!ua.isNullOrBlank()) {
                MPVLib.setOptionString("user-agent", ua)
                android.util.Log.d(TAG, "mpv user-agent 已设置")
            }
            // Referer 走 mpv 专门的 referrer 选项（比 http-header-fields 更可靠）
            val referer = request.headers.entries
                .firstOrNull { it.key.equals("referer", true) }?.value
            if (!referer.isNullOrBlank()) {
                MPVLib.setOptionString("referrer", referer)
                android.util.Log.d(TAG, "mpv referrer 已设置")
            }
            val fields = buildList {
                request.headers.entries.forEach { (k, v) ->
                    if (v.isNotBlank() &&
                        !k.equals("User-Agent", true) && !k.equals("user-agent", true) &&
                        !k.equals("Host", true) && !k.equals("Referer", true) && !k.equals("referer", true)
                    ) {
                        add("$k: $v")
                    }
                }
            }
            if (fields.isNotEmpty()) {
                MPVLib.setOptionString("http-header-fields", fields.joinToString(","))
                android.util.Log.d(TAG, "mpv http-header-fields=${fields.joinToString(",")}")
            }
        }.onFailure { e ->
            android.util.Log.w(TAG, "mpv 注入请求头失败", e)
        }
    }

    /** 自动探测系统 HTTP 代理并注入 mpv `http-proxy`（调优报告 §5.1 第 5 点）。仅对 http(s) 网络流生效。 */
    private fun applySystemProxy(request: PlaybackRequest) {
        runCatching {
            val scheme = request.uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") return
            val proxyUri = java.net.URI.create(request.uri.toString())
            val proxy = java.net.ProxySelector.getDefault()
                ?.select(proxyUri)
                ?.firstOrNull { it.type() == java.net.Proxy.Type.HTTP }
            val address = proxy?.address() as? java.net.InetSocketAddress ?: return
            val proxyUrl = "http://${address.hostName}:${address.port}"
            MPVLib.setOptionString("http-proxy", proxyUrl)
            android.util.Log.d(TAG, "mpv 已应用系统代理: $proxyUrl")
        }.onFailure { e ->
            android.util.Log.w(TAG, "mpv 探测系统代理失败", e)
        }
    }

    override fun play() {
        executor.post {
            view?.let {
                wasPlayingMpv = true
                it.paused = false
            }
        }
    }

    override fun pause() {
        executor.post {
            view?.let {
                wasPlayingMpv = false
                it.paused = true
            }
        }
    }

    override fun togglePlay() {
        executor.execute {
            view?.let {
                wasPlayingMpv = it.paused
                it.cyclePause()
            }
        }
    }

    override fun stop() {
        executor.execute {
            MPVLib.command(arrayOf("stop"))
            cachedPositionMs = 0L
            publishState(PlaybackState.IDLE)
        }
    }

    private fun stopPositionPusher() {
        positionPusher?.let { runCatching { it.interrupt() } }
        positionPusher = null
    }

    override fun release() {
        if (released) return // ★ 幂等守卫：只真正释放一次（防多重 release 触发 native crash）
        released = true
        stopPositionPusher()
        executor.execute {
            MPVLib.removeObserver(eventObserver)
            view?.destroy()
            view = null
            initialized = false
            cachedPositionMs = 0L
            cachedDurationMs = 0L
        }
        executor.shutdown()
    }

    // ---------------- 控制 ----------------

    override fun seekTo(positionMs: Long) {
        executor.execute {
            view?.timePos = positionMs.coerceAtLeast(0L) / 1000.0
        }
    }

    override fun seekBy(deltaMs: Long) {
        executor.execute {
            MPVLib.command(arrayOf("seek", (deltaMs / 1000.0).toString(), "relative"))
        }
    }

    override fun setSpeed(speed: Float) {
        executor.execute {
            view?.playbackSpeed = speed.coerceIn(0.25f, 8f).toDouble()
        }
    }

    override fun setVolume(volume: Float) {
        executor.execute {
            view?.volume = (volume.coerceIn(0f, 1f) * 100.0)
        }
    }

    override fun setMuted(muted: Boolean) {
        executor.execute {
            view?.muted = muted
        }
    }

    // ---------------- 轨道 ----------------

    override fun getTracks(): TrackModel = cachedTracks

    private fun refreshTracksFromView() {
        val v = view ?: run { cachedTracks = TrackModel.EMPTY; return }
        v.loadTracks()
        val video = v.tracksFor(TrackType.VIDEO).map { toTrackInfo(it, TrackType.VIDEO, v.vid) }
        val audio = v.tracksFor(TrackType.AUDIO).map { toTrackInfo(it, TrackType.AUDIO, v.aid) }
        val sub = v.tracksFor(TrackType.SUBTITLE).map { toTrackInfo(it, TrackType.SUBTITLE, v.sid) }
        cachedTracks = TrackModel(video, audio, sub)
        listener?.onTracksChanged(cachedTracks)
    }

    private fun toTrackInfo(track: MpvView.Track, type: TrackType, selectedId: Int): TrackInfo {
        val hint = TrackHint(
            type = type,
            mpvTrackId = track.mpvId.takeIf { it >= 0 },
            language = null,
            title = track.name
        )
        return TrackInfo(
            hint = hint,
            label = track.name,
            selected = track.mpvId == selectedId,
            selectable = true
        )
    }

    override fun selectTrack(selection: TrackSelection) {
        executor.execute {
            val v = view ?: return@execute
            if (selection.disable) {
                when (selection.type) {
                    TrackType.AUDIO -> v.aid = -1
                    TrackType.VIDEO -> v.vid = -1
                    TrackType.SUBTITLE -> v.sid = -1
                }
                return@execute
            }
            selection.hint?.mpvTrackId?.let { id ->
                when (selection.type) {
                    TrackType.AUDIO -> v.aid = id
                    TrackType.VIDEO -> v.vid = id
                    TrackType.SUBTITLE -> v.sid = id
                }
            }
        }
    }

    // ---------------- 快照 ----------------

    override fun getSnapshot(): PlaybackSnapshot {
        var speed = 1f
        var volume = 1f
        executor.execute {
            view?.let {
                speed = it.playbackSpeed.toFloat()
                volume = (it.volume / 100.0).toFloat()
            }
        }
        // 位置/时长优先用缓存（由事件更新），避免阻塞读与回调竞态造成 0 覆盖 → 进度条跳动
        val positionMs = cachedPositionMs.coerceAtLeast(0L)
        val durationMs = cachedDurationMs.coerceAtLeast(0L)
        val req = loadedRequest
        return PlaybackSnapshot(
            request = req ?: PlaybackRequest(uri = android.net.Uri.EMPTY, sourceType = SourceType.UNKNOWN),
            coreType = type,
            positionMs = positionMs,
            durationMs = durationMs,
            speed = speed,
            wasPlaying = wasPlayingMpv,
            volume = volume,
            muted = view?.muted ?: false,
            audioTrackHint = view?.let { TrackHint(TrackType.AUDIO, mpvTrackId = it.aid.takeIf { id -> id >= 0 }) },
            subtitleTrackHints = emptyList(),
            subtitleDelayMs = null,
            audioDelayMs = null,
            fallbackUsed = false,
            lastError = null,
            createdAt = System.currentTimeMillis()
        )
    }

    // ---------------- mpv 专属 ----------------

    override fun command(args: List<String>) {
        executor.post { MPVLib.command(args.toTypedArray()) }
    }

    override fun observeMpvProperty(name: String) {
        executor.post { MPVLib.observeProperty(name, MPVLib.MpvFormat.MPV_FORMAT_STRING) }
    }

    override fun setMpvOption(name: String, value: String): Int {
        return executor.executeWithResult { MPVLib.setOptionString(name, value) } ?: -1
    }

    private fun publishState(state: PlaybackState) {
        playbackState = state
        listener?.onPlaybackStateChanged(state)
    }

    companion object {
        private const val TAG = "MpvPlayerCore"

        /**
         * 检测 mpv 原生库是否可用。
         * 注意：MPVLib 的 init{} 会立即 System.loadLibrary，一旦首次引用 MPVLib 就会尝试加载；
         * 因此此处预先、独立地探活，避免把核心标记为可用但运行时崩溃。
         */
        val isNativeAvailable: Boolean by lazy {
            try {
                System.loadLibrary("mpv")
                System.loadLibrary("player")
                android.util.Log.i(TAG, "mpv 原生库可用（libmpv.so / libplayer.so 已加载），mpv 核心就绪")
                true
            } catch (_: UnsatisfiedLinkError) {
                android.util.Log.w(TAG, "mpv 原生库缺失/加载失败，mpv 核心不可用")
                false
            } catch (_: Throwable) {
                false
            }
        }
    }
}

/** 让 [CoreExecutor] 支持返回结果的同步执行。 */
private fun CoreExecutor.executeWithResult(block: () -> Int): Int? {
    return java.util.concurrent.atomic.AtomicReference<Int?>().let { ref ->
        execute { ref.set(block()) }
        ref.get()
    }
}