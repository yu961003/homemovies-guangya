package com.example.localmovielibrarz.ui.player

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.data.repository.DirectLinkRepository
import com.example.localmovielibrarz.data.repository.GuangyaDirectLinkResolver
import com.example.localmovielibrarz.data.repository.MovieRepository
import com.example.localmovielibrarz.data.repository.PlaybackProgressRepository
import com.example.localmovielibrarz.data.repository.UsageStatsRepository
import com.example.localmovielibrarz.playback.PlaybackRequest
import com.example.localmovielibrarz.playback.PlaybackResolver
import com.example.localmovielibrarz.player.core.PlaybackError
import com.example.localmovielibrarz.player.core.PlaybackState
import com.example.localmovielibrarz.player.core.PlayerCoreLauncher
import com.example.localmovielibrarz.player.core.PlayerCoreListener
import com.example.localmovielibrarz.player.core.PlayerCoreType
import com.example.localmovielibrarz.player.core.TrackModel
import com.example.localmovielibrarz.player.core.TrackHint
import com.example.localmovielibrarz.player.core.TrackSelection
import com.example.localmovielibrarz.player.core.TrackType
import com.example.localmovielibrarz.player.host.PlayerHost
import kotlin.math.abs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * 统一播放器 ViewModel（重构收敛后唯一页面）。
 *
 * 走 PlayerCoreLauncher + PlayerHost + PlayerCoreHost 组合：一个页面，底层 ExoPlayer / mpv
 * 双核心，可手动切换并具备自动回退（看门狗）。在此吸收原 legacy 数据层能力：
 * 续播进度自动保存、播放时长统计、看完标记。
 */
class PlayerViewModel(
    application: Application,
    private val videoUri: Uri,
    private val title: String,
    private val fileName: String,
    private val movieId: Long = -1L,
    directLinkRepository: DirectLinkRepository,
    guangyaDirectLinkResolver: GuangyaDirectLinkResolver,
    private val settingsRepository: AppSettingsRepository,
    private val playbackProgressRepository: PlaybackProgressRepository,
    private val movieRepository: MovieRepository,
    private val usageStatsRepository: UsageStatsRepository
) : AndroidViewModel(application) {

    private val launcher = PlayerCoreLauncher(application, settingsRepository)
    private val resolver = PlaybackResolver(
        application.contentResolver,
        directLinkRepository,
        guangyaDirectLinkResolver
    )
    private val progressPersistenceScope =
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)
    private fun playbackMediaKey(): String = videoUri.toString()
    private var lastPersistedPositionMs = Long.MIN_VALUE
    private var lastPersistedDurationMs = 0L
    private var lastPersistedAtMs = 0L
    private var playbackStartedAt = 0L
    private var hasMarkedWatched = false
    /** 倍速档位（0.75x ~ 4x）。 */
    val speedOptions: List<Float> = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f, 4.0f)
    private var speedIndex = 1

    @Volatile
    private var host: PlayerHost? = null

    private val _uiState = MutableStateFlow(
        PlayerUiState(
            isLoading = true,
            loadingMessage = "正在解析播放地址...",
            title = title.ifBlank { "Movie" }
        )
    )
    val uiState: StateFlow<PlayerUiState> = _uiState

    val currentHost: PlayerHost? get() = host

    /** mpv 是否可用（原生库缺失时为 false，此时只能切到 Exo）。 */
    val canSwitchToMpv: Boolean get() = launcher.isMpvAvailable()

    private val coreListener = object : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) {
            when (state) {
                PlaybackState.PLAYING -> {
                    if (playbackStartedAt <= 0L) playbackStartedAt = SystemClock.elapsedRealtime()
                }
                PlaybackState.PAUSED, PlaybackState.IDLE, PlaybackState.ERROR, PlaybackState.ENDED -> {
                    recordPlaybackTime()
                }
                PlaybackState.READY, PlaybackState.PREPARING, PlaybackState.BUFFERING -> Unit
            }
            _uiState.update { it.copy(state = state, isPlaying = state == PlaybackState.PLAYING) }
        }
        override fun onPositionChanged(positionMs: Long, durationMs: Long) {
            _uiState.update { s ->
                s.copy(
                    positionMs = positionMs.coerceAtLeast(0L),
                    durationMs = durationMs.coerceAtLeast(0L)
                )
            }
        }
        override fun onVideoSizeChanged(width: Int, height: Int) {
            _uiState.update {
                it.copy(
                    videoWidth = width,
                    videoHeight = height,
                    // 竖屏视频（含旋转归一后）自动请求竖屏方向
                    videoOrientation = when {
                        width > 0 && height > width -> VideoOrientation.PORTRAIT
                        width > 0 && width > height -> VideoOrientation.LANDSCAPE
                        else -> VideoOrientation.SQUARE
                    }
                )
            }
        }
        override fun onTracksChanged(tracks: TrackModel) {
            _uiState.update { it.copy(tracks = tracks) }
        }
        override fun onError(error: PlaybackError) {
            // 自动回退已由 PlayerHost 内部处理（§12.4）；这里仅展示残余错误
            _uiState.update { it.copy(errorMessage = error.message ?: error.type.name) }
        }
        override fun onBufferingChanged(buffering: Boolean) {
            _uiState.update { it.copy(buffering = buffering) }
        }
        override fun onPlaybackEnded() {
            _uiState.update { it.copy(isPlaying = false) }
        }
    }

    private val switchCallback: (PlayerHost.SwitchState) -> Unit = { state ->
        _uiState.update { it.copy(switchInProgress = state != PlayerHost.SwitchState.IDLE) }
    }

    init {
        viewModelScope.launch {
            resolveLegacy()?.let { legacy ->
                val resume = playbackProgressRepository
                    .getResumePosition(videoUri.toString())
                    .takeIf { it > 0L }
                val (request, coreType) = launcher.toPlaybackRequest(legacy, startPositionMs = resume)
                val h = launcher.buildHost(coreListener).apply {
                    setSwitchCallback(switchCallback)
                }
                host = h
                _uiState.value = PlayerUiState(
                    title = (legacy.title?.takeIf { it.isNotBlank() } ?: title).ifBlank { "Movie" },
                    coreType = coreType,
                    state = PlaybackState.PREPARING
                )
                h.play(request, coreType)
                pollProgress()
            } ?: run {
                _uiState.value = PlayerUiState(
                    title = title.ifBlank { "Movie" },
                    errorMessage = "解析播放地址失败"
                )
            }
        }
    }

    private suspend fun resolveLegacy(): PlaybackRequest? =
        try {
            withTimeout(30_000L) {
                resolver.resolve(videoUri.toString(), title, fileName, forceRefresh = false)
                    .getOrThrow()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            null
        }

    private suspend fun pollProgress() {
        while (true) {
            val h = host ?: return
            delay(if (_uiState.value.durationMs <= 0L) 250L else 600L)
            val snap = runCatching { h.getSnapshot() }.getOrNull() ?: continue
            _uiState.update { s ->
                s.copy(
                    positionMs = snap.positionMs.coerceAtLeast(0L),
                    durationMs = if (snap.durationMs > 0L) snap.durationMs else s.durationMs,
                    isPlaying = snap.wasPlaying,
                    coreType = h.currentCoreType ?: s.coreType
                )
            }
            // 续播进度自动保存（节流）
            persistProgressThrottled(snap)
            // 接近片尾视为看完
            markMovieWatchedIfNearEnd(snap.positionMs.coerceAtLeast(0L), snap.durationMs)
        }
    }

    private fun persistProgressThrottled(snap: com.example.localmovielibrarz.player.core.PlaybackSnapshot) {
        val position = snap.positionMs.coerceAtLeast(0L)
        val duration = snap.durationMs.takeIf { it > 0L } ?: 0L
        val now = System.currentTimeMillis()

        if (duration <= 0L && position <= 0L) return
        if (position < MIN_AUTOSAVE_POSITION_MS) return

        val positionDelta = if (lastPersistedPositionMs == Long.MIN_VALUE) Long.MAX_VALUE else abs(position - lastPersistedPositionMs)
        val durationStable = abs(duration - lastPersistedDurationMs) <= 1_000L
        val intervalNotReached = now - lastPersistedAtMs < PROGRESS_SAVE_INTERVAL_MS
        if (positionDelta < PROGRESS_SAVE_POSITION_DELTA_MS && durationStable && intervalNotReached) return

        progressPersistenceScope.launch {
            runCatching {
                playbackProgressRepository.save(playbackMediaKey(), position, duration)
            }
        }
        lastPersistedPositionMs = position
        lastPersistedDurationMs = duration
        lastPersistedAtMs = now
    }

    /** 退出/暂停时立即持久化（force）。 */
    private fun persistProgressNow() {
        val snap = runCatching { host?.getSnapshot() }.getOrNull() ?: return
        val position = snap.positionMs.coerceAtLeast(0L)
        val duration = snap.durationMs.takeIf { it > 0L } ?: 0L
        progressPersistenceScope.launch {
            runCatching { playbackProgressRepository.save(playbackMediaKey(), position, duration) }
        }
    }

    /** 播放时长统计：在暂停/结束/销毁时把已播放时长累加到统计库。 */
    private fun recordPlaybackTime() {
        if (playbackStartedAt <= 0L) return
        usageStatsRepository.addPlaybackMillis(SystemClock.elapsedRealtime() - playbackStartedAt)
        playbackStartedAt = 0L
    }

    /** 接近片尾 → 标记影片已看完。 */
    private fun markMovieWatchedIfNearEnd(positionMs: Long, durationMs: Long) {
        if (hasMarkedWatched || movieId <= 0L || durationMs <= 0L) return
        val nearEnd = durationMs - positionMs <= NEAR_END_THRESHOLD_MS ||
            positionMs >= (durationMs * NEAR_END_FRACTION).toLong()
        if (!nearEnd) return
        hasMarkedWatched = true
        progressPersistenceScope.launch {
            runCatching { movieRepository.setWatched(movieId, true) }
        }
    }

    // ---------------- 控制转发 ----------------

    fun togglePlayPause() { host?.togglePlay() }
    fun seekTo(positionMs: Long) {
        host?.seekTo(positionMs)
        persistProgressNow()
    }
    fun seekBy(deltaMs: Long) {
        host?.seekBy(deltaMs)
        _uiState.update { s -> s.copy(positionMs = (s.positionMs + deltaMs).coerceAtLeast(0L)) }
    }
    private var pendingSeekMs: Long? = null

    /** 拖动进度条时的临时位置（仅更新 UI，不真正 seek）。 */
    fun tempSeek(positionMs: Long) {
        pendingSeekMs = positionMs
        _uiState.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    /** 拖动结束：提交实际 seek。 */
    fun commitTempSeek() {
        val target = pendingSeekMs
        pendingSeekMs = null
        if (target != null) {
            host?.seekTo(target)
            persistProgressNow()
        }
    }

    /** 离开播放页：立即保存进度。宿主释放交由 PlayerCoreHost.onDispose 统一处理（幂等），避免三重释放时序竞争。 */
    fun leavePlayer() {
        persistProgressNow()
        recordPlaybackTime()
    }

    override fun onCleared() {
        persistProgressNow()
        recordPlaybackTime()
        progressPersistenceScope.cancel()
        host?.release()
        super.onCleared()
    }
    /** 选中某档倍速并真正应用到当前核心。 */
    fun setSpeed(value: Float) {
        speedOptions.indexOfFirst { kotlin.math.abs(it - value) < 0.001f }
            .takeIf { it >= 0 }
            ?.let { speedIndex = it }
        host?.setSpeed(value)
    }
    /** 当前选中档位。 */
    val selectedSpeed: Float get() = speedOptions[speedIndex]

    fun switchCore(target: PlayerCoreType, onDone: (Boolean) -> Unit = {}) {
        host?.switchCore(target) { r -> onDone(r.isSuccess) }
    }

    // ---------------- 轨道选择（§6.10 / Phase 7 对齐） ----------------

    fun selectAudioTrack(hint: TrackHint?) {
        host?.selectTrack(TrackSelection(TrackType.AUDIO, hint))
    }

    fun disableAudioTrack() {
        host?.selectTrack(TrackSelection(TrackType.AUDIO, hint = null, disable = true))
    }

    fun selectSubtitleTrack(hint: TrackHint?, disable: Boolean = false) {
        host?.selectTrack(TrackSelection(TrackType.SUBTITLE, hint, disable = disable))
    }

    companion object {
        private const val PROGRESS_SAVE_INTERVAL_MS = 15_000L
        private const val PROGRESS_SAVE_POSITION_DELTA_MS = 10_000L
        private const val MIN_AUTOSAVE_POSITION_MS = 5_000L
        private const val NEAR_END_THRESHOLD_MS = 60_000L
        private const val NEAR_END_FRACTION = 0.95f

        fun factory(
            application: Application,
            videoUri: Uri,
            title: String,
            fileName: String,
            movieId: Long = -1L,
            directLinkRepository: DirectLinkRepository,
            guangyaDirectLinkResolver: GuangyaDirectLinkResolver,
            settingsRepository: AppSettingsRepository,
            playbackProgressRepository: PlaybackProgressRepository,
            movieRepository: MovieRepository,
            usageStatsRepository: UsageStatsRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return PlayerViewModel(
                    application = application,
                    videoUri = videoUri,
                    title = title,
                    fileName = fileName,
                    movieId = movieId,
                    directLinkRepository = directLinkRepository,
                    guangyaDirectLinkResolver = guangyaDirectLinkResolver,
                    settingsRepository = settingsRepository,
                    playbackProgressRepository = playbackProgressRepository,
                    movieRepository = movieRepository,
                    usageStatsRepository = usageStatsRepository
                ) as T
            }
        }
    }
}

/** 统一播放 UI 状态容器。 */
data class PlayerUiState(
    val isLoading: Boolean = false,
    val loadingMessage: String? = null,
    val title: String = "Movie",
    val coreType: PlayerCoreType? = null,
    val state: PlaybackState = PlaybackState.IDLE,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val errorMessage: String? = null,
    val switchInProgress: Boolean = false,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val videoOrientation: VideoOrientation = VideoOrientation.SQUARE,
    val tracks: TrackModel = TrackModel.EMPTY
)

/** 视频有效方向（用于自动转屏）。 */
enum class VideoOrientation { PORTRAIT, LANDSCAPE, SQUARE }