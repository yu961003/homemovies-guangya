package com.example.localmovielibrarz.player.core

import android.net.Uri

/**
 * 双核心播放器统一播放请求（v5 设计方案 §6.1）。
 *
 * 该模型独立于现有 [com.example.localmovielibrarz.playback.PlaybackRequest]，
 * 由 [PlaybackRequestMapper] 将现有 PlaybackResolver 的输出转换而来。
 */
data class PlaybackRequest(
    val uri: Uri,
    val sourceType: SourceType = SourceType.UNKNOWN,
    val title: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val startPositionMs: Long? = null,
    val autoplay: Boolean = true,
    val subtitleSources: List<SubtitleSource> = emptyList(),
    val audioTrackHint: TrackHint? = null,
    val subtitleTrackHints: List<TrackHint> = emptyList(),
    val fallbackPolicy: FallbackPolicy = FallbackPolicy.AUTO,
    val origin: PlaybackOrigin = PlaybackOrigin.USER
)

enum class SourceType {
    LOCAL_FILE,
    HTTP_PROGRESSIVE,
    HLS,
    DASH,
    RTSP,
    UNKNOWN
}

enum class FallbackPolicy {
    AUTO,
    DISABLED,
    FORCE_MPV,
    FORCE_EXOPLAYER
}

enum class PlaybackOrigin {
    USER,
    EXTERNAL_INTENT,
    INTERNAL_SWITCH,
    FALLBACK
}

/** 字幕源（§6.2）。 */
data class SubtitleSource(
    val uri: Uri,
    val mimeType: String? = null,
    val language: String? = null,
    val label: String? = null,
    val isExternal: Boolean = true,
    val isAutoSelect: Boolean = false
)

/** 轨道提示，用于在核心之间移植轨道选择（§6.3）。 */
data class TrackHint(
    val type: TrackType,
    val mpvTrackId: Int? = null,
    val exoTrackGroupIndex: Int? = null,
    val exoTrackIndex: Int? = null,
    val language: String? = null,
    val title: String? = null,
    val mimeType: String? = null,
    val channels: Int? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false
)

enum class TrackType { VIDEO, AUDIO, SUBTITLE }