package com.example.localmovielibrarz.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrarz.player.core.PlayerCoreType
import com.example.localmovielibrarz.player.core.TrackHint
import com.example.localmovielibrarz.player.core.TrackInfo
import com.example.localmovielibrarz.player.host.PlayerCoreHost
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

/**
 * 双核心播放器屏幕（v5 §9）。
 *
 * 用 [PlayerCoreHost] 承载 PlayerHost 注入的渲染容器；控制层通过 VM 转发到当前核心。
 * 独立于既有 [PlayerScreen]：默认 Exo 行为不受影响，仅经双核心路由进入。
 */
@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val host = viewModel.currentHost

    // 播放时常亮（与既有播放页一致）
    DisposableEffect(activity) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // 沉浸式全屏（与 Exo 播放页一致）：禁用装饰窗口适配、隐藏系统栏，仅靠滑动手势临时唤出
    DisposableEffect(activity) {
        val window = activity?.window
        val view = activity?.window?.decorView
        val controller = window?.let { w -> view?.let { v -> WindowInsetsControllerCompat(w, v) } }
        window?.let { WindowCompat.setDecorFitsSystemWindows(it, false) }
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            window?.let { WindowCompat.setDecorFitsSystemWindows(it, true) }
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // 系统返回同样先保存进度再退出
    BackHandler {
        viewModel.leavePlayer()
        onBack()
    }

    // mpv/Exo 自动转屏：根据视频有效方向设置屏幕方向（竖屏视频竖放、横屏视频横放）。
    // 未知(SQUARE)时保持系统默认，不强制。
    DisposableEffect(activity, uiState.videoOrientation) {
        activity?.requestedOrientation = when (uiState.videoOrientation) {
            VideoOrientation.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            VideoOrientation.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            VideoOrientation.SQUARE -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // 控制条显隐状态：点击画面切换显示/隐藏；显示 3.5s 后无操作自动隐藏（与 Exo 播放页一致）
    var controlsVisible by remember { mutableStateOf(true) }

    // 倍速选择菜单展开状态
    var speedMenuExpanded by remember { mutableStateOf(false) }

    // ---- 滑动手势（灵敏度与 Exo 播放页完全一致，§mpv） ----
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    var gestureMode by remember { mutableStateOf<GestureEdgeMode?>(null) }
    var gestureStartSide by remember { mutableStateOf<GestureEdgeSide?>(null) }
    var gestureFeedback by remember { mutableStateOf<GestureEdgeFeedback?>(null) }
    var seekDragStartPositionMs by remember { mutableLongStateOf(0L) }
    var seekDragTotalX by remember { mutableFloatStateOf(0f) }
    var seekDragTotalY by remember { mutableFloatStateOf(0f) }
    var seekDragPreviewMs by remember { mutableStateOf<Long?>(null) }
    var brightnessValue by remember(activity) {
        mutableFloatStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f)
    }
    // 进入播放页前的原始屏幕亮度，离开时恢复
    val originalScreenBrightness = remember(activity) {
        activity?.window?.attributes?.screenBrightness
            ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
    }
    var volumeValue by remember(audioManager) {
        mutableFloatStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat())
    }
    // 离开页面时恢复亮度，避免手势调低后遗留
    DisposableEffect(activity) {
        onDispose {
            val window = activity?.window
            if (window != null) {
                val attrs = window.attributes
                attrs.screenBrightness = originalScreenBrightness
                window.attributes = attrs
            }
        }
    }

    fun setBrightness(value: Float) {
        val window = activity?.window ?: return
        brightnessValue = value.coerceIn(0.02f, 1f)
        val attrs = window.attributes
        attrs.screenBrightness = brightnessValue
        window.attributes = attrs
        gestureFeedback = GestureEdgeFeedback(
            side = GestureEdgeSide.Brightness,
            percent = (brightnessValue * 100f).roundToInt().coerceIn(0, 100),
            version = System.nanoTime()
        )
    }

    fun setVolume(value: Float) {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volumeValue = value.coerceIn(0f, maxVolume.toFloat())
        val targetVolume = volumeValue.roundToInt().coerceIn(0, maxVolume)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
        gestureFeedback = GestureEdgeFeedback(
            side = GestureEdgeSide.Volume,
            percent = ((targetVolume.toFloat() / maxVolume.toFloat()) * 100f).roundToInt().coerceIn(0, 100),
            version = System.nanoTime()
        )
    }

    // 亮度/音量反馈浮层短暂显示后自动消失（与 Exo 一致）
    LaunchedEffect(gestureFeedback?.version, gestureStartSide) {
        if (gestureFeedback != null && gestureStartSide == null) {
            delay(850)
            gestureFeedback = null
        }
    }

    // 自动隐藏：显示后定时关闭
    LaunchedEffect(controlsVisible) {
        if (controlsVisible) {
            delay(3500)
            controlsVisible = false
        }
    }

    // 画面点按层：点击视频区域切换控制条显隐；拖动（滑动手势）与 Exo 播放页一致
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(
                if (host != null || uiState.errorMessage != null) {
                    Modifier.pointerInput(activity, audioManager) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                gestureMode = null
                                gestureStartSide =
                                    if (offset.x < size.width / 2f) GestureEdgeSide.Brightness else GestureEdgeSide.Volume
                                seekDragStartPositionMs = uiState.positionMs
                                seekDragTotalX = 0f
                                seekDragTotalY = 0f
                                seekDragPreviewMs = null
                            },
                            onDragEnd = {
                                seekDragPreviewMs?.let { target ->
                                    viewModel.seekTo(target)
                                }
                                seekDragPreviewMs = null
                                gestureMode = null
                                gestureStartSide = null
                            },
                            onDragCancel = {
                                seekDragPreviewMs = null
                                gestureMode = null
                                gestureStartSide = null
                            },
                            onDrag = { change, dragAmount ->
                                seekDragTotalX += dragAmount.x
                                seekDragTotalY += dragAmount.y
                                if (gestureMode == null) {
                                    val threshold = 18f
                                    if (abs(seekDragTotalX) < threshold && abs(seekDragTotalY) < threshold) {
                                        return@detectDragGestures
                                    }
                                    gestureMode = if (abs(seekDragTotalX) > abs(seekDragTotalY)) {
                                        GestureEdgeMode.Seek
                                    } else {
                                        GestureEdgeMode.VerticalAdjust
                                    }
                                }
                                if (gestureMode == GestureEdgeMode.Seek) {
                                    if (uiState.durationMs <= 0L) return@detectDragGestures
                                    // 每屏可拖动全片 10%，限幅 30s~180s
                                    val seekPerScreenMs = (uiState.durationMs * 0.10f)
                                        .toLong()
                                        .coerceIn(30_000L, 180_000L)
                                    val deltaMs = ((seekDragTotalX / size.width.coerceAtLeast(1)) * seekPerScreenMs).toLong()
                                    seekDragPreviewMs = (seekDragStartPositionMs + deltaMs).coerceIn(0L, uiState.durationMs)
                                    controlsVisible = false
                                } else {
                                    val delta = -dragAmount.y / size.height.coerceAtLeast(1)
                                    when (gestureStartSide) {
                                        GestureEdgeSide.Brightness -> {
                                            setBrightness(brightnessValue + delta * 1.15f)
                                            controlsVisible = true
                                        }
                                        GestureEdgeSide.Volume -> {
                                            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                            setVolume(volumeValue + delta * maxVolume * 1.25f)
                                            controlsVisible = true
                                        }
                                        null -> Unit
                                    }
                                }
                            }
                        )
                    }
                } else Modifier
            )
            .then(
                if (host != null || uiState.errorMessage != null) {
                    Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { controlsVisible = !controlsVisible }
                } else Modifier
            )
    ) {
        // ---------- 渲染容器 / 加载 / 错误 ----------
        when {
            host != null -> {
                PlayerCoreHost(
                    playerHost = host,
                    modifier = Modifier.fillMaxSize()
                )
            }
            uiState.errorMessage != null -> {
                Text(
                    text = uiState.errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
            }
            else -> {
                CircularProgressIndicator(
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(48.dp)
                )
                Text(
                    text = uiState.loadingMessage ?: "正在启动...",
                    color = Color.White.copy(alpha = 0.78f),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(top = 120.dp)
                )
            }
        }

        // ---------- 中心浮层：亮度/音量反馈 + 拖动进度预览 ----------
        GestureEdgeFeedbackOverlay(
            feedback = gestureFeedback,
            modifier = Modifier.align(Alignment.Center)
        )
        EdgeSeekDragOverlay(
            targetPositionMs = seekDragPreviewMs,
            startPositionMs = seekDragStartPositionMs,
            modifier = Modifier.align(Alignment.Center)
        )

        // ---------- 顶栏（随控制条显隐） ----------
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth()
            ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = {
                    viewModel.leavePlayer()
                    onBack()
                }) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "返回",
                        tint = Color.White
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = uiState.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    )
                    // 标题下方保留精简的「核心 + 状态」一行，字号小、不遮挡画面主体
                    Text(
                        text = buildString {
                            append(titleLineTitle(uiState.coreType, viewModel.canSwitchToMpv))
                            if (uiState.isPlaying) append(" · 播放中")
                            else if (uiState.buffering) append(" · 缓冲中")
                        },
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
                Spacer(Modifier.width(8.dp))
                TrackMenu(
                    enabled = host != null,
                    hasAudio = uiState.tracks.audioTracks.isNotEmpty(),
                    audioTracks = uiState.tracks.audioTracks,
                    hasSubtitle = uiState.tracks.subtitleTracks.isNotEmpty(),
                    subtitleTracks = uiState.tracks.subtitleTracks,
                    onSelectAudio = { viewModel.selectAudioTrack(it) },
                    onDisableAudio = { viewModel.disableAudioTrack() },
                    onSelectSubtitle = { viewModel.selectSubtitleTrack(it) },
                    onDisableSubtitle = { viewModel.selectSubtitleTrack(null, disable = true) }
                )
                Spacer(Modifier.width(8.dp))
                CoreSwitcher(
                    enabled = host != null,
                    canSwitchToMpv = viewModel.canSwitchToMpv,
                    current = uiState.coreType ?: PlayerCoreType.EXOPLAYER,
                    switching = uiState.switchInProgress,
                    onSwitch = { viewModel.switchCore(it) }
                )
                }
            }
        }

        // ---------- 底部控制（随控制条显隐） ----------
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "${formatTime(uiState.positionMs)} / ${formatTime(uiState.durationMs)}"
                        + if (uiState.buffering) "（缓冲中）" else "",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium
                )
                if (uiState.durationMs > 0L) {
                    Slider(
                        value = uiState.positionMs.toFloat().coerceIn(0f, uiState.durationMs.toFloat()),
                        onValueChange = { viewModel.tempSeek(it.toLong()) },
                        onValueChangeFinished = { viewModel.commitTempSeek() },
                        valueRange = 0f..uiState.durationMs.toFloat(),
                        enabled = host != null,
                        colors = androidx.compose.material3.SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White.copy(alpha = 0.9f),
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ControlIconButton(
                        onClick = { viewModel.seekBy(-10_000L) },
                        icon = { Icon(Icons.Rounded.Replay10, "后退10秒", tint = Color.White) },
                        enabled = host != null
                    )
                    ControlIconButton(
                        onClick = { viewModel.togglePlayPause() },
                        icon = {
                            Icon(
                                if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (uiState.isPlaying) "暂停" else "播放",
                                tint = Color.White
                            )
                        },
                        enabled = host != null
                    )
                    ControlIconButton(
                        onClick = { viewModel.seekBy(10_000L) },
                        icon = { Icon(Icons.Rounded.Forward10, "前进10秒", tint = Color.White) },
                        enabled = host != null
                    )
                    Spacer(Modifier.weight(1f))
                    // 倍速：点击弹出选择菜单（0.75x ~ 4x，当前项加粗 + 勾选）
                    Box {
                        ControlIconButton(
                            onClick = { if (host != null) speedMenuExpanded = true },
                            icon = { Icon(Icons.Rounded.Speed, "倍速", tint = Color.White) },
                            enabled = host != null,
                            label = "x${formatSpeed(viewModel.selectedSpeed)}"
                        )
                        DropdownMenu(
                            expanded = speedMenuExpanded,
                            onDismissRequest = { speedMenuExpanded = false }
                        ) {
                            viewModel.speedOptions.forEach { s ->
                                val selectedOpt = s == viewModel.selectedSpeed
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "x${formatSpeed(s)}",
                                            fontWeight = if (selectedOpt) FontWeight.Bold else FontWeight.Normal,
                                            color = Color.White
                                        )
                                    },
                                    trailingIcon = if (selectedOpt) {
                                        { Text("✓", color = Color.White, fontWeight = FontWeight.Bold) }
                                    } else null,
                                    onClick = {
                                        speedMenuExpanded = false
                                        viewModel.setSpeed(s)
                                    }
                                )
                            }
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun ControlIconButton(
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    enabled: Boolean,
    label: String? = null
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, enabled = enabled) {
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { icon() }
        }
        label?.let {
            Text(it, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
        }
    }
}

/** 顶栏标题下方的一行简短核心/状态说明。 */
private fun titleLineTitle(coreType: PlayerCoreType?, canSwitchToMpv: Boolean): String = when {
    coreType == PlayerCoreType.MPV -> "核心：mpv"
    !canSwitchToMpv -> "核心：ExoPlayer（mpv 未集成）"
    else -> "核心：ExoPlayer"
}

@Composable
private fun CoreSwitcher(
    enabled: Boolean,
    canSwitchToMpv: Boolean,
    current: PlayerCoreType,
    switching: Boolean,
    onSwitch: (PlayerCoreType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    // 单个「核心按钮」：图标 + 当前核心名，点击弹出菜单切换。紧凑、显示核心信息、可切换，不遮挡画面。
    val label = when {
        switching -> "切换中"
        !canSwitchToMpv -> "Exo"
        else -> current.label()
    }
    val tintButColor = when (current) {
        PlayerCoreType.MPV -> Color(0xFF4CAF50)
        else -> if (!canSwitchToMpv) Color(0xFFFFB300) else Color(0xFF29B6F6)
    }
    Box {
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = Color.Black.copy(alpha = 0.45f),
            onClick = { if (enabled && !switching) expanded = true },
            enabled = enabled && !switching
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
                if (switching) {
                    CircularProgressIndicator(
                        color = Color.White,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(14.dp)
                    )
                } else {
                    Icon(
                        Icons.Rounded.SwapHoriz,
                        contentDescription = "切换核心",
                        tint = tintButColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Spacer(Modifier.width(4.dp))
                Text(
                    text = label,
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { Text("ExoPlayer（联网宽带流/常规）") },
                onClick = {
                    expanded = false
                    if (current != PlayerCoreType.EXOPLAYER) onSwitch(PlayerCoreType.EXOPLAYER)
                }
            )
            DropdownMenuItem(
                text = { Text(if (canSwitchToMpv) "mpv（格式兼容性更强）" else "mpv（不可用）") },
                enabled = canSwitchToMpv,
                onClick = {
                    expanded = false
                    if (canSwitchToMpv && current != PlayerCoreType.MPV) onSwitch(PlayerCoreType.MPV)
                }
            )
        }
    }
}

private fun PlayerCoreType.label(): String = when (this) {
    PlayerCoreType.EXOPLAYER -> "ExoPlayer"
    PlayerCoreType.MPV -> "mpv"
}

@Composable
private fun TrackMenu(
    enabled: Boolean,
    hasAudio: Boolean,
    audioTracks: List<TrackInfo>,
    hasSubtitle: Boolean,
    subtitleTracks: List<TrackInfo>,
    onSelectAudio: (TrackHint?) -> Unit,
    onDisableAudio: () -> Unit,
    onSelectSubtitle: (TrackHint?) -> Unit,
    onDisableSubtitle: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var audioDialog by remember { mutableStateOf(false) }
    var subtitleDialog by remember { mutableStateOf(false) }
    IconButton(onClick = { if (enabled) expanded = true }, enabled = enabled) {
        Icon(Icons.Rounded.ClosedCaption, "轨道", tint = Color.White)
    }
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        DropdownMenuItem(
            text = { Text("音轨（${audioTracks.size}）") },
            enabled = hasAudio,
            onClick = { expanded = false; audioDialog = true }
        )
        DropdownMenuItem(
            text = { Text("字幕（${subtitleTracks.size}）") },
            enabled = hasSubtitle,
            onClick = { expanded = false; subtitleDialog = true }
        )
    }
    if (audioDialog) {
        TrackListDialog(
            title = "选择音轨",
            tracks = audioTracks,
            onDismiss = { audioDialog = false },
            onSelect = { hint -> onSelectAudio(hint); audioDialog = false }
        )
    }
    if (subtitleDialog) {
        TrackListDialog(
            title = "选择字幕",
            tracks = subtitleTracks,
            onDismiss = { subtitleDialog = false },
            onSelect = { hint -> onSelectSubtitle(hint); subtitleDialog = false }
        )
    }
}

@Composable
private fun TrackListDialog(
    title: String,
    tracks: List<TrackInfo>,
    onDismiss: () -> Unit,
    onSelect: (TrackHint?) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                tracks.forEach { info ->
                    ListItem(
                        headlineContent = { Text(info.label ?: "轨道", maxLines = 1) },
                        trailingContent = if (info.selected) {
                            { Text("✓", color = Color.White) }
                        } else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(info.hint) }
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } }
    )
}

private fun formatTime(ms: Long): String {
    val absMs = if (ms < 0) -ms else ms
    val totalSec = absMs / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) String.format(Locale.ROOT, "%02d:%02d:%02d", h, m, s)
    else String.format(Locale.ROOT, "%02d:%02d", m, s)
}

private fun formatSpeed(v: Float): String =
    try {
        if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()
    } catch (_: Throwable) {
        v.toString()
    }

// ---------------- 滑动手势类型（重命名为 GestureEdge*，避免与 PlayerScreen 顶层私有声明冲突） ----------------

private enum class GestureEdgeSide {
    Brightness,
    Volume
}

private enum class GestureEdgeMode {
    Seek,
    VerticalAdjust
}

private data class GestureEdgeFeedback(
    val side: GestureEdgeSide,
    val percent: Int,
    val version: Long
)

/** 亮度/音量调节的百分比反馈浮层（与 Exo 播放页一致）。 */
@Composable
private fun GestureEdgeFeedbackOverlay(
    feedback: GestureEdgeFeedback?,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = feedback != null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        val current = feedback ?: return@AnimatedVisibility
        val isVolumeMuted = current.side == GestureEdgeSide.Volume && current.percent == 0
        val icon = when {
            current.side == GestureEdgeSide.Brightness -> Icons.Rounded.Brightness6
            isVolumeMuted -> Icons.Rounded.VolumeOff
            else -> Icons.Rounded.VolumeUp
        }
        val label = when (current.side) {
            GestureEdgeSide.Brightness -> "亮度"
            GestureEdgeSide.Volume -> "音量"
        }
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(Color.Black.copy(alpha = 0.62f))
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(38.dp)
            )
            Text(
                text = "$label ${current.percent}%",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            LinearProgressIndicator(
                progress = { current.percent / 100f },
                modifier = Modifier
                    .width(156.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.24f)
            )
        }
    }
}

/** 左右拖动进度时的中心时间浮层（松手后才真正 seek，与 Exo 播放页一致）。 */
@Composable
private fun EdgeSeekDragOverlay(
    targetPositionMs: Long?,
    startPositionMs: Long,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = targetPositionMs != null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        val target = targetPositionMs ?: return@AnimatedVisibility
        val deltaSeconds = ((target - startPositionMs) / 1000).toInt()
        val deltaText = when {
            deltaSeconds > 0 -> "+${formatSeekDelta(deltaSeconds)}"
            deltaSeconds < 0 -> "-${formatSeekDelta(-deltaSeconds)}"
            else -> "0:00"
        }
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(Color.Black.copy(alpha = 0.66f))
                .padding(horizontal = 26.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = deltaText,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = formatTime(target),
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun formatSeekDelta(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) String.format(Locale.ROOT, "%d:%02d", m, s)
    else String.format(Locale.ROOT, "0:%02d", s)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}