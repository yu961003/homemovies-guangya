package com.example.localmovielibrarz.player.core

/** 播放核心类型（§6.5）。 */
enum class PlayerCoreType {
    EXOPLAYER,
    MPV
}

/** 播放器状态（§6.7）。 */
enum class PlaybackState {
    IDLE,
    PREPARING,
    READY,
    BUFFERING,
    PLAYING,
    PAUSED,
    ERROR,
    ENDED
}

/** 能力枚举（§6.11）。 */
enum class PlayerCapability {
    /** mpv：高级字幕样式 / 位置布局。 */
    ADVANCED_SUB_STYLE,
    /** mpv：副字幕。 */
    SECONDARY_SUBTITLE,
    /** mpv：截图。 */
    SCREENSHOT,
    /** mpv：缩放器 / 去带。 */
    SCALER_DEBAND,
    /** Exo：自适应流（HLS / DASH）。 */
    ADAPTIVE_STREAM,
    /** Exo：DRM。 */
    DRM,
    /** 字幕延迟。 */
    SUBTITLE_DELAY,
    /** 音轨延迟。 */
    AUDIO_DELAY,
    /** 运行时：硬解可用。 */
    HWDEC_AVAILABLE,
    /** 媒体能力：可 seek。 */
    MEDIA_SEEKABLE,
    /** 媒体能力：直播流。 */
    MEDIA_LIVE,
    /** 媒体能力：含音轨。 */
    MEDIA_HAS_AUDIO_TRACKS,
    /** 媒体能力：含字幕。 */
    MEDIA_HAS_SUBTITLES
}