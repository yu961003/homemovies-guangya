package com.example.localmovielibrarz.ui.guangya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import com.example.localmovielibrarz.cloudguangya.GuangyaFolderRef
import com.example.localmovielibrarz.cloudguangya.GuangyaOfflineProgress
import com.example.localmovielibrarz.ui.settings.settingsTextFieldColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 光鸭云盘浏览 / 添加界面（操作逻辑对齐 115 CloudBrowserScreen）。
 * 已接入导航图（Route.GuangyaBrowser），也可嵌入网盘 tab（topInsetHandled=true 时由外层切换栏处理状态栏）。
 *
 * - 点视频 = 播放（onPlayVideo 回调，AppRoot 构造 guangya://guangya_res/$fileId 交给播放器）。
 * - 行右侧「添加」= 入库并自动刮削；目录行「添加」= 递归添加整个文件夹（带确认弹窗）。
 * - 「离线下载」= 完整功能版：txt 批量导入 + 记忆去重/黑名单 + 每日限额 + 3 路并发 + 暂停/继续 + 文件夹选择 + 记忆导出/导入。
 */
@Composable
fun GuangyaBrowserScreen(
    viewModel: GuangyaBrowserViewModel,
    onBack: () -> Unit,
    onPlayVideo: (GuangyaFileItem) -> Unit,
    topInsetHandled: Boolean = false
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val offlineProgress by viewModel.offlineProgress.collectAsStateWithLifecycle()
    val offlineLogs by viewModel.offlineLogs.collectAsStateWithLifecycle()
    val statusBarPadding = if (topInsetHandled) Modifier else Modifier.windowInsetsPadding(WindowInsets.statusBars)
    var pendingFolder by remember { mutableStateOf<GuangyaFileItem?>(null) }
    var showOfflineDialog by remember { mutableStateOf(false) }

    // 系统返回（含手势左滑）：先返回上级目录，栈空才退出页面
    fun handleBack() {
        if (viewModel.canGoBackFolder()) {
            viewModel.goUp()
        } else {
            onBack()
        }
    }
    BackHandler(onBack = ::handleBack)

    // 对齐 115「懒加载浏览」体验：按目录记忆 LazyListState 滚动位置，
    // 返回上级 / 重新进入某目录时恢复到上次浏览位置。
    val currentParentId = state.currentParentId
    val savedScroll = remember(currentParentId) { viewModel.scrollPositionFor(currentParentId) }
    val listState = rememberSaveable(currentParentId, saver = LazyListState.Saver) {
        LazyListState(
            firstVisibleItemIndex = savedScroll.firstVisibleItemIndex,
            firstVisibleItemScrollOffset = savedScroll.firstVisibleItemScrollOffset
        )
    }

    // 持续保存当前目录滚动位置
    LaunchedEffect(currentParentId, listState) {
        snapshotFlow {
            listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset
        }.collect { (index, offset) ->
            viewModel.saveScrollPosition(currentParentId, index, offset)
        }
    }

    // 提示信息自动清除
    LaunchedEffect(state.message) {
        state.message?.let {
            delay(2_500)
            viewModel.clearMessage()
        }
    }

    if (!viewModel.isLoggedIn()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(statusBarPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "尚未登录光鸭云盘",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "请先到「设置 → 网盘设置 → 光鸭云盘」完成手机号登录，再来浏览网盘并添加影片。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f),
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onBack) { Text("返回") }
        }
        return
    }

    LaunchedEffect(Unit) {
        if (state.files.isEmpty() && state.error == null && !state.loading) {
            viewModel.restoreOrRoot()
        }
    }

    pendingFolder?.let { folder ->
        AlertDialog(
            onDismissRequest = { pendingFolder = null },
            title = { Text("添加整个文件夹？") },
            text = {
                Text(
                    "确认后会递归读取“${folder.name}”内的视频，逐个入库并自动刮削。"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingFolder = null
                        viewModel.addFolderToLibrary(folder)
                    }
                ) {
                    Text("开始添加")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingFolder = null }) {
                    Text("取消")
                }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        GuangyaTopBar(
            path = state.path,
            onBack = ::handleBack,
            topInsetHandled = topInsetHandled
        )

        // 快捷导航：返回上级（可返回时）+ 根目录（随时脱困）+ 离线下载（主操作，样式区分）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row {
                if (viewModel.canGoBackFolder()) {
                    TextButton(onClick = viewModel::goUp) {
                        Text("返回上级")
                    }
                }
                TextButton(
                    onClick = viewModel::enterRoot,
                    enabled = !state.loading
                ) {
                    Text("根目录")
                }
            }
            OutlinedButton(
                onClick = { showOfflineDialog = true },
                enabled = !state.loading,
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("离线下载")
            }
        }

        // 完整版离线下载面板
        if (showOfflineDialog) {
            OfflineDownloadDialog(
                viewModel = viewModel,
                progress = offlineProgress,
                logs = offlineLogs,
                defaultParentId = state.currentParentId,
                onDismiss = { showOfflineDialog = false }
            )
        }

        state.message?.let { msg ->
            Text(
                text = msg,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        state.error?.let { err ->
            Text(
                text = "出错：$err",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        when {
            state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onSurface)
            }
            state.error != null && state.files.isEmpty() -> Unit // 错误已在上方展示
            state.files.isEmpty() -> Box(
                Modifier.fillMaxSize().padding(18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "这个目录是空的",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.74f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(14.dp)
            ) {
                items(state.files, key = { it.fileId }) { file ->
                    GuangyaFileRow(
                        file = file,
                        isAdding = file.fileId in state.addingFileIds,
                        isAdded = file.fileId in state.addedFileIds,
                        onOpen = {
                            if (file.isDir) {
                                viewModel.openFolder(file)
                            } else {
                                onPlayVideo(file)
                            }
                        },
                        onAdd = {
                            if (file.isDir) pendingFolder = file else viewModel.addVideoToLibrary(file)
                        }
                    )
                }
                // 自动分页加载更多：footer 进入组合(接近视口)即请求下一页
                if (state.hasMore) {
                    item(key = "load-more") {
                        LoadMoreFooter(loading = state.loadingMore)
                        LaunchedEffect(state.files.size, state.hasMore, state.loadingMore) {
                            viewModel.loadMoreFiles()
                        }
                    }
                }
            }
        }
    }
}

// ==================== 离线下载完整面板 ====================

/** 列目录触底加载更多 footer：加载中显示进度环，否则显示占位文本（滚动接近时自动触发下一页）。 */
@Composable
private fun LoadMoreFooter(loading: Boolean) {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            Text(
                text = "加载更多...",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OfflineDownloadDialog(
    viewModel: GuangyaBrowserViewModel,
    progress: GuangyaOfflineProgress,
    logs: List<String>,
    defaultParentId: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var offlineText by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<OfflineParsePreview?>(null) }
    var limitInput by remember { mutableStateOf(viewModel.offlineDailyLimit().toString()) }
    var showFolderPicker by remember { mutableStateOf(false) }
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var pendingClearMemory by remember { mutableStateOf(false) }

    val targetFolder by viewModel.offlineTargetFolderFlow.collectAsStateWithLifecycle()

    // 按钮统一样式
    val dialogButtonShape = RoundedCornerShape(14.dp)

    // 选本地 txt（SAF），自动填充并解析
    val txtLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val text = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
            } ?: ""
            offlineText = text
            preview = viewModel.parseOfflineText(text)
        }
    }

    // 内容较多，改用 ModalBottomSheet 提供更好的滚动体验（避免 AlertDialog 内容超出屏幕）
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "离线下载",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 4.dp)
            )
                // 1. 目标文件夹
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "目标文件夹：${targetFolder?.name ?: "（当前目录）"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { showFolderPicker = true },
                        shape = dialogButtonShape
                    ) {
                        Text("选择文件夹")
                    }
                    if (targetFolder != null) {
                        OutlinedButton(
                            onClick = { viewModel.setOfflineTargetFolder(null) },
                            shape = dialogButtonShape
                        ) {
                            Text("清除")
                        }
                    }
                }

                // 2. 输入区
                OutlinedTextField(
                    value = offlineText,
                    onValueChange = {
                        offlineText = it
                        preview = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("磁力链接 / .torrent URL / ed2k（每行一个）") },
                    minLines = 4,
                    maxLines = 6,
                    shape = dialogButtonShape,
                    colors = settingsTextFieldColors(),
                    trailingIcon = {
                        if (offlineText.isNotBlank()) {
                            IconButton(onClick = { offlineText = ""; preview = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = "清空")
                            }
                        }
                    },
                    placeholder = { Text("magnet:?xt=urn:btih:...\n或 40 位 hex / 32 位 base32\n或直接选本地 txt 文件") }
                )
                OutlinedButton(
                    onClick = { txtLauncher.launch(arrayOf("text/plain", "text/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = dialogButtonShape
                ) {
                    Text("选本地 txt 导入")
                }

                // 3. 解析统计
                preview?.let { p ->
                    val pendingCount = p.magnets.size
                    Text(
                        text = buildString {
                            append("识别 $pendingCount 个 · 待提交 ${(pendingCount - p.submittedSkip - p.failedSkip).coerceAtLeast(0)} 个")
                            if (p.submittedSkip > 0) append(" · 已提交跳过 ${p.submittedSkip}")
                            if (p.failedSkip > 0) append(" · 黑名单跳过 ${p.failedSkip}")
                        },
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                // 4. 每日限额 — label 固定 64dp，输入框 weight(1f)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "每日限额",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                        modifier = Modifier.width(64.dp)
                    )
                    OutlinedTextField(
                        value = limitInput,
                        onValueChange = { limitInput = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall,
                        shape = dialogButtonShape,
                        colors = settingsTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    TextButton(
                        onClick = {
                            val n = limitInput.toIntOrNull()
                            if (n != null && n in 1..100000) {
                                viewModel.setOfflineDailyLimit(n)
                            } else {
                                limitInput = viewModel.offlineDailyLimit().toString()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("保存", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                    Text(
                        text = "${viewModel.offlineTodayCount()}/${viewModel.offlineDailyLimit()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f),
                        maxLines = 1
                    )
                }

                // 5. 操作按钮 — 统一 44dp 高度，maxLines=1 防换行
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            if (preview == null) {
                                preview = viewModel.parseOfflineText(offlineText)
                            } else if (preview!!.magnets.isNotEmpty()) {
                                // 开始上传前自动保存当前输入的限额值，避免用户忘了点保存
                                val n = limitInput.toIntOrNull()
                                if (n != null && n in 1..100000) viewModel.setOfflineDailyLimit(n)
                                val parentId = targetFolder?.fileId ?: defaultParentId
                                viewModel.startOffline(preview!!.magnets, parentId)
                            }
                        },
                        enabled = !progress.running,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(
                            if (preview == null) "解析" else "开始上传",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (progress.running) {
                        Button(
                            onClick = {
                                if (progress.paused) viewModel.resumeOffline() else viewModel.pauseOffline()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text(
                                if (progress.paused) "继续" else "暂停",
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1
                            )
                        }
                        OutlinedButton(
                            onClick = viewModel::cancelOffline,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text("停止", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                    }
                }

                // 6. 进度
                if (progress.running) {
                    LinearProgressIndicator(
                        progress = {
                            if (progress.total <= 0) 0f else (progress.done.toFloat() / progress.total).coerceIn(0f, 1f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                    Text(
                        text = "提交 ${progress.done}/${progress.total} · 成功 ${progress.ok} · 失败 ${progress.fail}" +
                            if (progress.paused) "（已暂停）" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f)
                    )
                }

                // 7. 日志区（最近 30 条，批量渲染防卡死）
                if (logs.isNotEmpty()) {
                    Spacer(Modifier.height(2.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp, max = 200.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                            .verticalScroll(rememberScrollState())
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        logs.takeLast(30).forEach { line ->
                            Text(
                                text = line,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                    }
                }

                // 8. 记忆管理 — 统一 labelMedium + 40dp 高度 + 单行
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showMemoryDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("记忆状态", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            val json = viewModel.exportOfflineMemory()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("光鸭离线记忆备份", json))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("导出记忆", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { importText = ""; showImportDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("导入记忆", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                }

                // 关闭
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = dialogButtonShape
                ) {
                    Text("关闭")
                }
            }
        }

    // 文件夹选择器
    if (showFolderPicker) {
        FolderPickerDialog(
            viewModel = viewModel,
            initialParentId = targetFolder?.fileId ?: "",
            initialName = targetFolder?.name ?: "",
            onSelect = { folder ->
                viewModel.setOfflineTargetFolder(folder)
                showFolderPicker = false
            },
            onDismiss = { showFolderPicker = false }
        )
    }

    // 记忆状态 + 清空确认
    if (showMemoryDialog) {
        AlertDialog(
            onDismissRequest = { showMemoryDialog = false },
            title = { Text("记忆状态") },
            text = { Text(viewModel.offlineMemoryStats()) },
            confirmButton = {
                TextButton(onClick = { showMemoryDialog = false }) { Text("知道了") }
            },
            dismissButton = {
                TextButton(onClick = { pendingClearMemory = true }) { Text("清空记忆") }
            }
        )
    }
    if (pendingClearMemory) {
        AlertDialog(
            onDismissRequest = { pendingClearMemory = false },
            title = { Text("清空全部记忆？") },
            text = { Text("清空后已提交的磁力链会被重新提交！仅调试用，不建议。") },
            confirmButton = {
                Button(onClick = {
                    viewModel.clearOfflineMemory()
                    pendingClearMemory = false
                    showMemoryDialog = false
                }) { Text("清空") }
            },
            dismissButton = {
                TextButton(onClick = { pendingClearMemory = false }) { Text("取消") }
            }
        )
    }

    // 导入记忆
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("导入记忆") },
            text = {
                OutlinedTextField(
                    value = importText,
                    onValueChange = { importText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("粘贴导出时的 JSON 备份内容") },
                    minLines = 5,
                    maxLines = 8
                )
            },
            confirmButton = {
                Button(onClick = {
                    val result = viewModel.importOfflineMemory(importText.trim())
                    showImportDialog = false
                }) { Text("导入") }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) { Text("取消") }
            }
        )
    }
}

// ==================== 文件夹选择器 ====================

@Composable
private fun FolderPickerDialog(
    viewModel: GuangyaBrowserViewModel,
    initialParentId: String,
    initialName: String = "",
    onSelect: (GuangyaFolderRef) -> Unit,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var currentParentId by remember { mutableStateOf(initialParentId) }
    // parentStack 仅记录用户在弹窗内的真实导航历史（每进入一层，将当前 parentId 入栈）。
    // 进入弹窗时若已有目标文件夹（initialParentId 非空），parentStack 初始为空，
    // 「返回上级」按钮不可见——因为不知道该文件夹的真实父目录，避免误跳根目录。
    // pathNames 预填初始目录名仅用于路径展示和「选择此文件夹」的名称显示。
    val parentStack = remember {
        mutableStateListOf<String>()
    }
    val pathNames = remember {
        mutableStateListOf<String>().apply {
            if (initialParentId.isNotBlank() && initialName.isNotBlank()) add(initialName)
        }
    }
    var folders by remember { mutableStateOf<List<GuangyaFileItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var searchKeyword by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }

    fun load(parentId: String) {
        loading = true
        error = null
        scope.launch {
            runCatching { viewModel.listOfflineFolders(parentId) }
                .onSuccess { folders = it }
                .onFailure { error = it.message }
            loading = false
        }
    }

    fun search(keyword: String) {
        if (keyword.isBlank()) return
        searching = true
        loading = true
        error = null
        scope.launch {
            runCatching { viewModel.searchOfflineFolders(keyword) }
                .onSuccess {
                    folders = it
                    searching = false
                }
                .onFailure {
                    error = it.message
                    searching = false
                }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        load(initialParentId)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择目标文件夹") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // 搜索行
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchKeyword,
                        onValueChange = { searchKeyword = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("搜索文件夹") },
                        textStyle = MaterialTheme.typography.bodySmall
                    )
                    Button(onClick = { search(searchKeyword.trim()) }, shape = RoundedCornerShape(12.dp)) {
                        Text("搜索")
                    }
                }
                // 当前路径 / 搜索提示
                Text(
                    text = when {
                        searching -> "搜索结果（点选即选中）"
                        pathNames.isNotEmpty() -> "当前：${pathNames.joinToString(" / ")}"
                        else -> "当前：根目录"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                error?.let {
                    Text(
                        text = "出错：$it",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                // 目录列表
                if (loading) {
                    Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (folders.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (searching) "未搜到文件夹" else "此目录没有子文件夹",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.height(220.dp)) {
                        items(folders, key = { it.fileId }) { folder ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    if (searching) {
                                        onSelect(GuangyaFolderRef(folder.fileId, folder.name))
                                    } else {
                                        parentStack.add(currentParentId)
                                        pathNames.add(folder.name)
                                        currentParentId = folder.fileId
                                        load(folder.fileId)
                                    }
                                }
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Rounded.Folder,
                                    contentDescription = null,
                                    tint = Color(0xFFE7C267),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = folder.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(start = 8.dp)
                                )
                                if (searching) {
                                    Text(
                                        "选中",
                                        color = MaterialTheme.colorScheme.primary,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!searching) {
                Button(
                    onClick = {
                        onSelect(
                            GuangyaFolderRef(
                                fileId = currentParentId,
                                name = pathNames.lastOrNull() ?: "(根目录)"
                            )
                        )
                    },
                    enabled = !loading
                ) { Text("选择此文件夹") }
            } else {
                TextButton(onClick = { searching = false; load(currentParentId) }) {
                    Text("退出搜索")
                }
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (parentStack.isNotEmpty() && !searching) {
                    TextButton(onClick = {
                        // parentStack 记录真实的导航历史，「返回上级」弹出栈顶即为父目录。
                        // 初始进入时（已有目标文件夹）parentStack 为空，不显示此按钮，避免误跳根目录。
                        currentParentId = parentStack.removeAt(parentStack.size - 1)
                        pathNames.removeAt(pathNames.size - 1)
                        load(currentParentId)
                    }) { Text("返回上级") }
                }
                if (!searching) {
                    TextButton(onClick = {
                        parentStack.clear()
                        pathNames.clear()
                        currentParentId = ""
                        load("")
                    }) { Text("根目录") }
                }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        }
    )
}

// ==================== 既有组件 ====================

@Composable
private fun GuangyaTopBar(
    path: List<String>,
    onBack: () -> Unit,
    topInsetHandled: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (topInsetHandled) {
                    // 嵌入网盘 tab：背景由外层渐变容器统一提供
                    Modifier.background(Color.Transparent)
                } else {
                    Modifier.background(
                        Brush.verticalGradient(
                            listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.background)
                        )
                    )
                }
            )
            .then(
                if (topInsetHandled) Modifier else Modifier.windowInsetsPadding(WindowInsets.statusBars)
            )
            .padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(22.dp)
                )
            }
            Icon(
                Icons.Rounded.Cloud,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "光鸭云盘",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            )
        }
        Text(
            text = path.joinToString(" / ").ifBlank { "根目录" },
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
    }
}

@Composable
private fun GuangyaFileRow(
    file: GuangyaFileItem,
    isAdding: Boolean,
    isAdded: Boolean,
    onOpen: () -> Unit,
    onAdd: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.075f))
            .clickable(onClick = onOpen)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (file.isDir) Icons.Rounded.Folder else Icons.Rounded.VideoFile,
                contentDescription = null,
                tint = if (file.isDir) Color(0xFFE7C267) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.76f)
            )
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = file.name,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = file.subtitle(),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.56f),
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        GuangyaAddButton(isAdding = isAdding, isAdded = isAdded, onAdd = onAdd)
    }
}

@Composable
private fun GuangyaAddButton(isAdding: Boolean, isAdded: Boolean, onAdd: () -> Unit) {
    if (isAdded) {
        Text(
            text = "已添加",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        return
    }
    if (isAdding) {
        Text(
            text = "添加中",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        return
    }
    Button(
        onClick = onAdd,
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp),
        modifier = Modifier.height(34.dp)
    ) {
        Text("添加", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

private fun GuangyaFileItem.subtitle(): String = when {
    isDir -> "目录 · 点按进入"
    isVideoFile() -> "视频 · ${formatSize(size)}"
    else -> "文件 · ${formatSize(size)}"
}

private fun GuangyaFileItem.isVideoFile(): Boolean =
    VIDEO_EXTENSIONS.any { name.endsWith(it, ignoreCase = true) }

private val VIDEO_EXTENSIONS = listOf(
    ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".ts", ".iso", ".flv", ".webm"
)

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024 && idx < units.size - 1) {
        value /= 1024
        idx++
    }
    return if (idx == 0) "$bytes B" else "%.1f %s".format(value, units[idx])
}
