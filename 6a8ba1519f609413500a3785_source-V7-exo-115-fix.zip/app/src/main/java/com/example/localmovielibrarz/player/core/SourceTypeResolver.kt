package com.example.localmovielibrarz.player.core

import android.net.Uri

/**
 * 根据 URI / mimeType 判定源类型（§10.2）。
 */
object SourceTypeResolver {
    fun resolve(uri: Uri, mimeType: String? = null): SourceType {
        val scheme = uri.scheme
        val path = uri.path.orEmpty().lowercase()
        return when {
            scheme == "http" && path.endsWith(".m3u8") -> SourceType.HLS
            scheme == "https" && path.endsWith(".m3u8") -> SourceType.HLS
            scheme == "http" && path.endsWith(".mpd") -> SourceType.DASH
            scheme == "https" && path.endsWith(".mpd") -> SourceType.DASH
            scheme == "file" || scheme == "content" -> SourceType.LOCAL_FILE
            scheme == "http" || scheme == "https" -> SourceType.HTTP_PROGRESSIVE
            scheme == "rtsp" -> SourceType.RTSP
            else -> when (mimeType) {
                "application/vnd.apple.mpegurl", "application/x-mpegurl" -> SourceType.HLS
                "application/dash+xml" -> SourceType.DASH
                else -> SourceType.UNKNOWN
            }
        }
    }

    /** 是否为网络流（决定回退策略与 UI 行为）。 */
    fun isNetwork(sourceType: SourceType): Boolean =
        sourceType == SourceType.HTTP_PROGRESSIVE ||
            sourceType == SourceType.HLS ||
            sourceType == SourceType.DASH ||
            sourceType == SourceType.RTSP
}