package com.example.localmovielibrarz.ui.guangya
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * 光鸭云盘短信登录面板。
 * 嵌入「网盘设置」页，位于 115 二维码登录面板下方，视觉风格与之一致。
 *
 * 光鸭不支持扫码登录（无 passport 二维码体系），App 内登录方式为：
 * 手机号 + 短信验证码两阶段，全程 App 内完成，不跳转浏览器。
 */
@Composable
fun GuangyaLoginPanel(viewModel: GuangyaLoginViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.075f),
                RoundedCornerShape(16.dp)
            )
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.Public,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f)
            )
            Column(modifier = Modifier.padding(start = 10.dp)) {
                Text(
                    text = "光鸭云盘",
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "通过手机号+短信验证码登录，登录后即可生成光鸭网盘的 STRM 文件并播放。",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        when (uiState.step) {
            GuangyaLoginStep.LoggedIn -> {
                Text(
                    text = "已登录光鸭云盘",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(
                    onClick = viewModel::logout,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("退出登录")
                }
            }

            GuangyaLoginStep.CodeSent -> {
                // 已发送验证码：输入验证码并登录
                OutlinedTextField(
                    value = uiState.verificationCode,
                    onValueChange = { value ->
                        viewModel.onCodeChanged(value.filter { it.isDigit() }.take(6))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("短信验证码") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    enabled = !uiState.isLoading,
                    shape = RoundedCornerShape(12.dp)
                )
                Button(
                    onClick = viewModel::submitCode,
                    enabled = uiState.verificationCode.length >= 4 && !uiState.isLoading,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.padding(end = 8.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Text(if (uiState.isLoading) "正在登录..." else "登录")
                }
                Text(
                    text = if (uiState.countdown > 0) {
                        "验证码已发送至 ${maskPhone(uiState.phoneNumber)}，${uiState.countdown}s 后可重新获取"
                    } else {
                        "未收到验证码？"
                    },
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f),
                    style = MaterialTheme.typography.bodySmall
                )
                if (uiState.countdown <= 0) {
                    TextButton(
                        onClick = viewModel::resendCode,
                        enabled = !uiState.isLoading,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("重新获取验证码")
                    }
                }
            }

            GuangyaLoginStep.Idle -> {
                OutlinedTextField(
                    value = uiState.phoneNumber,
                    onValueChange = viewModel::onPhoneChanged,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("手机号（+86 13800138000）") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    enabled = !uiState.isLoading,
                    shape = RoundedCornerShape(12.dp)
                )
                Button(
                    onClick = viewModel::sendCode,
                    enabled = !uiState.isLoading,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.padding(end = 8.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Text(if (uiState.isLoading) "正在发送..." else "获取验证码")
                }
            }
        }

        uiState.status.takeIf { it.isNotBlank() && it != "登录成功" }?.let { status ->
            Text(
                text = status,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                style = MaterialTheme.typography.bodySmall
            )
        }
        uiState.error?.let { err ->
            Text(
                text = "出错：$err",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun maskPhone(phone: String): String {
    val digits = phone.filter { it.isDigit() }
    return if (digits.length >= 7) {
        "${digits.take(3)}****${digits.takeLast(4)}"
    } else {
        phone
    }
}
