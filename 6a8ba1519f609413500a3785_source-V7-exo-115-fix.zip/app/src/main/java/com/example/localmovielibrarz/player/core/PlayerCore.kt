package com.example.localmovielibrarz.player.core

import android.content.Context
import android.view.View

/**
 * 通用播放接口（§6.4）。
 *
 * UI 只依赖本抽象，不感知具体核心（ExoPlayer / mpv）。
 * 前端通过 [getOrCreateView] 获取渲染 View，交由 PlayerHost 注入 Compose AndroidView 容器。
 */
interface PlayerCore {
    val type: PlayerCoreType

    /** 静态能力：核心自身具备的能力集合。 */
    val staticCapabilities: Set<PlayerCapability>

    /**
     * 幂等获取渲染 View：同一实例缓存同一 View。
     * 仅当你采用 mpv 等原生渲染时才真正创建 SurfaceView。
     */
    fun getOrCreateView(context: Context): View

    fun load(request: PlaybackRequest)
    fun play()
    fun pause()
    fun togglePlay()
    fun stop()
    fun release()

    fun seekTo(positionMs: Long)
    fun seekBy(deltaMs: Long)

    fun setSpeed(speed: Float)
    fun setVolume(volume: Float)
    fun setMuted(muted: Boolean)

    fun getTracks(): TrackModel
    fun selectTrack(selection: TrackSelection)

    fun getSnapshot(): PlaybackSnapshot

    fun supportsCapability(capability: PlayerCapability): Boolean

    fun setListener(listener: PlayerCoreListener?)
    fun removeListener(listener: PlayerCoreListener)

    /** 当前播放状态（供宿主读取，无需依赖回调）。 */
    val playbackState: PlaybackState
}

interface PlayerCoreListener {
    fun onPlaybackStateChanged(state: PlaybackState)
    fun onPositionChanged(positionMs: Long, durationMs: Long)
    fun onVideoSizeChanged(width: Int, height: Int)
    fun onTracksChanged(tracks: TrackModel)
    fun onError(error: PlaybackError)
    fun onBufferingChanged(buffering: Boolean)
    fun onPlaybackEnded()
}

/** mpv 专属扩展接口（§6.12）。 */
interface MpvPlayerCore : PlayerCore {
    fun command(args: List<String>)
    fun observeMpvProperty(name: String)
    fun setMpvOption(name: String, value: String): Int

    /**
     * mpv 渲染输出是否已就绪（vo 已配置并开始出帧）。
     * 供 PlayerHost 看门狗判断"已 READY 但黑屏"的载体：若一直为 false，
     * 说明 mpv 打开了流却始终没有视频帧到达 → 判为黑屏，触发自动回退。
     */
    val videoOutputRendered: Boolean
}

/** ExoPlayer 专属扩展接口（§6.12）。 */
interface ExoPlayerCore : PlayerCore {
    /** 返回底层 androidx.media3.exoplayer.ExoPlayer 实例（供既有逻辑/诊断用）。 */
    fun getExoPlayer(): Any

    /**
     * 是否已渲染出第一帧（[androidx.media3.common.Player.Listener.onRenderedFirstFrame] 触发）。
     * 供 PlayerHost 看门狗判断"已 READY 但黑屏"的载体；
     * 一直为 false → 判为黑屏 → 自动回退到 mpv。
     */
    val firstVideoFrameRendered: Boolean
}