package com.example.localmovielibrarz.player.core.exo

import android.content.Context
import android.net.Uri
import android.view.View
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.localmovielibrarz.player.core.*
import com.example.localmovielibrarz.playback.DEFAULT_USER_AGENT

/**
 * ExoPlayer 核心实现（§7）。
 *
 * 复用既有 ExoPlayer.Builder 创建逻辑，但移除 nextlib（§5.1/5.4）：使用原生
 * DefaultRenderersFactory + setEnableDecoderFallback(true)。
 * 所有 PlayerCore 调用顺序化到专用 CoreExecutor，避免与 UI 线程并发冲突。
 */
@OptIn(UnstableApi::class)
class ExoPlayerCoreImpl(context: Context) : ExoPlayerCore {

    @Volatile
    private var applicationContext: Context = context.applicationContext

    private val executor = CoreExecutor("exo").apply {
        setErrorHandler { e ->
            android.util.Log.e(TAG, "ExoPlayerCore executor error", e)
        }
        start()
    }

    @Volatile
    private var player: ExoPlayer? = null

    @Volatile
    private var request: PlaybackRequest? = null

    @Volatile
    private var firstFrameRendered = false

    override val firstVideoFrameRendered: Boolean get() = firstFrameRendered

    @Volatile
    private var cachedTracks: TrackModel = TrackModel.EMPTY

    /**
     * 渲染视图：media3 官方 [PlayerView]（与 V6 legacy PlayerScreen 对齐）。
     * 自定义 SurfaceHolderView 为空壳（无 surface 生命周期处理），对光鸭/115 等网络直链无法正常出画面，
     * 改为 PlayerView 后由其内部自动完成 Surface 绑定 / 字幕 / 渲染启动（修复黑屏）。
     */
    @Volatile
    private var playerView: PlayerView? = null

    /** 幂等释放守卫：三重 release（leavePlayer / onDispose / onCleared）只真正释放一次，避免 native crash。 */
    @Volatile
    private var released = false

    @Volatile
    override var playbackState: PlaybackState = PlaybackState.IDLE
        private set

    @Volatile
    private var listener: PlayerCoreListener? = null

    private val positionPusher = object : Thread("exo-position-pusher") {
        override fun run() {
            while (!isInterrupted) {
                runCatching {
                    Thread.sleep(500)
                    val exo = player ?: continue
                    val pos = exo.currentPosition.coerceAtLeast(0L)
                    val dur = exo.duration.coerceAtLeast(0L)
                    if (exo.isPlaying || dur > 0L) {
                        listener?.onPositionChanged(pos, dur)
                    }
                }
            }
        }
    }.also { it.isDaemon = true }

    init {
        positionPusher.start()
    }

    override val type: PlayerCoreType = PlayerCoreType.EXOPLAYER

    override val staticCapabilities: Set<PlayerCapability> = setOf(
        PlayerCapability.ADAPTIVE_STREAM,
        PlayerCapability.DRM,
        PlayerCapability.SUBTITLE_DELAY
    )

    override fun supportsCapability(capability: PlayerCapability): Boolean =
        capability in staticCapabilities

    // ---------------- 视图 ----------------

    /**
     * 幂等获取渲染视图：缓存 [PlayerView] 并复用。
     *
     * ★ 主线程创建：PlayerView 是 Android View，必须在主线程构造（内部会创建 Handler、注册
     * Choreographer 回调等）。PlayerHost.attachCore 在主线程调用此方法，但 ensurePlayer 在 executor
     * 线程也可能调用，因此加断言保护；若在非主线程调用（ensurePlayer 误调），用 Handler 切回主线程同步创建。
     */
    @Synchronized
    override fun getOrCreateView(context: Context): View {
        playerView?.let { return it }
        val isMainThread = Thread.currentThread() == android.os.Looper.getMainLooper().thread
        val ctx = context.applicationContext
        return if (isMainThread) {
            createPlayerView(ctx)
        } else {
            // 非主线程调用（ensurePlayer 误调）：切回主线程同步创建
            createPlayerViewOnMainThread(ctx)
        }
    }

    private fun createPlayerView(ctx: Context): PlayerView =
        PlayerView(ctx).apply {
            useController = false
            setKeepContentOnPlayerReset(true)
            playerView = this
        }

    private fun createPlayerViewOnMainThread(ctx: Context): PlayerView {
        val latch = java.util.concurrent.CountDownLatch(1)
        val result = arrayOfNulls<PlayerView>(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            result[0] = createPlayerView(ctx)
            latch.countDown()
        }
        latch.await()
        return result[0]!!
    }

    override fun setListener(listener: PlayerCoreListener?) {
        this.listener = listener
    }

    override fun removeListener(listener: PlayerCoreListener) {
        if (this.listener === listener) this.listener = null
    }

    // ---------------- 生命周期 ----------------

    override fun load(request: PlaybackRequest) {
        com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
            "Exo", "load uri=${request.uri} sourceType=${request.sourceType} headers=${request.headers.keys}"
        )
        executor.execute {
            this.request = request
            firstFrameRendered = false // ★ 新一次播放：重置"已出帧"标记
            val exo = ensurePlayer()
            val mediaItem = createMediaItem(request)
            val start = request.startPositionMs ?: 0L
            publishState(PlaybackState.PREPARING)
            exo.setMediaItem(mediaItem, start.coerceAtLeast(0L))
            exo.prepare()
            if (request.autoplay) exo.playWhenReady = true
        }
    }

    override fun play() {
        executor.post { player?.play() }
    }

    override fun pause() {
        executor.post { player?.pause() }
    }

    override fun togglePlay() {
        executor.execute {
            player?.playWhenReady = !(player?.playWhenReady ?: false)
        }
    }

    override fun stop() {
        executor.execute {
            player?.let { if (it.playbackState != Player.STATE_IDLE) it.stop() }
        }
    }

    override fun release() {
        if (released) return // ★ 幂等守卫：只真正释放一次（leavePlayer / onDispose / onCleared 三重调用）
        released = true

        // ① 主线程先解除 PlayerView 绑定（避免 removeView 时 PlayerView 仍在引用 player）
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching { playerView?.player = null }
            playerView = null
        }

        // ② executor 同步等待 player.release() 完成（CoreExecutor.execute 是同步等待的，
        //    确保 native 释放在返回前结束，之后再 shutdown 不会出现异步释放竞争）。
        executor.execute {
            runCatching { player?.release() }
            player = null
        }
        executor.shutdown()
        positionPusher.interrupt()
    }

    // ---------------- 控制 ----------------

    override fun seekTo(positionMs: Long) {
        executor.execute { player?.seekTo(positionMs.coerceAtLeast(0L)) }
    }

    override fun seekBy(deltaMs: Long) {
        executor.execute {
            player?.let {
                it.seekTo((it.currentPosition.coerceAtLeast(0L) + deltaMs).coerceAtLeast(0L))
            }
        }
    }

    override fun setSpeed(speed: Float) {
        executor.execute { player?.setPlaybackSpeed(speed.coerceIn(0.25f, 8f)) }
    }

    override fun setVolume(volume: Float) {
        executor.execute { player?.volume = volume.coerceIn(0f, 1f) }
    }

    override fun setMuted(muted: Boolean) {
        executor.execute { player?.volume = if (muted) 0f else 1f }
    }

    // ---------------- 轨道 ----------------

    override fun getTracks(): TrackModel = cachedTracks

    override fun selectTrack(selection: TrackSelection) {
        executor.execute {
            val exo = player ?: return@execute
            if (selection.disable) {
                // media3 无按类型清空 override 的公开 API，退化为清空全部 override 还原自动选择
                exo.setTrackSelectionParameters(
                    exo.trackSelectionParameters.buildUpon().clearOverrides().build()
                )
                return@execute
            }
            val params = exo.trackSelectionParameters.buildUpon()
            val hint = selection.hint ?: return@execute
            val track = exo.currentTracks.groups.firstOrNull { g ->
                groupMatches(g, selection.type, hint)
            } ?: return@execute
            val index = hint.exoTrackIndex?.takeIf { it >= 0 } ?: 0
            exo.setTrackSelectionParameters(
                params.setOverrideForType(TrackSelectionOverride(track.mediaTrackGroup, index)).build()
            )
        }
    }

    private fun groupMatches(group: Tracks.Group, type: TrackType, hint: TrackHint): Boolean {
        val typeOk = when (type) {
            TrackType.AUDIO -> group.type == C.TRACK_TYPE_AUDIO
            TrackType.VIDEO -> group.type == C.TRACK_TYPE_VIDEO
            TrackType.SUBTITLE -> group.type == C.TRACK_TYPE_TEXT
        }
        if (!typeOk) return false
        val format = runCatching { group.getTrackFormat(0) }.getOrNull() ?: return true
        return hint.language == null || format.language == hint.language
    }

    // ---------------- 快照 ----------------

    override fun getSnapshot(): PlaybackSnapshot {
        var positionMs = 0L
        var durationMs = 0L
        var speed = 1f
        var wasPlaying = false
        var volume = 1f
        executor.execute {
            player?.let {
                positionMs = it.currentPosition.coerceAtLeast(0L)
                durationMs = it.duration.coerceAtLeast(0L)
                speed = it.playbackParameters.speed
                wasPlaying = it.isPlaying
                volume = it.volume
            }
        }
        val req = request
        return PlaybackSnapshot(
            request = req ?: PlaybackRequest(uri = Uri.EMPTY, sourceType = SourceType.UNKNOWN),
            coreType = type,
            positionMs = positionMs,
            durationMs = durationMs,
            speed = speed,
            wasPlaying = wasPlaying,
            volume = volume,
            muted = volume == 0f,
            audioTrackHint = req?.audioTrackHint,
            subtitleTrackHints = req?.subtitleTrackHints ?: emptyList(),
            subtitleDelayMs = null,
            audioDelayMs = null,
            fallbackUsed = false,
            lastError = null,
            createdAt = System.currentTimeMillis()
        )
    }

    override fun getExoPlayer(): Any = player ?: ensurePlayer()

    @Synchronized
    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val headers = request?.headers.orEmpty()
        val userAgent = headers["User-Agent"] ?: DEFAULT_USER_AGENT

        // ★ 拉流栈修复（回归 V6 行为，方案 A）：改用 DefaultHttpDataSource + DefaultDataSource 包装。
        //   光鸭/115 为「https + URL 签名」的直连直链，不依赖系统代理；
        //   直接 HttpURLConnection 栈已实际验证稳定，避免 OkHttpDataSource(V7) 引入的
        //   代理转发/重定向/seek(MP4 moov 尾部) 差异导致的起播黑屏回归。
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setDefaultRequestProperties(headers)
            .setAllowCrossProtocolRedirects(true)
        // DefaultDataSource 包装：统一处理 file/content/asset/http 等 scheme，并提供异常兜底。
        val dataSourceFactory = DefaultDataSource.Factory(applicationContext, httpDataSourceFactory)
        com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
            "Exo", "ensurePlayer opening uri=${request?.uri}"
        )
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 2_500, 5_000)
            .build()

        // 移除 nextlib，使用原生渲染器 + 使能解码器回退（§5.4）
        val renderersFactory = DefaultRenderersFactory(applicationContext)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val exo: ExoPlayer = ExoPlayer.Builder(applicationContext)
            .setRenderersFactory(renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(10_000L)
            .setSeekForwardIncrementMs(10_000L)
            .build()

        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_ALL)
                .build(),
            true
        )

        // ★ 线程时序修复（线程时序版）：不在此处（executor 线程）创建/绑定 PlayerView。
        //   View 创建由 PlayerHost.attachCore（主线程）的 getOrCreateView 完成；
        //   player 绑定由 attachPlayerViewOnMainThread（主线程 Handler post）完成，
        //   保证 PlayerView.player = exo 只在主线程执行（PlayerView setter 内部 setVideoSurfaceHolder
        //   并触发 Surface attach，必须在主线程）。
        exo.addListener(playerListener)
        player = exo

        // 确保主线程绑定 player 到已有的 PlayerView（若 attachCore 已先执行创建了 View）
        attachPlayerViewOnMainThread(exo)

        return exo
    }

    /**
     * 在主线程把 exo 绑定到 playerView（若已存在）。
     * PlayerView 在主线程创建，player 绑定也必须在主线程（PlayerView.player setter
     * 内部会 setVideoSurfaceHolder 并触发 Surface attach，必须在主线程执行）。
     */
    private fun attachPlayerViewOnMainThread(exo: ExoPlayer) {
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.post {
            val pv = playerView
            if (pv != null) {
                pv.player = exo
                com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
                    "Exo", "attachPlayerViewOnMainThread: 已绑定 PlayerView.player=exo（主线程）"
                )
            } else {
                com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
                    "Exo", "attachPlayerViewOnMainThread: playerView 仍为 null，等待 attachCore 创建后由 bindPlayerViewIfReady 绑定"
                )
            }
        }
    }

    /**
     * 由 PlayerHost.attachCore 在主线程调用：若 player 已创建但 PlayerView 刚创建，补绑。
     * 场景 B（ensurePlayer 先于 attachCore 执行）的 fallback 路径。
     */
    fun bindPlayerViewIfReady() {
        val exo = player ?: return
        val pv = playerView ?: return
        pv.player = exo
        com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
            "Exo", "bindPlayerViewIfReady: 已补绑 PlayerView.player=exo（主线程）"
        )
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            val state = when (playbackState) {
                Player.STATE_IDLE -> PlaybackState.IDLE
                Player.STATE_BUFFERING -> PlaybackState.BUFFERING
                Player.STATE_READY -> PlaybackState.READY
                Player.STATE_ENDED -> PlaybackState.ENDED
                else -> PlaybackState.IDLE
            }
            publishBuffering()
            publishState(if (state == PlaybackState.READY && player?.isPlaying == true) PlaybackState.PLAYING else state)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                listener?.onPlaybackStateChanged(PlaybackState.PLAYING)
            } else if (player?.playbackState == Player.STATE_READY) {
                listener?.onPlaybackStateChanged(PlaybackState.PAUSED)
            }
            listener?.onBufferingChanged(player?.playbackState == Player.STATE_BUFFERING)
            publishBuffering()
        }

        private fun publishBuffering() {
            listener?.onBufferingChanged(player?.playbackState == Player.STATE_BUFFERING)
        }

        override fun onTracksChanged(tracks: Tracks) {
            cachedTracks = mapTracks(tracks)
            listener?.onTracksChanged(cachedTracks)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            listener?.onVideoSizeChanged(videoSize.width, videoSize.height)
        }

        override fun onPlayerError(error: PlaybackException) {
            // 关键：把 Exo 的完整错误（errorCodeName + message + 根因堆栈）写入应用内日志，
            // 否则用户/开发者看不到 Exo 到底因何失败（mpv 有 MpvLogBuffer，Exo 此前无对应缓冲）。
            com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
                "Exo", "onPlayerError code=${error.errorCodeName}(${error.errorCode}) msg=${error.message} " +
                    "uri=${request?.uri}"
            )
            error.cause?.let { cause ->
                com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
                    "Exo", "onPlayerError cause=${cause.javaClass.simpleName}: ${cause.message}"
                )
                com.example.localmovielibrarz.diagnostics.ExoLogBuffer.log(
                    "Exo", "onPlayerError stack=${cause.stackTraceToString().lineSequence().take(12).joinToString("\\n")}"
                )
            }
            val mapped = ExoErrorMapper.mapError(error)
            listener?.onError(mapped)
        }

        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            listener?.onPositionChanged(
                newPosition.positionMs.coerceAtLeast(0L),
                player?.duration?.coerceAtLeast(0L) ?: 0L
            )
        }

        override fun onRenderedFirstFrame() {
            firstFrameRendered = true // ★ 真正出帧
            listener?.onVideoSizeChanged(
                player?.videoSize?.width ?: 0,
                player?.videoSize?.height ?: 0
            )
        }
    }

    private fun publishState(state: PlaybackState) {
        playbackState = state
        listener?.onPlaybackStateChanged(state)
    }

    private fun createMediaItem(request: PlaybackRequest): MediaItem {
        val builder = MediaItem.Builder().setUri(request.uri)
        if (request.subtitleSources.isNotEmpty()) {
            val configs = request.subtitleSources.map { src ->
                MediaItem.SubtitleConfiguration.Builder(src.uri)
                    .setMimeType(src.mimeType ?: defaultSubMime(src))
                    .setLanguage(src.language ?: "zh")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
            }
            builder.setSubtitleConfigurations(configs)
        }
        return builder.build()
    }

    private fun defaultSubMime(src: SubtitleSource): String {
        val ext = src.uri.path?.substringAfterLast('.', "").orEmpty().lowercase()
        return when (ext) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun mapTracks(tracks: Tracks): TrackModel {
        val video = mutableListOf<TrackInfo>()
        val audio = mutableListOf<TrackInfo>()
        val sub = mutableListOf<TrackInfo>()
        tracks.groups.forEachIndexed { groupIndex, group ->
            val type = when (group.type) {
                C.TRACK_TYPE_VIDEO -> TrackType.VIDEO
                C.TRACK_TYPE_AUDIO -> TrackType.AUDIO
                C.TRACK_TYPE_TEXT -> TrackType.SUBTITLE
                else -> null
            } ?: return@forEachIndexed
            val format = runCatching { group.getTrackFormat(0) }.getOrNull()
            val hint = TrackHint(
                type = type,
                exoTrackGroupIndex = groupIndex,
                exoTrackIndex = 0,
                language = format?.language,
                title = format?.label,
                mimeType = format?.sampleMimeType,
                channels = format?.channelCount,
                isDefault = format?.selectionFlags?.and(C.SELECTION_FLAG_DEFAULT) != 0,
                isForced = format?.selectionFlags?.and(C.SELECTION_FLAG_FORCED) != 0
            )
            val label = buildString {
                append(format?.id ?: "轨道")
                format?.language?.let { append(" · ").append(it) }
                format?.label?.let { append(" · ").append(it) }
            }
            val info = TrackInfo(hint, label, group.isSelected, group.isSupported)
            when (type) {
                TrackType.VIDEO -> video.add(info)
                TrackType.AUDIO -> audio.add(info)
                TrackType.SUBTITLE -> sub.add(info)
                else -> Unit
            }
        }
        return TrackModel(video, audio, sub)
    }

    companion object {
        private const val TAG = "ExoPlayerCore"
    }
}