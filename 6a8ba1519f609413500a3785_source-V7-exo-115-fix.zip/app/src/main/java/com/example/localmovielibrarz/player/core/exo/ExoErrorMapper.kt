package com.example.localmovielibrarz.player.core.exo

import androidx.media3.common.PlaybackException
import com.example.localmovielibrarz.player.core.ErrorSeverity
import com.example.localmovielibrarz.player.core.PlaybackError
import com.example.localmovielibrarz.player.core.PlaybackErrorClassifier
import com.example.localmovielibrarz.player.core.PlaybackErrorType

/**
 * ExoPlayer 错误码 → 统一错误分类映射（§7.4 增强版）。
 *
 * 覆盖 ExoPlayer.ERROR_CODE_*；解码/格式类返回 FALLBACK_RECOMMENDED 触发回退，
 * 网络/权限/DRM 等返回 FATAL 不回退。
 */
object ExoErrorMapper {

    fun mapError(error: PlaybackException): PlaybackError {
        val type = mapType(error.errorCode, error)
        val severity = PlaybackErrorClassifier.classify(type)
        return PlaybackError(
            type = type,
            severity = severity,
            message = error.errorCodeName + ": " + (error.message ?: ""),
            rawCode = error.errorCode,
            cause = error
        )
    }

    private fun mapType(errorCode: Int, error: PlaybackException): PlaybackErrorType = when (errorCode) {
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> PlaybackErrorType.DECODE_INIT_FAILED
        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED -> PlaybackErrorType.DECODE_INIT_FAILED
        PlaybackException.ERROR_CODE_DECODING_FAILED -> PlaybackErrorType.DECODE_FAILED

        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> PlaybackErrorType.CONTAINER_UNSUPPORTED
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> PlaybackErrorType.FORMAT_UNSUPPORTED
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> PlaybackErrorType.CONTAINER_UNSUPPORTED

        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> PlaybackErrorType.NETWORK_ERROR
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> PlaybackErrorType.HTTP_ERROR
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> PlaybackErrorType.FILE_NOT_FOUND
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> PlaybackErrorType.PERMISSION_DENIED
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> PlaybackErrorType.TIMEOUT
        PlaybackException.ERROR_CODE_TIMEOUT -> PlaybackErrorType.TIMEOUT
        PlaybackException.ERROR_CODE_IO_UNSPECIFIED -> PlaybackErrorType.SOURCE_UNREADABLE

        PlaybackException.ERROR_CODE_FAILED_RUNTIME_CHECK -> PlaybackErrorType.DECODE_FAILED

        else -> when (error.errorCodeName.orEmpty().contains("DRM", ignoreCase = true)) {
            true -> PlaybackErrorType.DRM_ERROR
            false -> PlaybackErrorType.UNKNOWN
        }
    }
}