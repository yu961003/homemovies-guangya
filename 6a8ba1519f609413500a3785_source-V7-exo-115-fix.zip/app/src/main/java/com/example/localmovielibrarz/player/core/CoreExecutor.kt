package com.example.localmovielibrarz.player.core

import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 单线程执行器（§8.3）。
 *
 * mpv 的 API 必须在专用线程调用，避免与 UI 线程并发冲突。
 * ExoPlayer 也在此串联核心方法，保证同一核心的操作顺序化。
 */
class CoreExecutor(
    name: String = "player-core"
) {
    private val terminated = AtomicBoolean(false)
    private val started = AtomicBoolean(false)
    private val tasks = LinkedBlockingQueue<Runnable>()
    private var errorHandler: ((Throwable) -> Unit)? = null

    private val worker = Thread {
        var run = true
        while (run) {
            val task = runCatching { tasks.poll(100, TimeUnit.MILLISECONDS) }.getOrNull()
            if (task != null) {
                runCatching { task.run() }.onFailure { e ->
                    errorHandler?.invoke(e)
                }
            }
            if (terminated.get() && tasks.isEmpty()) run = false
        }
    }.apply {
        this.name = "$name-worker"
        isDaemon = true
    }

    /** 队列中待执行任务数，供诊断。 */
    val pendingTasks: Int
        get() = tasks.size

    fun setErrorHandler(handler: (Throwable) -> Unit) {
        errorHandler = handler
    }

    fun start() {
        if (started.compareAndSet(false, true)) {
            worker.start()
        }
    }

    /** 提交异步任务。若已终止则丢弃，返回是否成功入队。 */
    fun post(action: () -> Unit): Boolean {
        if (terminated.get()) return false
        val runnable = Runnable { runCatching { action() } }
        return tasks.offer(runnable).also {
            if (!it) errorHandler?.invoke(IllegalStateException("队列已满"))
        }
    }

    /** 同步执行并等待完成；适用于切换核心时必须确认旧核心已释放。 */
    fun execute(action: () -> Unit) {
        if (terminated.get()) return
        val latch = CountDownLatch(1)
        var failure: Throwable? = null
        val runnable = Runnable {
            runCatching { action() }.onFailure { failure = it }.also { latch.countDown() }
        }
        if (tasks.offer(runnable)) {
            runCatching { latch.await() }
            failure?.let { f -> errorHandler?.invoke(f) }
        }
    }

    /** 终止线程，等待正在执行的任务结束后退出。 */
    fun shutdown() {
        if (terminated.compareAndSet(false, true)) {
            post {} // 唤醒 worker 检查终止标记
        }
    }
}