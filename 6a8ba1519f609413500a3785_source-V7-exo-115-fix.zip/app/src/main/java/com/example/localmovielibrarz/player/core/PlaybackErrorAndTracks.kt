package com.example.localmovielibrarz.player.core

/** 播放错误分类（§6.9）。 */
data class PlaybackError(
    val type: PlaybackErrorType,
    val severity: ErrorSeverity,
    val message: String? = null,
    val rawCode: Int? = null,
    val cause: Throwable? = null
)

enum class PlaybackErrorType {
    DECODE_INIT_FAILED,
    DECODE_FAILED,
    FORMAT_UNSUPPORTED,
    CONTAINER_UNSUPPORTED,
    SUBTITLE_UNSUPPORTED,
    SOURCE_UNREADABLE,
    FILE_NOT_FOUND,
    NETWORK_ERROR,
    TIMEOUT,
    HTTP_ERROR,
    DRM_ERROR,
    PERMISSION_DENIED,
    USER_CANCELED,
    UNKNOWN
}

enum class ErrorSeverity {
    RECOVERABLE,
    FALLBACK_RECOMMENDED,
    FATAL
}

/** 轨道模型与选择（§6.10）。 */
data class TrackModel(
    val videoTracks: List<TrackInfo>,
    val audioTracks: List<TrackInfo>,
    val subtitleTracks: List<TrackInfo>
) {
    companion object {
        val EMPTY = TrackModel(emptyList(), emptyList(), emptyList())
    }
}

data class TrackInfo(
    val hint: TrackHint,
    val label: String?,
    val selected: Boolean,
    val selectable: Boolean = true
)

data class TrackSelection(
    val type: TrackType,
    val hint: TrackHint? = null,
    val disable: Boolean = false
)