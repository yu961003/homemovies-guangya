package com.example.localmovielibrarz.player.host

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import com.example.localmovielibrarz.diagnostics.ExoLogBuffer
import com.example.localmovielibrarz.player.core.*
import com.example.localmovielibrarz.player.core.exo.ExoPlayerCoreImpl

/**
 * 播放器宿主（§4 / §9.2）：负责渲染容器注入、状态协调、切换调度。
 *
 * Compose 通过 [attachContainer] 注入 FrameLayout；切换核心时按「先释放旧视图 → 注入新视图」顺序处理 Surface 生命周期冲突（§9.3）。
 */
class PlayerHost(
    private val context: Context,
    private val registry: PlayerCoreRegistry,
    private val fallbackController: FallbackController,
    private val listener: PlayerCoreListener? = null
) {

    @Volatile
    private var container: FrameLayout? = null

    @Volatile
    private var currentCore: PlayerCore? = null

    @Volatile
    private var switchState: SwitchState = SwitchState.IDLE

    /** 当前请求：用于错误回调时触发自动回退（\u00a712）。 */
    @Volatile
    private var currentRequest: PlaybackRequest? = null

    /** 界面侧当前核心类型（供 UI 显示）。 */
    @Volatile
    var currentCoreType: PlayerCoreType? = null
        private set

    private var switchCallback: ((SwitchState) -> Unit)? = null

    /** 切换待恢复快照：新核心 READY 时由内层监听触发续播（替代替换监听器，保留回退钩子）。 */
    @Volatile
    private var pendingResume: PlaybackSnapshot? = null

    /** 最近一次监听上报的播放位置（供看门狗判断是否有实际进度）。 */
    @Volatile
    private var lastPositionMs: Long = 0L

    /** 看门狗在本次会话（play ~ release）内触发的核心切换次数，最多 1 次，防止 Exo↔mpv 循环互踢。 */
    @Volatile
    private var watchdogSwitchCount = 0

    /** 幂等释放守卫：leavePlayer / onDispose / onCleared 三重调用只真正释放一次，消除返回退出崩溃。 */
    @Volatile
    private var released = false

    fun setSwitchCallback(cb: ((SwitchState) -> Unit)?) {
        switchCallback = cb
    }

    val availableCoreTypes: Set<PlayerCoreType> = setOf(PlayerCoreType.EXOPLAYER, PlayerCoreType.MPV)

    // ---------------- 容器 ----------------

    /** 由 Compose AndroidView factory / update 调用，注入渲染容器（幂等）。 */
    fun attachContainer(container: FrameLayout) {
        // 同一容器已附加且有子视图：recompose 场景直接跳过，避免反复销毁/重建 Surface（§9.3）
        if (this.container === container && container.childCount > 0) return
        this.container = container
        container.removeAllViews()
        currentCore?.let { attachCore(it) }
    }

    fun detachContainer() {
        this.container = null
    }

    private fun attachCore(core: PlayerCore) {
        val c = container ?: return
        c.removeAllViews()
        val view: View = core.getOrCreateView(context) // 主线程创建 PlayerView
        c.addView(view, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        // ★ 若 ExoPlayerCoreImpl 的 player 已创建但 PlayerView 刚才才创建（场景 B），补绑到主线程
        if (core is ExoPlayerCoreImpl) {
            core.bindPlayerViewIfReady()
        }
    }

    // ---------------- 初始播放 ----------------

    fun play(request: PlaybackRequest, requestedCore: PlayerCoreType? = null) {
        currentRequest = request
        watchdogSwitchCount = 0 // ★ 新播放会话：允许看门狗介入一次
        val coreType = registry.resolveDefaultCore(request, requestedCore)
        val core = registry.create(coreType)
        android.util.Log.i(TAG, "play -> 初始核心=$coreType（requested=$requestedCore uri=${request.uri}）")
        ExoLogBuffer.log("Host", "play -> 初始核心=$coreType requested=$requestedCore fallback=${request.fallbackPolicy} uri=${request.uri}")
        if (coreType == PlayerCoreType.EXOPLAYER) ExoLogBuffer.log("Host", "play -> 已选择 ExoPlayer 核心")
        core.setListener(innerListener)
        currentCore?.let { old ->
            // 若已有核心先释放（正常切换流程）
            with(old) { stop(); release() }
        }
        currentCore = core
        currentCoreType = coreType
        attachCore(core)
        core.load(request)
        armWatchdogIfNeeded(core)
    }

    // ---------------- 核心切换（伪实时） ----------------

    /**
     * 伪实时切换（§11）：记录快照 → 停止/释放旧核心 → 创建新核心 → 注入 → 恢复。
     *
     * @param target 目标核心类型
     * @param onSwitched 切换完成回调（成功/失败）
     */
    fun switchCore(target: PlayerCoreType, onSwitched: (Result<Unit>) -> Unit = {}) {
        val oldCore = currentCore ?: run { onSwitched(Result.failure(IllegalStateException("无当前核心"))); return }
        if (oldCore.type == target || switchState != SwitchState.IDLE) {
            onSwitched(Result.failure(IllegalStateException("正在切换或目标核心相同")))
            return
        }
        setState(SwitchState.SNAPSHOT_TAKEN)
        val snapshot = runCatching { oldCore.getSnapshot() }.getOrNull()
        if (snapshot == null) {
            // 快照失败：复位状态，避免 UI 一直卡在"切换中"
            android.util.Log.w(TAG, "switchCore 获取快照失败，中止切换并复位状态")
            setState(SwitchState.IDLE)
            onSwitched(Result.failure(IllegalStateException("无法获取当前播放快照")))
            return
        }

        switchCoreInternal(oldCore, target, snapshot, onSwitched)
    }

    private fun switchCoreInternal(
        oldCore: PlayerCore,
        target: PlayerCoreType,
        snapshot: PlaybackSnapshot,
        onSwitched: (Result<Unit>) -> Unit
    ) {
        val oldCoreLabel = oldCore.type.name
        // 1. 停止并释放旧核心（先 release 再移除视图，确保 Surface 正确销毁，§9.3）
        setState(SwitchState.OLD_CORE_RELEASED)
        runCatching { oldCore.stop() }
        runCatching { oldCore.release() }

        // 2. 创建并注入新核心；沿用 innerListener（保留 onError 自动回退钩子），
        //    续播改为 pendingResume + READY 触发，避免替换监听器导致回退失效。
        val newCore = registry.create(target)
        android.util.Log.i(TAG, "switchCore $oldCoreLabel -> $target")
        newCore.setListener(innerListener)
        currentCore = newCore
        currentCoreType = target
        attachCore(newCore)
        setState(SwitchState.NEW_CORE_LOADING)

        // 3. 用修改后的 PlaybackRequest 加载；READY 后由 innerListener 触发恢复速度/音量/播放态
        pendingResume = snapshot
        newCore.load(snapshot.toResumeRequest(PlaybackOrigin.INTERNAL_SWITCH))
        armWatchdogIfNeeded(newCore)

        // ★ 关键修复：复位状态，否则 UI 永远停在"切换中"，且下一次切换被判定为"正在切换"拒绝。
        setState(SwitchState.SWITCH_COMPLETED)
        setState(SwitchState.IDLE)
        onSwitched(Result.success(Unit))
    }

    private fun resumeAfterReady(newCore: PlayerCore, snapshot: PlaybackSnapshot) {
        newCore.setSpeed(snapshot.speed.coerceIn(0.25f, 8f))
        newCore.setVolume(snapshot.volume.coerceIn(0f, 1f))
        newCore.setMuted(snapshot.muted)
        if (snapshot.wasPlaying) newCore.play() else newCore.pause()
        listener?.let {
            it.onPositionChanged(snapshot.positionMs, snapshot.durationMs)
        }
        lastPositionMs = snapshot.positionMs
    }

    /**
     * 看门狗：Exo 或 mpv 核心加载后若迟迟未真正出画面，自动回退到对侧核心，避免永久黑屏。
     *
     * 健康判据（与 mpv 版统一语义）：
     *  - Exo：READY 且已出首帧 / PLAYING / ENDED，或位置推进 > 1s。
     *  - mpv：READY/PLAYING/PAUSED 且 vo 已渲染，或位置推进 > 1s。
     * 在 graceMs 内始终不满足 → 判为黑屏 / 未就绪 → 回退对侧核心。
     *
     * 会话级守卫 watchdogSwitchCount：整个播放会话最多自动回退一次，
     * 避免 Exo↔mpv 互相黑屏时无限循环互踢。
     */
    @Volatile
    private var watchdogCancelled = false

    private var watchdogThread: Thread? = null

    private fun armWatchdogIfNeeded(core: PlayerCore, graceMs: Long = 16_000L, tickMs: Long = 3_000L) {
        // 看门狗仅在工作核心为两种之一时启用。
        if (core.type != PlayerCoreType.EXOPLAYER && core.type != PlayerCoreType.MPV) return
        cancelWatchdog()
        watchdogCancelled = false
        val watched = currentCore
        // 以"启动时位置"为基线：真实渲染时位置会不断推进；黑屏时通常卡住不动
        val basePos = lastPositionMs
        watchdogThread = Thread {
            val start = System.currentTimeMillis()
            while (!watchdogCancelled && !Thread.currentThread().isInterrupted) {
                val c = currentCore
                // 仅在两种核心之一、切换已复位(IDLE)、且仍是本次被观察核心时判定
                if (switchState != SwitchState.IDLE || c?.type != core.type || c !== watched) break

                val state = c.playbackState
                val rendered = when (c.type) {
                    PlayerCoreType.EXOPLAYER -> (c as? ExoPlayerCore)?.firstVideoFrameRendered == true
                    PlayerCoreType.MPV -> (c as? MpvPlayerCore)?.videoOutputRendered == true
                    else -> false
                }
                val pos = lastPositionMs
                val advanced = pos - basePos >= 1_000L   // 位置推进 1s 以上

                // 健康：真出帧且位置推进；或已就绪并渲染；或正在播放；或已结束
                val healthy =
                    (state == PlaybackState.PLAYING && (advanced || rendered)) ||
                        (state == PlaybackState.READY && rendered) ||
                        (state == PlaybackState.PAUSED && rendered) ||
                        state == PlaybackState.ENDED
                if (healthy) {
                    android.util.Log.i(
                        TAG, "看门狗健康(${core.type} state=$state rendered=$rendered pos=$pos base=$basePos)"
                    )
                    break
                }

                // ★ 会话级守卫：本会话已自动回退过一次，则不再自动干预，避免 Exo↔mpv 无限互踢。
                //   必须在循环内实时读取（切换后重新 arm 时 watchdogSwitchCount 已为 1）。
                if (watchdogSwitchCount >= 1) {
                    android.util.Log.w(
                        TAG,
                        "看门狗: ${core.type} 黑屏但已达会话回退上限，不再自动切换（渲染告警）"
                    )
                    break
                }

                if (System.currentTimeMillis() - start > graceMs) {
                    val target = if (core.type == PlayerCoreType.EXOPLAYER) PlayerCoreType.MPV else PlayerCoreType.EXOPLAYER
                    android.util.Log.w(
                        TAG,
                        "看门狗: ${core.type} ${graceMs / 1000}s 未见有效画面(state=$state rendered=$rendered pos=$pos base=$basePos)，自动回退 $target"
                    )
                    watchdogSwitchCount++
                    switchCore(target)
                    break
                }
                Thread.sleep(tickMs)
            }
        }.also { it.isDaemon = true }
        watchdogThread?.start()
    }

    private fun cancelWatchdog() {
        watchdogCancelled = true
        watchdogThread?.let { runCatching { it.interrupt() } }
        watchdogThread = null
    }

    /**
     * 自动回退：Exo → mpv（§12.4）；mpv 出错/不 READY 时反向回退到 Exo（防黑屏兜底）。
     * 由宿主监听核心错误触发，且仅在满足条件时切换。
     */
    fun onCoreError(request: PlaybackRequest, error: PlaybackError) {
        val current = currentCore ?: return
        if (switchState != SwitchState.IDLE) return

        when (current.type) {
            PlayerCoreType.EXOPLAYER -> {
                if (!fallbackController.shouldAutoFallback(request, error.type)) {
                    android.util.Log.w(TAG, "onCoreError 不做回退（error=${error.type}），透传给 UI")
                    listener?.onError(error)
                    return
                }
                fallbackController.markAutoFallback(request)
                android.util.Log.w(TAG, "自动回退 Exo -> mpv（error=${error.type}）")
                switchCore(PlayerCoreType.MPV)
            }
            PlayerCoreType.MPV -> {
                android.util.Log.w(TAG, "mpv 出错（error=${error.type}），回退 ExoPlayer")
                switchCore(PlayerCoreType.EXOPLAYER) { r ->
                    if (r.isFailure) listener?.onError(error)
                }
            }
        }
    }

    // ---------------- 转发到当前核心 ----------------

    fun getSnapshot(): PlaybackSnapshot? = currentCore?.getSnapshot()

    fun play() = currentCore?.play()
    fun pause() = currentCore?.pause()
    fun togglePlay() = currentCore?.togglePlay()
    fun seekTo(positionMs: Long) = currentCore?.seekTo(positionMs)
    fun seekBy(deltaMs: Long) = currentCore?.seekBy(deltaMs)
    fun setSpeed(speed: Float) = currentCore?.setSpeed(speed)
    fun setVolume(volume: Float) = currentCore?.setVolume(volume)
    fun setMuted(muted: Boolean) = currentCore?.setMuted(muted)
    fun getTracks(): TrackModel = currentCore?.getTracks() ?: TrackModel.EMPTY
    fun selectTrack(selection: TrackSelection) = currentCore?.selectTrack(selection)

    fun release() {
        if (released) return // ★ 幂等守卫：只真正释放一次（leavePlayer / onDispose / onCleared 三重调用）
        released = true
        cancelWatchdog()
        watchdogThread = null
        watchdogSwitchCount = 0 // 复位会话级看门狗守卫，避免旧会话残留
        val old = currentCore
        // ★ 先释放 core（内部 executor.execute 同步等待 player.release() 完成），
        //   再拆视图（此时 player 已 null，View detach 不会触发 native 回调，消除返回退出崩溃）。
        old?.release()
        container?.removeAllViews()
        currentCore = null
        currentCoreType = null
        currentRequest = null
        pendingResume = null
        container = null
    }

    private val innerListener = object : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) {
            val snap = pendingResume
            if (snap != null && state == PlaybackState.READY) {
                pendingResume = null
                currentCore?.let { resumeAfterReady(it, snap) }
            }
            if (snap != null && (state == PlaybackState.ERROR || state == PlaybackState.ENDED)) {
                // 未 READY 就出错/结束：清理待恢复快照，避免误触发一次续播
                pendingResume = null
            }
            listener?.onPlaybackStateChanged(state)
        }
        override fun onPositionChanged(positionMs: Long, durationMs: Long) {
            lastPositionMs = positionMs
            listener?.onPositionChanged(positionMs, durationMs)
        }
        override fun onVideoSizeChanged(width: Int, height: Int) { listener?.onVideoSizeChanged(width, height) }
        override fun onTracksChanged(tracks: TrackModel) { listener?.onTracksChanged(tracks) }
        override fun onError(error: PlaybackError) {
            pendingResume = null
            currentRequest?.let { req -> onCoreError(req, error) } ?: listener?.onError(error)
        }
        override fun onBufferingChanged(buffering: Boolean) { listener?.onBufferingChanged(buffering) }
        override fun onPlaybackEnded() { listener?.onPlaybackEnded() }
    }

    private fun setState(state: SwitchState) {
        switchState = state
        switchCallback?.invoke(state)
    }

    private companion object {
        const val TAG = "PlayerHost"
    }

    enum class SwitchState {
        IDLE,
        SNAPSHOT_TAKEN,
        OLD_CORE_RELEASED,
        NEW_CORE_LOADING,
        SWITCH_COMPLETED
    }

    private object NullListener : PlayerCoreListener {
        override fun onPlaybackStateChanged(state: PlaybackState) {}
        override fun onPositionChanged(positionMs: Long, durationMs: Long) {}
        override fun onVideoSizeChanged(width: Int, height: Int) {}
        override fun onTracksChanged(tracks: TrackModel) {}
        override fun onError(error: PlaybackError) {}
        override fun onBufferingChanged(buffering: Boolean) {}
        override fun onPlaybackEnded() {}
    }
}