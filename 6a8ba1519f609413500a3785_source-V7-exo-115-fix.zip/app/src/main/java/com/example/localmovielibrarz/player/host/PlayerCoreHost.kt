package com.example.localmovielibrarz.player.host

import android.widget.FrameLayout
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Compose 播放器容器（§9.1）。
 *
 * 用 AndroidView 承载 [PlayerHost] 注入的 FrameLayout；在 DisposableEffect onDispose 时释放核心，
 * 避免 Surface 生命周期冲突与泄漏（§9.3 / 风险缓解）。
 */
@Composable
fun PlayerCoreHost(
    playerHost: PlayerHost,
    modifier: Modifier = Modifier
) {
    DisposableEffect(playerHost) {
        onDispose {
            playerHost.release()
        }
    }
    AndroidView(
        factory = { context ->
            FrameLayout(context).also { container ->
                playerHost.attachContainer(container)
            }
        },
        modifier = modifier,
        update = { container ->
            playerHost.attachContainer(container)
        }
    )
}