package com.example.localmovielibrarz.player.core

import android.content.Context
import com.example.localmovielibrarz.player.core.exo.ExoPlayerCoreImpl
import com.example.localmovielibrarz.player.core.mpv.MpvPlayerCoreImpl

/**
 * 核心注册表（§4 / §10.3）。
 *
 * 根据默认核心设置与智能路由规则返回初始核心；提供双核心实例工厂。
 */
class PlayerCoreRegistry(private val context: Context) {
    /** 双核心是否均可用（mpv 依赖原生库，缺失则 mpv 不可用）。 */
    val mpvAvailable: Boolean
        get() = MpvPlayerCoreImpl.isNativeAvailable

    fun isCoreAvailable(type: PlayerCoreType): Boolean = when (type) {
        PlayerCoreType.EXOPLAYER -> true
        PlayerCoreType.MPV -> mpvAvailable
    }

    fun availableCoreTypes(): Set<PlayerCoreType> {
        val set = mutableSetOf<PlayerCoreType>(PlayerCoreType.EXOPLAYER)
        if (mpvAvailable) set.add(PlayerCoreType.MPV)
        return set
    }

    fun create(type: PlayerCoreType): PlayerCore = when (type) {
        PlayerCoreType.EXOPLAYER -> ExoPlayerCoreImpl(context)
        PlayerCoreType.MPV -> {
            check(mpvAvailable) { "mpv 原生库不可用" }
            MpvPlayerCoreImpl(context)
        }
    }

    /**
     * 智能路由（§10.3）。
     *
     * @param requestedCore 用户显式选择的核心（none = 未指定）
     * @param preferMpvForComplexLocal 对本地怪格式 / 复杂字幕倾向 mpv
     */
    fun resolveDefaultCore(
        request: PlaybackRequest,
        requestedCore: PlayerCoreType? = null,
        preferMpvForComplexLocal: Boolean = true
    ): PlayerCoreType {
        when (request.fallbackPolicy) {
            FallbackPolicy.FORCE_MPV -> return PlayerCoreType.MPV
            FallbackPolicy.FORCE_EXOPLAYER -> return PlayerCoreType.EXOPLAYER
            else -> Unit
        }
        requestedCore?.let { return it }

        return when (request.sourceType) {
            SourceType.HLS, SourceType.DASH -> PlayerCoreType.EXOPLAYER
            SourceType.LOCAL_FILE -> {
                if (preferMpvForComplexLocal && isComplexLocalFile(request)) {
                    PlayerCoreType.MPV
                } else {
                    PlayerCoreType.EXOPLAYER
                }
            }
            SourceType.RTSP -> PlayerCoreType.MPV
            else -> PlayerCoreType.EXOPLAYER
        }
    }

    /** 本地怪格式启发式：扩展名等。 */
    private fun isComplexLocalFile(request: PlaybackRequest): Boolean {
        val ext = request.uri.path?.substringAfterLast('.', "").orEmpty().lowercase()
        return when (ext) {
            "mkv", "avi", "ts", "av1", "flv" -> true
            "mp4", "mov", "webm" -> false
            else -> false
        }
    }
}