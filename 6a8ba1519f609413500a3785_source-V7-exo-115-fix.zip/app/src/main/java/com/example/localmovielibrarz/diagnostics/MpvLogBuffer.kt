package com.example.localmovielibrarz.diagnostics

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * mpv 应用内日志缓冲（诊断用）。
 *
 * 目的：mpv 内部日志（libmpv 的 log_message）默认只进 Logcat，需要连电脑才能看。
 * 本缓冲在 [MpvPlayerCoreImpl] 的 logObserver 里同步写入，既保留内存环形缓存（供播放页即时读取），
 * 也异步落盘（供日志页面/导出查看），让真机无需连电脑即可定位黑屏/解码/渲染问题。
 */
object MpvLogBuffer {

    @Volatile private var persistent: MpvLogSink? = null

    private val lock = Any()
    private val ring = ArrayDeque<String>()
    private const val RING_CAPACITY = 600

    /** 必须在 App 初始化时调用一次（用 applicationContext）。 */
    fun init(context: Context) {
        val c = context.applicationContext
        persistent = MpvLogSink(c)
    }

    /** logObserver 回调入口：prefix=日志来源(如 vo/vd)，levelName=级别，text=日志正文。 */
    fun append(prefix: String, level: String, text: String) {
        val line = buildString {
            append('[').append(timestampShort()).append("] ")
            append('[').append(level).append("] ")
            if (prefix.isNotBlank()) append(prefix).append(' ')
            append(text.trimEnd())
        }
        synchronized(lock) {
            if (ring.size >= RING_CAPACITY) ring.removeFirst()
            ring.addLast(line)
        }
        persistent?.append(line)
    }

    /** 返回内存缓冲的完整快照（最新在后）。 */
    fun snapshot(): List<String> = synchronized(lock) { ring.toList() }

    fun clear() {
        synchronized(lock) { ring.clear() }
        persistent?.clear()
    }

    fun file(): File? = persistent?.file()

    private fun timestampShort(): String =
        SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
}

/** 异步落盘实现，与 [RuntimeErrorLog] 同样的写入约束。 */
private class MpvLogSink(context: Context) {
    private val appContext = context.applicationContext

    @Volatile private var pending: StringBuilder = StringBuilder()
    @Volatile private var flushScheduled = false

    @Synchronized
    fun append(line: String) {
        pending.append(line).append('\n')
        if (!flushScheduled) {
            flushScheduled = true
            val t = Thread({ flush() }, "mpv-log-writer")
            t.isDaemon = true
            t.start()
        }
    }

    @Synchronized
    private fun flush() {
        if (pending.isEmpty()) { flushScheduled = false; return }
        val batch = pending.toString()
        pending = StringBuilder()
        flushScheduled = false
        if (batch.isBlank()) return
        runCatching {
            val f = file()
            f.parentFile?.mkdirs()
            if (f.exists() && f.length() > MAX_BYTES) {
                // 已超限：只保留最后 TRIM_TO_CHARS 再追加
                runCatching {
                    val rest = f.readText(Charsets.UTF_8).takeLast(TRIM_TO_CHARS)
                    f.writeText(rest, Charsets.UTF_8)
                }
            }
            f.appendText(batch, Charsets.UTF_8)
        }
    }

    fun file(): File = File(appContext.filesDir, "diagnostics/mpv.log")

    @Synchronized
    fun clear() {
        pending = StringBuilder()
        runCatching { file().delete() }
    }

    private companion object {
        const val MAX_BYTES = 512 * 1024
        const val TRIM_TO_CHARS = 256 * 1024
    }
}