package com.example.localmovielibrarz.player.core

/**
 * 播放器快照（§6.8）。
 *
 * 用于「伪实时切换」：保存旧核心状态 → 释放 → 新核心根据快照恢复。
 */
data class PlaybackSnapshot(
    val request: PlaybackRequest,
    val coreType: PlayerCoreType,
    val positionMs: Long,
    val durationMs: Long,
    val speed: Float,
    val wasPlaying: Boolean,
    val volume: Float,
    val muted: Boolean,
    val audioTrackHint: TrackHint?,
    val subtitleTrackHints: List<TrackHint>,
    val subtitleDelayMs: Long?,
    val audioDelayMs: Long?,
    val fallbackUsed: Boolean,
    val lastError: PlaybackError?,
    val createdAt: Long
) {
    companion object {
        const val POSITION_UNKNOWN = -1L
    }

    /** 生成可供新核心直接使用的 PlaybackRequest（records startPosition）。 */
    fun toResumeRequest(origin: PlaybackOrigin = PlaybackOrigin.INTERNAL_SWITCH): PlaybackRequest =
        request.copy(
            startPositionMs = positionMs.coerceAtLeast(0L),
            audioTrackHint = audioTrackHint,
            subtitleTrackHints = subtitleTrackHints,
            origin = origin
        )
}