package com.example.localmovielibrarz.player.core

/**
 * 错误分类（§12.3）。
 *
 * 决定错误是可恢复、推荐回退 mpv、还是致命。自动回退仅 Exo → mpv。
 */
object PlaybackErrorClassifier {
    fun classify(type: PlaybackErrorType): ErrorSeverity = when (type) {
        PlaybackErrorType.DECODE_INIT_FAILED,
        PlaybackErrorType.DECODE_FAILED,
        PlaybackErrorType.FORMAT_UNSUPPORTED,
        PlaybackErrorType.CONTAINER_UNSUPPORTED ->
            ErrorSeverity.FALLBACK_RECOMMENDED

        PlaybackErrorType.SOURCE_UNREADABLE ->
            // 本地文件最多一次，网络流不回退（是否回退交给 FallbackController 判定）
            ErrorSeverity.FALLBACK_RECOMMENDED

        PlaybackErrorType.SUBTITLE_UNSUPPORTED ->
            // 优先禁用字幕而非回退
            ErrorSeverity.RECOVERABLE

        PlaybackErrorType.NETWORK_ERROR,
        PlaybackErrorType.TIMEOUT,
        PlaybackErrorType.HTTP_ERROR,
        PlaybackErrorType.DRM_ERROR,
        PlaybackErrorType.FILE_NOT_FOUND,
        PlaybackErrorType.PERMISSION_DENIED,
        PlaybackErrorType.USER_CANCELED ->
            ErrorSeverity.FATAL

        PlaybackErrorType.UNKNOWN ->
            ErrorSeverity.RECOVERABLE
    }

    fun classify(error: PlaybackError): ErrorSeverity = classify(error.type)
}

/**
 * 是否「允许」自动回退 mpv（§12.2）。
 *
 * @param isNetwork 该请求是否为网络流；网络流仅限解码/格式类，本地文件允许 SOURCE_UNREADABLE / UNKNOWN 谨慎回退一次。
 *
 * 调优（EXO 网络流失败回退）：115/光鸭等云盘直链（HTTP_PROGRESSIVE/HLS）在 mpv 下走系统代理+UA 可稳定拉流，
 * 而 ExoPlay 可能因代理/UA/远端状态码差异返回 HTTP_ERROR / NETWORK_ERROR / TIMEOUT。若按旧策略这些
 * FATAL 类错误不回退，会使用户"默认 Exo 时拉流失败即彻底卡死、切 mpv 却能播"。因此对网络流也允许
 * 网络错误**自动回退一次** mpv，由 FallbackController 的单会话单次限制防止无限循环。
 */
fun shouldFallbackToMpv(errorType: PlaybackErrorType, isNetwork: Boolean): Boolean = when (errorType) {
    PlaybackErrorType.DECODE_INIT_FAILED,
    PlaybackErrorType.DECODE_FAILED,
    PlaybackErrorType.FORMAT_UNSUPPORTED,
    PlaybackErrorType.CONTAINER_UNSUPPORTED -> true

    PlaybackErrorType.SOURCE_UNREADABLE,
    PlaybackErrorType.UNKNOWN -> !isNetwork // 本地最多一次，网络不回退

    // 网络错误（HTTP_ERROR / NETWORK_ERROR / TIMEOUT / FILE_NOT_FOUND）：网络流允许回退一次 mpv 兜底，
    // 因为 Elo 与 mpv 对云盘直链的拉流能力存在差异（代理/UA/远端状态码）。
    PlaybackErrorType.HTTP_ERROR,
    PlaybackErrorType.NETWORK_ERROR,
    PlaybackErrorType.TIMEOUT,
    PlaybackErrorType.FILE_NOT_FOUND -> isNetwork

    else -> false
}