package com.example.localmovielibrarz.player.core.mpv

import android.content.Context
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import `is`.xyz.mpv.MPVLib

/**
 * 精简版 mpv SurfaceView（§8.2 / §9.3）。
 *
 * 移植自 mpv-android 的 BaseMPVView，仅保留把画面画到屏幕所需的核心逻辑。
 * 生命周期：
 *  - [initialize] 在首次显示前调用，初始化 libmpv 并注册 Surface 回调。
 *  - [destroy] 在移除视图 / 释放核心前调用，确保 detachSurface 后再销毁。
 *  - Compose 中由 MpvPlayerCore 在 AndroidView onRelease / DisposableEffect 中调用。
 */
abstract class BaseMpvView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    private var filePath: String? = null

    /** surface 是否已就绪（已 attachSurface）。mpv 必须在 surface 就绪后才能 loadfile，否则无输出窗口 → 黑屏。 */
    @Volatile
    private var surfaceReady = false

    /**
     * 初始化 libmpv。
     * @param configDir mpv 配置目录（通常 filesDir.path）
     * @param cacheDir 缓存目录（gpu-shader 等）
     */
    fun initialize(configDir: String, cacheDir: String) {
        MPVLib.create(context.applicationContext)

        MPVLib.setOptionString("config", "yes")
        MPVLib.setOptionString("config-dir", configDir)
        for (opt in arrayOf("gpu-shader-cache-dir", "icc-cache-dir"))
            MPVLib.setOptionString(opt, cacheDir)

        initOptions()
        MPVLib.init()

        postInitOptions()
        // force-window=yes：让 vo 在 idle 时也持有输出窗口，配合 attachSurface 才有渲染目标，
        // 否则网络流 loadfile 后 vo 可能迟迟不配置 → 黑屏。
        MPVLib.setOptionString("force-window", "yes")
        MPVLib.setOptionString("idle", "once")

        holder.addCallback(this)
        observeProperties()
    }

    fun destroy() {
        holder.removeCallback(this)
        surfaceReady = false
        MPVLib.destroy()
    }

    protected abstract fun initOptions()
    protected abstract fun postInitOptions()
    protected abstract fun observeProperties()

    /** 设置要播放的文件：登记路径，并仅在 surface 已就绪时立即加载，否则等 surfaceCreated（防黑屏时序）。 */
    fun playFile(filePath: String) {
        this.filePath = filePath
        if (surfaceReady) {
            doLoadfile(filePath)
            this.filePath = null
        }
    }

    /** 内部统一加载入口，防止双重 loadfile 与加载早于 surface 就绪。 */
    private fun doLoadfile(path: String) {
        android.util.Log.d(TAG, "loadfile on ready surface: $path")
        MPVLib.command(arrayOf("loadfile", path))
    }

    private var voInUse: String = "gpu"

    fun setVo(vo: String) {
        voInUse = vo
        MPVLib.setOptionString("vo", vo)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        MPVLib.setPropertyString("android-surface-size", "${width}x$height")
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.d(TAG, "attaching surface")
        // 先确保 vo 持有窗口，再 attachSurface，避免渲染目标缺失
        MPVLib.setOptionString("force-window", "yes")
        MPVLib.attachSurface(holder.surface)
        surfaceReady = true

        // mpv 官方流程：surface 就绪后再 loadfile，确保有输出窗口
        filePath?.let {
            doLoadfile(it)
            filePath = null
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.d(TAG, "detaching surface")
        surfaceReady = false
        MPVLib.setPropertyString("vo", "null")
        MPVLib.setPropertyString("force-window", "no")
        MPVLib.detachSurface()
    }

    private companion object {
        const val TAG = "MpvView"
    }
}