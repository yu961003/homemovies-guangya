package com.example.localmovielibrarz.player.core

import android.net.Uri
import java.util.concurrent.ConcurrentHashMap

/**
 * 错误回退控制器（§12）。
 *
 * 原则：
 *  - 自动回退仅限 Exo → mpv。
 *  - 仅解码/格式类错误触发。
 *  - 同一 PlaybackRequest + 同一播放会话内最多自动回退一次。
 *  - 用户手动切换核心会重置自动回退标记（允许再次自动回退一次）。
 */
class FallbackController(
    private val isNetwork: (SourceType) -> Boolean = { SourceTypeResolver.isNetwork(it) }
) {
    /** 每个请求 key（uri）的本次会话自动回退标记。 */
    private val autoFellBack = ConcurrentHashMap<String, Boolean>()

    /**
     * 根据错误决定是否应自动回退 mpv。
     *
     * @param request 当前请求
     * @param errorType 错误类型
     * @param forceReset 用户手动切换核心时传 true，重置本请求的回退标记
     */
    fun shouldAutoFallback(request: PlaybackRequest, errorType: PlaybackErrorType, forceReset: Boolean = false): Boolean {
        if (request.fallbackPolicy == FallbackPolicy.DISABLED) return false
        if (request.fallbackPolicy == FallbackPolicy.FORCE_MPV) return false
        if (request.coreRequested() != null) return false

        val key = fallbackKey(request.uri)
        if (forceReset) {
            autoFellBack.remove(key)
            return false // 仅重置，不触发
        }
        if (autoFellBack[key] == true) return false // 同一会话已回退过

        val network = isNetwork(request.sourceType)
        if (!shouldFallbackToMpv(errorType, network)) return false
        return true
    }

    /** 标记某请求已发生自动回退。 */
    fun markAutoFallback(request: PlaybackRequest) {
        autoFellBack[fallbackKey(request.uri)] = true
    }

    /** 用户手动切换核心时重置自动回退标记。 */
    fun resetAutoFallback(uri: Uri) {
        autoFellBack.remove(fallbackKey(uri))
    }

    /** 是否允许再次自动回退（用户切换后）。 */
    fun canAutoFallback(uri: Uri): Boolean = autoFellBack[fallbackKey(uri)] != true

    private fun PlaybackRequest.coreRequested(): PlayerCoreType? = when (fallbackPolicy) {
        FallbackPolicy.FORCE_MPV -> PlayerCoreType.MPV
        FallbackPolicy.FORCE_EXOPLAYER -> PlayerCoreType.EXOPLAYER
        else -> null
    }

    private fun fallbackKey(uri: Uri): String = uri.toString()

    /** 清理内存。 */
    fun clear() {
        autoFellBack.clear()
    }
}