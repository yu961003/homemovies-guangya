package com.example.localmovielibrarz.cloudguangya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 光鸭云盘浏览业务编排（镜像 Cloud115Client 薄封装）。 */
class GuangyaBrowserRepository(
    private val apiClient: GuangyaApiClient
) {
    /** parentId="" 为根目录（115 用 Long 类型的 ROOT_CID，光鸭用空串，P2-3）。带分页，返回页码数据与是否有更多。 */
    suspend fun listFiles(parentId: String, page: Int = 0, pageSize: Int = 100): GuangyaFilePage = withContext(Dispatchers.IO) {
        apiClient.listFiles(parentId, page, pageSize)
    }

    /** 列出某目录下的一级子文件夹（离线下载目标文件夹选择）。 */
    suspend fun listFolders(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFolders(parentId)
    }

    /** 全局搜索文件夹（离线下载目标文件夹搜索）。 */
    suspend fun searchFolders(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFolders(keyword)
    }

    /** 解析离线下载链接（磁力链/.torrent/ed2k）。 */
    suspend fun resolveOfflineUrl(url: String) = apiClient.resolveOfflineUrl(url)

    /** 创建云下载任务（离线下载）。 */
    suspend fun createOfflineTask(url: String, parentId: String) = apiClient.createOfflineTask(url, parentId)
}
