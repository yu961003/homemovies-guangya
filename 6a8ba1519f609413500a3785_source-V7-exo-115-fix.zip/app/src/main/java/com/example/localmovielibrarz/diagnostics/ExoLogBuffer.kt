package com.example.localmovielibrarz.diagnostics

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ExoPlayer 应用内日志缓冲（诊断用，对齐 [MpvLogBuffer]）。
 *
 * 目的：mpv 核心有独立的 [MpvLogBuffer] 可将内部日志写到应用内，而 ExoPlayer 核心之前
 * 全走 android.util.Log（仅 Logcat，需连电脑）。本缓冲在 [ExoPlayerCoreImpl] 的关键路径
 * （load / ensurePlayer / 状态 / onPlayerError / onPositionDiscontinuity）写入，
 * 供日志页即时查看与导出，真机无需连电脑即可定位拉流/解码/渲染问题。
 */
object ExoLogBuffer {

    @Volatile private var persistent: Sink? = null

    private val lock = Any()
    private val ring = ArrayDeque<String>()
    private const val RING_CAPACITY = 600

    /** 必须在 App 初始化时调用一次（用 applicationContext）。 */
    fun init(context: Context) {
        val c = context.applicationContext
        persistent = Sink(c)
    }

    /** 日志入口。 */
    fun log(prefix: String, text: String) {
        val line = buildString {
            append('[').append(timestampShort()).append("] ")
            if (prefix.isNotBlank()) append(prefix).append(' ')
            append(text.trimEnd())
        }
        synchronized(lock) {
            if (ring.size >= RING_CAPACITY) ring.removeFirst()
            ring.addLast(line)
        }
        persistent?.append(line)
    }

    /** 返回内存缓冲的完整快照（最新在后）。 */
    fun snapshot(): List<String> = synchronized(lock) { ring.toList() }

    fun clear() {
        synchronized(lock) { ring.clear() }
        persistent?.clear()
    }

    fun file(): File? = persistent?.file()

    private fun timestampShort(): String =
        SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
}

private class Sink(context: Context) {
    private val appContext = context.applicationContext

    @Volatile private var pending: StringBuilder = StringBuilder()
    @Volatile private var flushScheduled = false

    @Synchronized
    fun append(line: String) {
        pending.append(line).append('\n')
        if (!flushScheduled) {
            flushScheduled = true
            val t = Thread({ flush() }, "exo-log-writer")
            t.isDaemon = true
            t.start()
        }
    }

    @Synchronized
    private fun flush() {
        if (pending.isEmpty()) { flushScheduled = false; return }
        val batch = pending.toString()
        pending = StringBuilder()
        flushScheduled = false
        if (batch.isBlank()) return
        runCatching {
            val f = file()
            f.parentFile?.mkdirs()
            if (f.exists() && f.length() > MAX_BYTES) {
                runCatching {
                    val rest = f.readText(Charsets.UTF_8).takeLast(TRIM_TO_CHARS)
                    f.writeText(rest, Charsets.UTF_8)
                }
            }
            f.appendText(batch, Charsets.UTF_8)
        }
    }

    fun file(): File = File(appContext.filesDir, "diagnostics/exo.log")

    @Synchronized
    fun clear() {
        pending = StringBuilder()
        runCatching { file().delete() }
    }

    private companion object {
        const val MAX_BYTES = 512 * 1024
        const val TRIM_TO_CHARS = 256 * 1024
    }
}