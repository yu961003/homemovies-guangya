# 推送到 yanwo 的 GitHub 仓库 — 一键执行清单
#
# 目标仓库: https://github.com/yu961003/homemovies-guangya
# 方式: 覆盖推进到 main
#
# 背景: 本沙箱环境无 GitHub 写令牌，无法代表你完成推送。
#       以下命令在你的个人电脑（或任意已登录 GitHub 的终端）上执行即可。

# 仓库已就绪（沙箱内已 commit 为 c7b4faf），本地状态:
#   - 已 git init、配置 .gitignore
#   - 完整项目已提交（241 文件，无敏感文件）
#   - 已加 CI: .github/workflows/android-ci.yml（push 即触发 assembleDebug）

# ---- 方式 A: 推送到新分支（保留远端 main 历史，最安全，推荐）----
# git remote add origin https://github.com/yu961003/homemovies-guangya.git
# git push -u origin main:feat-dual-core

# ---- 方式 B: 覆盖推进既有 main（会以你的提交替换远端历史）----
# git remote add origin https://github.com/yu961003/homemovies-guangya.git
# git push -f origin main

# 注意:
#   - 仓库公开，匿名可读；写需要认证（PAT 或已登录 gh）。
#   - 若想仓库 CI 自动构建，确保 repo 的 Settings > Secrets 下已配置
#     ANDROID_SDK 所需 build-tools 不经公网即可，或直接用该 workflow 的 ubuntu 镜像。
#   - CI workflow 文件已随代码推送，push 后会自动在 Actions 中运行 assembleDebug。