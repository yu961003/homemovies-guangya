package com.example.localmovielibrarz.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        MovieEntity::class,
        DirectLinkEntity::class,
        PlaybackProgressEntity::class,
        CloudStrmRecordEntity::class,
        CloudFolderBatchTaskEntity::class,
        CloudVideoTaskEntity::class,
        GuangyaDirectLinkEntity::class
    ],
    version = 17,
    exportSchema = true
)
@TypeConverters(MovieTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun movieDao(): MovieDao
    abstract fun directLinkDao(): DirectLinkDao
    abstract fun playbackProgressDao(): PlaybackProgressDao
    abstract fun cloudStrmRecordDao(): CloudStrmRecordDao
    abstract fun cloudFolderBatchTaskDao(): CloudFolderBatchTaskDao
    abstract fun cloudVideoTaskDao(): CloudVideoTaskDao
    abstract fun guangyaDirectLinkDao(): GuangyaDirectLinkDao
}
