package com.example.localmovielibrarz.ui.cloudclean

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrarz.ui.settings.settingsTextFieldColors
import kotlinx.coroutines.delay

/**
 * 115 清理工具界面（需求 13）：
 * 顶部为共享清理规则配置（关键词 / 后缀 + 大小阈值），下方为全盘扫描命中列表，
 * 支持多选 / 全选后批量移入回收站（绝不永久删除）。
 */
@Composable
fun CloudCleanScreen(
    viewModel: CloudCleanViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var kwInput by remember { mutableStateOf("") }
    var sxInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf(viewModel.maxSizeMb().toString()) }
    var showCleanConfirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    LaunchedEffect(state.message) {
        state.message?.let {
            delay(2_500)
            viewModel.clearMessage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        // 顶栏
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "返回")
            }
            Text(
                text = "115 清理工具",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(
                onClick = { if (state.scanning) viewModel.stopScan() else viewModel.startScan() },
                enabled = !state.cleaning
            ) {
                Text(if (state.scanning) "停止扫描" else "开始扫描")
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.message?.let { msg ->
                Text(
                    text = msg,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            state.error?.let { err ->
                Text(
                    text = "出错：$err",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // 共享清理规则卡片
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("清理规则", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

                    // 关键词
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = kwInput,
                            onValueChange = { kwInput = it },
                            placeholder = { Text("关键词", style = MaterialTheme.typography.bodySmall) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f),
                            colors = settingsTextFieldColors()
                        )
                        Button(
                            onClick = {
                                viewModel.addKeyword(kwInput)
                                kwInput = ""
                            },
                            enabled = kwInput.isNotBlank(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) { Text("添加") }
                    }
                    KeywordChips(
                        items = viewModel.keywords().toList(),
                        hint = "无关键词（文件名包含即命中）",
                        onRemove = viewModel::removeKeyword
                    )

                    // 后缀
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = sxInput,
                            onValueChange = { sxInput = it },
                            placeholder = { Text("后缀，如 txt", style = MaterialTheme.typography.bodySmall) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f),
                            colors = settingsTextFieldColors()
                        )
                        Button(
                            onClick = {
                                viewModel.addSuffix(sxInput)
                                sxInput = ""
                            },
                            enabled = sxInput.isNotBlank(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) { Text("添加") }
                    }
                    KeywordChips(
                        items = viewModel.suffixes().toList(),
                        hint = "无后缀（匹配文件扩展名）",
                        onRemove = viewModel::removeSuffix
                    )

                    // 大小阈值
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("小文件上限(MB)", style = MaterialTheme.typography.labelMedium)
                        OutlinedTextField(
                            value = sizeInput,
                            onValueChange = { sizeInput = it },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            textStyle = MaterialTheme.typography.bodySmall,
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )
                        TextButton(
                            onClick = {
                                val n = sizeInput.toIntOrNull()
                                if (n != null) viewModel.saveMaxSizeMb(n) else sizeInput = viewModel.maxSizeMb().toString()
                            }
                        ) { Text("保存") }
                    }
                }
            }

            // 扫描状态与命中列表标题
            if (state.scanning) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "扫描中：目录 ${state.scannedDirs} · 文件 ${state.scannedFiles} · 命中 ${state.matches.size}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                Text(
                    text = "命中 ${state.matches.size} 项",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // 命中列表
            if (state.matches.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (state.scanning) "正在扫描…" else "暂无命中项，点击「开始扫描」检查网盘",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.matches, key = { it.pickcode }) { match ->
                        val checked = match.pickcode in state.selectedPickcodes
                        val rowBg =
                            if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    rowBg,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = match.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "路径：${match.path} · ${match.reason}",
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                match.size?.let {
                                    Text(
                                        text = formatSize(it),
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            if (state.selectionMode) {
                                Checkbox(checked = checked, onCheckedChange = { viewModel.toggleSelect(match.pickcode) })
                            } else {
                                TextButton(onClick = { viewModel.enterSelectionMode(); viewModel.toggleSelect(match.pickcode) }) {
                                    Text("选择", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 底部操作栏（多选模式）
        if (state.selectionMode) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "已选 ${state.selectedPickcodes.size}/${state.matches.size}",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = viewModel::selectAll) { Text("全选", style = MaterialTheme.typography.labelMedium) }
                    TextButton(
                        onClick = { showCleanConfirm = true },
                        enabled = state.selectedPickcodes.isNotEmpty() && !state.cleaning
                    ) {
                        Text("移入回收站", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = viewModel::clearSelection) { Text("完成", style = MaterialTheme.typography.labelMedium) }
                }
            }
        }
    }

    if (showCleanConfirm) {
        AlertDialog(
            onDismissRequest = { showCleanConfirm = false },
            title = { Text("移入回收站？") },
            text = {
                Text("确定将选中的 ${state.selectedPickcodes.size} 项移入回收站吗？回收站内可恢复，不会彻底删除。")
            },
            confirmButton = {
                Button(onClick = {
                    showCleanConfirm = false
                    viewModel.cleanSelected()
                }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showCleanConfirm = false }) { Text("取消") }
            }
        )
    }
}

/** 规则项 chips（可逐个删除）。 */
@Composable
private fun KeywordChips(items: List<String>, hint: String, onRemove: (String) -> Unit) {
    if (items.isEmpty()) {
        Text(
            text = hint,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            style = MaterialTheme.typography.bodySmall
        )
        return
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(items) { item ->
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(start = 10.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                IconButton(
                    onClick = { onRemove(item) },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "移除 $item",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024 && idx < units.size - 1) {
        value /= 1024
        idx++
    }
    return if (idx == 0) "$bytes B" else "%.1f %s".format(value, units[idx])
}