package com.example.localmovielibrarz.cloudguangya

import com.example.localmovielibrarz.playback.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import com.example.localmovielibrarz.util.HttpClients

class GuangyaTokenExpiredException(message: String = "光鸭访问令牌已失效") : Exception(message)
class GuangyaApiException(message: String, code: String = "") : Exception(message)

/**
 * 光鸭业务客户端：列目录 / 直链。返回 {msg, data, error} 信封（P1-7）。
 *
 * - 仅注入 `Authorization: Bearer <token>`，无签名 / HMAC（反编译确认）。
 * - 401 或信封错误 → 抛 [GuangyaTokenExpiredException]，由 [apiCall] 触发刷新重试（P1-4）。
 */
class GuangyaApiClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .connectionPool(HttpClients.sharedConnectionPool)
        .dispatcher(HttpClients.sharedDispatcher)
        .build(),
    private val tokenProvider: GuangyaTokenProvider,
    private val rateLimiter: GuangyaRateLimiter
    ) {
    private companion object {
        const val MAX_PAGES = 50 // 循环翻页上限（≤5000 项；文件夹场景 pageSize=500 时≤25000），防止接口异常导致无限循环
    }

    private suspend fun <T> apiCall(block: suspend () -> T): T = try {
        block()
    } catch (e: GuangyaTokenExpiredException) {
        tokenProvider.refreshAndStore() // P1-4 刷新（带并发锁）+ 存盘
        block()                         // 重试一次
    }

    suspend fun listFiles(parentId: String): List<GuangyaFileItem> =
        apiCall {
            // 审查 P1(A)：循环翻页聚合，避免目录超过一页被静默截断（对齐 115 行为）
            val all = mutableListOf<GuangyaFileItem>()
            var page = 0
            while (true) {
                rateLimiter.acquireRead() // 每页都限频，避免连续翻页触发光鸭限频
                val data = postEnvelope(
                    "/userres/v1/file/get_file_list",
                    mapOf("parentId" to parentId, "page" to page, "pageSize" to 100)
                )
                val list = data.optJSONArray("list")
                if (list == null || list.length() == 0) break
                val parsed = buildList {
                    for (i in 0 until list.length()) {
                        parseFile(list.optJSONObject(i))?.let { add(it) }
                    }
                }
                all += parsed
                if (parsed.size < 100 || page >= MAX_PAGES) break
                page++
            }
            all
        }

    /** 原始直链（核心路径）。返回 data.signedURL（临时地址，播放时实时解析）。 */
    suspend fun fetchDirectUrl(fileId: String): String =
        apiCall {
            rateLimiter.acquireRead()
            val data = postEnvelope("/userres/v1/get_res_download_url", mapOf("fileId" to fileId))
            data.optString("signedURL").takeIf { it.isNotBlank() } ?: error("光鸭直链为空")
        }

    /**
     * VOD(m3u8) 直链（可选，P2-2 首期不建议启用）。
     * gcid 为空时按 P1-5 先取文件详情补 gcid。
     */
    suspend fun fetchVodUrl(fileId: String, gcid: String?): String =
        apiCall {
            val realGcid = gcid ?: getFileDetailGcid(fileId)
            rateLimiter.acquireRead()
            val data = postEnvelope(
                "/userres/v1/file/get_vod_download_url",
                mapOf("fileId" to fileId, "gcid" to (realGcid ?: ""))
            )
            data.optString("signedURL").takeIf { it.isNotBlank() } ?: error("光鸭 VOD 直链为空")
        }

    private suspend fun getFileDetailGcid(fileId: String): String? =
        runCatching {
            rateLimiter.acquireRead()
            val data = postEnvelope("/userres/v1/file/get_file_detail", mapOf("fileId" to fileId))
            data.optString("gcid").takeIf { it.isNotBlank() }
        }.getOrNull()

    // ==================== 文件夹选择（离线下载目标目录） ====================

    /** 列出某目录下的一级子文件夹（resType=2），用于离线下载目标文件夹选择（移植脚本 listFoldersUnder）。 */
    suspend fun listFolders(parentId: String): List<GuangyaFileItem> =
        apiCall {
            // 审查 P1(A)：文件夹选择器同样需循环翻页，避免大目录被静默截断
            val all = mutableListOf<GuangyaFileItem>()
            var page = 0
            while (true) {
                rateLimiter.acquireRead()
                val data = postEnvelope(
                    "/userres/v1/file/get_file_list",
                    mapOf("parentId" to parentId, "page" to page, "pageSize" to 500, "orderBy" to 0, "sortType" to 0, "resType" to 2)
                )
                val list = data.optJSONArray("list")
                if (list == null || list.length() == 0) break
                val parsed = buildList {
                    for (i in 0 until list.length()) {
                        parseFile(list.optJSONObject(i))?.let { if (it.isDir) add(it) }
                    }
                }
                all += parsed
                if (parsed.size < 500 || page >= MAX_PAGES) break
                page++
            }
            all
        }

    /** 全局搜索文件夹（search_files，resType=2），用于离线下载目标文件夹搜索（移植脚本 searchFolders）。 */
    suspend fun searchFolders(keyword: String): List<GuangyaFileItem> =
        apiCall {
            // 审查 P1(A)：文件夹搜索同样需循环翻页，避免大结果被静默截断
            val all = mutableListOf<GuangyaFileItem>()
            var page = 0
            while (true) {
                rateLimiter.acquireRead()
                val data = postEnvelope(
                    "/userres/v1/file/search_files",
                    mapOf("name" to keyword, "page" to page, "pageSize" to 100, "orderBy" to 0, "sortType" to 0, "resType" to 2)
                )
                val list = data.optJSONArray("list")
                if (list == null || list.length() == 0) break
                val parsed = buildList {
                    for (i in 0 until list.length()) {
                        val o = list.optJSONObject(i) ?: continue
                        // 搜索结果每项可能直接有 fileId/fileName，或包在 fileInfo 里（脚本已确认）
                        val fi = o.optJSONObject("fileInfo") ?: o
                        val fileId = fi.optString("fileId").takeIf { it.isNotBlank() } ?: fi.optString("id", "")
                        val name = fi.optString("fileName").takeIf { it.isNotBlank() } ?: fi.optString("name", "")
                        if (fileId.isNotBlank() && name.isNotBlank()) {
                            add(
                                GuangyaFileItem(
                                    fileId = fileId,
                                    name = name,
                                    isDir = true,
                                    size = 0L,
                                    fileType = null,
                                    gcid = null,
                                    parentId = fi.optString("parentId", "")
                                )
                            )
                        }
                    }
                }
                all += parsed
                if (parsed.size < 100 || page >= MAX_PAGES) break
                page++
            }
            all
        }

    // ==================== 离线下载（cloudcollection/v1，借鉴 guangya-txt 脚本逆向接口） ====================

    /** 解析离线下载链接（磁力链 / .torrent URL / ed2k），返回任务信息。 */
    suspend fun resolveOfflineUrl(url: String): JSONObject =
        apiCall {
            rateLimiter.acquireRead()
            postCloud("/cloudcollection/v1/resolve_res", mapOf("url" to url))
        }

    /** 创建云下载任务（离线下载）。 */
    suspend fun createOfflineTask(url: String, parentId: String = ""): JSONObject =
        apiCall {
            rateLimiter.acquireRead()
            postCloud(
                "/cloudcollection/v1/create_task",
                mapOf("url" to url, "parentId" to parentId)
            )
        }

    /**
     * cloudcollection（离线下载）专用请求：`{code, msg, data}` 信封 + dt/traceparent 头。
     * 与业务接口的 `{msg, data, error}` 信封不同，不能复用 postEnvelope。
     */
    private suspend fun postCloud(path: String, body: Map<String, Any?>): JSONObject =
        withContext(Dispatchers.IO) {
            val token = tokenProvider.getValidAccessToken()
            val req = Request.Builder().url(GuangyaConstants.API_BASE + path)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("dt", "4")
                .header("traceparent", GuangyaDevice.generateTraceparent())
                .post(JSONObject(body).toString().toRequestBody(GuangyaConstants.MEDIA_JSON))
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.code == 401) throw GuangyaTokenExpiredException() // 触发上层刷新重试
                val root = JSONObject(resp.body?.string().orEmpty())
                if (root.has("code") && root.optInt("code", -1) != 0) {
                    throw GuangyaApiException(
                        root.optString("msg").takeIf { it.isNotBlank() } ?: "code ${root.optInt("code")}",
                        root.optString("error", "")
                    )
                }
                return@withContext if (root.has("data")) root.getJSONObject("data") else root
            }
        }

    private suspend fun postEnvelope(path: String, body: Map<String, Any?>): JSONObject =
        withContext(Dispatchers.IO) {
            val token = tokenProvider.getValidAccessToken() // 协程内预取（P2-6），非拦截器 runBlocking
            val req = Request.Builder().url(GuangyaConstants.API_BASE + path)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/json")
                .header("Content-Type", "application/json") // P1-8
                .post(JSONObject(body).toString().toRequestBody(GuangyaConstants.MEDIA_JSON))
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.code == 401) throw GuangyaTokenExpiredException() // 触发上层刷新重试
                val root = JSONObject(resp.body?.string().orEmpty())
                val msg = root.optString("msg", "success")
                if (msg != "success" || root.opt("error") != null) {
                    throw GuangyaApiException(msg, root.optString("error", ""))
                }
                return@withContext root.getJSONObject("data") // 信封 data
            }
        }

    /** 全局搜索文件+目录（search_files，resType 不限），用于列表页搜索（需求 2）。 */
    suspend fun searchFiles(keyword: String): List<GuangyaFileItem> =
        apiCall {
            val all = mutableListOf<GuangyaFileItem>()
            var page = 0
            while (true) {
                rateLimiter.acquireRead()
                val data = postEnvelope(
                    "/userres/v1/file/search_files",
                    mapOf("name" to keyword, "page" to page, "pageSize" to 100, "orderBy" to 0, "sortType" to 0)
                )
                val list = data.optJSONArray("list")
                if (list == null || list.length() == 0) break
                val parsed = buildList {
                    for (i in 0 until list.length()) {
                        val o = list.optJSONObject(i) ?: continue
                        val fi = o.optJSONObject("fileInfo") ?: o // 搜索结果可能包在 fileInfo 里
                        parseFile(fi)?.let { add(it) } // 复用统一字段兜底（fileId/id、fileName/name、fileSize/size、resType）
                    }
                }
                all += parsed
                if (parsed.size < 100 || page >= MAX_PAGES) break
                page++
            }
            all
        }

    // ==================== 文件操作（需求 3，参照 GuangyaTools 安全语义） ====================

    /** 批量移动文件/目录到目标父目录（每批 ≤50）。 */
    suspend fun moveFiles(fileIds: List<String>, targetParentId: String) {
        if (fileIds.isEmpty()) return
        fileIds.chunked(50).forEach { batch ->
            apiCall {
                rateLimiter.acquireRead()
                postFileOp("/nd.bizuserres.s/v1/file/move_file", mapOf("fileIds" to batch, "parentId" to targetParentId))
            }
        }
    }

    /** 批量移入回收站（每批 ≤50，绝不永久删除）。 */
    suspend fun recycleFiles(fileIds: List<String>) {
        if (fileIds.isEmpty()) return
        fileIds.chunked(50).forEach { batch ->
            apiCall {
                rateLimiter.acquireRead()
                postFileOp("/nd.bizuserres.s/v1/file/recycle_file", mapOf("fileIds" to batch))
            }
        }
    }

    /** 重命名文件/目录（保留扩展名由调用方保证）。 */
    suspend fun renameFile(fileId: String, newName: String) {
        if (fileId.isBlank() || newName.isBlank()) return
        apiCall {
            rateLimiter.acquireRead()
            postFileOp(
                "/nd.bizuserres.s/v1/file/rename",
                mapOf("fileId" to fileId, "newName" to newName, "clientId" to GuangyaConstants.CLIENT_ID)
            )
        }
    }

    /**
     * 文件操作专用请求：在 postEnvelope 基础上补充 dt/traceparent 头 + 请求体追加 clientId，
     * 对齐 guangya_flutter 的 apiRequest/did，确保服务端鉴权通过（需求 3 ⚠️ 请求头差异）。
     * 信封与业务接口相同（{msg, data, error}）。
     */
    private suspend fun postFileOp(path: String, body: Map<String, Any?>): JSONObject =
        withContext(Dispatchers.IO) {
            val token = tokenProvider.getValidAccessToken()
            val payload = JSONObject(body).apply { put("clientId", GuangyaConstants.CLIENT_ID) }
            val req = Request.Builder().url(GuangyaConstants.API_BASE + path)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("dt", "4")
                .header("traceparent", GuangyaDevice.generateTraceparent())
                .post(payload.toString().toRequestBody(GuangyaConstants.MEDIA_JSON))
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.code == 401) throw GuangyaTokenExpiredException() // 触发上层刷新重试
                val root = JSONObject(resp.body?.string().orEmpty())
                val msg = root.optString("msg", "success")
                if (msg != "success" || root.opt("error") != null) {
                    throw GuangyaApiException(msg, root.optString("error", ""))
                }
                return@withContext if (root.has("data")) root.optJSONObject("data") ?: JSONObject() else root
            }
        }

    /** P1-3 列目录字段兜底（对齐 guangya.py:542-553 的 fileId/id、fileName/name、fileSize/size）。 */
    private fun parseFile(o: JSONObject?): GuangyaFileItem? {
        o ?: return null
        val fileId = o.optString("fileId").takeIf { it.isNotBlank() } ?: o.optString("id", "")
        val name = o.optString("fileName").takeIf { it.isNotBlank() } ?: o.optString("name", "")
        if (fileId.isBlank() || name.isBlank()) return null
        val rawSize = o.opt("fileSize") ?: o.opt("size")
        val size = (rawSize as? Number)?.toLong() ?: 0L
        // 目录判断：光鸭用 resType==2（文件为 1），响应中没有 isDir 字段（AList 驱动确认）
        val isDir = o.optInt("resType", 1) == 2 || o.optBoolean("isDir", false)
        return GuangyaFileItem(
            fileId = fileId,
            name = name,
            isDir = isDir,
            size = size,
            fileType = o.optString("fileType").takeIf { it.isNotBlank() },
            gcid = o.optString("gcid").takeIf { it.isNotBlank() },
            parentId = o.optString("parentId", "")
        )
    }
}
