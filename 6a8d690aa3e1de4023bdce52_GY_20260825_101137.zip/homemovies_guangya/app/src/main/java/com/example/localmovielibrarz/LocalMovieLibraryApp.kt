package com.example.localmovielibrarz

import android.app.Application
import android.util.Log
import com.example.localmovielibrarz.data.AppContainer
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import android.os.SystemClock

class LocalMovieLibraryApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, BUILD_MARKER)
        container = AppContainer(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            private var startedAt = 0L
            override fun onStart(owner: LifecycleOwner) { startedAt = SystemClock.elapsedRealtime() }
            override fun onStop(owner: LifecycleOwner) {
                if (startedAt > 0L) container.usageStatsRepository.addAppMillis(SystemClock.elapsedRealtime() - startedAt)
                startedAt = 0L
            }
            override fun onDestroy(owner: LifecycleOwner) {
                // 审查 B1：进程退出时释放光鸭离线下载协程作用域，避免 ioScope 常驻泄漏
                container.guangyaOfflineMemory.dispose()
            }
        })
    }

    private companion object {
        private const val TAG = "LocalMovieLibraryApp"
        private const val BUILD_MARKER = "BUILD_MARKER=2026-06-12-room-paged-dao-player-subtitles"
    }
}
