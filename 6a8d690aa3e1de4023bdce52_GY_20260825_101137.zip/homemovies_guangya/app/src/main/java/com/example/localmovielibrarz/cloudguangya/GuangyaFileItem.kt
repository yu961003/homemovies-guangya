package com.example.localmovielibrarz.cloudguangya

/** 光鸭云盘文件模型（镜像 Cloud115FileItem，以 fileId 作为稳定标识）。 */
data class GuangyaFileItem(
    val fileId: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val fileType: String?,
    val gcid: String?,
    val parentId: String
) {
    fun isVideoFile(): Boolean =
        VIDEO_EXTENSIONS.any { name.endsWith(it, ignoreCase = true) }

    companion object {
        val VIDEO_EXTENSIONS = listOf(
            ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".ts", ".iso", ".flv", ".webm"
        )
    }
}
