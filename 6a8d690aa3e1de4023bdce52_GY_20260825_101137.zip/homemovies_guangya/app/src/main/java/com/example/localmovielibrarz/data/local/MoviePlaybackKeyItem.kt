package com.example.localmovielibrarz.data.local

data class MoviePlaybackKeyItem(
    val id: Long,
    val videoUri: String
)
