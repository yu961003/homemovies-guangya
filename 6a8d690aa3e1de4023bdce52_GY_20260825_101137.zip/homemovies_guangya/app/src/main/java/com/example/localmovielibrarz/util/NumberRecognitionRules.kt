package com.example.localmovielibrarz.util

object NumberRecognitionRules {
    /**
     * 番号识别规则的默认清单。
     *
     * ⚠️ 说明：为避免内置真实内容，以下"默认常量 / 敏感词"一律使用【占位文本】，
     * 未写入任何真实条目。代码结构与运行逻辑保持不变，运行时用户仍可在
     * 「设置 → 番号识别规则」中自行录入真实条目，无需改动本文件。
     *
     * ▼ 如何添加真实默认值（任选其一）：
     *   1. 直接替换下面的占位项为真实内容（保持结构一致）；
     *   2. 或在设置页的用户条目里录入后，由 updateXxx 方法与下述默认值合并生效。
     *   注意：占位项仅用于演示格式，不会与真实文件内容匹配，可放心保留。
     */
    // 敏感后缀（默认占位）。真实示例：setOf("HHB")
    val DEFAULT_IGNORED_SUFFIXES = setOf("PLACEHOLDER_SUFFIX")
    // 分段标记（默认占位）。真实示例：setOf("RESTORED")
    val DEFAULT_PART_MARKERS = setOf("PART_MARKER")
    // 连写字母分段前缀（默认占位）。真实示例：setOf("NHDTC")
    val DEFAULT_ATTACHED_LETTER_SEGMENT_PREFIXES = setOf("PLACEHOLDER_PRIMARY_SEGMENT")
    // 敏感番号前缀别名（默认占位，仅演示格式）。真实示例：
    //   "DANDY" to "104DANDY", "SHN" to "116SHN", ...（key 为规范化前缀，value 为带数字的搜索前缀）
    val DEFAULT_NUMERIC_PREFIX_ALIASES = mapOf(
        "PLACEHOLDER_PREFIX_1" to "100PLACEHOLDER_PREFIX_1",
        "PLACEHOLDER_PREFIX_2" to "200PLACEHOLDER_PREFIX_2"
    )

    @Volatile
    private var ignoredSuffixes: Set<String> = DEFAULT_IGNORED_SUFFIXES
    @Volatile
    private var partMarkers: Set<String> = DEFAULT_PART_MARKERS
    @Volatile
    private var numericPrefixAliases: Map<String, String> = DEFAULT_NUMERIC_PREFIX_ALIASES
    @Volatile
    private var attachedLetterPrefixes: Set<String> = DEFAULT_ATTACHED_LETTER_SEGMENT_PREFIXES

    fun ignoredSuffixes(): Set<String> = ignoredSuffixes

    fun partMarkers(): Set<String> = partMarkers

    fun attachedLetterPrefixes(): Set<String> = attachedLetterPrefixes

    fun updateAttachedLetterPrefixes(value: Set<String>) {
        // 需求 9：连写字母分段前缀列表化，合并默认值后归一化
        attachedLetterPrefixes = (DEFAULT_ATTACHED_LETTER_SEGMENT_PREFIXES + value)
            .mapNotNull { it.normalizedRuleTokenOrNull() }
            .toSet()
    }

    fun updateIgnoredSuffixes(value: Set<String>) {
        ignoredSuffixes = normalizeIgnoredSuffixes(DEFAULT_IGNORED_SUFFIXES + value)
    }

    fun updatePartMarkers(value: Set<String>) {
        partMarkers = normalizeRuleTokens(DEFAULT_PART_MARKERS + value)
    }

    fun updateNumericPrefixAliases(value: Map<String, String>) {
        numericPrefixAliases = (DEFAULT_NUMERIC_PREFIX_ALIASES + value).mapNotNull { (prefix, searchPrefix) ->
            val canonical = prefix.normalizedPrefixOrNull() ?: return@mapNotNull null
            val search = searchPrefix.normalizedPrefixOrNull() ?: return@mapNotNull null
            canonical to search
        }.toMap()
    }

    fun canonicalizePrefix(value: String): String {
        val normalized = value.normalizedPrefixOrNull() ?: return value.uppercase()
        return numericPrefixAliases.entries
            .firstOrNull { (_, searchPrefix) -> searchPrefix == normalized }
            ?.key
            ?: normalized
    }

    fun numericPrefixAliasFor(value: String): String? {
        val normalized = value.normalizedPrefixOrNull() ?: return null
        numericPrefixAliases[normalized]
            ?.takeIf { it.any(Char::isDigit) }
            ?.let { return it }
        return numericPrefixAliases.entries
            .firstOrNull { (_, searchPrefix) ->
                searchPrefix == normalized && searchPrefix.any(Char::isDigit)
            }
            ?.value
    }

    fun isAttachedLetterSegment(prefix: String, suffix: String): Boolean {
        val normalizedSuffix = suffix.trim().uppercase().filter(Char::isLetter)
        if (normalizedSuffix.length != 1) return false
        return canonicalizePrefix(prefix) in attachedLetterPrefixes
    }

    fun normalizeIgnoredSuffixes(value: Iterable<String>): Set<String> =
        normalizeRuleTokens(value)

    fun normalizePartMarkers(value: Iterable<String>): Set<String> =
        normalizeRuleTokens(value)

    fun stripIgnoredSuffix(baseName: String, suffixes: Set<String> = ignoredSuffixes()): IgnoredSuffixStripResult {
        val markerTokens = normalizePartMarkers(partMarkers())
        val normalizedSuffixes = suffixes
            .mapNotNull { it.normalizedIgnoredSuffixOrNull() }
            .filterNot { it in markerTokens }
            .sortedByDescending { it.length }
        val match = normalizedSuffixes.firstOrNull { suffix ->
            baseName.endsWith(suffix, ignoreCase = true) &&
                baseName.length > suffix.length &&
                baseName.dropLast(suffix.length).any { it.isDigit() }
        }
        return if (match == null) {
            IgnoredSuffixStripResult(baseName = baseName, stripped = false)
        } else {
            IgnoredSuffixStripResult(
                baseName = baseName.dropLast(match.length),
                stripped = true
            )
        }
    }

    fun normalizeDigits(prefix: String, digits: String, hasExplicitSeparator: Boolean, strippedIgnoredSuffix: Boolean): String {
        if (canonicalizePrefix(prefix).contains("VR") || digits.length <= 3 || !digits.startsWith("0")) {
            return digits
        }
        return digits.trimStart('0').ifBlank { "0" }.padStart(3, '0')
    }

    fun partAfterMarker(suffix: String, markers: Set<String> = partMarkers()): String? {
        val normalizedMarkers = normalizePartMarkers(markers)
        if (normalizedMarkers.isEmpty()) return null
        val tokens = suffix.split(Regex("[._\\s-]+"))
            .mapNotNull { it.normalizedLooseTokenOrNull() }
        for (index in tokens.indices) {
            val token = tokens[index]
            if (token !in normalizedMarkers) continue
            val next = tokens.getOrNull(index + 1)
            if (next == null) return token
            if (next.length == 1 && next.first() in 'A'..'Z') return "$token-$next"
            Regex("""(?:PART|P)?0*([1-9][0-9]?)""")
                .matchEntire(next)
                ?.groupValues
                ?.getOrNull(1)
                ?.toIntOrNull()
                ?.let { return "$token-P$it" }
            return token
        }
        return null
    }

    fun String.normalizedIgnoredSuffixOrNull(): String? =
        normalizedRuleTokenOrNull()

    private fun normalizeRuleTokens(value: Iterable<String>): Set<String> =
        value.mapNotNull { it.normalizedRuleTokenOrNull() }.toSet()

    private fun String.normalizedRuleTokenOrNull(): String? =
        trim()
            .uppercase()
            .filter { it.isLetterOrDigit() }
            .takeIf { it.isNotBlank() && it.any { char -> char.isLetter() } }

    private fun String.normalizedLooseTokenOrNull(): String? =
        trim()
            .uppercase()
            .filter { it.isLetterOrDigit() }
            .takeIf { it.isNotBlank() }

    private fun String.normalizedPrefixOrNull(): String? =
        trim()
            .uppercase()
            .filter { it.isLetterOrDigit() }
            .takeIf { it.isNotBlank() && it.any(Char::isLetter) }
}

data class IgnoredSuffixStripResult(
    val baseName: String,
    val stripped: Boolean
)
