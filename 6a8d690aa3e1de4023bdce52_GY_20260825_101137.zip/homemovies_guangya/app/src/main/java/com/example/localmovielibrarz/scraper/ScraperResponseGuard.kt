package com.example.localmovielibrarz.scraper

import okhttp3.ResponseBody
import java.io.IOException

/**
 * 刮削器 HTTP 响应健壮性守卫（安全审查修复）。
 *
 * - [readLimited]：限量读取响应体，防止异常网站返回超长 HTML/JSON 导致 OOM。
 * - [requireSafeScrapeNumber]：番号白名单校验，防止特殊字符改写 URL 主机/路径（SSRF/路径注入）。
 */
internal object ScraperResponseGuard {
    /** HTML 页面最大读取字节数（20MB，正常刮削页面远小于此）。 */
    const val MAX_HTML_BYTES = 20L * 1024 * 1024

    /** JSON 接口最大读取字节数（8MB）。 */
    const val MAX_JSON_BYTES = 8L * 1024 * 1024

    /** 限量读取响应体；超限抛 IOException。 */
    fun readLimited(body: ResponseBody, maxBytes: Long = MAX_HTML_BYTES): ByteArray {
        val source = body.source()
        val limited = source.readByteArray(maxBytes + 1)
        if (limited.size.toLong() > maxBytes) {
            throw IOException("响应体超过 ${maxBytes / 1024 / 1024}MB 限制，已中止读取")
        }
        return limited
    }

    /** 番号白名单：仅允许字母、数字与连字符，长度 1-40。异常格式直接抛错（正常番号如 ABC-123 均符合）。 */
    fun requireSafeScrapeNumber(number: String): String {
        val trimmed = number.trim()
        if (trimmed.isEmpty() || !trimmed.matches(SAFE_NUMBER)) {
            throw IllegalArgumentException("番号格式异常，无法安全搜索：$number")
        }
        return trimmed
    }

    private val SAFE_NUMBER = Regex("[A-Za-z0-9-]{1,40}")
}
