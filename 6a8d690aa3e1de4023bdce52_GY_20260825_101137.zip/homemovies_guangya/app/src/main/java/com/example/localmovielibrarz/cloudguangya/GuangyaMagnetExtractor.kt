package com.example.localmovielibrarz.cloudguangya

/**
 * 磁力链接/离线下载链接提取（移植自 guangya-txt-cloud-add 油猴脚本）。
 *
 * 支持格式：magnet:?xt=urn:btih:...、40 位 hex、32 位 base32、.torrent URL、ed2k 链接。
 * 逐行解析，去重，忽略 # / // 开头的注释行。
 * 每行支持提取多个链接（findAll），解决手动粘贴时同行多链接只识别首个的问题。
 */
object GuangyaMagnetExtractor {
    fun extractMagnets(text: String): List<String> {
        val found = LinkedHashSet<String>()
        text.lineSequence().forEach { line ->
            val s = line.trim()
            if (s.isEmpty() || s.startsWith("#") || s.startsWith("//")) return@forEach

            // 优先提取所有 magnet 链接（一行可能含多个）
            val magnets = MAGNET_RE.findAll(s).toList()
            if (magnets.isNotEmpty()) {
                magnets.forEach { found.add(it.value) }
                return@forEach
            }

            // .torrent URL（一行可能含多个，用 findAll）
            TORRENT_URL_RE.findAll(s).forEach { found.add(it.value) }

            // ed2k（一行可能含多个，用 findAll）
            ED2K_RE.findAll(s).forEach { found.add(it.value) }

            // 纯 40 位 hex（一行可能含多个）
            HASH40_RE.findAll(s).forEach { found.add("magnet:?xt=urn:btih:${it.value}") }

            // 纯 32 位 base32（一行可能含多个）
            HASH32_RE.findAll(s).forEach { found.add("magnet:?xt=urn:btih:${it.value}") }
        }
        return found.toList()
    }

    private val MAGNET_RE = Regex("""magnet:\?xt=urn:btih:[0-9a-fA-F]{32,40}""", RegexOption.IGNORE_CASE)
    private val HASH40_RE = Regex("""\b[0-9a-fA-F]{40}\b""")
    private val HASH32_RE = Regex("""\b[A-Z2-7]{32}\b""")
    private val TORRENT_URL_RE = Regex("""https?://\S+\.torrent(?:[?#]\S*)?""", RegexOption.IGNORE_CASE)
    private val ED2K_RE = Regex("""ed2k://\|file\|[^|]+\|\d+\|[0-9a-fA-F]{32}\|/""", RegexOption.IGNORE_CASE)

    /** 提取 urn:btih: 后的 info-hash（32-40 字符，用于去重记忆）。 */
    private val BTIH_RE = Regex("""urn:btih:([0-9a-fA-F]{32,40})""", RegexOption.IGNORE_CASE)

    /**
     * 从磁力链提取稳定哈希（info_hash），用于记忆去重 / 黑名单（移植油猴脚本 magnetHash）。
     * - magnet:?xt=urn:btih:HASH → HASH 大写
     * - 纯 40hex / 32base32 → 原值（hex 大写）
     * - .torrent URL → "url:xxx"
     * - 其它 → "raw:xxx"
     */
    fun magnetHash(magnet: String): String {
        val s = magnet.trim()
        BTIH_RE.find(s)?.let { return it.groupValues[1].uppercase() }
        HASH40_RE.find(s)?.let { return it.value.uppercase() }
        HASH32_RE.find(s)?.let { return it.value }
        if (s.startsWith("http://") || s.startsWith("https://")) return "url:$s"
        return "raw:$s"
    }
}
