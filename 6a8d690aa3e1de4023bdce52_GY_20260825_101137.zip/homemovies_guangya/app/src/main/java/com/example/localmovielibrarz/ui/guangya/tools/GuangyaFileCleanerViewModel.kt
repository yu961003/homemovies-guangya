package com.example.localmovielibrarz.ui.guangya.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuangyaFileCleanMatch(
    val fileId: String,
    val name: String,
    val size: Long?,
    val path: String,
    val reason: String
)

data class GuangyaFileCleanUiState(
    val scanning: Boolean = false,
    val matches: List<GuangyaFileCleanMatch> = emptyList(),
    val error: String? = null,
    val message: String? = null,
    val selectionMode: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val cleaning: Boolean = false
)

/** 光鸭文件清理：按共享清理名单递归扫描目录树 → 勾选 → 分批移入回收站。 */
class GuangyaFileCleanerViewModel(
    private val repository: GuangyaBrowserRepository,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GuangyaFileCleanUiState())
    val uiState: StateFlow<GuangyaFileCleanUiState> = _uiState.asStateFlow()

    private fun keywords() = settingsRepository.getCloudCleanKeywords()
    private fun suffixes() = settingsRepository.getCloudCleanSuffixes()
    private fun maxSizeMb() = settingsRepository.getCloudCleanMaxSizeMb()

    fun startScan(rootParentId: String, rootName: String) {
        if (keywords().isEmpty() && suffixes().isEmpty()) {
            _uiState.update { it.copy(message = "清理规则为空：请先在 设置→网盘→清理名单 添加关键词或后缀") }
            return
        }
        _uiState.update {
            it.copy(scanning = true, matches = emptyList(), selectionMode = false, selectedIds = emptySet(), error = null)
        }
        viewModelScope.launch {
            try {
                scanAll(rootParentId, rootName)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "扫描失败", scanning = false) }
            }
        }
    }

    private suspend fun scanAll(rootParentId: String, rootName: String) {
        val kw = keywords()
        val sfx = suffixes()
        // 大小阈值 0 = 不限制；>0 时仅对命中后缀且 size≤阈值生效（与 CloudCleanViewModel 一致）
        val maxBytes = maxSizeMb().takeIf { it > 0 }?.times(1024L * 1024L)
        val found = mutableListOf<GuangyaFileCleanMatch>()
        val visited = mutableSetOf<String>()
        val stack = ArrayDeque<Pair<String, String>>() // (parentId, path)
        stack.add(rootParentId to rootName)
        var expanded = 0
        while (stack.isNotEmpty()) {
            val (pid, path) = stack.removeLast()
            if (pid in visited) continue
            visited.add(pid)
            if (++expanded > 5000) break
            val children = repository.listFiles(pid)
            for (c in children) {
                if (c.isDir) {
                    if (expanded < 5000) stack.add(c.fileId to "$path/${c.name}")
                    continue
                }
                val reason = matchReason(c.name, c.size, kw, sfx, maxBytes)
                    ?: continue
                found += GuangyaFileCleanMatch(c.fileId, c.name, c.size, path, reason)
            }
            if (found.size % 200 == 0) {
                _uiState.update { it.copy(matches = found.toList()) }
                delay(16)
            }
        }
        _uiState.update { it.copy(matches = found.toList(), scanning = false, message = "扫描完成：命中 ${found.size} 个") }
    }

    private fun matchReason(name: String, size: Long?, kw: Set<String>, sfx: Set<String>, maxBytes: Long?): String? {
        val k = kw.firstOrNull { name.contains(it, ignoreCase = true) }
        if (k != null) return "包含关键词「$k」"
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isNotEmpty() && ext in sfx) {
            if (maxBytes != null) {
                val s = size ?: 0L
                if (s > 0L && s <= maxBytes) return "后缀 .$ext（≤${maxSizeMb()}MB）"
                if (s <= 0L) return "后缀 .$ext"
                return null
            }
            return "后缀 .$ext"
        }
        return null
    }

    fun toggleSelect(id: String) {
        _uiState.update { s -> s.copy(selectedIds = if (id in s.selectedIds) s.selectedIds - id else s.selectedIds + id) }
    }

    fun selectAll() { _uiState.update { s -> s.copy(selectedIds = s.matches.map { it.fileId }.toSet()) } }

    fun clearSelection() { _uiState.update { it.copy(selectionMode = false, selectedIds = emptySet()) } }

    fun cleanSelected() {
        val ids = _uiState.value.selectedIds.toList()
        if (ids.isEmpty()) { _uiState.update { it.copy(message = "请先勾选要移入回收站的文件") }; return }
        _uiState.update { it.copy(cleaning = true, message = "正在移入回收站…") }
        viewModelScope.launch {
            try {
                repository.recycleFiles(ids)
                _uiState.update {
                    it.copy(
                        message = "已移入回收站 ${ids.size} 项",
                        cleaning = false, selectionMode = false, selectedIds = emptySet(),
                        matches = it.matches.filterNot { m -> m.fileId in ids }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "移入回收站失败：${e.message}", cleaning = false) }
            }
        }
    }

    fun clearMessage() { _uiState.update { it.copy(message = null, error = null) } }

    companion object {
        fun factory(repository: GuangyaBrowserRepository, settingsRepository: AppSettingsRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    GuangyaFileCleanerViewModel(repository, settingsRepository) as T
            }
    }
}
