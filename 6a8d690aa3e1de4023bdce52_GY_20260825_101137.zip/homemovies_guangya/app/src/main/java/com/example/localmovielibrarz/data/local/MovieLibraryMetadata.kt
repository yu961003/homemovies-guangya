package com.example.localmovielibrarz.data.local

data class MovieMetadataList(
    val items: List<String>
)

data class MovieMetadataText(
    val value: String?
)
