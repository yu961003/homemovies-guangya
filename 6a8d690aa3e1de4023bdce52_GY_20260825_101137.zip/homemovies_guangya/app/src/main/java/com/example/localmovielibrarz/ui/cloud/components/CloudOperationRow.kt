package com.example.localmovielibrarz.ui.cloud.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * 网盘页统一尺寸规范（UI 重构指南 §2.2）。
 *
 * 所有功能按钮统一：18dp 图标、16dp 圆角、labelLarge + SemiBold 文字，
 * 消除 115 / 光鸭两页面按钮形态混搭。
 */
private object CloudBarDefaults {
    val IconSize = 22.dp // 顶栏导航图标
    val ButtonIconSize = 18.dp // 功能按钮内图标
    val IconButtonSize = 40.dp // IconButton 容器
    val ButtonCorner = 16.dp // 所有功能按钮圆角
    val PillCorner = 999.dp // pill 形圆角
    val BarHPadding = 8.dp // 顶栏左右内边距
    val BarTopPadding = 6.dp // 顶栏上内边距
    val BarBottomPadding = 10.dp // 顶栏下内边距
    val ItemSpacing = 4.dp // 顶栏内元素间距
}

/**
 * 网盘页统一第二行操作栏（115 / 光鸭共用）。
 *
 * 左侧：返回上级（仅 canGoBack 时显示）+ 根目录 + 搜索
 * 右侧：主操作（工具箱 / 离线下载，可按需传多个，样式统一）
 *
 * 所有按钮统一 16dp 圆角、18dp 图标、labelLarge 文字，消除混搭。
 */
@Composable
fun CloudOperationRow(
    canGoBack: Boolean,
    onGoBack: () -> Unit,
    onGoRoot: () -> Unit,
    onSearch: () -> Unit,
    searchEnabled: Boolean,
    primaryActions: List<CloudPrimaryAction>,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ===== 左侧：导航 + 搜索（统一 OutlinedButton，不再用 Surface pill 混搭） =====
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (canGoBack) {
                OutlinedButton(
                    onClick = onGoBack,
                    shape = RoundedCornerShape(CloudBarDefaults.ButtonCorner),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "返回上级", modifier = Modifier.size(CloudBarDefaults.ButtonIconSize))
                    Text(
                        "返回上级",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = CloudBarDefaults.ItemSpacing)
                    )
                }
            }
            OutlinedButton(
                onClick = onGoRoot,
                shape = RoundedCornerShape(CloudBarDefaults.ButtonCorner),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Rounded.Home, contentDescription = "根目录", modifier = Modifier.size(CloudBarDefaults.ButtonIconSize))
                Text(
                    "根目录",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = CloudBarDefaults.ItemSpacing)
                )
            }
            OutlinedButton(
                onClick = onSearch,
                shape = RoundedCornerShape(CloudBarDefaults.ButtonCorner),
                enabled = searchEnabled,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Rounded.Search, contentDescription = "搜索", modifier = Modifier.size(CloudBarDefaults.ButtonIconSize))
                Text(
                    "搜索",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = CloudBarDefaults.ItemSpacing)
                )
            }
        }

        // ===== 右侧：主操作（工具箱 / 离线下载，样式统一） =====
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            primaryActions.forEach { action ->
                when (action) {
                    is CloudPrimaryAction.Toolbox -> {
                        OutlinedButton(
                            onClick = action.onClick,
                            shape = RoundedCornerShape(CloudBarDefaults.ButtonCorner),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(CloudBarDefaults.ButtonIconSize))
                            Text(
                                "工具箱",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = CloudBarDefaults.ItemSpacing)
                            )
                        }
                    }
                    is CloudPrimaryAction.OfflineDownload -> {
                        Button(
                            onClick = action.onClick,
                            enabled = action.enabled,
                            shape = RoundedCornerShape(CloudBarDefaults.ButtonCorner),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Rounded.CloudDownload, contentDescription = null, modifier = Modifier.size(CloudBarDefaults.ButtonIconSize))
                            Text(
                                "离线下载",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = CloudBarDefaults.ItemSpacing)
                            )
                        }
                    }
                }
            }
        }
    }
}

/** 操作栏右侧主操作统一抽象。 */
sealed class CloudPrimaryAction {
    data class Toolbox(val onClick: () -> Unit) : CloudPrimaryAction()
    data class OfflineDownload(val onClick: () -> Unit, val enabled: Boolean = true) : CloudPrimaryAction()
}