plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

val purgeStaleRoomGeneratedSources by tasks.registering(Delete::class) {
    delete(
        layout.buildDirectory.dir("generated/ksp/debug/java/com/example/localmovielibrarz/data/local"),
        layout.buildDirectory.dir("kspCaches/debug/backups/java/byRounds")
    )
}

android {
    namespace = "com.example.localmovielibrarz"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.localmovielibrarz"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "3.2"
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Kotlin 2.3 已移除 kotlinOptions.jvmTarget，改用 compilerOptions DSL。
    // 用全限定名避免 JvmTarget 在 .kts 顶级作用域未解析的问题。
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }
}

// 导出 Room schema（5.6 优化）：追踪数据库 schema 变更历史，便于生成迁移测试
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

tasks.matching { task ->
    task.name in setOf("kspDebugKotlin", "compileDebugKotlin")
}.configureEach {
    dependsOn(purgeStaleRoomGeneratedSources)
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.05.00") // 跟随 Kotlin 2.3 的 Compose 编译器版本
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06") // 光鸭令牌加密存储 (P1-2)
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.zxing:core:3.5.3") // 需求 11：光鸭扫码登录二维码渲染

    implementation("androidx.media3:media3-exoplayer:1.9.1")
    implementation("androidx.media3:media3-ui:1.9.1")
    // 双核心 v5：移除 nextlib-media3ext（minCompileSdk 冲突 / 维护成本高），
    // Exo 软解短板改由 mpv 核心兜底（§5.4）。ExoPlayer 回归原生解码 + 解码器回退。

    implementation("androidx.room:room-ktx:2.8.4") // 升 2.8.4 以兼容 Kotlin 2.3 / KSP 2.3.x（2.6.1 的 KSP 处理器跟不上）
    ksp("androidx.room:room-compiler:2.8.4")

    testImplementation("junit:junit:4.13.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
