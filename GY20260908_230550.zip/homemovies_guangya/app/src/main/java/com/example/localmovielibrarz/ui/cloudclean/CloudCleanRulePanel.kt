package com.example.localmovielibrarz.ui.cloudclean
import com.example.localmovielibrarz.ui.AppRadius

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.ui.settings.settingsTextFieldColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.charset.Charset
import androidx.compose.foundation.layout.sizeIn
import com.example.localmovielibrarz.ui.MinTouchTarget

/** 清理名单条目数上限：防止 SharedPreferences StringSet 无上限失控（500 条 × 万级文件的 contains 仍是毫秒级）。 */
private const val MAX_RULE_ITEMS = 500

/**
 * 宽松分隔解析：换行/顿号/中英文逗号/分号/Tab/连续空格；每条 trim + 去首尾引号；空条丢弃。
 * 自检："广告 推广,试看、免费；完整版 now" → [广告, 推广, 试看, 免费, 完整版, now]；'"广告"' → [广告]。
 */
internal fun parseCleanRuleText(text: String): List<String> =
    text.split('\n', '、', ',', '，', ';', '；', '\t')
        .flatMap { it.split(Regex("\\s+")) }      // 空格分隔（单个/连续）
        .map { it.trim().trim('"', '「', '」').trim() }
        .filter { it.isNotEmpty() }
        .distinct()

/**
 * 共享清理名单卡片（115 / 光鸭两端的清理工具页内嵌）。
 * 同一份 SharedPreferences 数据（关键词/后缀/大小阈值 + 开关），两端修改即时互相同步。
 * 面板内不放标题——修复三的页面外层卡已有「清理名单」标题；只放开关可折叠内容。
 */
@Composable
fun CloudCleanRulePanel(
    keywords: Set<String>,
    suffixes: Set<String>,
    maxSizeMb: Int,
    keywordEnabled: Boolean,                       // ★ 新增
    suffixEnabled: Boolean,                        // ★ 新增
    onToggleKeyword: (Boolean) -> Unit,            // ★ 新增
    onToggleSuffix: (Boolean) -> Unit,             // ★ 新增
    onAddKeyword: (String) -> Unit,
    onRemoveKeyword: (String) -> Unit,
    onAddSuffix: (String) -> Unit,
    onRemoveSuffix: (String) -> Unit,
    onSaveMaxSizeMb: (Int) -> Unit,
    onImportKeywords: (List<String>) -> Unit,      // ★ 新增（TXT 批量导入）
    onImportSuffixes: (List<String>) -> Unit       // ★ 新增
) {
    var kwInput by remember { mutableStateOf("") }
    var sxInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf(maxSizeMb.toString()) }
    // TXT 批量导入：预览状态（目标, 解析条目）
    var importPreview by remember { mutableStateOf<Pair<String, List<String>>?>(null) }
    // UTF-8 优先 + GBK 回退的文件读取 launcher（Windows 记事本默认 ANSI）
    val kwTxtLauncher = rememberTxtLauncher { text ->
        val items = parseCleanRuleText(text)
        if (items.isNotEmpty()) importPreview = "关键词" to items
    }
    val sxTxtLauncher = rememberTxtLauncher { text ->
        val items = parseCleanRuleText(text)
        if (items.isNotEmpty()) importPreview = "后缀" to items
    }
    Column(
        modifier = Modifier.fillMaxWidth().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 开关行：两个可点亮 FilterChip（关键词 / 后缀）
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = keywordEnabled,
                onClick = { onToggleKeyword(!keywordEnabled) },
                label = { Text("关键词", style = MaterialTheme.typography.labelSmall) },
                leadingIcon = if (keywordEnabled) {
                    { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null
            )
            FilterChip(
                selected = suffixEnabled,
                onClick = { onToggleSuffix(!suffixEnabled) },
                label = { Text("后缀", style = MaterialTheme.typography.labelSmall) },
                leadingIcon = if (suffixEnabled) {
                    { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null
            )
        }
        Text(
            "点亮生效：只按点亮的规则匹配；两项都点亮时需同时命中（大小阈值仅对后缀生效）",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )

        // 关键词
        Row(
            modifier = Modifier.alpha(if (keywordEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = kwInput,
                onValueChange = { kwInput = it },
                placeholder = { Text("关键词", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                shape = AppRadius.MD,
                modifier = Modifier.weight(1f),
                colors = settingsTextFieldColors()
            )
            Button(
                onClick = {
                    onAddKeyword(kwInput)
                    kwInput = ""
                },
                enabled = kwInput.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) { Text("添加") }
            OutlinedButton(
                onClick = { kwTxtLauncher.launch(arrayOf("text/plain", "text/*")) },
                enabled = keywords.size < MAX_RULE_ITEMS,          // 上限保护
                shape = AppRadius.MD,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
            ) { Text("导入TXT", style = MaterialTheme.typography.labelMedium) }
        }
        KeywordList(
            items = keywords.toList(),
            hint = "无关键词（文件名包含即命中）",
            onRemove = onRemoveKeyword,
            dimmed = !keywordEnabled
        )

        // 后缀
        Row(
            modifier = Modifier.alpha(if (suffixEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = sxInput,
                onValueChange = { sxInput = it },
                placeholder = { Text("后缀，如 txt", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                shape = AppRadius.MD,
                modifier = Modifier.weight(1f),
                colors = settingsTextFieldColors()
            )
            Button(
                onClick = {
                    onAddSuffix(sxInput)
                    sxInput = ""
                },
                enabled = sxInput.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) { Text("添加") }
            OutlinedButton(
                onClick = { sxTxtLauncher.launch(arrayOf("text/plain", "text/*")) },
                enabled = suffixes.size < MAX_RULE_ITEMS,          // 上限保护
                shape = AppRadius.MD,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
            ) { Text("导入TXT", style = MaterialTheme.typography.labelMedium) }
        }
        KeywordList(
            items = suffixes.toList(),
            hint = "无后缀（匹配文件扩展名）",
            onRemove = onRemoveSuffix,
            dimmed = !suffixEnabled
        )

        // 大小阈值
        Row(
            modifier = Modifier.alpha(if (suffixEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("小文件上限(MB)", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(
                value = sizeInput,
                onValueChange = { sizeInput = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f),
                textStyle = MaterialTheme.typography.bodySmall,
                shape = AppRadius.MD,
                colors = settingsTextFieldColors()
            )
            TextButton(
                onClick = {
                    val n = sizeInput.toIntOrNull()
                    if (n != null) onSaveMaxSizeMb(n) else sizeInput = maxSizeMb.toString()
                }
            ) { Text("保存") }
        }
    }

    // 导入预览弹窗
    importPreview?.let { (target, items) ->
        AlertDialog(
            onDismissRequest = { importPreview = null },
            title = { Text("导入${target}（共 ${items.size} 条）") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        items.take(10).joinToString("、") + if (items.size > 10) " 等 ${items.size} 条" else "",
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 3, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "与现有列表自动去重；支持空格/逗号/顿号/分号/Tab/换行分隔",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (target == "关键词") onImportKeywords(items) else onImportSuffixes(items)
                    importPreview = null
                }) { Text("导入") }
            },
            dismissButton = { TextButton(onClick = { importPreview = null }) { Text("取消") } }
        )
    }
}

/**
 * TXT 文件读取 launcher：UTF-8 优先，出现替换符回退 GBK（Windows 记事本默认 ANSI）。
 * 文件读取放 IO 线程，回调切回主线程（修改 Compose 状态必须在主线程）。
 */
@Composable
private fun rememberTxtLauncher(onText: (String) -> Unit): ActivityResultLauncher<Array<String>> {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    return rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch(Dispatchers.IO) {
            val bytes = runCatching {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }.getOrNull() ?: return@launch
            val text = bytes.toString(Charsets.UTF_8)
                .takeIf { !it.contains('\uFFFD') }
                ?: String(bytes, Charset.forName("GBK"))
            withContext(Dispatchers.Main) { onText(text) }
        }
    }
}

/** 规则项折叠列表：默认预览 5 条，超限显示「共 N 条 / 展开全部」；可逐个删除；熄灭组整体降透明度。 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KeywordList(items: List<String>, hint: String, onRemove: (String) -> Unit, dimmed: Boolean = false) {
    var expanded by remember { mutableStateOf(false) }
    val maxPreview = 5

    if (items.isEmpty()) {
        Text(
            text = hint,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (dimmed) 0.25f else 0.5f),
            style = MaterialTheme.typography.bodySmall
        )
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "共 ${items.size} 条",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.weight(1f)
            )
            if (items.size > maxPreview) {
                TextButton(onClick = { expanded = !expanded }) {
                    Text(
                        if (expanded) "收起" else "展开全部",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
        val shown = if (expanded) items else items.take(maxPreview)
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (expanded) Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())
                    else Modifier
                ),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            shown.forEach { item -> KeywordChip(item, onRemove, dimmed) }
            if (!expanded && items.size > maxPreview) {
                Text(
                    "…还有 ${items.size - maxPreview} 条",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/** 单个规则项 chip（可点 × 删除）。 */
@Composable
private fun KeywordChip(item: String, onRemove: (String) -> Unit, dimmed: Boolean) {
    Row(
        modifier = Modifier
            .alpha(if (dimmed) 0.45f else 1f)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), AppRadius.MD)
            .padding(start = 10.dp, top = 3.dp, bottom = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(item, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        IconButton(
            onClick = { onRemove(item) },
            modifier = Modifier.sizeIn(minWidth = MinTouchTarget, minHeight = MinTouchTarget)
        ) {
            Icon(
                Icons.Rounded.Close,
                contentDescription = "移除 $item",
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}