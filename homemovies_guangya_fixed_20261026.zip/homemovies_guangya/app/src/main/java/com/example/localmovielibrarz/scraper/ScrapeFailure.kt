package com.example.localmovielibrarz.scraper

import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * 刮削失败的结构化归因（参考 peach 的 12 档失败分类，但只保留鸭影真正会遇到的几类）。
 *
 * 为什么需要它：现在所有失败都退化成 `error.message` 一个字符串，于是
 * 「站点 403 封了出口 IP」和「这个番号在站内确实搜不到」在日志里长得一模一样，
 * 用户与自动重试策略都没法据此做不同决定——前者该降权/冷却，后者该换下一个源。
 */
enum class ScrapeFailureKind(
    /** 换源/重试是否可能成功。确定性失败（番号不存在、配置错）重试只是浪费请求。 */
    val retryable: Boolean,
    /** 同一来源在这么久之内不应再被打扰；0 表示无需冷却。 */
    val cooldownMillis: Long
) {
    /** HTTP 401/403：被拦，通常与出口 IP 或风控有关，冷却要长。 */
    Forbidden(retryable = true, cooldownMillis = 30L * 60 * 1000),

    /** HTTP 429：明确要求限速。 */
    RateLimited(retryable = true, cooldownMillis = 10L * 60 * 1000),

    /** 验证页 / 人机校验 / 站点维护页：继续打只会被记更多次。 */
    Blocked(retryable = true, cooldownMillis = 30L * 60 * 1000),

    /** HTTP 5xx：服务端临时故障。 */
    ServerError(retryable = true, cooldownMillis = 2L * 60 * 1000),

    /** HTTP 404 / 站内没有该番号：确定性失败，换源而不是重试同一源。 */
    NotFound(retryable = false, cooldownMillis = 0L),

    /** 抓到了页面但解析不出字段：可能是站点改版，冷却中等。 */
    ParseError(retryable = true, cooldownMillis = 5L * 60 * 1000),

    /** 连接/超时/DNS/TLS：与站点内容无关，短冷却后即可再试。 */
    Network(retryable = true, cooldownMillis = 15_000L),

    /** 配置类错误（源未启用、地址非法、来源不支持）：重试永远不会成功。 */
    Config(retryable = false, cooldownMillis = 0L),

    Unknown(retryable = true, cooldownMillis = 0L)
}

data class ScrapeFailure(
    val kind: ScrapeFailureKind,
    val message: String,
    val httpCode: Int? = null
) {
    val retryable: Boolean get() = kind.retryable
    val cooldownMillis: Long get() = kind.cooldownMillis
}

/**
 * 从异常里解析出结构化失败。
 *
 * 站点实现统一用 `error("...")` 抛出 IllegalStateException，把 HTTP 状态码塞在文案里，
 * 所以这里既看异常类型，也看格式化后的文案——两条路都比改七个 scraper 的静态类型便宜。
 */
object ScrapeFailureClassifier {

    private val httpCodeRegex = Regex("""HTTP\s*(\d{3})""", RegexOption.IGNORE_CASE)

    fun fromThrowable(error: Throwable): ScrapeFailure {
        val text = buildString {
            append(error::class.java.simpleName)
            append(": ")
            append(error.message.orEmpty())
        }
        val httpCode = httpCodeRegex.find(text)?.groupValues?.get(1)?.toIntOrNull()
        val kind = classifyKind(error, text, httpCode)
        return ScrapeFailure(
            kind = kind,
            message = error.message ?: error::class.java.simpleName,
            httpCode = httpCode
        )
    }

    private fun classifyKind(error: Throwable, text: String, httpCode: Int?): ScrapeFailureKind {
        // 先看类型：网络层异常与文案无关，最可靠的信号。
        var current: Throwable? = error
        var depth = 0
        while (current != null && depth < 8) {
            when (current) {
                is SocketTimeoutException,
                is UnknownHostException,
                is SSLException,
                is InterruptedIOException -> return ScrapeFailureKind.Network
                else -> Unit
            }
            current = current.cause
            depth += 1
        }

        if (httpCode != null) {
            return when {
                httpCode == 401 || httpCode == 403 -> ScrapeFailureKind.Forbidden
                httpCode == 404 -> ScrapeFailureKind.NotFound
                httpCode == 429 -> ScrapeFailureKind.RateLimited
                httpCode in 500..599 -> ScrapeFailureKind.ServerError
                else -> ScrapeFailureKind.Unknown
            }
        }

        val lower = text.lowercase()
        return when {
            lower.contains("验证") || lower.contains("captcha") || lower.contains("人机") ->
                ScrapeFailureKind.Blocked
            lower.contains("没有搜索到") || lower.contains("未匹配") ||
                lower.contains("没有返回") || lower.contains("搜不到") ->
                ScrapeFailureKind.NotFound
            lower.contains("解析") || lower.contains("响应体超过") -> ScrapeFailureKind.ParseError
            lower.contains("请求失败") || lower.contains("连接") || lower.contains("超时") ||
                lower.contains("timeout") || lower.contains("socket") || lower.contains("响应为空") ->
                ScrapeFailureKind.Network
            lower.contains("不支持") || lower.contains("未启用") ||
                lower.contains("必须以 http") -> ScrapeFailureKind.Config
            else -> ScrapeFailureKind.Unknown
        }
    }
}

/**
 * 来源级健康度与冷却（参考 peach 的 403 按出口 IP 记账，但记账粒度收窄到「来源」）。
 *
 * 鸭影是单机 App，没有服务端出口 IP 的概念；真正会受伤的是「同一个站点被本地反复打」，
 * 所以按 [ScrapeSource] 记冷却就够了，也避免了引入持久化表。
 */
class ScrapeSourceHealthTracker(
    private val clock: () -> Long = System::currentTimeMillis
) {
    private val lock = Any()
    private val coolingUntil = mutableMapOf<ScrapeSource, Long>()
    private val lastFailures = mutableMapOf<ScrapeSource, ScrapeFailure>()

    fun cooldownRemaining(source: ScrapeSource): Long {
        synchronized(lock) {
            val until = coolingUntil[source] ?: return 0L
            return (until - clock()).coerceAtLeast(0L)
        }
    }

    fun isCoolingDown(source: ScrapeSource): Boolean = cooldownRemaining(source) > 0L

    fun lastFailure(source: ScrapeSource): ScrapeFailure? = synchronized(lock) { lastFailures[source] }

    /** 记录一次失败；[ScrapeFailureKind.cooldownMillis] 为 0 的种类不产生冷却。 */
    fun recordFailure(source: ScrapeSource, failure: ScrapeFailure) {
        synchronized(lock) {
            lastFailures[source] = failure
            if (failure.cooldownMillis > 0L) {
                val until = clock() + failure.cooldownMillis
                val previous = coolingUntil[source] ?: 0L
                if (until > previous) coolingUntil[source] = until
            }
        }
    }

    /** 成功一次就清掉冷却：站点已经能正常响应，没必要继续躲着。 */
    fun recordSuccess(source: ScrapeSource) {
        synchronized(lock) {
            coolingUntil.remove(source)
            lastFailures.remove(source)
        }
    }

    /**
     * 冷启动回灌：把上一次运行留在库里的冷却状态装回内存（由
     * `SourceHealthRepository.primeTracker` 调用）。
     *
     * 与 [recordFailure] 的区别是**不累加、不重算**：库里存的截止时间就是权威值，
     * 这里只负责把它翻译成「还剩多少毫秒」。重复回灌是幂等的（取较大值），
     * 所以启动期间被调用两次也不会把冷却越推越远。
     */
    fun restore(source: ScrapeSource, failure: ScrapeFailure, cooldownRemainingMillis: Long) {
        synchronized(lock) {
            lastFailures[source] = failure
            if (cooldownRemainingMillis > 0L) {
                val until = clock() + cooldownRemainingMillis
                val previous = coolingUntil[source] ?: 0L
                if (until > previous) coolingUntil[source] = until
            } else {
                coolingUntil.remove(source)
            }
        }
    }

    fun reset() {
        synchronized(lock) {
            coolingUntil.clear()
            lastFailures.clear()
        }
    }

    /** 给日志与设置页用的可读快照，例如 `Dmm=Forbidden（剩余 28 分钟）`。 */
    fun snapshot(): Map<ScrapeSource, String> = synchronized(lock) {
        lastFailures.mapValues { (source, failure) ->
            val remaining = ((coolingUntil[source] ?: 0L) - clock()).coerceAtLeast(0L)
            if (remaining > 0L) {
                "${failure.kind.name}（剩余 ${(remaining / 60_000L).coerceAtLeast(1L)} 分钟）"
            } else {
                failure.kind.name
            }
        }
    }
}
