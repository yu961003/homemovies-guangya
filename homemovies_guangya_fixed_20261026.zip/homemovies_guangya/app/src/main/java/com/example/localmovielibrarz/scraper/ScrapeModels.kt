package com.example.localmovielibrarz.scraper

enum class ScrapeSource {
    Priority,
    Dmm,
    Dmm2,
    Official,
    Mgstage,
    Javbus,
    TheJavDB,

    /**
     * r18.dev：DMM 数字版目录的 JSON 镜像。
     *
     * 位置放在枚举尾部的 `CustomJson` 之前，是为了让设置页的来源勾选顺序读起来仍是
     * 「DMM 系 → 官方 → 社区索引 → 镜像」；枚举序号不参与任何业务判断（路由与结算都走显式表）。
     */
    R18Dev,
    CustomJson;

    /**
     * 展示名，唯一来源。
     *
     * 在此之前，`StrmScrapeRepository` / `SettingsScreen` / `DetailViewModel` 各自有一份
     * 逐字相同的 `when (source) { ... -> "JavBus" }` 私有扩展——三份副本意味着将来改文案
     * 必然漏改一处。更麻烦的是刮削链（`ScrapeSourceChain`）在两个文件之外，够不着任何一份，
     * 只能自己再抄第四份。收敛到枚举成员后，链层的失败原因、设置页的当前来源、详情页的
     * 重刮按钮文案都取同一个值。
     *
     * 文案与既有三份保持一致（"优先级刮削" 而不是 "优先级链"），避免这一轮增强顺带改掉用户
     * 已经习惯的措辞。
     */
    val label: String
        get() = when (this) {
            Priority -> "优先级刮削"
            Dmm -> "DMM"
            Dmm2 -> "DMM2"
            Official -> "Official"
            Mgstage -> "MGStage"
            Javbus -> "JavBus"
            TheJavDB -> "TheJavDB"
            R18Dev -> "r18.dev"
            CustomJson -> "自定义 JSON"
        }

    companion object {
        fun fromStoredName(value: String?): ScrapeSource? {
            val normalized = value?.trim().orEmpty()
            if (normalized.equals("Javdb", ignoreCase = true)) return TheJavDB
            return entries.firstOrNull { it.name.equals(normalized, ignoreCase = true) }
        }
    }
}

data class ScrapedMovieInfo(
    val number: String,
    val title: String,
    val originalTitle: String = title,
    val plot: String = "",
    val outline: String = plot,
    val year: String = "",
    val premiered: String = "",
    val runtime: String = "",
    val studio: String = "",
    val publisher: String = "",
    val series: String = "",
    val directors: List<String> = emptyList(),
    val actors: List<String> = emptyList(),
    val actorImageUrls: Map<String, String> = emptyMap(),
    val genres: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
    val rating: String = "",
    val trailer: String = "",
    val website: String = "",
    val source: String = "",
    val thumbUrl: String = "",
    val posterUrl: String = "",
    val fanartUrl: String = "",
    val thumbImageUrls: List<String> = emptyList(),
    val posterImageUrls: List<String> = emptyList()
)

data class ScrapeRunResult(
    val scanned: Int,
    val success: Int,
    val skipped: Int,
    val failed: Int
)
