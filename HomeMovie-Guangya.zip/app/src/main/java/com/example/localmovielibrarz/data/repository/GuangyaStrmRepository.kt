package com.example.localmovielibrarz.data.repository

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.localmovielibrarz.cloudguangya.GuangyaApiClient
import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 光鸭 STRM 生成仓储（镜像 Cloud115StrmRepository）。
 *
 * 关键铁律：STRM 内容只写稳定 fileId，不写临时 signedURL：
 *   ${strmBaseUrl}/guangya_res/$fileId/$encodedName
 * 播放时由 PlaybackResolver 按 route 分流到 GuangyaDirectLinkResolver 实时解析直链。
 *
 * 注意：下方复用的 GeneratedStrmFile / WrittenStrmFile 由同包的 Cloud115StrmRepository 定义，
 * 本文件不再重复声明（避免同一包内数据类重声明冲突）。
 */
class GuangyaStrmRepository(
    private val context: Context,
    private val guangyaClient: GuangyaApiClient,
    private val settingsRepository: AppSettingsRepository,
    private val recordRepository: CloudStrmRecordRepository
) {
    suspend fun listFiles(parentId: String): List<GuangyaFileItem> = guangyaClient.listFiles(parentId)

    suspend fun generateStrmForVideo(item: GuangyaFileItem): GeneratedStrmFile = withContext(Dispatchers.IO) {
        if (item.isDir) error("请选择一个视频文件")
        if (!item.isVideoFile()) error("当前文件不是支持的视频格式")
        val fileId = item.fileId.takeIf { it.isNotBlank() } ?: error("这个文件没有 fileId，无法生成 STRM")

        recordRepository.getCached(fileId)?.let { existing ->
            return@withContext GeneratedStrmFile(
                fileName = existing.fileName,
                pickcode = fileId,
                strmUri = existing.strmUri,
                created = false
            )
        }

        val targetRoot = requireWritableStrmRoot()
        val file = writeStrmFile(targetRoot, item.name, fileId)
        recordRepository.upsertGenerated(
            pickcode = fileId, // 复用记录表，以 fileId 作为主键
            fileName = file.name,
            strmUri = file.uri,
            libraryRootUri = settingsRepository.getLibraryRootUri(),
            videoSizeBytes = item.size
        )
        GeneratedStrmFile(
            fileName = file.name,
            pickcode = fileId,
            strmUri = file.uri,
            created = true
        )
    }

    private fun requireWritableStrmRoot(): DocumentFile {
        val treeUri = settingsRepository.getStrmTreeUri()
            ?: error("请先到设置页选择影片库目录")
        val targetRoot = DocumentFile.fromTreeUri(context, Uri.parse(treeUri))
            ?: error("影片库目录不可用")
        if (!targetRoot.canWrite()) error("影片库目录没有写入权限")
        return targetRoot
    }

    private fun writeStrmFile(root: DocumentFile, videoName: String, fileId: String): GuangyaWrittenStrm {
        val baseName = videoName.substringBeforeLast('.', videoName).sanitizeFileName()
        val fileName = uniqueStrmName(root, baseName, fileId)
        val file = root.createFile("application/octet-stream", fileName)
            ?: error("无法创建 STRM 文件：$fileName")
        val encodedName = Uri.encode(videoName)
        val content = "${settingsRepository.getStrmBaseUrl()}/guangya_res/$fileId/$encodedName"
        context.contentResolver.openOutputStream(file.uri, "wt")?.use { output ->
            output.write(content.toByteArray(Charsets.UTF_8))
        } ?: error("无法写入 STRM 文件：$fileName")
        return GuangyaWrittenStrm(name = fileName, uri = file.uri.toString())
    }

    private fun uniqueStrmName(root: DocumentFile, baseName: String, fileId: String): String {
        val first = "$baseName.strm"
        if (root.findFile(first) == null) return first
        return "${baseName}_$fileId.strm"
    }

    private fun String.sanitizeFileName(): String =
        replace(Regex("""[\\/:*?"<>|]"""), "_").trim().ifBlank { "video" }

    companion object {
        val VIDEO_EXTENSIONS = listOf(
            ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".ts", ".iso", ".flv", ".webm"
        )
    }
}

/** 本文件内部使用的临时结构（与 Cloud115StrmRepository 的 WrittenStrmFile 隔离命名，避免重声明）。 */
private data class GuangyaWrittenStrm(
    val name: String,
    val uri: String
)
