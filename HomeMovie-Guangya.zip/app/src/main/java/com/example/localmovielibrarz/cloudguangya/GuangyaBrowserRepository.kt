package com.example.localmovielibrarz.cloudguangya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 光鸭云盘浏览业务编排（镜像 Cloud115Client 薄封装）。 */
class GuangyaBrowserRepository(
    private val apiClient: GuangyaApiClient
) {
    /** parentId="" 为根目录（115 用 Long 类型的 ROOT_CID，光鸭用空串，P2-3）。 */
    suspend fun listFiles(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFiles(parentId)
    }
}
