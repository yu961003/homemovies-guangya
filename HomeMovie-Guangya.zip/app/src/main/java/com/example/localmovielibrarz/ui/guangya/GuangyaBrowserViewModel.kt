package com.example.localmovielibrarz.ui.guangya

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.data.repository.CloudStrmRecordRepository
import com.example.localmovielibrarz.data.repository.GuangyaLocationSnapshot
import com.example.localmovielibrarz.data.repository.GuangyaStrmRepository
import com.example.localmovielibrarz.data.repository.MovieRepository
import com.example.localmovielibrarz.data.repository.StrmScrapeRepository
import com.example.localmovielibrarz.data.repository.finalizeOrganizedScrape
import com.example.localmovielibrarz.scraper.MovieNumberExtractor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuangyaBrowserUiState(
    val files: List<GuangyaFileItem> = emptyList(),
    val currentParentId: String = "",
    val path: List<String> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val message: String? = null,
    val addingFileIds: Set<String> = emptySet(),
    val addedFileIds: Set<String> = emptySet()
)

/**
 * 光鸭云盘浏览 + 添加 ViewModel（对齐 115 CloudBrowserViewModel 的操作逻辑）。
 * 根目录为 parentId=""（115 用 Long 类型的 ROOT_CID，光鸭用空串）。
 *
 * - 点视频 = 播放（由 UI 回调导航到播放器，播放时 PlaybackResolver 按 guangya_res 分流）。
 * - 点「添加」= 生成 STRM → 扫描入库 → 提取番号 → 自动刮削 → 整理同步（复用 115 链路，fileId 作为记录主键）。
 * - 目录「添加」= 递归遍历子目录，逐个添加视频（简化批量，不建持久化任务表）。
 */
class GuangyaBrowserViewModel(
    private val repository: GuangyaBrowserRepository,
    private val strmRepository: GuangyaStrmRepository,
    private val recordRepository: CloudStrmRecordRepository,
    private val movieRepository: MovieRepository,
    private val scrapeRepository: StrmScrapeRepository,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GuangyaBrowserUiState())
    val uiState: StateFlow<GuangyaBrowserUiState> = _uiState.asStateFlow()

    /** 进入页面时的持久登录态（浏览需要有效 token，未登录时 UI 引导去设置页）。 */
    val loggedIn: Boolean = settingsRepository.isGuangyaLoggedIn()

    /** 已进入目录的 parentId 栈（栈底为根的空串，栈顶=当前目录的父），用于「返回上级」。 */
    private val pathStack = mutableListOf<String>()

    /** 已进入目录的名称栈（根目录为空），用于顶栏路径展示。 */
    private val nameStack = mutableListOf<String>()

    /** 恢复的当前位置（当前目录的 fileId），restoreOrRoot 消费后置空。 */
    private var restoredParentId: String? = null

    init {
        // 恢复上次浏览位置（跨进程/重启保留）
        if (loggedIn) {
            val snapshot = settingsRepository.getGuangyaLocation()
            if (snapshot.currentParentId.isNotBlank() && snapshot.stack.isNotEmpty()) {
                pathStack.addAll(snapshot.stack)
                nameStack.addAll(snapshot.names)
                restoredParentId = snapshot.currentParentId
            } else {
                // 快照不完整（旧版本 bug 产生的数据）：清掉避免卡在错误状态
                settingsRepository.clearGuangyaLocation()
            }
        }
    }

    fun canGoBackFolder(): Boolean = pathStack.isNotEmpty()

    /** 进入页面时调用：有恢复位置则回到该目录，否则进入根目录。 */
    fun restoreOrRoot() {
        val target = restoredParentId ?: ""
        restoredParentId = null
        loadFiles(target)
    }

    fun enterRoot() {
        pathStack.clear()
        nameStack.clear()
        settingsRepository.clearGuangyaLocation()
        loadFiles("")
    }

    fun openFolder(item: GuangyaFileItem) {
        if (item.isDir) {
            pathStack.add(_uiState.value.currentParentId)
            nameStack.add(item.name)
            // 持久化「新目录」作为当前位置（loadFiles 为异步，不能依赖其后的状态）
            persistLocation(item.fileId)
            loadFiles(item.fileId)
        }
    }

    fun goUp() {
        if (pathStack.isEmpty()) {
            settingsRepository.clearGuangyaLocation()
            loadFiles("")
        } else {
            nameStack.removeLastOrNull()
            val parent = pathStack.removeAt(pathStack.size - 1)
            // 持久化「上级目录」作为当前位置
            persistLocation(parent)
            loadFiles(parent)
        }
    }

    private fun persistLocation(currentParentId: String) {
        settingsRepository.saveGuangyaLocation(
            GuangyaLocationSnapshot(
                stack = pathStack.toList(),
                currentParentId = currentParentId,
                names = nameStack.toList()
            )
        )
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }

    /** 添加单个视频：生成 STRM → 入库 → 自动刮削（镜像 115 的 processCloudVideoAddAllowScrapeFailure）。 */
    fun addVideoToLibrary(item: GuangyaFileItem) {
        val fileId = item.fileId
        if (fileId.isBlank()) {
            _uiState.update { it.copy(message = "这个视频没有 fileId，无法添加") }
            return
        }
        if (fileId in _uiState.value.addedFileIds || fileId in _uiState.value.addingFileIds) {
            _uiState.update { it.copy(message = "这个视频已经添加或正在添加") }
            return
        }
        _uiState.update {
            it.copy(addingFileIds = it.addingFileIds + fileId, message = "正在检查 ${item.name}")
        }
        viewModelScope.launch {
            runCatching { processGuangyaVideoAdd(item, fileId) }
                .onSuccess { result ->
                    _uiState.update {
                        it.copy(
                            addingFileIds = it.addingFileIds - fileId,
                            addedFileIds = it.addedFileIds + fileId,
                            message = result
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            addingFileIds = it.addingFileIds - fileId,
                            message = error.message ?: "添加失败"
                        )
                    }
                }
        }
    }

    /** 添加整个文件夹：递归遍历子目录，逐个添加视频（简化批量，无持久化队列）。 */
    fun addFolderToLibrary(folder: GuangyaFileItem) {
        val fileId = folder.fileId
        if (fileId.isBlank()) {
            _uiState.update { it.copy(message = "这个文件夹没有 fileId，无法批量添加") }
            return
        }
        if (fileId in _uiState.value.addingFileIds) {
            _uiState.update { it.copy(message = "这个文件夹正在添加中") }
            return
        }
        _uiState.update {
            it.copy(addingFileIds = it.addingFileIds + fileId, message = "正在读取文件夹：${folder.name}")
        }
        viewModelScope.launch {
            runCatching { processFolderAdd(folder) }
                .onSuccess { summary ->
                    _uiState.update {
                        it.copy(
                            addingFileIds = it.addingFileIds - fileId,
                            message = summary
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            addingFileIds = it.addingFileIds - fileId,
                            message = error.message ?: "文件夹添加失败"
                        )
                    }
                }
        }
    }

    private suspend fun processFolderAdd(folder: GuangyaFileItem): String {
        var added = 0
        var failed = 0
        val stack = ArrayDeque<GuangyaFileItem>()
        stack.add(folder)
        while (stack.isNotEmpty()) {
            val dir = stack.removeLast()
            val children = repository.listFiles(dir.fileId)
            children.filter { it.isDir }.forEach { stack.add(it) }
            for (video in children.filter { !it.isDir && it.isVideoFile() }) {
                runCatching { processGuangyaVideoAdd(video, video.fileId) }
                    .onSuccess {
                        added++
                        _uiState.update { s -> s.copy(addedFileIds = s.addedFileIds + video.fileId) }
                    }
                    .onFailure {
                        failed++
                        scrapeRepository.appendLog("光鸭文件夹添加失败：${video.name} / ${video.fileId}，原因：${it.message}")
                    }
            }
        }
        return "文件夹添加完成：入库 $added 个${if (failed > 0) "，失败 $failed 个" else ""}"
    }

    /** 单个光鸭视频完整链路：STRM → 扫描入库 → 番号 → 刮削 → 整理同步（镜像 115，fileId 作为记录主键）。 */
    private suspend fun processGuangyaVideoAdd(item: GuangyaFileItem, fileId: String): String {
        if (recordRepository.get(fileId) != null) {
            scrapeRepository.appendLog("光鸭添加跳过：${item.name} / $fileId，原因：影片已经添加")
            return "影片已经添加"
        }
        scrapeRepository.appendLog("开始处理光鸭添加：${item.name} / $fileId")
        val generated = strmRepository.generateStrmForVideo(item)
        val libraryRoot = settingsRepository.getLibraryRootUri()
            ?: error("请先到设置页选择影片库目录")
        val rootUri = Uri.parse(libraryRoot)

        if (!generated.shouldScrape) {
            scrapeRepository.appendLog("附加播放源 STRM 写入完成，不单独刮削：${generated.fileName}")
            return "已加入播放源：${generated.movieNumberHint ?: item.name}"
        }

        scrapeRepository.appendLog("光鸭 STRM 写入完成，开始扫描：${generated.fileName}")
        val addedMovie = movieRepository.scanSingleMovie(rootUri, Uri.parse(generated.strmUri), mergeByMovieNumber = true)
        addedMovie?.let { recordRepository.attachMovie(fileId, it.id) }

        val number = extractMovieNumberWithRules(generated.fileName, item.name)
        if (number == null) {
            val reason = "无法从文件名提取番号，无法自动刮削"
            addedMovie?.let { movieRepository.markScrapeTaskFailed(it.id, reason) }
            scrapeRepository.appendLog("光鸭添加未刮削：${item.name}，原因：$reason")
            return "已添加但未刮削：${item.name}"
        }

        val movieForScrape = addedMovie
            ?: movieRepository.findMovieByNumberAndVariant(libraryRoot, number, generated.fileName)
            ?: error("STRM 已添加，但扫描后没有在影片库中找到 $number")
        recordRepository.attachMovie(fileId, movieForScrape.id)
        movieRepository.markScrapeTaskPending(movieForScrape.id)
        val source = settingsRepository.getDefaultScrapeSource()
        scrapeRepository.appendLog("开始刮削光鸭影片：$number，来源：$source")
        movieRepository.markScrapeTaskRunning(movieForScrape.id)
        val scrapeResult = runCatching {
            scrapeRepository.scrapeStrmUriWithOutput(
                libraryRootUri = libraryRoot,
                strmUri = generated.strmUri,
                source = source,
                forceDistinct = false
            )
        }.getOrElse { error ->
            val reason = "刮削来源 ${source.name} 失败：${error.message ?: error::class.java.simpleName}"
            movieRepository.markScrapeTaskFailed(movieForScrape.id, reason)
            scrapeRepository.appendLog("光鸭已入库但刮削失败：$number，原因：$reason")
            return "已添加但刮削失败：$number"
        }

        scrapeRepository.appendLog("光鸭文件整理完成，开始同步影片数据库：$number")
        val refreshedMovie = runCatching {
            finalizeOrganizedScrape(
                refreshMovie = {
                    movieRepository.refreshMovieAfterScrape(
                        original = movieForScrape,
                        scrapedStrmUri = scrapeResult.strmUri,
                        mergeByMovieNumber = true
                    )
                },
                markCompleted = { movieRepository.markScrapeTaskCompleted(it.id) },
                markFailed = { reason -> movieRepository.markScrapeTaskFailed(movieForScrape.id, reason) },
                missingMovieMessage = "整理后的 STRM 已写入，但影片路径或元数据未同步到数据库：$number"
            )
        }.getOrElse { error ->
            val reason = error.message ?: "整理后的 STRM 未同步到数据库：$number"
            scrapeRepository.appendLog("光鸭刮削整理失败：$reason")
            return reason
        }
        recordRepository.updateStrmLocation(
            pickcode = fileId,
            strmUri = refreshedMovie.videoUri,
            libraryRootUri = refreshedMovie.libraryRootUri,
            movieId = refreshedMovie.id
        )
        scrapeRepository.appendLog(
            "[媒体路径] 状态=成功，操作=光鸭单片刮削整理并更新数据库，movieId=${refreshedMovie.id}，文件=${refreshedMovie.videoName}"
        )
        return if (generated.created) {
            "已添加并刮削：$number"
        } else {
            "STRM 已存在，已刷新并刮削：$number"
        }
    }

    private suspend fun extractMovieNumberWithRules(vararg values: String?): String? {
        scrapeRepository.loadCachedNumberRecognitionRules()
        values.mapNotNull { it?.takeIf(String::isNotBlank) }.forEach { value ->
            MovieNumberExtractor.extract(value)?.let { return it }
        }
        return null
    }

    private fun loadFiles(parentId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                loading = true,
                error = null,
                currentParentId = parentId,
                path = nameStack.toList()
            )
            runCatching {
                val items = repository.listFiles(parentId)
                val added = recordRepository.existingPickcodesForVisibleItems(
                    items.map { it.fileId }.filter { it.isNotBlank() }.toSet()
                )
                items to added
            }.onSuccess { (items, added) ->
                _uiState.update {
                    it.copy(files = items, addedFileIds = added, loading = false)
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(error = error.message, loading = false)
                }
            }
        }
    }

    companion object {
        fun factory(
            repository: GuangyaBrowserRepository,
            strmRepository: GuangyaStrmRepository,
            recordRepository: CloudStrmRecordRepository,
            movieRepository: MovieRepository,
            scrapeRepository: StrmScrapeRepository,
            settingsRepository: AppSettingsRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return GuangyaBrowserViewModel(
                    repository,
                    strmRepository,
                    recordRepository,
                    movieRepository,
                    scrapeRepository,
                    settingsRepository
                ) as T
            }
        }
    }
}
