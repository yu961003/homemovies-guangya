package com.example.localmovielibrarz.ui.guangya

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import kotlinx.coroutines.delay

/**
 * 光鸭云盘浏览 / 添加界面（操作逻辑对齐 115 CloudBrowserScreen）。
 * 已接入导航图（Route.GuangyaBrowser），也可嵌入网盘 tab（topInsetHandled=true 时由外层切换栏处理状态栏）。
 *
 * - 点视频 = 播放（onPlayVideo 回调，AppRoot 构造 guangya://guangya_res/$fileId 交给播放器）。
 * - 行右侧「添加」= 入库并自动刮削；目录行「添加」= 递归添加整个文件夹（带确认弹窗）。
 */
@Composable
fun GuangyaBrowserScreen(
    viewModel: GuangyaBrowserViewModel,
    onBack: () -> Unit,
    onPlayVideo: (GuangyaFileItem) -> Unit,
    topInsetHandled: Boolean = false
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val statusBarPadding = if (topInsetHandled) Modifier else Modifier.windowInsetsPadding(WindowInsets.statusBars)
    var pendingFolder by remember { mutableStateOf<GuangyaFileItem?>(null) }

    // 系统返回（含手势左滑）：先返回上级目录，栈空才退出页面
    fun handleBack() {
        if (viewModel.canGoBackFolder()) {
            viewModel.goUp()
        } else {
            onBack()
        }
    }
    BackHandler(onBack = ::handleBack)

    // 提示信息自动清除
    LaunchedEffect(state.message) {
        state.message?.let {
            delay(2_500)
            viewModel.clearMessage()
        }
    }

    if (!viewModel.loggedIn) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(statusBarPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "尚未登录光鸭云盘",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "请先到「设置 → 网盘设置 → 光鸭云盘」完成手机号登录，再来浏览网盘并添加影片。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f),
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onBack) { Text("返回") }
        }
        return
    }

    LaunchedEffect(Unit) {
        if (state.files.isEmpty() && state.error == null && !state.loading) {
            viewModel.restoreOrRoot()
        }
    }

    pendingFolder?.let { folder ->
        AlertDialog(
            onDismissRequest = { pendingFolder = null },
            title = { Text("添加整个文件夹？") },
            text = {
                Text(
                    "确认后会递归读取“${folder.name}”内的视频，逐个入库并自动刮削。"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingFolder = null
                        viewModel.addFolderToLibrary(folder)
                    }
                ) {
                    Text("开始添加")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingFolder = null }) {
                    Text("取消")
                }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        GuangyaTopBar(
            path = state.path,
            onBack = ::handleBack,
            topInsetHandled = topInsetHandled
        )

        // 快捷导航：返回上级（可返回时）+ 根目录（随时脱困）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            if (viewModel.canGoBackFolder()) {
                TextButton(onClick = viewModel::goUp) {
                    Text("返回上级")
                }
            }
            TextButton(
                onClick = viewModel::enterRoot,
                enabled = !state.loading
            ) {
                Text("根目录")
            }
        }

        state.message?.let { msg ->
            Text(
                text = msg,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        state.error?.let { err ->
            Text(
                text = "出错：$err",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        when {
            state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onSurface)
            }
            state.error != null && state.files.isEmpty() -> Unit // 错误已在上方展示
            state.files.isEmpty() -> Box(
                Modifier.fillMaxSize().padding(18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "这个目录是空的",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.74f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(14.dp)
            ) {
                items(state.files, key = { it.fileId }) { file ->
                    GuangyaFileRow(
                        file = file,
                        isAdding = file.fileId in state.addingFileIds,
                        isAdded = file.fileId in state.addedFileIds,
                        onOpen = {
                            if (file.isDir) {
                                viewModel.openFolder(file)
                            } else {
                                onPlayVideo(file)
                            }
                        },
                        onAdd = {
                            if (file.isDir) pendingFolder = file else viewModel.addVideoToLibrary(file)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun GuangyaTopBar(
    path: List<String>,
    onBack: () -> Unit,
    topInsetHandled: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (topInsetHandled) {
                    // 嵌入网盘 tab：背景由外层渐变容器统一提供
                    Modifier.background(Color.Transparent)
                } else {
                    Modifier.background(
                        Brush.verticalGradient(
                            listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.background)
                        )
                    )
                }
            )
            .then(
                if (topInsetHandled) Modifier else Modifier.windowInsetsPadding(WindowInsets.statusBars)
            )
            .padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(22.dp)
                )
            }
            Icon(
                Icons.Rounded.Cloud,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "光鸭云盘",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            )
        }
        Text(
            text = path.joinToString(" / ").ifBlank { "根目录" },
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
    }
}

@Composable
private fun GuangyaFileRow(
    file: GuangyaFileItem,
    isAdding: Boolean,
    isAdded: Boolean,
    onOpen: () -> Unit,
    onAdd: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.075f))
            .clickable(onClick = onOpen)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (file.isDir) Icons.Rounded.Folder else Icons.Rounded.VideoFile,
                contentDescription = null,
                tint = if (file.isDir) Color(0xFFE7C267) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.76f)
            )
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = file.name,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = file.subtitle(),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.56f),
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        GuangyaAddButton(isAdding = isAdding, isAdded = isAdded, onAdd = onAdd)
    }
}

@Composable
private fun GuangyaAddButton(isAdding: Boolean, isAdded: Boolean, onAdd: () -> Unit) {
    if (isAdded) {
        Text(
            text = "已添加",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        return
    }
    if (isAdding) {
        Text(
            text = "添加中",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        return
    }
    Button(
        onClick = onAdd,
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp),
        modifier = Modifier.height(34.dp)
    ) {
        Text("添加", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

private fun GuangyaFileItem.subtitle(): String = when {
    isDir -> "目录 · 点按进入"
    isVideoFile() -> "视频 · ${formatSize(size)}"
    else -> "文件 · ${formatSize(size)}"
}

private fun GuangyaFileItem.isVideoFile(): Boolean =
    VIDEO_EXTENSIONS.any { name.endsWith(it, ignoreCase = true) }

private val VIDEO_EXTENSIONS = listOf(
    ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".ts", ".iso", ".flv", ".webm"
)

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024 && idx < units.size - 1) {
        value /= 1024
        idx++
    }
    return if (idx == 0) "$bytes B" else "%.1f %s".format(value, units[idx])
}
