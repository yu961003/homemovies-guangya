package com.example.localmovielibrary.ui.guangya

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrary.cloudguangya.GuangyaBrowserRepository
import com.example.localmovielibrary.cloudguangya.GuangyaFileItem
import com.example.localmovielibrary.data.repository.AppSettingsRepository
import com.example.localmovielibrary.data.repository.GuangyaStrmRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GuangyaBrowserUiState(
    val files: List<GuangyaFileItem> = emptyList(),
    val currentParentId: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val lastGenerated: String? = null
)

/**
 * 光鸭云盘浏览 + 生成 STRM 的 ViewModel（P2-3）。
 * 根目录为 parentId=""（115 用 Long 类型的 ROOT_CID，光鸭用空串）。
 */
class GuangyaBrowserViewModel(
    private val repository: GuangyaBrowserRepository,
    private val strmRepository: GuangyaStrmRepository,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GuangyaBrowserUiState())
    val uiState: StateFlow<GuangyaBrowserUiState> = _uiState.asStateFlow()

    /** 进入页面时的持久登录态（浏览需要有效 token，未登录时 UI 引导去设置页）。 */
    val loggedIn: Boolean = settingsRepository.isGuangyaLoggedIn()

    /** 已进入目录的 parentId 栈，用于「返回上级」。 */
    private val pathStack = mutableListOf<String>()

    fun enterRoot() {
        pathStack.clear()
        loadFiles("")
    }

    fun openFolder(item: GuangyaFileItem) {
        if (item.isDir) {
            pathStack.add(_uiState.value.currentParentId)
            loadFiles(item.fileId)
        }
    }

    fun goUp() {
        if (pathStack.isEmpty()) {
            loadFiles("")
        } else {
            loadFiles(pathStack.removeAt(pathStack.size - 1))
        }
    }

    fun generateStrm(item: GuangyaFileItem) {
        viewModelScope.launch {
            runCatching { strmRepository.generateStrmForVideo(item) }
                .onSuccess { _uiState.value = _uiState.value.copy(lastGenerated = "已生成：${it.fileName}") }
                .onFailure { _uiState.value = _uiState.value.copy(error = it.message) }
        }
    }

    private fun loadFiles(parentId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true, error = null, currentParentId = parentId)
            runCatching { repository.listFiles(parentId) }
                .onSuccess { _uiState.value = _uiState.value.copy(files = it, loading = false) }
                .onFailure { _uiState.value = _uiState.value.copy(error = it.message, loading = false) }
        }
    }

    companion object {
        fun factory(
            repository: GuangyaBrowserRepository,
            strmRepository: GuangyaStrmRepository,
            settingsRepository: AppSettingsRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return GuangyaBrowserViewModel(repository, strmRepository, settingsRepository) as T
            }
        }
    }
}
