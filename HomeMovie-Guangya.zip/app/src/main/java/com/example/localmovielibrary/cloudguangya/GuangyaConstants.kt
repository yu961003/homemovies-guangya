package com.example.localmovielibrary.cloudguangya

import okhttp3.MediaType.Companion.toMediaType

/**
 * 光鸭云盘接入常量。
 *
 * 协议端点来自反编译第三方包 guangyapan (v0.0.0) 的真实 REST 调用。
 */
object GuangyaConstants {
    /** 鉴权域名：设备码登录 / 令牌刷新。返回【顶层】JSON（非信封）。 */
    const val ACCOUNT_BASE = "https://account.guangyapan.com"

    /** 业务域名：文件列表 / 直链。返回 {msg, data, error} 信封。 */
    const val API_BASE = "https://api.guangyapan.com"

    /**
     * 客户端 ID。
     *
     * ⚠️ 合规风险提示（P2-5）：此值取自第三方 guangyapan 库，本质是“冒充该应用身份”访问光鸭，
     * 可能违反光鸭 ToS；且登录可能触发 captcha / shield 校验。建议向光鸭申请自有 client_id 后替换。
     */
    const val CLIENT_ID = "aMe-8VSlkrbQXpUR"

    val MEDIA_JSON = "application/json; charset=utf-8".toMediaType()
}
