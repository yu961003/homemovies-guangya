package com.example.localmovielibrary.cloudguangya

import com.example.localmovielibrary.playback.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GuangyaTokenExpiredException : Exception("光鸭访问令牌已失效")
class GuangyaApiException(message: String, code: String = "") : Exception(message)

/**
 * 光鸭业务客户端：列目录 / 直链。返回 {msg, data, error} 信封（P1-7）。
 *
 * - 仅注入 `Authorization: Bearer <token>`，无签名 / HMAC（反编译确认）。
 * - 401 或信封错误 → 抛 [GuangyaTokenExpiredException]，由 [apiCall] 触发刷新重试（P1-4）。
 */
class GuangyaApiClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build(),
    private val tokenProvider: GuangyaTokenProvider,
    private val rateLimiter: GuangyaRateLimiter
) {
    private suspend fun <T> apiCall(block: suspend () -> T): T = try {
        block()
    } catch (e: GuangyaTokenExpiredException) {
        tokenProvider.refreshAndStore() // P1-4 刷新（带并发锁）+ 存盘
        block()                         // 重试一次
    }

    suspend fun listFiles(parentId: String, page: Int = 0): List<GuangyaFileItem> =
        apiCall {
            rateLimiter.acquireRead()
            val data = postEnvelope(
                "/userres/v1/file/get_file_list",
                mapOf("parentId" to parentId, "page" to page, "pageSize" to 100)
            )
            val list = data.optJSONArray("list") ?: return@apiCall emptyList()
            buildList {
                for (i in 0 until list.length()) {
                    parseFile(list.optJSONObject(i))?.let { add(it) }
                }
            }
        }

    /** 原始直链（核心路径）。返回 data.signedURL（临时地址，播放时实时解析）。 */
    suspend fun fetchDirectUrl(fileId: String): String =
        apiCall {
            rateLimiter.acquireRead()
            val data = postEnvelope("/userres/v1/get_res_download_url", mapOf("fileId" to fileId))
            data.optString("signedURL").takeIf { it.isNotBlank() } ?: error("光鸭直链为空")
        }

    /**
     * VOD(m3u8) 直链（可选，P2-2 首期不建议启用）。
     * gcid 为空时按 P1-5 先取文件详情补 gcid。
     */
    suspend fun fetchVodUrl(fileId: String, gcid: String?): String =
        apiCall {
            val realGcid = gcid ?: getFileDetailGcid(fileId)
            rateLimiter.acquireRead()
            val data = postEnvelope(
                "/userres/v1/file/get_vod_download_url",
                mapOf("fileId" to fileId, "gcid" to (realGcid ?: ""))
            )
            data.optString("signedURL").takeIf { it.isNotBlank() } ?: error("光鸭 VOD 直链为空")
        }

    private suspend fun getFileDetailGcid(fileId: String): String? =
        runCatching {
            rateLimiter.acquireRead()
            val data = postEnvelope("/userres/v1/file/get_file_detail", mapOf("fileId" to fileId))
            data.optString("gcid").takeIf { it.isNotBlank() }
        }.getOrNull()

    private suspend fun postEnvelope(path: String, body: Map<String, Any?>): JSONObject {
        val token = tokenProvider.getValidAccessToken() // 协程内预取（P2-6），非拦截器 runBlocking
        val req = Request.Builder().url(GuangyaConstants.API_BASE + path)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .header("Content-Type", "application/json") // P1-8
            .post(RequestBody.create(GuangyaConstants.MEDIA_JSON, JSONObject(body).toString()))
            .build()
        http.newCall(req).execute().use { resp ->
            if (resp.code == 401) throw GuangyaTokenExpiredException() // 触发上层刷新重试
            val root = JSONObject(resp.body?.string().orEmpty())
            val msg = root.optString("msg", "success")
            if (msg != "success" || root.opt("error") != null) {
                throw GuangyaApiException(msg, root.optString("error", ""))
            }
            return root.getJSONObject("data") // 信封 data
        }
    }

    /** P1-3 列目录字段兜底（对齐 guangya.py:542-553 的 fileId/id、fileName/name、fileSize/size）。 */
    private fun parseFile(o: JSONObject?): GuangyaFileItem? {
        o ?: return null
        val fileId = o.optString("fileId").takeIf { it.isNotBlank() } ?: o.optString("id", "")
        val name = o.optString("fileName").takeIf { it.isNotBlank() } ?: o.optString("name", "")
        if (fileId.isBlank() || name.isBlank()) return null
        val rawSize = o.opt("fileSize") ?: o.opt("size")
        val size = (rawSize as? Number)?.toLong() ?: 0L
        return GuangyaFileItem(
            fileId = fileId,
            name = name,
            isDir = o.optBoolean("isDir", false),
            size = size,
            fileType = o.optString("fileType").takeIf { it.isNotBlank() },
            gcid = o.optString("gcid").takeIf { it.isNotBlank() },
            parentId = o.optString("parentId", "")
        )
    }
}
