package com.example.localmovielibrary.ui.guangya

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrary.cloudguangya.GuangyaLoginClient
import com.example.localmovielibrary.cloudguangya.GuangyaTokenStore
import com.example.localmovielibrary.data.repository.AppSettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class GuangyaLoginStep { Idle, CodeSent, LoggedIn }

data class GuangyaLoginUiState(
    val step: GuangyaLoginStep = GuangyaLoginStep.Idle,
    val phoneNumber: String = "",
    val verificationCode: String = "",
    val status: String = "",
    val isLoading: Boolean = false,
    val countdown: Int = 0,
    val error: String? = null
)

/**
 * 光鸭短信登录 ViewModel。
 * 流程：输入手机号 → 获取验证码（smsInit + smsSend）→ 输入验证码 → 提交（smsVerify + smsSignin）→ 存令牌。
 * 全程 App 内完成，不跳转浏览器。
 */
class GuangyaLoginViewModel(
    private val loginClient: GuangyaLoginClient,
    private val tokenStore: GuangyaTokenStore,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GuangyaLoginUiState())
    val uiState: StateFlow<GuangyaLoginUiState> = _uiState.asStateFlow()

    // 跨步骤暂存（验证码发送后、提交前需要）
    private var captchaToken: String? = null
    private var verificationId: String? = null
    private var currentPhone: String? = null
    private var countdownJob: Job? = null

    init {
        // 进入页面时根据持久标记还原登录态
        if (settingsRepository.isGuangyaLoggedIn()) {
            _uiState.value = _uiState.value.copy(step = GuangyaLoginStep.LoggedIn)
        }
    }

    fun onPhoneChanged(value: String) {
        _uiState.value = _uiState.value.copy(phoneNumber = value, error = null)
    }

    fun onCodeChanged(value: String) {
        _uiState.value = _uiState.value.copy(verificationCode = value, error = null)
    }

    fun sendCode() = sendCode(_uiState.value.phoneNumber.trim())

    fun resendCode() {
        val phone = currentPhone ?: return
        sendCode(phone)
    }

    private fun sendCode(phone: String) {
        if (!isValidPhone(phone)) {
            _uiState.value = _uiState.value.copy(error = "请输入有效的手机号，如 +86 13800138000")
            return
        }
        countdownJob?.cancel()
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null, status = "正在发送验证码...")
            val captcha = runCatching { loginClient.smsInit(phone) }.getOrElse {
                _uiState.value = _uiState.value.copy(isLoading = false, error = it.message ?: "初始化失败")
                return@launch
            }
            val vid = runCatching { loginClient.smsSend(phone, captcha) }.getOrElse {
                _uiState.value = _uiState.value.copy(isLoading = false, error = it.message ?: "发送失败")
                return@launch
            }
            captchaToken = captcha
            verificationId = vid
            currentPhone = phone
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                step = GuangyaLoginStep.CodeSent,
                status = "验证码已发送，请查收短信",
                countdown = RESEND_SECONDS
            )
            startCountdown()
        }
    }

    fun submitCode() {
        val code = _uiState.value.verificationCode.trim()
        val vid = verificationId
        val captcha = captchaToken
        val phone = currentPhone
        if (code.length < 4) {
            _uiState.value = _uiState.value.copy(error = "请输入收到的验证码")
            return
        }
        if (vid == null || captcha == null || phone == null) {
            _uiState.value = _uiState.value.copy(error = "登录状态已失效，请重新获取验证码")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null, status = "正在验证...")
            val vtoken = runCatching { loginClient.smsVerify(vid, code) }.getOrElse {
                _uiState.value = _uiState.value.copy(isLoading = false, error = it.message ?: "验证失败")
                return@launch
            }
            val pair = runCatching { loginClient.smsSignin(code, vtoken, phone, captcha) }.getOrElse {
                _uiState.value = _uiState.value.copy(isLoading = false, error = it.message ?: "登录失败")
                return@launch
            }
            tokenStore.save(pair)
            settingsRepository.setGuangyaLoggedIn(true)
            countdownJob?.cancel()
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                step = GuangyaLoginStep.LoggedIn,
                status = "登录成功",
                verificationCode = ""
            )
        }
    }

    fun logout() {
        countdownJob?.cancel()
        captchaToken = null
        verificationId = null
        currentPhone = null
        tokenStore.clear()
        settingsRepository.setGuangyaLoggedIn(false)
        _uiState.value = GuangyaLoginUiState()
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (_uiState.value.countdown > 0) {
                delay(1000)
                _uiState.value = _uiState.value.copy(countdown = _uiState.value.countdown - 1)
            }
        }
    }

    private fun isValidPhone(phone: String): Boolean {
        val digits = phone.replace(Regex("[^0-9]"), "")
        return phone.any { it.isDigit() } && digits.length in 6..15
    }

    companion object {
        const val RESEND_SECONDS = 60

        fun factory(
            loginClient: GuangyaLoginClient,
            tokenStore: GuangyaTokenStore,
            settingsRepository: AppSettingsRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return GuangyaLoginViewModel(loginClient, tokenStore, settingsRepository) as T
            }
        }
    }
}
