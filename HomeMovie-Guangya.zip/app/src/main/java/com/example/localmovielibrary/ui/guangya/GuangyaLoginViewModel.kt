package com.example.localmovielibrary.ui.guangya

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrary.cloudguangya.GuangyaLoginChallenge
import com.example.localmovielibrary.cloudguangya.GuangyaLoginClient
import com.example.localmovielibrary.cloudguangya.GuangyaTokenStore
import com.example.localmovielibrary.data.repository.AppSettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GuangyaLoginUiState(
    val challenge: GuangyaLoginChallenge? = null,
    val status: String = "",
    val isLoggingIn: Boolean = false,
    val loggedIn: Boolean = false,
    val error: String? = null
)

/**
 * 光鸭设备码登录 ViewModel（P2-3）。
 * 流程：startLogin → 展示 verificationUri 让用户网页端确认 → 轮询 pollLogin → 存令牌。
 */
class GuangyaLoginViewModel(
    private val loginClient: GuangyaLoginClient,
    private val tokenStore: GuangyaTokenStore,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GuangyaLoginUiState())
    val uiState: StateFlow<GuangyaLoginUiState> = _uiState.asStateFlow()

    private var pollJob: Job? = null

    init {
        // 进入页面时根据持久标记还原登录态
        _uiState.value = _uiState.value.copy(loggedIn = settingsRepository.isGuangyaLoggedIn())
    }

    fun startLogin() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoggingIn = true, error = null)
            val challenge = runCatching { loginClient.startLogin() }.getOrElse {
                _uiState.value = _uiState.value.copy(isLoggingIn = false, error = it.message)
                return@launch
            }
            _uiState.value = _uiState.value.copy(
                challenge = challenge,
                status = "请在浏览器打开下方链接，于光鸭网页端确认登录"
            )
            pollLoop(challenge)
        }
    }

    private suspend fun pollLoop(challenge: GuangyaLoginChallenge) {
        val interval = challenge.pollIntervalSeconds.coerceAtLeast(1).toLong()
        while (true) {
            delay(interval * 1000)
            val pair = runCatching { loginClient.pollLogin(challenge.deviceCode) }.getOrNull()
            if (pair != null) {
                tokenStore.save(pair)
                settingsRepository.setGuangyaLoggedIn(true)
                _uiState.value = _uiState.value.copy(
                    isLoggingIn = false,
                    loggedIn = true,
                    status = "登录成功"
                )
                return
            }
            _uiState.value = _uiState.value.copy(status = "等待用户在光鸭网页端确认...")
        }
    }

    fun logout() {
        pollJob?.cancel()
        tokenStore.clear()
        settingsRepository.setGuangyaLoggedIn(false)
        _uiState.value = GuangyaLoginUiState()
    }

    companion object {
        fun factory(
            loginClient: GuangyaLoginClient,
            tokenStore: GuangyaTokenStore,
            settingsRepository: AppSettingsRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return GuangyaLoginViewModel(loginClient, tokenStore, settingsRepository) as T
            }
        }
    }
}
