package com.example.localmovielibrary.ui.guangya

import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * 光鸭云盘浏览 / 生成 STRM 的最小 Compose 界面（P2-3）。
 * 当前未接入导航图，作为可复用的独立可组合项；接入方式见仓库根 README_guanya.md。
 */
@Composable
fun GuangyaBrowserScreen(
    viewModel: GuangyaBrowserViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    LazyColumn {
        item { Button(onClick = onBack) { Text("返回") } }
        item { Button(onClick = { viewModel.enterRoot() }) { Text("进入光鸭根目录") } }
        state.error?.let { err -> item { Text("错误：$err") } }
        state.lastGenerated?.let { msg -> item { Text(msg) } }
        if (state.loading) item { Text("加载中...") }
        items(state.files) { file ->
            Text(
                text = (if (file.isDir) "[目录] " else "[视频] ") + file.name,
                modifier = Modifier.clickable {
                    if (file.isDir) viewModel.openFolder(file) else viewModel.generateStrm(file)
                }
            )
        }
    }
}
