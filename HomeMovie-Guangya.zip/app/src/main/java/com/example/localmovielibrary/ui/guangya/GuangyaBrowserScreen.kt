package com.example.localmovielibrary.ui.guangya

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localmovielibrary.cloudguangya.GuangyaFileItem

/**
 * 光鸭云盘浏览 / 生成 STRM 界面（P2-3），已接入导航图（Route.GuangyaBrowser）。
 * 入口：设置 → 网盘设置 → 「浏览光鸭网盘 / 生成 STRM」。
 *
 * - 未登录时引导去设置页登录（浏览需要有效 token）。
 * - 目录可逐级进入 / 返回上级；点视频文件即生成 STRM。
 */
@Composable
fun GuangyaBrowserScreen(
    viewModel: GuangyaBrowserViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    if (!viewModel.loggedIn) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "尚未登录光鸭云盘",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "请先到「设置 → 网盘设置 → 光鸭云盘」完成手机号登录，再来浏览网盘并生成 STRM。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f),
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onBack) { Text("返回设置") }
        }
        return
    }

    LaunchedEffect(Unit) {
        if (state.files.isEmpty() && state.error == null && !state.loading) {
            viewModel.enterRoot()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // 顶栏：返回 + 标题
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Rounded.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onSurface
                )
                Text("设置")
            }
            Text(
                text = "光鸭网盘",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        // 操作行：返回上级 + 回到根目录
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TextButton(
                onClick = viewModel::goUp,
                enabled = !state.loading
            ) {
                Text("返回上级")
            }
            TextButton(
                onClick = viewModel::enterRoot,
                enabled = !state.loading
            ) {
                Text("根目录")
            }
        }

        if (state.loading) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 20.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator()
            }
        }

        state.error?.let { err ->
            Text(
                text = "出错：$err",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        state.lastGenerated?.let { msg ->
            Text(
                text = "✓ $msg",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (state.files.isEmpty() && !state.loading && state.error == null) {
                item {
                    Text(
                        text = "（空目录）",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            items(state.files, key = { it.fileId }) { file ->
                GuangyaFileRow(
                    file = file,
                    onClick = {
                        if (file.isDir) viewModel.openFolder(file) else viewModel.generateStrm(file)
                    }
                )
            }
        }
    }
}

@Composable
private fun GuangyaFileRow(
    file: GuangyaFileItem,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (file.isDir) Icons.Rounded.Cloud else Icons.Rounded.Movie,
            contentDescription = if (file.isDir) "目录" else "视频",
            tint = if (file.isDir) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
            }
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp)
        ) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (file.isDir) {
                Text(
                    text = "目录",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    text = "视频 · ${formatSize(file.size)} · 点按生成 STRM",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024 && idx < units.size - 1) {
        value /= 1024
        idx++
    }
    return if (idx == 0) "${bytes} B" else "%.1f %s".format(value, units[idx])
}
