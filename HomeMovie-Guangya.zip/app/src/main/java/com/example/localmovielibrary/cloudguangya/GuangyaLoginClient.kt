package com.example.localmovielibrary.cloudguangya

import com.example.localmovielibrary.playback.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GuangyaLoginChallenge(
    val deviceCode: String,
    val verificationUri: String,
    val expiresInSeconds: Int,
    val pollIntervalSeconds: Int
)

/**
 * 光鸭登录客户端：设备码登录 / 轮询 / 刷新。
 *
 * ⚠️ P0-1 修正：account.guangyapan.com 端点返回【顶层】JSON，不是 {msg,data,error} 信封，
 * 因此直接读取根层级字段（device_code / access_token ...），不能用 optJSONObject("data")。
 */
class GuangyaLoginClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    suspend fun startLogin(): GuangyaLoginChallenge = withContext(Dispatchers.IO) {
        val json = postTopLevel(
            GuangyaConstants.ACCOUNT_BASE + "/v1/auth/device/code",
            mapOf("client_id" to GuangyaConstants.CLIENT_ID, "scope" to "user")
        )
        val deviceCode = json.optString("device_code").takeIf { it.isNotBlank() }
            ?: error("光鸭设备码响应缺少 device_code")
        val verificationUri = json.optString("verification_uri_complete").takeIf { it.isNotBlank() }
            ?: error("光鸭设备码响应缺少 verification_uri_complete")
        GuangyaLoginChallenge(
            deviceCode = deviceCode,
            verificationUri = verificationUri,
            expiresInSeconds = json.optInt("expires_in", 600),
            pollIntervalSeconds = json.optInt("interval", 2)
        )
    }

    /** 轮询换取令牌：pending 返回 null，成功返回令牌对。 */
    suspend fun pollLogin(deviceCode: String): GuangyaTokenPair? = withContext(Dispatchers.IO) {
        val json = postTopLevel(
            GuangyaConstants.ACCOUNT_BASE + "/v1/auth/token",
            mapOf(
                "client_id" to GuangyaConstants.CLIENT_ID,
                "grant_type" to "device_code",
                "code" to deviceCode
            )
        )
        val access = json.optString("access_token").takeIf { it.isNotBlank() } ?: return@withContext null
        val refresh = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: return@withContext null
        GuangyaTokenPair(accessToken = access, refreshToken = refresh, obtainedAt = nowSeconds())
    }

    suspend fun refreshTokens(refreshToken: String): GuangyaTokenPair = withContext(Dispatchers.IO) {
        val json = postTopLevel(
            GuangyaConstants.ACCOUNT_BASE + "/v1/auth/token",
            mapOf(
                "client_id" to GuangyaConstants.CLIENT_ID,
                "grant_type" to "refresh_token",
                "refresh_token" to refreshToken
            )
        )
        val access = json.optString("access_token").takeIf { it.isNotBlank() } ?: error("光鸭刷新失败")
        // 幂等：新 refresh_token 缺失时沿用旧值
        val refresh = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: refreshToken
        GuangyaTokenPair(accessToken = access, refreshToken = refresh, obtainedAt = nowSeconds())
    }

    private fun postTopLevel(url: String, body: Map<String, Any?>): JSONObject {
        val req = Request.Builder().url(url)
            .header("Accept", "application/json")
            .header("Content-Type", "application/json") // P1-8
            .header("User-Agent", USER_AGENT)           // P2-1 公共头
            .post(RequestBody.create(GuangyaConstants.MEDIA_JSON, JSONObject(body).toString()))
            .build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("光鸭登录请求失败：HTTP ${resp.code}")
            return JSONObject(resp.body?.string().orEmpty())
        }
    }

    private fun nowSeconds(): Long = System.currentTimeMillis() / 1000L
}
