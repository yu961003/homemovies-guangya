package com.example.localmovielibrary.cloudguangya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 光鸭登录客户端：短信验证码两阶段登录，严格对齐官方 guangyaclient SDK。
 *
 * 流程：
 *   smsInit   → 人机验证初始化，返回 captcha_token
 *   smsSend   → 发送短信验证码（需 x-captcha-token 头），返回 verification_id
 *   smsVerify → 校验短信验证码，返回 verification_token
 *   smsSignin → 完成登录（需 x-captcha-token 头），返回 access / refresh token
 *
 * 全程 App 内完成，不跳转浏览器——解决旧 device-code 流程 verification_uri 404 的问题。
 * 鉴权头复刻 SDK 的 _account_headers()（x-client-id / x-device-id / x-device-sign 等）。
 */
class GuangyaLoginClient(
    private val device: GuangyaDevice = GuangyaDevice,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    /** 实例级固定 did，与 SDK 单例行为一致。 */
    private val did = device.generateDid()

    private val accountHeaders: Map<String, String>
        get() = mapOf(
            "accept" to "*/*",
            "content-type" to "application/json",
            "origin" to "https://www.guangyapan.com",
            "referer" to "https://www.guangyapan.com/",
            "user-agent" to GuangyaConstants.CHROME_UA,
            "x-client-id" to GuangyaConstants.CLIENT_ID,
            "x-client-version" to "0.0.1",
            "x-device-id" to did,
            "x-device-model" to "chrome%2F147.0.0.0",
            "x-device-name" to "PC-Chrome",
            "x-device-sign" to device.generateDeviceSign(did),
            "x-net-work-type" to "NONE",
            "x-os-version" to "MacIntel",
            "x-platform-version" to "1",
            "x-protocol-version" to "301",
            "x-provider-name" to "NONE",
            "x-sdk-version" to "9.0.2"
        )

    /** 步骤1：人机验证初始化，返回 captcha_token。 */
    suspend fun smsInit(phone: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("client_id", GuangyaConstants.CLIENT_ID)
            put("action", "POST:/v1/auth/verification")
            put("device_id", did)
            put("meta", JSONObject().apply { put("phone_number", phone) })
        }
        val json = post(GuangyaConstants.ACCOUNT_BASE + "/v1/shield/captcha/init", body)
        json.optString("captcha_token").takeIf { it.isNotBlank() }
            ?: error("光鸭人机验证初始化失败（可能需网页验证）：$json")
    }

    /** 步骤2：发送短信验证码，返回 verification_id。 */
    suspend fun smsSend(phone: String, captchaToken: String): String = withContext(Dispatchers.IO) {
        val headers = accountHeaders.toMutableMap().apply { put("x-captcha-token", captchaToken) }
        val body = JSONObject().apply {
            put("phone_number", phone)
            put("target", "ANY")
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val json = post(GuangyaConstants.ACCOUNT_BASE + "/v1/auth/verification", body, headers)
        json.optString("verification_id").takeIf { it.isNotBlank() }
            ?: error("光鸭发送验证码失败：$json")
    }

    /** 步骤3：校验短信验证码，返回 verification_token。 */
    suspend fun smsVerify(verificationId: String, code: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("verification_id", verificationId)
            put("verification_code", code)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val json = post(GuangyaConstants.ACCOUNT_BASE + "/v1/auth/verification/verify", body)
        json.optString("verification_token").takeIf { it.isNotBlank() }
            ?: error("光鸭验证码校验失败：$json")
    }

    /** 步骤4：完成登录，返回令牌对。 */
    suspend fun smsSignin(
        code: String,
        verificationToken: String,
        phone: String,
        captchaToken: String
    ): GuangyaTokenPair = withContext(Dispatchers.IO) {
        val headers = accountHeaders.toMutableMap().apply { put("x-captcha-token", captchaToken) }
        val body = JSONObject().apply {
            put("verification_code", code)
            put("verification_token", verificationToken)
            put("username", phone)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val json = post(GuangyaConstants.ACCOUNT_BASE + "/v1/auth/signin", body, headers)
        val access = json.optString("access_token").takeIf { it.isNotBlank() }
            ?: error("光鸭登录失败：$json")
        val refresh = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: ""
        GuangyaTokenPair(accessToken = access, refreshToken = refresh, obtainedAt = nowSeconds())
    }

    /**
     * 刷新令牌（供 GuangyaTokenProvider 调用，签名保持不变）。
     * 需 x-action: 401 头，对齐 SDK refresh_token()。
     */
    suspend fun refreshTokens(refreshToken: String): GuangyaTokenPair = withContext(Dispatchers.IO) {
        val headers = accountHeaders.toMutableMap().apply { put("x-action", "401") }
        val body = JSONObject().apply {
            put("client_id", GuangyaConstants.CLIENT_ID)
            put("grant_type", "refresh_token")
            put("refresh_token", refreshToken)
        }
        val json = post(GuangyaConstants.ACCOUNT_BASE + "/v1/auth/token", body, headers)
        val access = json.optString("access_token").takeIf { it.isNotBlank() } ?: error("光鸭刷新失败")
        // 幂等：新 refresh_token 缺失时沿用旧值
        val refresh = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: refreshToken
        GuangyaTokenPair(accessToken = access, refreshToken = refresh, obtainedAt = nowSeconds())
    }

    private fun post(
        url: String,
        body: JSONObject,
        extraHeaders: Map<String, String> = emptyMap()
    ): JSONObject {
        val headers = accountHeaders + extraHeaders
        val req = Request.Builder().url(url)
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .post(RequestBody.create(GuangyaConstants.MEDIA_JSON, body.toString()))
            .build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                val raw = resp.body?.string().orEmpty()
                val detail = runCatching { JSONObject(raw) }.getOrNull()?.let { json ->
                    json.optString("msg").takeIf { it.isNotBlank() }
                        ?: json.optString("message").takeIf { it.isNotBlank() }
                } ?: raw.take(160)
                error("光鸭请求失败：HTTP ${resp.code}${detail.takeIf { it.isNotBlank() }?.let { " $it" } ?: ""}")
            }
            return JSONObject(resp.body?.string().orEmpty())
        }
    }

    private fun nowSeconds(): Long = System.currentTimeMillis() / 1000L
}
