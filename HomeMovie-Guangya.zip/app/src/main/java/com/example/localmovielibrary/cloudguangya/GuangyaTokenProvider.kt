package com.example.localmovielibrary.cloudguangya

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 取 / 刷令牌的并发安全封装。
 *
 * - [getValidAccessToken]：协程内预取令牌（P2-6：不在 OkHttp 拦截器里 runBlocking）。
 * - [refreshAndStore]：带 Mutex 并发锁，避免多个请求同时触发刷新（P1-4）。
 */
class GuangyaTokenProvider(
    private val store: GuangyaTokenStore,
    private val loginClient: GuangyaLoginClient
) {
    private val refreshMutex = Mutex()

    suspend fun getValidAccessToken(): String =
        store.getAccessToken() ?: error("光鸭未登录，请先完成设备码登录")

    suspend fun refreshAndStore() = refreshMutex.withLock {
        val refresh = store.getRefreshToken() ?: error("光鸭 refresh_token 缺失，请重新登录")
        store.save(loginClient.refreshTokens(refresh))
    }
}
