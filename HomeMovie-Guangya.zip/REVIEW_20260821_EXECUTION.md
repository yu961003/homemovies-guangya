# HomeMovie-Guangya 代码审查执行记录

审查日期：2026-08-21
执行日期：2026-08-21
依据：《HomeMovie-Guangya 代码审查报告》（CodeFuse Code Review）

## 一、执行总览

| 优先级 | 编号 | 状态 | 说明 |
|---|---|---|---|
| 🔴 P0 | 3.2 | ✅ 完成 | APK 更新强制 SHA-256 校验 |
| 🔴 P0 | 3.3 | ✅ 完成 | 更新代理 URL 拼接加固（校验代理基址自身） |
| 🔴 P0 | 4.0 | ✅ 完成 | 媒体库扫描性能优化（阶段一 F1/F2/F3/F4/F6/F10） |
| 🔴 P0 | 3.1 | ✅ 保持 | 明文流量全局允许（已评估：STRM 播放需要，不改） |
| 🟡 P1 | 5.1 | ✅ 完成 | OkHttp 废弃 API → toRequestBody |
| 🟡 P1 | 5.2 | ✅ 完成 | 光鸭登录错误消息不再暴露原始 JSON |
| 🟡 P1 | 5.3 | ✅ 完成 | GuangyaApiClient postEnvelope/postCloud 补 withContext(IO) |
| 🟡 P1 | 7.1 | ✅ 完成 | 光鸭登录 captcha 重试前加 1s 延迟 |
| 🟡 P2 | 2.2 | ✅ 完成 | AppContainer 非核心路径懒加载（光鸭 9 项 + 115 7 项） |
| 🟡 P2 | 4.1 | ✅ 完成 | 115 文件列表分页 1000 → 200 |
| 🟡 P2 | 4.3 | ✅ 完成 | OkHttp 共享连接池（12 个客户端复用） |
| 🟡 P2 | 6.2 | ✅ 完成 | 离线提交器限额超额竞态修复 |
| 🟡 P2 | 4.0-F5/F7/F9 | ✅ 完成 | 扫描性能阶段二：NFO 并发解析（并入 F9）、movieNumberKey 缓存、目录级并发扫描 |
| 🟡 P3 | 4.0-F8 | ✅ 完成 | 扫描性能阶段三：SAF 批量查询替代 DocumentFile（带降级回退） |
| 🟢 Nit | 3.7 | ✅ 完成 | 备份规则排除 guangya_tokens.xml |
| 🟢 Nit | 5.6 | ✅ 完成 | Room exportSchema = true + schemaLocation |
| 🎉 更名 | 12 节 | ✅ 完成 | APP 更名 鸭影 / DuckReel |
| — | 5.4 | ✅ 保持 | 包名 localmovielibrarz（刻意修改，不改） |
| — | 3.5/3.6/3.8/9.1 | 保持 | client_id 合规 / P115Cipher / 明文记忆（MODE_PRIVATE 已做）/ security-crypto alpha（等稳定版） |

## 二、分项详情

### 🔴 P0-3.2 强制 SHA-256 校验（AppUpdateRepository.kt）

- 原逻辑：`if (update.sha256.isNotBlank()) { 校验 }` —— manifest 被篡改移除 sha256 后可绕过校验直接安装
- 修改为：**强制校验**——sha256 为空时删除临时文件并报错「更新信息缺少 SHA-256 校验值，拒绝安装未验证的 APK」；有值则校验，不匹配删除并报错

### 🔴 P0-3.3 代理 URL 拼接加固（AppUpdateRepository.kt）

- 原逻辑：`return "$proxyBaseUrl/$normalizedUrl"` 无任何约束，proxyBaseUrl 被配置为恶意域名时构成开放重定向
- 复核修正（按报告 13 节）：拼接后最终 host 恒等于 proxyBaseUrl 的 host，「校验拼接结果」是恒真死校验，必须**直接校验 proxyBaseUrl 自身**
- 新增 `isTrustedProxyBaseUrl()`：必须 HTTPS、无 userinfo（username/password）、无 query/fragment；不满足则拒绝走代理、直接访问原始地址
- 与 3.2 强制 SHA-256 形成纵深防御（即使代理被恶意替换，篡改的 APK 也无法通过校验）

### 🔴 P0-4.0 媒体库扫描性能（阶段一）

| 项 | 改动 | 文件 |
|---|---|---|
| F1 缓存 STRM pickcode | MovieEntity 新增 `@Ignore cachedPickcode`；LibraryScanner.buildMovie 扫描时一次性读取 STRM 填缓存；`extractPickcodeFromStrm()` 优先返回缓存。一处修改覆盖 242/306/936 三个全库扫描调用点（564/735/923 明确不改） | MovieEntity.kt / LibraryScanner.kt / MovieRepository.kt |
| F2 消除 canOpenUri 试探 | findStaleMovedDuplicateIds 改为接收其他库根精简行，默认不再 `!canOpenUri()` 文件试探；新增 `requireFileUnavailable` 参数开关（默认 false），函数本体保留，不影响 848/873 的 STRM 记录有效性判断 | MovieRepository.kt |
| F3 全库快照→按根查询 | 去掉 `getMoviesSnapshotLite()` 全库载入；existingByUri/existingById 只用当前库根；新增 `getOtherRootMoviesForStaleCheck()` 精简投影（id/libraryRootUri/videoUri/videoName/title/originalTitle/uniqueIds）+ `MovieStaleCheckRow` DTO | MovieDao.kt / MovieRepository.kt |
| F4 进度回调 | `scanner.scan()` / `scanLibrary()` 新增 `onProgress(scanned, currentPath)` 回调；SettingsViewModel 每 200ms 节流更新 `scanningCount`/`scanningCurrentPath`；设置页按钮显示「扫描中…已发现 N 部」+ 当前目录 | LibraryScanner.kt / MovieRepository.kt / SettingsViewModel.kt / SettingsScreen.kt |
| F6 合并目录遍历 | scanDirectory 单次遍历分类（文件 map / 视频 / 子目录），消除 3 次 filter 重复访问 isFile/isDirectory/name | LibraryScanner.kt |
| F10 Regex 常量化 | `Regex("\\s+")` 提取为 companion 常量 WHITESPACE_REGEX | LibraryScanner.kt |

### 🟡 P1

- **5.1**：GuangyaLoginClient.post / GuangyaApiClient.postCloud/postEnvelope 改用 `body.toRequestBody(MediaType)`（12 处客户端统一无残留废弃 API）
- **5.2**：光鸭登录 4 处 `error("...：$json")` 去掉原始 JSON，只保留用户友好描述（captcha 判断在 smsSend 内部完成，不影响逻辑）
- **5.3**：postCloud/postEnvelope 包裹 `withContext(Dispatchers.IO)`，避免阻塞调用意外在主线程执行
- **7.1**：captcha 重试前 `delay(1_000)`，避免服务端持续返回 captcha_invalid 时快速重试循环

### 🟡 P2

- **2.2**：AppContainer 光鸭 9 个属性 + 115 相关 7 个属性（cloud115Client/cloud115QrLoginClient/cloud115StrmRepository/directLinkRepository/cloudVideoAddProcessor/cloudVideoTaskRunner/cloudFolderBatchTaskRunner）改为 `by lazy`，启动时不再急初始化非核心路径
- **4.1**：`FILES_PAGE_SIZE = 1000 → 200`（分页循环已存在，安全）
- **4.3**：新增 `util/HttpClients.kt` 共享 ConnectionPool(8, 60s) + Dispatcher(64/8)，12 个 OkHttpClient 实例全部复用
- **6.2**：worker 提交前锁内再次检查 `ok >= remaining`，拦截并发超额部分（不超过限额）

### 🟢 Nit

- **3.7**：backup_rules.xml / data_extraction_rules.xml（cloud-backup + device-transfer）增加 `<exclude domain="sharedpref" path="guangya_tokens.xml" />`
- **5.6**：AppDatabase `exportSchema = true`；build.gradle.kts 增加 `ksp { arg("room.schemaLocation", "$projectDir/schemas") }`；创建 schemas/ 目录

### 🎉 APP 更名：鸭影 / DuckReel（报告 12 节）

| 文件 | 改动 |
|---|---|
| res/values/strings.xml | app_name: 家庭电影院 → 鸭影 |
| ui/StartupAnimationOverlay.kt | 启动动画文字 HomeMovie → 鸭影 |
| ui/logs/ScrapeLogScreen.kt | 日志导出文件名前缀 HomeMovie- → 鸭影- |
| data/repository/AppUpdateRepository.kt | User-Agent HomeMovie/ → DuckReel/（2 处）；APK 文件名 HomeMovie-v → DuckReel-v |
| data/repository/RemoteScrapeConfigRepository.kt | User-Agent HomeMovie/ → DuckReel/ |
| test/.../ScrapeLogExportTest.kt | 2 处断言同步更新 |
| README.md | 标题 # 鸭影 / DuckReel；英文描述 HomeMovie → DuckReel |
| RELEASE_NOTES_3.0.md | 标题 → 鸭影 v3.0 |

未改动（按报告要求）：内部代码标识符（HomeMovieSection/HomeMovieTheme/HomeMovieBuckets 等）、GitHub 仓库 URL、旧版本 RELEASE_NOTES。

### 🟡 P2：扫描性能阶段二 + 阶段三（追加完成）

- **F7 movieNumberKey 缓存**（MovieRepository.kt）：scanLibrary 入口预计算 `scannedKeyByUri` / `existingKeyByUri` / `otherRootKeyById` 三个 key 映射（每部影片只算一次正则），替代 synchronizedMovies 匹配、buildExistingMovieNumberMap、findStaleMovedDuplicateIds 中的重复 `movieNumberKey()` 调用；单影片路径（835 等）不受影响
- **F9 目录级并发扫描**（LibraryScanner.kt）：`Semaphore(4)` 控制最多 4 个目录同时 `listChildren + buildMovie`；子目录通过协程递归且**不持有信号量**（避免并发满时父子互相等待死锁）；`ArrayList` 用 `synchronized(movies)` 保护 addAll；计数改 `AtomicInteger`
- **F5 NFO 并发解析**：不单独实现——F9 目录级并发后 NFO 解析 IO 天然并发（最多 4 路），收益重叠且避免目录内再并发推高内存峰值
- **F8 SAF 批量查询**（LibraryScanner.kt）：`listChildren()` 用 `DocumentsContract.buildChildDocumentsUriUsingTree` + `ContentResolver.query` 直接读 Cursor 列（DOCUMENT_ID/MIME_TYPE/DISPLAY_NAME/SIZE），跳过 4 万+ DocumentFile 实例创建；查询失败（列缺失/异常）自动降级 `fallbackListChildren()`（DocumentFile 路径），子目录降级失败按空目录处理、绝不错列根目录

## 三、校验结果

- 全项目 **135 个 Kotlin 文件** tree-sitter 语法解析 0 错误
- **KSP 编译修复记录**：CI 报 `MovieEntity.kt:26-54 Cannot find setter for field` —— 根因是 Room 2.6.1 KSP 对 data class **构造器中的 `@Ignore` 参数**存在缺陷（引入后处理器误判全部字段需要 setter）。已修复：`cachedPickcode` 从构造参数改为**类体 `@Ignore var` 属性**（Room 标准用法），`LibraryScanner.buildMovie` 改为构造后 `.apply { cachedPickcode = ... }` 赋值，`MovieRepository` 的 `copy()` 分支用 `.also { it.cachedPickcode = scanned.cachedPickcode }` 恢复（data class 的 copy 不复制类体属性）
- Domestic 残留 0；HomeMovie 用户可见文案残留 0（仅内部标识符与 GitHub URL，符合报告要求）
- 关键符号一致性验证通过：scanLibrary 新签名与唯一调用点、scanningCount/scanningCurrentPath 三处、delay/toHttpUrl/isTrustedProxyBaseUrl import
- MovieTypeConverters 提供 List<String> 转换，MovieStaleCheckRow 查询映射正确

## 四、未执行项说明

- **8.2/8.3**（核心云盘逻辑测试、迁移测试）：沙箱无 Android 测试环境，测试代码无法运行验证，未落地
- **2.3**（AppSettingsRepository 按领域拆分）：大重构，涉及 60+ key/80+ 方法迁移，建议独立迭代
- **9.4**（release 混淆/ProGuard）：开启 minify 需要配套 keep 规则，风险高，建议发布流程中单独处理
- **4.2**（离线记忆 Room 化）：行为敏感（断点续跑），建议真机验证后迁移
