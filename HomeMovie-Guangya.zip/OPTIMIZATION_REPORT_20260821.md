# HomeMovie-Guangya 优化执行报告

执行日期：2026-08-21
依据：《HomeMovie-Guangya 优化报告》（2026-08-21 生成）

## 一、执行总览

> 共 21 项，20 项完成、1 项（4.11）经确认后回退。

| 优先级 | 编号 | 状态 | 说明 |
|---|---|---|---|
| P0 | 4.1 | ✅ 完成 | FolderPickerDialog dismissButton 布局错误修复 |
| P0 | 4.2 | ✅ 完成 | loggedIn 构造时固定不刷新修复 |
| P1 | 1.x | ✅ 完成 | 删除「A目录/国产」功能（15 个文件） |
| P1 | 3.x | ✅ 完成 | 离线下载弹窗按钮样式统一 |
| P1 | 2.1 | ✅ 完成 | 「115 Cookie」→「115 网盘登录」 |
| P1 | 2.2 | ✅ 完成 | 概览页增加光鸭登录状态（含实时刷新增强） |
| P1 | 4.5 | ✅ 完成 | 开始上传前自动保存每日限额 |
| P2 | 2.3 | ✅ 完成 | 保存按钮上方增加说明文字 |
| P2 | 2.4 | ✅ 完成 | 网盘删除描述补充光鸭 |
| P2 | 4.4 | ✅ 完成 | 离线下载入口改为 OutlinedButton 醒目化 |
| P2 | 4.7 | ✅ 完成 | 磁力链接输入框增加清空按钮 |
| P2 | 4.10 | ✅ 完成 | settingsTextFieldColors 改 internal 并应用到离线弹窗 |
| P2 | 4.11 | ⏪ 回退 | 验证码长度限制保持原样（`length >= 4`）——光鸭验证码为 4 位，精确匹配无益且阻碍登录 |
| P3 | 2.5 | ✅ 完成 | 小文件阈值描述补充 |
| P3 | 2.6 | ✅ 完成 | 排除视频描述精确化 |
| P3 | 2.7 | ✅ 完成 | 代理地址未保存时橙色提示 |
| P3 | 2.8 | ✅ 完成 | 进度条预览时间改为 00:00/99:99 + 「预览」水印 |
| P3 | 4.3 | ✅ 完成 | 离线下载弹窗 AlertDialog → ModalBottomSheet |
| P3 | 4.6 | ✅ 完成 | 日志区高度固定 150dp → heightIn(100..200dp) |
| P3 | 4.8 | ✅ 完成 | 删除死代码 ManualScrapeTaskPanel / CloudFolderBatchTaskPanel |
| P3 | 4.9 | ✅ 完成 | 使用统计空状态提示 |
| — | 4.12 | ✅ 确认 | 光鸭未登录引导文案无国产引用，无需改动 |

## 二、分项详情

### P0

**4.1 FolderPickerDialog dismissButton 布局错误（GuangyaBrowserScreen.kt）**
- 原问题：dismissButton 内「返回上级/根目录」Row 与「取消」TextButton 同级，布局不可预期
- 修改：全部按钮合并进同一个 `Row(horizontalArrangement = Arrangement.spacedBy(4.dp))`，「取消」作为最后一个元素

**4.2 loggedIn 构造时固定不刷新（GuangyaBrowserViewModel.kt）**
- 原问题：`val loggedIn: Boolean` 在 ViewModel 构造时固定，用户在设置页登录后浏览页不刷新
- 修改：改为 `fun isLoggedIn(): Boolean = settingsRepository.isGuangyaLoggedIn()`，每次重组/init 实时读取
- 同步更新调用处：`init` 中 `if (isLoggedIn())`、GuangyaBrowserScreen 中 `if (!viewModel.isLoggedIn())`

### P1-1：删除「A目录/国产」功能（15 个文件）

| 文件 | 修改内容 |
|---|---|
| ui/settings/SettingsScreen.kt | 概览页网盘条目改为「115 网盘与光鸭云盘」；删除 A目录 section（CID 输入框 + 国产开关）；删除 DomesticPageSwitchRow 函数；删除 onDomesticRootCidChange/onDomesticPageEnabledChange 参数 |
| ui/settings/SettingsViewModel.kt | 删除 domesticRootCidText/domesticPageEnabled 字段与 updateDomesticRootCid/updateDomesticPageEnabled 方法；loadState/save 同步清理 |
| data/repository/AppSettingsRepository.kt | 删除 5 个 Domestic 方法与 2 个常量（KEY_DOMESTIC_ROOT_CID/KEY_DOMESTIC_PAGE_ENABLED） |
| ui/home/HomeViewModel.kt | 删除 domesticMovieRepository 构造参数、domesticPageEnabledState、domesticMovies flow、refreshDomesticPageEnabled 方法；HomeUiState 删除 2 个字段；factory 同步 |
| ui/home/HomeScreen.kt | 删除 onDomesticPlay 参数、Domestic 过滤逻辑、DomesticMoviesGrid/DomesticMovieCard 函数、LibraryTab.Domestic 枚举；清理 4 个未使用 import |
| ui/LocalMovieLibraryAppRoot.kt | 删除 2 处 HomeViewModel.factory 与 1 处 CloudBrowserViewModel.factory 的 domesticMovieRepository 传参；删除 onDomesticPlay 回调 |
| ui/cloud/CloudBrowserViewModel.kt | 删除 domesticMovieRepository 参数、domesticRootCid()/addDomesticFolder() 方法、UiState 2 个字段、CloudDirectoryLoadResult 字段 |
| ui/cloud/CloudBrowserScreen.kt | 删除 isDomesticRoot/addingDomesticFolderCids/addedDomesticFolderCids/onAddDomesticFolder/showDomesticAdd/isDomesticAdding/isDomesticAdded 参数与渲染分支 |
| data/AppContainer.kt | 删除 domesticMovieRepository 实例；新增 MIGRATION_16_17（DROP 两张 domestic 表） |
| data/local/AppDatabase.kt | 删除 2 个 Entity 注解与 2 个 DAO 方法；version 16 → 17 |
| data/local/DomesticMovieEntity.kt | 🗑 整文件删除 |
| data/local/DomesticMovieDao.kt | 🗑 整文件删除 |
| data/local/DomesticVideoSourceEntity.kt | 🗑 整文件删除 |
| data/local/DomesticVideoSourceDao.kt | 🗑 整文件删除 |
| data/repository/DomesticMovieRepository.kt | 🗑 整文件删除 |

**数据库迁移说明（1.3）**
- 旧迁移 MIGRATION_7_8 / MIGRATION_8_9 中的建表语句**保留**（旧版本用户升级会按序执行）
- 新增 `MIGRATION_16_17`：`DROP TABLE IF EXISTS domestic_video_sources / domestic_movies`
- AppDatabase version 16 → 17，已在 AppContainer 的 addMigrations 链中注册

### P1-3：离线下载弹窗按钮样式统一（GuangyaBrowserScreen.kt）

统一常量：`dialogButtonShape = RoundedCornerShape(14.dp)`、`dialogRowButtonModifier = Modifier.weight(1f)`

| 区域 | 修改后 | shape | 字体 | padding |
|---|---|---|---|---|
| 1. 目标文件夹 | OutlinedButton ×2（选择文件夹/清除，清除由 TextButton 改来） | 14dp | 默认 | 默认 |
| 2. txt 导入 | Button → OutlinedButton 全宽 | 14dp | 默认 | 默认 |
| 4. 每日限额 | TextButton → OutlinedButton「保存」；输入框加 shape + 数字键盘 | 14dp | 默认 | 默认 |
| 5. 主操作 | Button 全宽单独一行（解析/开始上传） | 14dp | 默认 | 默认 |
| 5. 运行时控制 | Button(暂停/继续) + OutlinedButton(停止) 各 weight(1f)，另起一行 | 14dp | 默认 | 默认 |
| 8. 记忆管理 | OutlinedButton ×3 各 weight(1f)，去掉 emoji 与自定义极小 padding | 14dp | 默认 | 默认 |

**4.5 已并入区域 5**：「开始上传」点击前自动保存当前输入的限额值。

### P1-2：设置页文案

- **2.1**：`SettingsSectionTitle("115 Cookie")` → `"115 网盘登录"`
- **2.2**：SettingsUiState 新增 `guangyaLoggedIn` 字段；概览页 subtitle 改为 `"115 账号：已登录/未登录 · 光鸭：已登录/未登录"`
- **2.2 增强**：新增 `SettingsViewModel.refreshGuangyaLoggedIn()`，设置页监听 GuangyaLoginViewModel.step 变化实时刷新概览页状态

### P2

- **2.3**：保存按钮上方新增说明「开关类设置即时生效；文本框内容需点击下方按钮保存」
- **2.4**：删除描述改为「同时删除 115/光鸭网盘的真实视频文件」
- **4.4**：快捷导航改 SpaceBetween 布局，「离线下载」改 OutlinedButton(14dp) 与导航 TextButton 区分
- **4.7**：磁力链接输入框 trailingIcon 增加清空按钮（非空时显示，点击清空并重置预览）
- **4.10**：`settingsTextFieldColors()` 由 private 改 internal，离线弹窗磁力链接/限额输入框应用统一颜色方案
- **4.11（已回退）**：~~登录按钮 enabled 条件改为精确 6 位~~ —— 经确认光鸭验证码为 **4 位**，且输入框本就限制 6 位、`length >= 4` 在输入满 4 位时即可提交，精确匹配无实际收益反而可能阻碍登录，**保持原逻辑 `length >= 4` 不变**

### P3

- **2.5**：小文件阈值 supportingText 追加「仅对文件夹批量添加生效，单个视频添加不受此限制」
- **2.6**：排除视频描述改为「在网盘浏览时命中这些文件名不会显示添加按钮，但仍可直接播放」
- **2.7**：SettingsUiState 新增 `savedScrapeProxyAddress`；地址修改未保存时输入框下方显示橙色提示「地址已修改，需点击页面底部保存后生效」
- **2.8**：预览时间 `00:42/01:30` → `00:00/99:99`，并在预览区右上角加「预览」水印
- **4.3**：OfflineDownloadDialog 由 AlertDialog 改为 `ModalBottomSheet`（skipPartiallyExpanded，内部 verticalScroll），「关闭」按钮移入面板底部
- **4.6**：日志区 `.height(150.dp)` → `.heightIn(min = 100.dp, max = 200.dp)`
- **4.8**：删除无调用的 `ManualScrapeTaskPanel`（原 2824-2928 行）与 `CloudFolderBatchTaskPanel`（原 3087-3202 行）
- **4.9**：使用统计页 stats 为空时显示「暂无使用记录」空状态，隐藏柱状图/汇总/周记录

## 三、校验结果

- **编译修复记录**：CI 报 `GuangyaBrowserScreen.kt:311 Unresolved reference 'weight'` —— 根因是 `val dialogRowButtonModifier = Modifier.weight(1f)` 定义在函数顶层（无 Row/Column scope），而 `Modifier.weight` 是 RowScope/ColumnScope 成员扩展。已删除该常量，全部使用处改为在 Row 内直接写 `Modifier.weight(1f)`，回归验证通过
- **语法解析**：全项目 134 个 Kotlin 文件通过 tree-sitter 语法解析，0 语法错误
- **括号配平**：全部修改文件通过括号平衡校验
- **残留检查**：「Domestic/domestic」残留引用为 0（仅数据库迁移中的表名与 DROP 语句，符合预期）
- **import 交叉检查**：项目内 `com.example.localmovielibrarz.*` 内部 import 全部有效；关键新增符号（`guangyaLoggedIn`、`savedScrapeProxyAddress`、`isLoggedIn()`、`refreshGuangyaLoggedIn()`、`MIGRATION_16_17`）定义与引用一一对应
- **配置文件**：AndroidManifest / build.gradle.kts / scripts 均无 domestic 残留
- 说明：沙箱网络无法访问 Google/Maven 仓库，未能安装 Android SDK 执行 Gradle 编译；建议在本地 Android Studio 打开项目执行一次 Build 验证（重点 `app:compileDebugKotlin`）

## 四、交付

- 修改后的完整工程：`/workspace/HomeMovie-Guangya/`
- 本说明文档：`/workspace/HomeMovie-Guangya/OPTIMIZATION_REPORT_20260821.md`
