# 发布指南（手机版 / GitHub 小白）

目标：把本工程推到你自己的 GitHub 仓库，由 GitHub 免费云端机器帮你编译出 APK。

> 重要前提：这台 AI 沙箱连不上 GitHub，无法代你推送。下面的操作全在你**自己的手机**上完成。
> 你只需要：① 能上网的手机 ② 一个 GitHub 账号。不需要电脑、不需要 Android Studio。

---

## 你是安卓手机 → 用 Termux（推荐，全程在手机上）

Termux 是安卓上的"终端"，可以在里面跑 git 和 GitHub 官方命令行，把代码推上去。

### 第 1 步：装 Termux
- 打开 **F-Droid**（https://f-droid.org ）搜索 **Termux** 安装（Google Play 上的版本较旧，建议用 F-Droid）。
- 首次打开 Termux，会请求"文件访问"权限，允许它。

### 第 2 步：在 Termux 里装工具
把下面几行**一行一行**粘贴到 Termux（粘贴：长按屏幕 → 粘贴），回车执行：

```bash
termux-setup-storage
pkg update
pkg install git gh unzip
```

> 中途可能问你 `Y/n`，输入 `y` 回车即可。

### 第 3 步：把工程弄进 Termux 并解压
先在手机浏览器里从 AI 对话下载好 `HomeMovie-Guangya.zip`，它会在 **Download（下载）** 文件夹里。然后在 Termux 执行：

```bash
cd ~
cp /sdcard/Download/HomeMovie-Guangya.zip .
unzip HomeMovie-Guangya.zip
cd HomeMovie-Guangya
```

### 第 4 步：登录 GitHub（设备码，手机浏览器就能完成）
```bash
gh auth login -w -h github.com -p https
```
执行后 Termux 会显示**一串设备码**（类似 `ABCD-1234`）和一个网址 `https://github.com/login/device`。
- 用手机浏览器打开那个网址 → 输入设备码 → 点 **Continue** → **Authorize** 授权。
- 授权完回到 Termux，看到登录成功的提示即可。

### 第 5 步：提交并推送到 GitHub（自动建仓库 + 触发编译）
```bash
git init -b main
git add .
git commit -m "feat: 接入光鸭云盘"
gh repo create HomeMovie-Guangya --private --source=. --push
```

最后一行会自动：① 在你的 GitHub 建一个名为 `HomeMovie-Guangya` 的私有仓库 ② 把代码推上去 ③ **推送即触发编译**。

### 第 6 步：等编译完，下载 APK
- 用手机浏览器打开 `https://github.com/<你的用户名>/HomeMovie-Guangya` → 点 **Actions** 标签页。
- 看到一条 "Build Debug APK" 正在跑，等它变绿 ✅（约 5–10 分钟）。
- 点进该次运行 → 拉到最下面 **Artifacts** → 下载 **app-debug**。
- 解压得到 `app-debug.apk`，用手机文件管理器打开安装（首次需允许"未知来源"安装）。

---

## 你是苹果手机（iOS）→ 只能用电脑

iOS 没有 Termux 这类终端，App Store 里的 GitHub 官方 App 也**不能**上传整个工程文件夹。所以 iOS 用户必须借一台电脑（自己的/朋友的/图书馆都行），按下面的"电脑版"做：

### 电脑版（极简，点鼠标）
1. 电脑浏览器登录 GitHub，下载并安装 **GitHub Desktop**（https://desktop.github.com ）。
2. 从 AI 对话下载 `HomeMovie-Guangya.zip`，解压。
3. GitHub Desktop：`File → Add Local Repository` 选解压文件夹 → 点 **Publish repository**（仓库名 `HomeMovie-Guangya`）。
4. 浏览器进 `github.com/<用户名>/HomeMovie-Guangya` → **Actions** → 等变绿 → 下载 Artifacts 里的 `app-debug`。
5. 把 `app-debug.apk` 通过微信/邮件/网盘发到自己手机上安装。

---

## 常见问题

- **Termux 里 `gh` 装不上？** 试试先 `pkg update` 再装；若仍不行，用备用方案：在 GitHub 网页用手机浏览器建一个空仓库，再生成 **Personal Access Token**（Settings → Developer settings → PAT，勾 `repo` 和 `workflow`），然后用 `git remote add origin https://<用户名>:<令牌>@github.com/<用户名>/HomeMovie-Guangya.git` 后 `git push -u origin main`。
- **`gh auth login` 卡住？** 确认你是在手机浏览器打开了 `github.com/login/device` 并正确输入了 Termux 里显示的那个码；码有效期约 15 分钟，过期重跑该命令即可。
- **编译失败（红 ✗）？** 进入该次 Actions 运行看红色步骤日志。最常见是网络抖动，点右上角 **Re-run all jobs** 重试一次。
- **APK 装不上？** 手机"设置 → 安全 → 安装未知应用"里，允许你用来打开 APK 的文件管理器/浏览器。
- **登录光鸭没反应？** App 里点登录会显示一串验证码，去提示的网页输入并授权；失效就点刷新重试。注意 `client_id` 目前复用的是第三方 guangyapan 库，极少数情况光鸭可能弹人机校验，届时在网页手动过一下。

---

## 编译环境说明（吃颗定心丸）
- 编译发生在 **GitHub 的云端 Ubuntu 机器**上，不是你的手机，所以手机不需要 SDK、不需要大内存。
- 工作流自动安装：JDK 17、Android SDK（platform-35 + build-tools;35.0.0）、接受许可、跑 `./gradlew assembleDebug`。
- 115 网盘代码**完全未改动**，光鸭是平行新增的 `cloudguangya` 包，二者互不影响。
- 工程自带的 `.gitignore` 会忽略 `115-cookies.txt`、`*.keystore`、`*.apk`，**不会误提交你的凭据**。
