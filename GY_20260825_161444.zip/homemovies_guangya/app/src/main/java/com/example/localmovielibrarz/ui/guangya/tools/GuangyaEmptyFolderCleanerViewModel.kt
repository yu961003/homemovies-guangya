package com.example.localmovielibrarz.ui.guangya.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuangyaEmptyFolderMatch(val folderId: String, val name: String, val path: String)

data class GuangyaEmptyFolderUiState(
    val scanning: Boolean = false,
    val candidates: List<GuangyaEmptyFolderMatch> = emptyList(),
    val error: String? = null,
    val message: String? = null,
    val selectionMode: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val cleaning: Boolean = false
)

/** 光鸭空文件夹清理：DFS 递归，子项为空 → 空候选 → 二次 listFiles 确认 → 分批移入回收站。 */
class GuangyaEmptyFolderCleanerViewModel(
    private val repository: GuangyaBrowserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GuangyaEmptyFolderUiState())
    val uiState: StateFlow<GuangyaEmptyFolderUiState> = _uiState.asStateFlow()

    fun startScan(rootParentId: String, rootName: String) {
        _uiState.update { it.copy(scanning = true, candidates = emptyList(), error = null) }
        viewModelScope.launch {
            runCatching {
                val found = mutableListOf<GuangyaEmptyFolderMatch>()
                val visited = mutableSetOf<String>()
                fun collect(pid: String, path: String, depth: Int) {
                    if (depth > 12 || found.size >= 5000) return
                    if (pid in visited) return
                    visited.add(pid)
                    val children = repository.listFiles(pid)
                    for (c in children) if (c.isDir) collect(c.fileId, "$path/${c.name}", depth + 1)
                    if (children.isEmpty()) {
                        found += GuangyaEmptyFolderMatch(pid, path.substringAfterLast('/'), path)
                    }
                }
                collect(rootParentId, rootName, 0)
                // 二次确认：排除扫描期间新增文件的目录（listFiles(folderId) 子项为空才算真空）
                found.filter { repository.listFiles(it.folderId).isEmpty() }
            }.onSuccess { list ->
                _uiState.update { it.copy(candidates = list, scanning = false, message = "空文件夹 ${list.size} 个") }
            }.onFailure { e ->
                _uiState.update { it.copy(error = e.message ?: "扫描失败", scanning = false) }
            }
        }
    }

    fun toggleSelect(id: String) { _uiState.update { s -> s.copy(selectedIds = if (id in s.selectedIds) s.selectedIds - id else s.selectedIds + id) } }
    fun selectAll() { _uiState.update { s -> s.copy(selectedIds = s.candidates.map { it.folderId }.toSet()) } }
    fun clearSelection() { _uiState.update { it.copy(selectionMode = false, selectedIds = emptySet()) } }

    fun cleanSelected() {
        val ids = _uiState.value.selectedIds.toList()
        if (ids.isEmpty()) { _uiState.update { it.copy(message = "请先勾选要移入回收站的空文件夹") }; return }
        _uiState.update { it.copy(cleaning = true, message = "正在移入回收站…") }
        viewModelScope.launch {
            runCatching { repository.recycleFiles(ids) }
                .onSuccess {
                    _uiState.update {
                        it.copy(message = "已移入回收站 ${ids.size} 个空文件夹", cleaning = false,
                            selectionMode = false, selectedIds = emptySet(),
                            candidates = it.candidates.filterNot { c -> c.folderId in ids })
                    }
                }
                .onFailure { e -> _uiState.update { it.copy(message = "移入回收站失败：${e.message}", cleaning = false) } }
        }
    }

    fun clearMessage() { _uiState.update { it.copy(message = null, error = null) } }

    companion object {
        fun factory(repository: GuangyaBrowserRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    GuangyaEmptyFolderCleanerViewModel(repository) as T
            }
    }
}
