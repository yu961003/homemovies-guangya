package com.example.localmovielibrarz.ui.cloud.components

/**
 * 已废弃：搜索条已迁移到 CloudSearchBar.kt（问题7 搜索框重设计）。
 * 本文件仅保留包声明以兼容已存在的引用；CloudSearchScope 定义见 CloudSearchBar.kt。
 */