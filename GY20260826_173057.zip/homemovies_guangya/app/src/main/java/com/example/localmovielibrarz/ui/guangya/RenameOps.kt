package com.example.localmovielibrarz.ui.guangya

import com.example.localmovielibrarz.cloudguangya.GuangyaFileItem
import org.json.JSONObject
import java.util.Locale

/**
 * 批量重命名 v3：四类操作（删除/替换、插入、全新命名、自定义正则）+ 正则增强 + 模板。
 * 纯函数实现，便于单测；所有「位置」语义均为 1 基（第 1 位 = 首字符）。
 * 语义示例统一用主名 "ABCDEF-123"（共 10 位）。
 */

// ==================== 配置模型 ====================

/** 批量重命名配置（四类操作统一入口）。 */
sealed interface BatchRenameConfig {
    /** 删除/替换字符：replacement 为空 = 纯删除；xxAsRegex=true 时 XX 按正则解释、替换为支持 $ 分组。 */
    data class DeleteReplace(
        val range: RenameDeleteRange,
        val replacement: String = "",
        val xxAsRegex: Boolean = false
    ) : BatchRenameConfig

    /** 新增/插入字符。 */
    data class Insert(
        val position: RenameInsertPosition,
        val text: String,
        val markerAsRegex: Boolean = false
    ) : BatchRenameConfig

    /** 全新命名：{name}=原主名，{n}=序号（startNumber 起、digits 位补零）。 */
    data class NewNaming(
        val template: String,
        val startNumber: Int = 1,
        val digits: Int = 2
    ) : BatchRenameConfig

    /** 自定义正则查找替换（完全自由 pattern，replacement 支持 $1/$2 分组）。 */
    data class CustomRegex(
        val pattern: String,
        val replacement: String,
        val ignoreCase: Boolean = false,
        val firstOnly: Boolean = false,
        val applyToExtension: Boolean = false
    ) : BatchRenameConfig
}

// ============ 删除/替换范围（示例主名 ABCDEF-123） ============

sealed interface RenameDeleteRange {
    /** 指定字符串 XX（字面模式：所有出现处；正则模式：XX 即 pattern）。XX="DEF" → ABC-123 */
    data class SpecifiedString(val text: String) : RenameDeleteRange

    /** 前 N 个字符。N=6 → -123 */
    data class FirstN(val n: Int) : RenameDeleteRange

    /** 后 N 个字符。N=3 → ABCDEF- */
    data class LastN(val n: Int) : RenameDeleteRange

    /** 第 M 位之后的 N 个字符。M=6,N=4 → 删第 7~10 位("-123") → ABCDEF */
    data class AfterPositionMN(val m: Int, val n: Int) : RenameDeleteRange

    /** 倒数第 M 位之前的 N 个字符（不含倒数第 M 位本身）。M=4,N=2 → 倒数第4位是"-"，删其前"EF" → ABCD-123 */
    data class BeforeEndPositionMN(val m: Int, val n: Int) : RenameDeleteRange

    /** XX 之后的全部字符。XX="-" → ABCDEF-（includeMarker=true 连 XX 一起删 → ABCDEF） */
    data class AfterStringAll(val text: String, val includeMarker: Boolean = false) : RenameDeleteRange

    /** XX 之前的全部字符。XX="-" → -123（includeMarker=true → 123） */
    data class BeforeStringAll(val text: String, val includeMarker: Boolean = false) : RenameDeleteRange

    /** XX 之后的 N 个字符。XX="-",N=2 → ABCDEF-3 */
    data class AfterStringN(val text: String, val n: Int, val includeMarker: Boolean = false) : RenameDeleteRange
}

// ==================== 插入位置（示例插入文本 "[HD]"） ====================

sealed interface RenameInsertPosition {
    /** 开头 → [HD]ABCDEF-123 */
    data object Start : RenameInsertPosition
    /** 末尾 → ABCDEF-123[HD] */
    data object End : RenameInsertPosition
    /** 第 N 个字符之后。N=6 → ABCDEF[HD]-123 */
    data class AfterNth(val n: Int) : RenameInsertPosition
    /** 倒数第 N 个字符之前。N=3 → ABCDEF-[HD]123 */
    data class BeforeLastNth(val n: Int) : RenameInsertPosition
    /** XX 字符串之后（字面模式：第一处；正则模式：每一处命中）。XX="-" → ABCDEF-[HD]123 */
    data class AfterString(val text: String) : RenameInsertPosition
    /** XX 字符串之前。XX="-" → ABCDEF[HD]-123 */
    data class BeforeString(val text: String) : RenameInsertPosition
}

// ==================== 纯函数实现 ====================

object RenameOps {

    val ILLEGAL_NAME_CHARS = charArrayOf('/', '\\', ':', '*', '?', '"', '<', '>', '|')

    /** 统一分发：xxAsRegex=false 走字面实现，true 走自动编译的正则实现。 */
    fun deleteOrReplace(
        base: String,
        range: RenameDeleteRange,
        replacement: String,
        xxAsRegex: Boolean = false
    ): String? {
        if (replacement.any { it in ILLEGAL_NAME_CHARS }) return null
        return if (xxAsRegex) regexDeleteOrReplace(base, range, replacement)
        else literalDeleteOrReplace(base, range, replacement)
    }

    /** 统一分发：markerAsRegex 仅对 XX 定位类位置有意义，纯位置类两模式行为一致。 */
    fun insert(
        base: String,
        position: RenameInsertPosition,
        text: String,
        markerAsRegex: Boolean = false
    ): String? {
        if (text.isEmpty() || text.any { it in ILLEGAL_NAME_CHARS }) return null
        return if (markerAsRegex) regexInsert(base, position, text)
        else literalInsert(base, position, text)
    }

    // ---------------- 字面实现 ----------------

    private fun literalDeleteOrReplace(base: String, range: RenameDeleteRange, replacement: String): String? {
        /** 处理 base 的 [start,end) 区间：start 越界=参数错误返回 null；end 自动收敛。 */
        fun cut(start: Int, end: Int): String? {
            if (start < 0 || start > base.length) return null
            val e = end.coerceIn(start, base.length)
            return base.replaceRange(start, e, replacement)
        }
        return when (range) {
            is RenameDeleteRange.SpecifiedString ->
                if (range.text.isEmpty()) null else base.replace(range.text, replacement)

            is RenameDeleteRange.FirstN ->
                if (range.n <= 0) null else cut(0, range.n)

            is RenameDeleteRange.LastN ->
                if (range.n <= 0) null else cut(base.length - range.n, base.length)

            is RenameDeleteRange.AfterPositionMN ->
                if (range.m < 0 || range.n <= 0) null else cut(range.m, range.m + range.n)

            is RenameDeleteRange.BeforeEndPositionMN ->
                if (range.m <= 0 || range.m > base.length || range.n <= 0) null
                else cut(base.length - range.m - range.n, base.length - range.m)

            is RenameDeleteRange.AfterStringAll -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() -> null
                    idx < 0 -> base
                    else -> cut(if (range.includeMarker) idx else idx + range.text.length, base.length)
                }
            }

            is RenameDeleteRange.BeforeStringAll -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() -> null
                    idx < 0 -> base
                    else -> cut(0, if (range.includeMarker) idx + range.text.length else idx)
                }
            }

            is RenameDeleteRange.AfterStringN -> {
                val idx = base.indexOf(range.text)
                when {
                    range.text.isEmpty() || range.n <= 0 -> null
                    idx < 0 -> base
                    else -> {
                        val start = if (range.includeMarker) idx else idx + range.text.length
                        cut(start, start + range.n)
                    }
                }
            }
        }
    }

    private fun literalInsert(base: String, position: RenameInsertPosition, text: String): String? {
        val at: Int = when (position) {
            RenameInsertPosition.Start -> 0
            RenameInsertPosition.End -> base.length
            is RenameInsertPosition.AfterNth -> position.n.coerceIn(0, base.length)
            is RenameInsertPosition.BeforeLastNth -> (base.length - position.n).coerceIn(0, base.length)
            is RenameInsertPosition.AfterString ->
                if (position.text.isEmpty()) return null
                else base.indexOf(position.text).takeIf { it >= 0 }
                    ?.let { it + position.text.length } ?: return base
            is RenameInsertPosition.BeforeString ->
                if (position.text.isEmpty()) return null
                else base.indexOf(position.text).takeIf { it >= 0 } ?: return base
        }
        return StringBuilder(base).insert(at, text).toString()
    }

    // ---------------- 正则实现（下拉选项自动编译为 pattern） ----------------

    /**
     * 分组约定（正则模式）：
     * - SpecifiedString：$1.. = 用户在 XX 中自己写的分组；
     * - FirstN/LastN/AfterPositionMN/BeforeEndPositionMN：$1 = 被替换的目标字符；
     * - AfterStringAll：pattern=(XX)[\s\S]*，$1 = XX 匹配内容（替换为 $1 = 保留 XX 删其后，留空 = 连 XX 一起删）；
     * - BeforeStringAll：pattern=[\s\S]*?(XX)，$1 = XX 匹配内容（替换为 $1 = 删其前保留 XX，留空 = 连 XX 一起删）；
     * - AfterStringN：pattern=(XX)([\s\S]{1,N})，$1 = XX，$2 = 其后 N 个字符。
     * XX 定位类对每一处命中生效（字面模式只作用于第一处）。
     */
    private fun regexDeleteOrReplace(base: String, range: RenameDeleteRange, replacement: String): String? {
        // runCatching 同时兜底「pattern 非法」与「replacement 引用了不存在的分组」
        fun apply(pattern: String): String? = runCatching {
            Regex(pattern).replace(base, replacement)
        }.getOrNull()

        return when (range) {
            is RenameDeleteRange.SpecifiedString ->
                if (range.text.isEmpty()) null else apply(range.text)

            is RenameDeleteRange.FirstN ->
                if (range.n <= 0) null else apply("^([\\s\\S]{1,${range.n}})")

            is RenameDeleteRange.LastN ->
                if (range.n <= 0) null else apply("([\\s\\S]{1,${range.n}})\$")

            is RenameDeleteRange.AfterPositionMN ->
                if (range.m < 0 || range.n <= 0) null
                else apply("(?<=^[\\s\\S]{${range.m}})([\\s\\S]{1,${range.n}})")

            is RenameDeleteRange.BeforeEndPositionMN ->
                if (range.m <= 0 || range.n <= 0) null
                else apply("([\\s\\S]{1,${range.n}})(?=[\\s\\S]{${range.m}}\$)")

            is RenameDeleteRange.AfterStringAll ->
                if (range.text.isEmpty()) null else apply("(${range.text})[\\s\\S]*")

            is RenameDeleteRange.BeforeStringAll ->
                if (range.text.isEmpty()) null else apply("[\\s\\S]*?(${range.text})")

            is RenameDeleteRange.AfterStringN ->
                if (range.text.isEmpty() || range.n <= 0) null
                else apply("(${range.text})([\\s\\S]{1,${range.n}})")
        }
    }

    private fun regexInsert(base: String, position: RenameInsertPosition, text: String): String? {
        // 插入文本中的 $ 需转义为 $$，避免被当作分组引用
        val safeText = text.replace("$", "$$")
        return when (position) {
            // 纯位置类：正则无增益，直接字面处理
            RenameInsertPosition.Start, RenameInsertPosition.End,
            is RenameInsertPosition.AfterNth, is RenameInsertPosition.BeforeLastNth ->
                literalInsert(base, position, text)

            is RenameInsertPosition.AfterString ->
                if (position.text.isEmpty()) null
                else runCatching {
                    Regex("(${position.text})").replace(base, "$1" + safeText)
                }.getOrNull()

            is RenameInsertPosition.BeforeString ->
                if (position.text.isEmpty()) null
                else runCatching {
                    Regex("(${position.text})").replace(base, safeText + "$1")
                }.getOrNull()
        }
    }

    // ---------------- 全新命名 / 自定义正则 ----------------

    /** 全新命名模板。{name}=原主名，{n}=序号。 */
    fun fromTemplate(template: String, base: String, index: Int, startNumber: Int, digits: Int): String? {
        val t = template.trim()
        if (t.isEmpty() || t.any { it in ILLEGAL_NAME_CHARS }) return null
        if (startNumber < 0 || digits !in 1..6) return null
        val seq = String.format(Locale.ROOT, "%0${digits}d", startNumber + index)
        return t.replace("{n}", seq).replace("{name}", base).trim().ifEmpty { null }
    }

    /** 自定义正则替换。pattern 为空或非法、replacement 引用不存在分组 → null。 */
    fun regexReplace(
        base: String,
        pattern: String,
        replacement: String,
        ignoreCase: Boolean,
        firstOnly: Boolean
    ): String? {
        if (pattern.isEmpty()) return null
        val regex = runCatching {
            Regex(pattern, if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet())
        }.getOrNull() ?: return null
        return runCatching {
            if (firstOnly) regex.replaceFirst(base, replacement) else regex.replace(base, replacement)
        }.getOrNull()
    }
}

// ==================== 批量结果计算 ====================

/** names=null 表示配置不合法，error 为用户可读原因。 */
data class BatchRenameResult(val names: List<String>?, val error: String?)

/**
 * 对选中文件（按文件名排序）统一应用配置，自动保留扩展名（自定义正则的 applyToExtension=true 除外）。
 * 校验链：参数合法性 → 非空 → 无非法字符 → 批内不重名。
 */
fun buildBatchRenameNames(
    files: List<GuangyaFileItem>,
    config: BatchRenameConfig
): BatchRenameResult {
    val names = mutableListOf<String>()
    files.forEachIndexed { index, item ->
        val dot = item.name.lastIndexOf('.')
        val hasExt = dot > 0
        val base = if (hasExt) item.name.substring(0, dot) else item.name
        val ext = if (hasExt) item.name.substring(dot) else ""

        val newFullName: String? = when (config) {
            is BatchRenameConfig.DeleteReplace ->
                RenameOps.deleteOrReplace(base, config.range, config.replacement, config.xxAsRegex)
                    ?.let { it + ext }

            is BatchRenameConfig.Insert ->
                RenameOps.insert(base, config.position, config.text, config.markerAsRegex)
                    ?.let { it + ext }

            is BatchRenameConfig.NewNaming ->
                RenameOps.fromTemplate(config.template, base, index, config.startNumber, config.digits)
                    ?.let { it + ext }

            is BatchRenameConfig.CustomRegex ->
                if (config.applyToExtension) {
                    RenameOps.regexReplace(
                        item.name, config.pattern, config.replacement, config.ignoreCase, config.firstOnly
                    )
                } else {
                    RenameOps.regexReplace(
                        base, config.pattern, config.replacement, config.ignoreCase, config.firstOnly
                    )?.let { it + ext }
                }
        }

        if (newFullName == null) {
            return BatchRenameResult(null, "规则参数不合法（检查「${item.name}」对应的 N/M/XX/正则输入）")
        }
        if (newFullName.isBlank()) {
            return BatchRenameResult(null, "「${item.name}」的生成结果为空")
        }
        if (newFullName.any { it in RenameOps.ILLEGAL_NAME_CHARS }) {
            return BatchRenameResult(null, "「${item.name}」的生成结果含非法字符 /\\:*?\"<>| 之一")
        }
        names += newFullName
    }
    if (names.toSet().size != names.size) {
        return BatchRenameResult(null, "生成结果存在重名：可用全新命名的 {n} 序号或正则捕获组区分")
    }
    return BatchRenameResult(names, null)
}

// ==================== 模板（全操作类型） ====================

/**
 * 批量重命名模板：镜像对话框表单的扁平参数集，JSON 序列化存 SharedPreferences StringSet。
 * opType：0=删除/替换 1=插入 2=全新命名 3=自定义正则。
 */
data class BatchRenameTemplate(
    val id: Long,                    // System.currentTimeMillis()
    val name: String,                // 展示名（保存时自动生成）
    val opType: Int,
    // —— 删除/替换 ——
    val rangeIndex: Int = 0,
    val xxText: String = "",
    val m: Int = 0,
    val n: Int = 0,
    val includeMarker: Boolean = false,
    val replacement: String = "",
    val xxAsRegex: Boolean = false,
    // —— 插入 ——
    val insertIndex: Int = 0,
    val insertText: String = "",
    val insertN: Int = 0,
    val insertMarker: String = "",
    val insertMarkerAsRegex: Boolean = false,
    // —— 全新命名 ——
    val namingTemplate: String = "{name}-{n}",
    val startNumber: Int = 1,
    val digits: Int = 2,
    // —— 自定义正则 ——
    val pattern: String = "",
    val regexReplacement: String = "",
    val ignoreCase: Boolean = false,
    val firstOnly: Boolean = false,
    val applyToExtension: Boolean = false
) {
    fun toJson(): String = JSONObject().apply {
        put("id", id); put("name", name); put("opType", opType)
        put("rangeIndex", rangeIndex); put("xxText", xxText); put("m", m); put("n", n)
        put("includeMarker", includeMarker); put("replacement", replacement); put("xxAsRegex", xxAsRegex)
        put("insertIndex", insertIndex); put("insertText", insertText); put("insertN", insertN)
        put("insertMarker", insertMarker); put("insertMarkerAsRegex", insertMarkerAsRegex)
        put("namingTemplate", namingTemplate); put("startNumber", startNumber); put("digits", digits)
        put("pattern", pattern); put("regexReplacement", regexReplacement)
        put("ignoreCase", ignoreCase); put("firstOnly", firstOnly); put("applyToExtension", applyToExtension)
    }.toString()

    companion object {
        fun fromJson(s: String): BatchRenameTemplate? = runCatching {
            val o = JSONObject(s)
            BatchRenameTemplate(
                id = o.optLong("id"), name = o.optString("name"), opType = o.optInt("opType"),
                rangeIndex = o.optInt("rangeIndex"), xxText = o.optString("xxText"),
                m = o.optInt("m"), n = o.optInt("n"),
                includeMarker = o.optBoolean("includeMarker"), replacement = o.optString("replacement"),
                xxAsRegex = o.optBoolean("xxAsRegex"),
                insertIndex = o.optInt("insertIndex"), insertText = o.optString("insertText"),
                insertN = o.optInt("insertN"), insertMarker = o.optString("insertMarker"),
                insertMarkerAsRegex = o.optBoolean("insertMarkerAsRegex"),
                namingTemplate = o.optString("namingTemplate", "{name}-{n}"),
                startNumber = o.optInt("startNumber", 1), digits = o.optInt("digits", 2),
                pattern = o.optString("pattern"), regexReplacement = o.optString("regexReplacement"),
                ignoreCase = o.optBoolean("ignoreCase"), firstOnly = o.optBoolean("firstOnly"),
                applyToExtension = o.optBoolean("applyToExtension")
            )
        }.getOrNull()
    }
}