package com.example.localmovielibrarz.ui.guangya

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RenameOpsTest {

    // ---- 字面模式 ----
    @Test fun `前N个字符`() =
        assertEquals("-123", RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.FirstN(6), ""))

    @Test fun `第M位后的N个字符`() =
        assertEquals("ABCDEF", RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.AfterPositionMN(6, 4), ""))

    @Test fun `倒数M位前的N个字符`() =
        assertEquals("ABCD-123", RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.BeforeEndPositionMN(4, 2), ""))

    @Test fun `XX之后全部_含标记`() =
        assertEquals("ABCDEF", RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.AfterStringAll("-", true), ""))

    @Test fun `XX未找到_原样返回`() =
        assertEquals("ABCDEF-123", RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.AfterStringAll("ZZ"), ""))

    @Test fun `插入到XX之后`() =
        assertEquals("ABCDEF-[HD]123", RenameOps.insert("ABCDEF-123", RenameInsertPosition.AfterString("-"), "[HD]"))

    // ---- 正则模式 ----
    @Test fun `正则XX删除中括号标记`() =
        assertEquals(
            "ABC-123",
            RenameOps.deleteOrReplace("ABC[HD]-123", RenameDeleteRange.SpecifiedString("\\[.*?\\]"), "", xxAsRegex = true)
        )

    @Test fun `正则保留XX删其后`() =
        assertEquals(
            "ABCDEF-",
            RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.AfterStringAll("-"), "$1", xxAsRegex = true)
        )

    @Test fun `正则前N字符带分组替换`() =
        assertEquals(
            "[AB]CDEF-123",
            RenameOps.deleteOrReplace("ABCDEF-123", RenameDeleteRange.FirstN(2), "[$1]", xxAsRegex = true)
        )

    @Test fun `正则插入到每处XX之后`() =
        assertEquals(
            "A-+B-+C",
            RenameOps.insert("A-B-C", RenameInsertPosition.AfterString("-"), "+", markerAsRegex = true)
        )

    @Test fun `非法正则返回null`() =
        assertNull(RenameOps.regexReplace("abc", "[", "x", false, false))

    @Test fun `引用不存在分组返回null`() =
        assertNull(RenameOps.regexReplace("abc", "(a)", "$2", false, false))

    @Test fun `正则分组交换`() =
        assertEquals("123-ABCDEF", RenameOps.regexReplace("ABCDEF-123", "(\\w+)-(\\d+)", "$2-$1", false, false))

    // ---- 模板 ----
    @Test fun `模板JSON往返`() {
        val t = BatchRenameTemplate(id = 1, name = "x", opType = 0, rangeIndex = 3, m = 6, n = 4)
        assertEquals(t, BatchRenameTemplate.fromJson(t.toJson()))
    }
}