package com.example.localmovielibrarz.data

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.localmovielibrarz.cloud115.Cloud115ApiClient
import com.example.localmovielibrarz.cloud115.Cloud115CookieProvider
import com.example.localmovielibrarz.cloud115.Cloud115QrLoginClient
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.data.repository.AppUpdateRepository
import com.example.localmovielibrarz.data.repository.Cloud115StrmRepository
import com.example.localmovielibrarz.data.local.AppDatabase
import com.example.localmovielibrarz.data.repository.CloudFolderBatchTaskRepository
import com.example.localmovielibrarz.data.repository.CloudFolderBatchTaskRunner
import com.example.localmovielibrarz.data.repository.CloudStrmRecordRepository
import com.example.localmovielibrarz.data.repository.CloudVideoAddProcessor
import com.example.localmovielibrarz.data.repository.CloudVideoTaskRepository
import com.example.localmovielibrarz.data.repository.CloudVideoTaskRunner
import com.example.localmovielibrarz.data.repository.DirectLinkRepository
import com.example.localmovielibrarz.data.repository.MovieRepository
import com.example.localmovielibrarz.data.repository.MovieScrapeTaskRunner
import com.example.localmovielibrarz.diagnostics.RuntimeErrorLog
import com.example.localmovielibrarz.data.repository.PlaybackProgressRepository
import com.example.localmovielibrarz.data.repository.StrmScrapeRepository
import com.example.localmovielibrarz.data.repository.UsageStatsRepository
import com.example.localmovielibrarz.cloudguangya.GuangyaApiClient
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import com.example.localmovielibrarz.cloudguangya.GuangyaCleanExecutor
import com.example.localmovielibrarz.cloudguangya.GuangyaLoginClient
import com.example.localmovielibrarz.cloudguangya.GuangyaOfflineMemory
import com.example.localmovielibrarz.cloudguangya.GuangyaOfflineSubmitter
import com.example.localmovielibrarz.cloudguangya.GuangyaRateLimiter
import com.example.localmovielibrarz.cloudguangya.GuangyaTokenProvider
import com.example.localmovielibrarz.cloudguangya.GuangyaTokenStore
import com.example.localmovielibrarz.data.local.GuangyaDirectLinkDao
import com.example.localmovielibrarz.data.repository.GuangyaDirectLinkResolver
import com.example.localmovielibrarz.data.repository.GuangyaStrmRepository
import com.example.localmovielibrarz.scanner.LibraryScanner
import com.example.localmovielibrarz.scraper.ScrapeLogStore
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val runtimeErrorLog: RuntimeErrorLog = RuntimeErrorLog(appContext)

    val database: AppDatabase = Room.databaseBuilder(
        appContext,
        AppDatabase::class.java,
        "local_movies.db"
    ).addMigrations(
        MIGRATION_1_2,
        MIGRATION_2_3,
        MIGRATION_3_4,
        MIGRATION_4_5,
        MIGRATION_5_6,
        MIGRATION_6_7,
        MIGRATION_7_8,
        MIGRATION_8_9,
        MIGRATION_9_10,
        MIGRATION_10_11,
        MIGRATION_11_12,
        MIGRATION_12_13,
        MIGRATION_13_14,
        MIGRATION_14_15,
        MIGRATION_15_16,
        MIGRATION_16_17,
        MIGRATION_17_18
    ).addCallback(
        object : RoomDatabase.Callback() {
            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                applyNonRoomIndexes(db)
            }
        }
    ).build()

    val scanner = LibraryScanner(appContext)
    val scrapeLogStore = ScrapeLogStore(appContext)

    /**
     * 在数据库每次打开时幂等创建 Room @Index 无法表达的索引（COLLATE NOCASE）。
     * Room 的 schema 校验只检查表与列，不校验索引，因此此处额外建索引不会触发
     * "migration didn't properly handle" 错误；IF NOT EXISTS 保证重复执行安全。
     */
    private fun applyNonRoomIndexes(db: SupportSQLiteDatabase) {
        db.execSQL(SQL_STRM_RECORDS_MOVIE_NUMBER_NOCASE_INDEX)
    }
    val settingsRepository = AppSettingsRepository(appContext)
    val usageStatsRepository = UsageStatsRepository(appContext)
    val appUpdateRepository = AppUpdateRepository(appContext, settingsRepository)
    // 2.2 优化：非核心路径（115 网盘 / 光鸭云盘）改为懒加载，
    // 避免 App 启动时急初始化用户可能永远用不到的客户端与 Repository。
    val cloud115Client by lazy { Cloud115ApiClient(Cloud115CookieProvider(appContext)) }
    val cloud115QrLoginClient by lazy { Cloud115QrLoginClient(appContext, settingsRepository) }
    val cloudStrmRecordRepository = CloudStrmRecordRepository(
        context = appContext,
        dao = database.cloudStrmRecordDao(),
        movieDao = database.movieDao(),
        settingsRepository = settingsRepository
    )
    val cloud115StrmRepository by lazy {
        Cloud115StrmRepository(
            context = appContext,
            cloud115Client = cloud115Client,
            settingsRepository = settingsRepository,
            recordRepository = cloudStrmRecordRepository
        )
    }
    // ===== 光鸭云盘（平行供应商，不影响 115） =====
    val guangyaRateLimiter by lazy { GuangyaRateLimiter() }
    val guangyaTokenStore by lazy { GuangyaTokenStore(appContext) }
    val guangyaLoginClient by lazy { GuangyaLoginClient(tokenStore = guangyaTokenStore) }
    val guangyaTokenProvider by lazy { GuangyaTokenProvider(guangyaTokenStore, guangyaLoginClient) }
    val guangyaApiClient by lazy {
        GuangyaApiClient(
            tokenProvider = guangyaTokenProvider,
            rateLimiter = guangyaRateLimiter,
            tokenStore = guangyaTokenStore
        )
    }
    val guangyaBrowserRepository by lazy { GuangyaBrowserRepository(guangyaApiClient) }
    val guangyaOfflineMemory by lazy { GuangyaOfflineMemory(appContext) }
    val guangyaOfflineSubmitter by lazy { GuangyaOfflineSubmitter(guangyaBrowserRepository, guangyaOfflineMemory) }
    /** 第四轮：大批量清理执行器（应用级单例，跨页面存活）。 */
    val guangyaCleanExecutor by lazy { GuangyaCleanExecutor(guangyaBrowserRepository) }
    val guangyaDirectLinkResolver by lazy {
        GuangyaDirectLinkResolver(
            dao = database.guangyaDirectLinkDao(),
            apiClient = guangyaApiClient
        )
    }
    val guangyaStrmRepository by lazy {
        GuangyaStrmRepository(
            context = appContext,
            guangyaClient = guangyaApiClient,
            settingsRepository = settingsRepository,
            recordRepository = cloudStrmRecordRepository
        )
    }
    val strmScrapeRepository = StrmScrapeRepository(
        context = appContext,
        settingsRepository = settingsRepository,
        logStore = scrapeLogStore
    )
    val directLinkRepository by lazy {
        DirectLinkRepository(
            directLinkDao = database.directLinkDao(),
            cloud115Client = cloud115Client
        )
    }
    val playbackProgressRepository = PlaybackProgressRepository(database.playbackProgressDao())
    val cloudFolderBatchTaskRepository = CloudFolderBatchTaskRepository(database.cloudFolderBatchTaskDao())
    val cloudVideoTaskRepository = CloudVideoTaskRepository(database.cloudVideoTaskDao())
    val movieRepository = MovieRepository(
        context = appContext,
        movieDao = database.movieDao(),
        cloudStrmRecordDao = database.cloudStrmRecordDao(),
        scanner = scanner,
        contentResolver = appContext.contentResolver,
        logStore = scrapeLogStore
    )
    private val cloudVideoAddProcessor by lazy {
        CloudVideoAddProcessor(
            strmRepository = cloud115StrmRepository,
            recordRepository = cloudStrmRecordRepository,
            settingsRepository = settingsRepository,
            movieRepository = movieRepository,
            scrapeRepository = strmScrapeRepository
        )
    }
    val cloudVideoTaskRunner by lazy {
        CloudVideoTaskRunner(
            taskRepository = cloudVideoTaskRepository,
            processor = cloudVideoAddProcessor,
            settingsRepository = settingsRepository
        )
    }
    val cloudFolderBatchTaskRunner by lazy {
        CloudFolderBatchTaskRunner(
            taskRepository = cloudFolderBatchTaskRepository,
            strmRepository = cloud115StrmRepository,
            recordRepository = cloudStrmRecordRepository,
            settingsRepository = settingsRepository,
            movieRepository = movieRepository,
            scrapeRepository = strmScrapeRepository,
            videoAddProcessor = cloudVideoAddProcessor,
            cloudVideoTaskRunner = cloudVideoTaskRunner
        )
    }
    val movieScrapeTaskRunner = MovieScrapeTaskRunner(
        settingsRepository = settingsRepository,
        movieRepository = movieRepository,
        scrapeRepository = strmScrapeRepository,
        cloudVideoTaskRepository = cloudVideoTaskRepository
    )

    // ★ 第九轮：播放来源自动回填（v18 迁移后仅执行一次；失败不置位，下次启动重试）
    private val sourceBackfillRunning = AtomicBoolean(false)
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun maybeRunSourceBackfillAsync() {
        if (settingsRepository.isSourceBackfillDone()) return
        if (!sourceBackfillRunning.compareAndSet(false, true)) return
        appScope.launch {
            try {
                cloudStrmRecordRepository.backfillRecordSources()
                settingsRepository.setSourceBackfillDone()
            } catch (e: Throwable) {
                // 失败不置位：下次启动重试；不抛到启动路径
            } finally {
                sourceBackfillRunning.set(false)
            }
        }
    }

    private companion object {
        /**
         * cloud_strm_records 复合索引（COLLATE NOCASE）。
         * Room 的 @Index 注解不支持 COLLATE，因此在此处经 onOpen 回调幂等创建。
         * 用于加速 DAO 中 `ORDER BY ... COLLATE NOCASE` 查询（getByMovieNumber / getByMovieId / getPlaybackRecords）。
         * 命名带 _nocase 后缀以区别于 Room 生成的 BINARY 索引。
         * ⚠️ 若日后升级 DB schema，请将此处 DDL 一并迁入正式 Migration。
         */
        private const val SQL_STRM_RECORDS_MOVIE_NUMBER_NOCASE_INDEX =
            "CREATE INDEX IF NOT EXISTS index_cloud_strm_records_movieNumber_partLabel_variant_fileName_nocase " +
                "ON cloud_strm_records (" +
                "movieNumber COLLATE NOCASE, " +
                "partLabel COLLATE NOCASE, " +
                "variant COLLATE NOCASE, " +
                "fileName COLLATE NOCASE" +
                ")"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE movies ADD COLUMN mpaa TEXT")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE movies ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE movies ADD COLUMN isWatched INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE movies ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `direct_links` (
                        `pickcode` TEXT NOT NULL, 
                        `url` TEXT NOT NULL, 
                        `expiresAt` INTEGER NOT NULL, 
                        `updatedAt` INTEGER NOT NULL, 
                        PRIMARY KEY(`pickcode`)
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `playback_progress` (
                        `mediaKey` TEXT NOT NULL,
                        `positionMs` INTEGER NOT NULL,
                        `durationMs` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`mediaKey`)
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE movies ADD COLUMN series TEXT")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cloud_strm_records` (
                        `pickcode` TEXT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `movieNumber` TEXT,
                        `variant` TEXT,
                        `partLabel` TEXT,
                        `strmUri` TEXT NOT NULL,
                        `libraryRootUri` TEXT,
                        `movieId` INTEGER,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`pickcode`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_strm_records_movieNumber` ON `cloud_strm_records` (`movieNumber`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_strm_records_libraryRootUri` ON `cloud_strm_records` (`libraryRootUri`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_strm_records_movieId` ON `cloud_strm_records` (`movieId`)")
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `domestic_movies` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `folderCid` INTEGER NOT NULL,
                        `folderName` TEXT NOT NULL,
                        `videoName` TEXT NOT NULL,
                        `videoPickcode` TEXT NOT NULL,
                        `imageName` TEXT,
                        `imagePickcode` TEXT,
                        `imageUrl` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_domestic_movies_folderCid` ON `domestic_movies` (`folderCid`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_domestic_movies_videoPickcode` ON `domestic_movies` (`videoPickcode`)")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `domestic_video_sources` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `folderCid` INTEGER NOT NULL,
                        `videoName` TEXT NOT NULL,
                        `videoPickcode` TEXT NOT NULL,
                        `sortOrder` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_domestic_video_sources_folderCid` ON `domestic_video_sources` (`folderCid`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_domestic_video_sources_videoPickcode` ON `domestic_video_sources` (`videoPickcode`)")
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `domestic_video_sources` (
                        `folderCid`, `videoName`, `videoPickcode`, `sortOrder`, `createdAt`, `updatedAt`
                    )
                    SELECT `folderCid`, `videoName`, `videoPickcode`, 0, `createdAt`, `updatedAt`
                    FROM `domestic_movies`
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sortTitle` ON `movies` (`sortTitle`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_scannedAtMillis` ON `movies` (`scannedAtMillis`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_updatedAt` ON `movies` (`updatedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_year` ON `movies` (`year`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_isFavorite` ON `movies` (`isFavorite`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_isWatched` ON `movies` (`isWatched`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_direct_links_expiresAt` ON `direct_links` (`expiresAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_playback_progress_updatedAt` ON `playback_progress` (`updatedAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_strm_records_movieNumber_partLabel_variant_fileName` ON `cloud_strm_records` (`movieNumber`, `partLabel`, `variant`, `fileName`)")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE movies ADD COLUMN scrapeFailureReason TEXT")
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE movies ADD COLUMN scrapeTaskStatus TEXT NOT NULL DEFAULT 'None'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_scrapeTaskStatus` ON `movies` (`scrapeTaskStatus`)")
            }
        }

        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cloud_folder_batch_tasks` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `folderCid` INTEGER NOT NULL,
                        `folderName` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `currentPath` TEXT,
                        `currentFileName` TEXT,
                        `queuedVideos` INTEGER NOT NULL,
                        `processedVideos` INTEGER NOT NULL,
                        `addedVideos` INTEGER NOT NULL,
                        `scrapeFailedVideos` INTEGER NOT NULL,
                        `skippedVideos` INTEGER NOT NULL,
                        `failedVideos` INTEGER NOT NULL,
                        `failedFolders` INTEGER NOT NULL,
                        `failureMessage` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_folder_batch_tasks_status` ON `cloud_folder_batch_tasks` (`status`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_folder_batch_tasks_folderCid` ON `cloud_folder_batch_tasks` (`folderCid`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_folder_batch_tasks_updatedAt` ON `cloud_folder_batch_tasks` (`updatedAt`)")
            }
        }

        val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cloud_strm_records ADD COLUMN videoSizeBytes INTEGER")
            }
        }

        val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cloud_video_tasks` (
                        `pickcode` TEXT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `cid` INTEGER,
                        `fid` INTEGER,
                        `size` INTEGER,
                        `addedAt` INTEGER,
                        `modifiedAt` INTEGER,
                        `forceDistinct` INTEGER NOT NULL,
                        `status` TEXT NOT NULL,
                        `failureReason` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`pickcode`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_video_tasks_status` ON `cloud_video_tasks` (`status`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_video_tasks_createdAt` ON `cloud_video_tasks` (`createdAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_cloud_video_tasks_updatedAt` ON `cloud_video_tasks` (`updatedAt`)")
            }
        }

        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `guangya_direct_links` (
                        `fileId` TEXT NOT NULL,
                        `url` TEXT NOT NULL,
                        `expiresAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`fileId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_guangya_direct_links_expiresAt` ON `guangya_direct_links` (`expiresAt`)")
            }
        }

        /**
         * 16 -> 17：删除已废弃的「A目录/国产」功能相关表。
         * 旧迁移 7_8 / 8_9 仍保留（旧版本升级会按序执行建表），此处统一清理。
         */
        val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP TABLE IF EXISTS `domestic_video_sources`")
                db.execSQL("DROP TABLE IF EXISTS `domestic_movies`")
            }
        }

        /**
         * 17 -> 18：cloud_strm_records 增加 source 列（"115" / "GUANGYA"）。
         * 存量回填不在 Migration 内做（9000+ 行文件 IO 会长时间持锁），
         * 由 SourceBackfillTask 在 DB 打开后异步执行（见 CloudStrmRecordRepository.backfillRecordSources）。
         * 顺带重建 nocase 复合索引（新版 schema 已含 source 无关，仅保持 DDL 一致）。
         */
        val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cloud_strm_records ADD COLUMN source TEXT NOT NULL DEFAULT '115'")
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_cloud_strm_records_movieNumber_partLabel_variant_fileName_nocase " +
                        "ON cloud_strm_records (" +
                        "movieNumber COLLATE NOCASE, " +
                        "partLabel COLLATE NOCASE, " +
                        "variant COLLATE NOCASE, " +
                        "fileName COLLATE NOCASE" +
                        ")"
                )
            }
        }
    }
}
