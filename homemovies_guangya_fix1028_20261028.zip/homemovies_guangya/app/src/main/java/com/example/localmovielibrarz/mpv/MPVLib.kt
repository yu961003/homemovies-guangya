package com.example.localmovielibrarz.mpv

import android.content.Context
import android.util.Log
import android.view.Surface
import java.util.concurrent.CopyOnWriteArraySet

/**
 * libmpv 的 JNI 门面。
 *
 * 原生实现见 `app/src/main/cpp/src 下的 .cpp`，编译产物为 `libplayer.so`，它在内部链接
 * 预编译的 `libmpv.so`。若 jniLibs 下没有 libmpv.so，CMake 会编译 stub 版，
 * [isAvailable] 恒为 false，[MpvPlaybackEngine] 据此把引擎判定为不可用。
 *
 * 线程约定（与上游 mpv-android 一致）：
 * - [create]/[init]/[destroy] 必须在同一个线程上成对调用（本项目固定在主线程）；
 * - [command]/[setProperty*]/[getProperty*] 可在任意线程调用，libmpv 内部会串行化；
 * - 回调 [event]/[eventProperty]/[logMessage] 来自原生事件线程，**不是主线程**，
 *   因此所有分发都通过 [listeners] 交给上层自行切线程。
 */
object MPVLib {

    private const val TAG = "MPVLib"

    // ---- mpv_format 常量（与 client.h 对齐）----
    const val MPV_FORMAT_NONE = 0
    const val MPV_FORMAT_STRING = 1
    const val MPV_FORMAT_OSD_STRING = 2
    const val MPV_FORMAT_FLAG = 3
    const val MPV_FORMAT_INT64 = 4
    const val MPV_FORMAT_DOUBLE = 5
    const val MPV_FORMAT_NODE = 6

    // ---- mpv_event_id 常用值（与 client.h 对齐）----
    const val MPV_EVENT_NONE = 0
    const val MPV_EVENT_SHUTDOWN = 1
    const val MPV_EVENT_LOG_MESSAGE = 2
    const val MPV_EVENT_END_FILE = 7
    const val MPV_EVENT_FILE_LOADED = 8
    const val MPV_EVENT_PLAYBACK_RESTART = 21
    const val MPV_EVENT_PROPERTY_CHANGE = 22

    // ---- mpv_end_file_reason ----
    const val MPV_END_FILE_REASON_EOF = 0
    const val MPV_END_FILE_REASON_STOP = 2

    @Volatile
    private var libraryLoaded = false

    @Volatile
    private var loadError: String? = null

    val listeners = CopyOnWriteArraySet<Listener>()

    /** libplayer.so 是否加载成功（与 libmpv 是否存在无关，后者看 [isAvailable]）。 */
    val isLibraryLoaded: Boolean get() = libraryLoaded

    private fun ensureLoaded(): Boolean {
        if (libraryLoaded) return true
        if (loadError != null) return false
        synchronized(this) {
            if (libraryLoaded) return true
            if (loadError != null) return false
            return try {
                System.loadLibrary("player")
                libraryLoaded = true
                Log.i(TAG, "libplayer.so 加载成功，libmpv 可用=${isAvailable()}")
                true
            } catch (t: Throwable) {
                loadError = t.message
                Log.e(TAG, "libplayer.so 加载失败，mpv 引擎不可用", t)
                false
            }
        }
    }

    /**
     * 探测 mpv 引擎是否可用：库能加载 + 原生侧报告 libmpv 已链接。
     * 任何一步失败都返回 false，绝不让异常冒到调用方。
     */
    fun probe(): Boolean {
        if (!ensureLoaded()) return false
        return try {
            isAvailable()
        } catch (t: Throwable) {
            Log.e(TAG, "isAvailable 调用失败", t)
            false
        }
    }

    fun loadErrorMessage(): String? = loadError ?: runCatching { lastError() }.getOrNull()

    // ---- native 声明（签名必须与 cpp/src 下的 .cpp 完全一致）----
    @JvmStatic private external fun isAvailable(): Boolean
    @JvmStatic private external fun isHwdecBridgeAvailable(): Boolean
    @JvmStatic private external fun lastError(): String?
    @JvmStatic private external fun create(appContext: Context?): Int
    @JvmStatic private external fun init(): Int
    @JvmStatic private external fun destroy()
    @JvmStatic private external fun command(args: Array<String>): Unit
    @JvmStatic private external fun attachSurface(surface: Surface): Int
    @JvmStatic private external fun detachSurface(): Int
    @JvmStatic private external fun setSurfaceSize(width: Int, height: Int): Int
    @JvmStatic private external fun setOptionString(option: String, value: String): Int
    @JvmStatic private external fun getPropertyInt(property: String): Int?
    @JvmStatic private external fun setPropertyInt(property: String, value: Int)
    @JvmStatic private external fun getPropertyDouble(property: String): Double?
    @JvmStatic private external fun setPropertyDouble(property: String, value: Double)
    @JvmStatic private external fun getPropertyBoolean(property: String): Boolean?
    @JvmStatic private external fun setPropertyBoolean(property: String, value: Boolean)
    @JvmStatic private external fun getPropertyString(property: String): String?
    @JvmStatic private external fun setPropertyString(property: String, value: String)
    @JvmStatic private external fun observeProperty(property: String, format: Int)
    @JvmStatic private external fun unobserveProperty(property: String)

    // ---- 供 Kotlin 侧使用的安全包装（库未加载时一律降级为空操作）----

    fun isHwdecBridgeReady(): Boolean =
        ensureLoaded() && runCatching { isHwdecBridgeAvailable() }.getOrDefault(false)

    fun createEngine(context: Context): Int {
        if (!ensureLoaded()) return ERR_NOT_LOADED
        return runCatching { create(context.applicationContext) }
            .getOrElse { t ->
                Log.e(TAG, "create 抛出异常", t)
                ERR_NOT_LOADED
            }
    }

    fun initialize(): Int {
        if (!ensureLoaded()) return ERR_NOT_LOADED
        return runCatching { init() }.getOrElse { ERR_NOT_LOADED }
    }

    fun destroyEngine() {
        if (!ensureLoaded()) return
        runCatching { destroy() }.onFailure { Log.e(TAG, "destroy 失败", it) }
    }

    fun cmd(vararg args: String) {
        if (!ensureLoaded() || args.isEmpty()) return
        runCatching { command(arrayOf(*args)) }
            .onFailure { Log.e(TAG, "command(${args.joinToString(" ")}) 失败", it) }
    }

    fun attachSurfaceSafe(surface: Surface): Int {
        if (!ensureLoaded()) return ERR_NOT_LOADED
        return runCatching { attachSurface(surface) }.getOrDefault(ERR_NOT_LOADED)
    }

    fun detachSurfaceSafe(): Int {
        if (!ensureLoaded()) return 0
        return runCatching { detachSurface() }.getOrDefault(ERR_NOT_LOADED)
    }

    fun setSurfaceSizeSafe(width: Int, height: Int) {
        if (!ensureLoaded() || width <= 0 || height <= 0) return
        runCatching { setSurfaceSize(width, height) }
    }

    fun setOption(name: String, value: String): Int {
        if (!ensureLoaded()) return ERR_NOT_LOADED
        return runCatching { setOptionString(name, value) }.getOrDefault(ERR_NOT_LOADED)
    }

    fun observe(property: String, format: Int) {
        if (!ensureLoaded()) return
        runCatching { observeProperty(property, format) }
    }

    fun unobserve(property: String) {
        if (!ensureLoaded()) return
        runCatching { unobserveProperty(property) }
    }

    fun getInt(property: String): Int? =
        if (!ensureLoaded()) null else runCatching { getPropertyInt(property) }.getOrNull()

    fun getDouble(property: String): Double? =
        if (!ensureLoaded()) null else runCatching { getPropertyDouble(property) }.getOrNull()

    fun getBoolean(property: String): Boolean? =
        if (!ensureLoaded()) null else runCatching { getPropertyBoolean(property) }.getOrNull()

    fun getString(property: String): String? =
        if (!ensureLoaded()) null else runCatching { getPropertyString(property) }.getOrNull()

    fun setInt(property: String, value: Int) {
        if (!ensureLoaded()) return
        runCatching { setPropertyInt(property, value) }
    }

    fun setDouble(property: String, value: Double) {
        if (!ensureLoaded()) return
        runCatching { setPropertyDouble(property, value) }
    }

    fun setBoolean(property: String, value: Boolean) {
        if (!ensureLoaded()) return
        runCatching { setPropertyBoolean(property, value) }
    }

    fun setString(property: String, value: String) {
        if (!ensureLoaded()) return
        runCatching { setPropertyString(property, value) }
    }

    const val ERR_NOT_LOADED = -1000

    // ---- 原生 → Java 的回调入口（名字/签名由 jni_utils.cpp 缓存）----

    @JvmStatic
    fun event(eventId: Int) {
        listeners.forEach { it.onEvent(eventId) }
    }

    @JvmStatic
    fun eventEndFile(reason: Int, error: Int) {
        listeners.forEach { it.onEndFile(reason, error) }
    }

    @JvmStatic
    fun eventProperty(property: String) {
        listeners.forEach { it.onProperty(property, null) }
    }

    @JvmStatic
    fun eventProperty(property: String, value: Boolean) {
        listeners.forEach { it.onProperty(property, value) }
    }

    @JvmStatic
    fun eventProperty(property: String, value: Long) {
        listeners.forEach { it.onProperty(property, value) }
    }

    @JvmStatic
    fun eventProperty(property: String, value: Double) {
        listeners.forEach { it.onProperty(property, value) }
    }

    @JvmStatic
    fun eventProperty(property: String, value: String) {
        listeners.forEach { it.onProperty(property, value) }
    }

    @JvmStatic
    fun logMessage(prefix: String, level: Int, text: String) {
        // log_level 越小越严重；mpv 的 error=error/warn/warn/info=v/info 等，这里只转发 warn 及以上。
        if (level >= 30) return
        Log.println(
            when {
                level <= 10 -> Log.ERROR
                level <= 20 -> Log.WARN
                else -> Log.INFO
            },
            TAG,
            "[$prefix] ${text.trimEnd()}"
        )
    }

    /** 回调接口。**全部方法都在原生事件线程上调用**，实现方负责切回自己的调度器。 */
    interface Listener {
        fun onEvent(eventId: Int)
        fun onEndFile(reason: Int, error: Int) {}
        fun onProperty(name: String, value: Any?)
    }
}
