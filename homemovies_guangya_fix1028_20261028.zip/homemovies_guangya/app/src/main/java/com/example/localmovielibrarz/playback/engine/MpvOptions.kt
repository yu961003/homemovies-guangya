package com.example.localmovielibrarz.playback.engine

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.localmovielibrarz.mpv.MPVLib
import java.io.File

/**
 * libmpv 的启动参数。
 *
 * 设计原则：**凡是 exo 侧已有的行为，这里都要有对应项**，否则「功能对齐」就是空话。
 * 每一项都写明它与 exo 的哪条行为对应，方便逐条核对（见交付文档的对齐表）。
 */
object MpvOptions {

    private const val TAG = "MpvOptions"

    /**
     * 生成 mpv 配置。
     *
     * @param hwdec 由 [decideHwdec] 决定；硬解确实不可用时回落软解而不是黑屏。
     * @param cacheDir mpv 的 `--cache-dir`，用于在线字幕/网络流缓存（与 exo 的 LoadControl 对位）。
     */
    fun build(context: Context, hwdec: String, cacheDir: File): List<Pair<String, String>> = buildList {
        // ── 渲染 ───────────────────────────────────────────────────────────────
        // exo: PlayerView 默认 SurfaceView 输出。mpv 对应 vo=gpu + android context。
        add("vo" to "gpu")
        add("gpu-context" to "android")
        // 硬件解码：exo 侧是 DefaultRenderersFactory 硬解优先 + 解码器回退（EXTENSION_RENDERER_MODE_PREFER）。
        // mpv 对应 hwdec=mediacodec（copy 模式兼容性最好），软解作为内部回退。
        add("hwdec" to hwdec)
        // exo: setVideoChangeFrameRateStrategy(OFF). mpv 侧关闭自动帧率切换以保持一致。
        add("video-sync" to "audio")
        // π 校准对齐：exo 用 CLOSEST_SYNC 近似 seek，mpv 对应 hr-seek=no（关键帧 seek，快）
        add("hr-seek" to "no")

        // ── 音频 ───────────────────────────────────────────────────────────────
        // exo: AudioAttributes USAGE_MEDIA / CONTENT_TYPE_MOVIE / ALLOW_CAPTURE_BY_ALL
        add("ao" to "audiotrack")
        add("audio-channels" to "auto-safe")

        // ── 网络 ───────────────────────────────────────────────────────────────
        // exo: DefaultHttpDataSource + allowCrossProtocolRedirects(true)
        add("network-timeout" to "30")
        add("stream-lavf-o" to "reconnect=1,reconnect_streamed=1,reconnect_delay_max=5")
        // exo: DefaultHttpDataSource 的 user agent；具体值在 load() 时按请求覆盖
        add("user-agent" to "Mozilla/5.0 (Linux; Android ${Build.VERSION.RELEASE}) Homemovies/MPV")

        // ── 缓存 ───────────────────────────────────────────────────────────────
        // exo: DefaultLoadControl(min 15s / max 60s / 1.5s / 3s)
        add("cache" to "yes")
        add("cache-dir" to cacheDir.absolutePath)
        add("cache-secs" to "60")
        add("demuxer-max-bytes" to "64MiB")
        add("demuxer-max-back-bytes" to "16MiB")

        // ── 字幕 ───────────────────────────────────────────────────────────────
        // exo: 外挂字幕由应用手动挂载（subtitleFeaturesEnabled 开关控制），内嵌字幕自动选。
        // mpv 对应 sub-auto=fuzzy（同目录同名自动加载）+ 手动 sub-add。
        add("sub-auto" to "fuzzy")
        add("sub-visibility" to "yes")
        // 字体：优先系统字体，找不到时回落 sans-serif，避免 ASS 字幕方块字
        add("sub-font" to "sans-serif")
        add("sub-font-provider" to "auto")
        // exo: CaptionStyleCompat 白字 + 黑描边 + 半透明底
        add("sub-color" to "#FFFFFFFF")
        add("sub-border-color" to "#FF000000")
        add("sub-back-color" to "#99000000")
        add("sub-border-size" to "2.0")
        add("sub-shadow-offset" to "0")

        // ── 其它 ───────────────────────────────────────────────────────────────
        // exo: 无 OSD；mpv 默认会在画面上烧字，必须关掉，UI 全部由 Compose 负责
        add("osd-level" to "0")
        // 输入：不接管按键（UI 层已有手势与按钮）
        add("input-default-bindings" to "no")
        add("input-vo-keyboard" to "no")
        add("osc" to "no")
        // 保持画面比例，由外层按 resizeMode 决定裁剪（FIT/FILL/ZOOM）
        add("keepaspect" to "yes")
        add("video-unscaled" to "no")
        // 日志量：info 级足够定位问题，all 会刷屏拖慢事件线程
        add("msg-level" to "all=info")
        // 结束行为：不自动播放下一个（exo 侧也是单条 mediaItem）
        add("idle" to "yes")
    }

    /**
     * 决定 hwdec 取值。
     *
     * 硬解依赖 FFmpeg 的 JNI 桥接（`av_jni_set_java_vm`），桥接失败时 mediacodec
     * 会初始化失败并导致黑屏。因此这里分三档：
     * 1. 桥接可用 → `mediacodec`（硬解，copy 回读，兼容性最好）
     * 2. 桥接不可用 → `no`（纯软解，画面正常但 CPU 高）
     * 3. 用户显式要求软解 → `no`
     */
    fun decideHwdec(preferHardware: Boolean): String {
        if (!preferHardware) return "no"
        val bridgeReady = MPVLib.isHwdecBridgeReady()
        if (!bridgeReady) {
            Log.w(TAG, "FFmpeg JNI 桥接不可用，mpv 使用软解（hwdec=no）")
            return "no"
        }
        return "mediacodec"
    }
}
