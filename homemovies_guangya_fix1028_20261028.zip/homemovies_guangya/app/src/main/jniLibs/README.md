# jniLibs：libmpv 预编译产物放置位置

本目录**刻意不携带任何二进制**（体积、许可、ABI 组合问题）。`libmpv.so` 及其兄弟库需要
自行产出后放进来，三个 ABI 目录已建好：

```
app/src/main/jniLibs/
├── arm64-v8a/       ← 主发行 ABI
├── armeabi-v7a/     ← 老设备
└── x86_64/          ← 模拟器
```

## 每个 ABI 目录里要放什么

**不是只放 `libmpv.so` 一个文件。** `libmpv.so` 通过 `DT_NEEDED` 依赖一整串兄弟库，
缺任何一个都会在 `dlopen` 阶段失败（表现为「未检测到 libmpv.so」而不是「解码失败」）：

```
libmpv.so
libavcodec.so  libavformat.so  libavutil.so  libswresample.so  libswscale.so
libavfilter.so libavdevice.so
libass.so      libfreetype.so  libharfbuzz.so  libfribidi.so
libplacebo.so  libluajit-5.1.so  libcurl.so
```

实测 `arm64-v8a` 整组约 40 MB（未压缩）。

## 怎么产出

### 方式 A：用本仓库脚本（Linux / macOS）

```bash
# 只准备上游构建链（幂等，可重复执行）
bash scripts/fetch-libmpv.sh --clone-only

# 编 mpv 目标并把整组 .so 拷进对应 jniLibs 目录
bash scripts/fetch-libmpv.sh --build all

# 校验产物（ELF 魔数 + 机器码 + 文件大小下限）
bash scripts/fetch-libmpv.sh --verify
```

脚本会把 `buildscripts/prefix/<arch>/lib/*.so` **全部**拷进 `jniLibs/<abi>/`，不做筛选。

- **Windows 不支持**：上游 `mpv-android/buildscripts` 明确要求 POSIX 工具链。
  脚本检测到 MINGW/MSYS/CYGWIN 会直接告警并给出替代路径。

### 方式 B：用 CI（推荐，无需本地环境）

`.github/workflows/build-libmpv.yml` 手动触发（`workflow_dispatch`）：

1. 在 GitHub 上该仓库 → Actions → `build-libmpv` → Run workflow；
2. 可选参数：`archs`（默认 `arm64`）、`full_abis`（是否三个 ABI 全编）；
3. 跑完下载 artifact `libmpv-<abi>`，解压后整目录覆盖到 `app/src/main/jniLibs/<abi>/`。

单个 ABI 在 GitHub 免费 runner 上约 40–70 分钟（要交叉编译 FFmpeg 整棵树），
工作流已设 240 分钟超时与 `buildscripts/{sdk,deps,prefix}` 三目录缓存。

### 方式 C：换用自己的 Yaozhi 定制构建

若已按路线文档（`docs/` 同级的分阶段移植路线深化文档）产出定制 `libmpv.so`，
直接把同一组 `.so` 覆盖进来即可，**宿主侧无需任何改动** —— 宿主只依赖
`app/src/main/cpp/include/mpv/client.h` 里声明的 libmpv C API。

## 不放也是合法的

`libmpv.so` 缺失时 CMake 会自动改用 `src/main/cpp/src/stub.cpp` 编一个空壳
`libplayer.so`（`MPV_AVAILABLE=0`），`assembleDebug` 仍然成功。运行期
`PlaybackEngineFactory.probeMpv()` 返回「未检测到 libmpv.so」，设置页把 MPV 显示为
不可选并给出原因，播放自动走 ExoPlayer。**这是设计内的降级路径，不是构建失败。**

## 注意

- 三种 ABI 不必都放。只放 `arm64-v8a` 也能构建，只是 32 位设备上 mpv 不可用。
- 文件名必须严格是 `libmpv.so`（CMakeLists 里按这个字面量查找）。
- 打包进 APK 时不需要额外配置 `jniLibs.srcDirs`，AGP 默认就认 `src/main/jniLibs/`。
- 各 `.so` 之间不要混用不同 STL/不同 NDK 版本构建的产物，会撞符号。
