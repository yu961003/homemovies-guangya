plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

val purgeStaleRoomGeneratedSources by tasks.registering(Delete::class) {
    delete(
        layout.buildDirectory.dir("generated/ksp/debug/java/com/example/localmovielibrarz/data/local"),
        layout.buildDirectory.dir("kspCaches/debug/backups/java/byRounds")
    )
}

android {
    namespace = "com.example.localmovielibrarz"
    compileSdk = 35

    // libmpv JNI 封装层（app/src/main/cpp）用 NDK 编译成 libplayer.so。
    // 显式 pin NDK 版本：不写的话 AGP 会取自身默认版本，CI 与本机可能不一致。
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.example.localmovielibrarz"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "3.2"

        // CMakeLists 只编 JNI 封装层；libmpv.so 本身是外部预编译产物，
        // 由 scripts/fetch-libmpv.sh（或 CI artifact）放进 jniLibs/<abi>/。
        // 找不到 libmpv.so 时 CMake 退化为 stub 版 libplayer.so，
        // 运行期 MpvPlaybackEngine 判定不可用并回退 ExoPlayer——所以这里不需要
        // 条件开关，两种情况都必须能 assemble 成功。
        externalNativeBuild {
            cmake {
                // 用静态 STL：封装层是纯 JNI C 风格代码（CMakeLists 里已 -fno-exceptions
                // -fno-rtti），静态链接可以少打包一个 libc++_shared.so，也不会和
                // libmpv.so 自带的 C++ 运行时在同一个进程里撞符号。
                arguments += listOf(
                    "-DANDROID_STL=c++_static",
                    // 16 KB 页对齐（Android 15 / API 35 起 64 位设备强制要求）。
                    // NDK r27 默认仍按 4 KB 对齐；r28+ 才默认 ON。本项目 pin 的是
                    // r27，必须显式打开，否则 libplayer.so 会在 Play Console 与
                    // 「应用兼容性」检查里被标为未对齐。等价于给链接器加
                    // -Wl,-z,max-page-size=16384，CMakeLists 里也兜了一层。
                    "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON",
                    // 关掉 CMake 的「构建前自动重跑 configure」规则。
                    //
                    // 不加这个，ninja 会在每次构建时重跑 cmake 重新生成 build.ninja，
                    // 跑完再 stat 一次发现 build.ninja 仍然「新不过」它的输入，于是
                    // 重来——循环 100 次后报：
                    //   ninja: error: manifest 'build.ninja' still dirty after 100 tries
                    // 症状就是 CMakeLists 里的 message() 被反复刷屏（每个 ABI 每轮一次，
                    // 4 个 ABI × 100 轮），看起来像 mpv 配置错了，其实只是 configure 在跑圈。
                    //
                    // 触发条件通常是「某个 configure 输入文件的 mtime 不比自己写出的
                    // build.ninja 旧」——CI 从缓存恢复 .cxx / build 目录时最典型
                    // （actions/cache 按 tar 还原，可能带回旧 mtime + 时钟偏差）。
                    // 与其逐个排查哪个输入 dirty，不如直接不生成这条规则：
                    // build.ninja 只在 .cxx 为空时由 AGP 生成一次，此后不再自检。
                    //
                    // 代价很小：AGP 自己有一层任务级增量判断（configureCMakeDebug[abi]
                    // 把 CMakeLists.txt、*.cmake、ndk 工具链文件都声明成了输入），
                    // 所以改 native 代码仍然会正常重新 configure。这里去掉的只是
                    // ninja 自己那条多余的自检——两套机制检查同一件事，后者出错时
                    // 会直接把构建带死。
                    "-DCMAKE_SUPPRESS_REGENERATION=ON",
                )
                cppFlags += listOf("-std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        compose = true
    }

    // 16 KB 页对齐的第 2 层：APK 里 .so 的存储方式。
    //
    // 16 KB 要求是两件事，缺一不可：
    //   1) ELF 段对齐  —— 编译期，每个 PT_LOAD 的 p_align >= 0x4000
    //                     （NDK r28+ 默认；r27 靠 ANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON）
    //   2) zip 偏移对齐 —— 打包期，未压缩的 .so 在 APK 内的起始偏移能被 16384 整除
    //
    // useLegacyPackaging 控制第 2 层走哪条路：
    //   true  → .so 被压缩存进 APK，安装时解压到磁盘。运行没问题，但 Play Console
    //           的 16 KB 检查看的是 APK 内偏移，压缩条目一律判不合格。
    //   false → .so 不压缩存储，AGP 8.5.1+ 会用 -P 16 做偏移对齐，两层都满足。
    //
    // minSdk = 26 时 AGP 默认已是 false，这里显式写死是为了防止后续有人调 minSdk
    // 或加 useLegacyPackaging 时无声退化——一旦退化，构建期不会报任何错，
    // 只有上传 Play Console 才会被打回。
    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Kotlin 2.3 已移除 kotlinOptions.jvmTarget，改用 compilerOptions DSL。
    // 用全限定名避免 JvmTarget 在 .kts 顶级作用域未解析的问题。
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }
}

// 导出 Room schema（5.6 优化）：追踪数据库 schema 变更历史，便于生成迁移测试
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

tasks.matching { task ->
    task.name in setOf("kspDebugKotlin", "compileDebugKotlin")
}.configureEach {
    dependsOn(purgeStaleRoomGeneratedSources)
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.05.00") // 跟随 Kotlin 2.3 的 Compose 编译器版本
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06") // 光鸭令牌加密存储 (P1-2)
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // 16 KB 页对齐：显式钉死 graphics-path 到首个 16 KB 对齐的版本。
    //
    // 这个 AAR 里带 libandroidx.graphics.path.so，是 APK 中除 libplayer.so 之外
    // 唯一的原生库。实测（dl.google.com 上的 AAR 解包读 PT_LOAD）：
    //   1.0.0-alpha01 / alpha02 / beta01 / beta02 → p_align = 0x1000（4 KB，不合格）
    //   1.0.0-rc01 起                            → p_align = 0x4000（16 KB，合格）
    //
    // 正常情况下 compose-bom 2026.05.00 → ui-graphics 1.11.1 已经请求 1.0.1，
    // 不会真解析到 alpha 版。写死是为了让「版本被别的依赖悄悄降到 alpha」这件事
    // 直接变编译期事实——否则它会以 Play Console 打回的形式在发版时才暴露。
    implementation("androidx.graphics:graphics-path:1.0.1")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.zxing:core:3.5.3") // 需求 11：光鸭扫码登录二维码渲染

    implementation("androidx.media3:media3-exoplayer:1.9.1")
    implementation("androidx.media3:media3-ui:1.9.1")
    // 双核心 v5：移除 nextlib-media3ext（minCompileSdk 冲突 / 维护成本高），
    // Exo 软解短板改由 mpv 核心兜底（§5.4）。ExoPlayer 回归原生解码 + 解码器回退。

    implementation("androidx.room:room-ktx:2.8.4") // 升 2.8.4 以兼容 Kotlin 2.3 / KSP 2.3.x（2.6.1 的 KSP 处理器跟不上）
    ksp("androidx.room:room-compiler:2.8.4")

    testImplementation("junit:junit:4.13.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
