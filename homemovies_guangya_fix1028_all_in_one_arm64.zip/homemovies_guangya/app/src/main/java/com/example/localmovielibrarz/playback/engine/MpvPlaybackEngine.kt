package com.example.localmovielibrarz.playback.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.localmovielibrarz.mpv.MPVLib
import com.example.localmovielibrarz.playback.lut.LutFileWriter
import com.example.localmovielibrarz.playback.lut.LutSettings
import com.example.localmovielibrarz.playback.lut.LutSkinAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.ArrayDeque
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

/**
 * mpv 引擎实现。
 *
 * 设计要点：
 * 1. **生命周期全部落在主线程**：`create`/`init`/`destroy` 与 mpv 的 JNI 约定绑定线程，
 *    这里用 [mainHandler] 保证串行；原生事件回调则在 [MPVLib.Listener] 里切回主线程。
 * 2. **状态单向流动**：mpv 属性 → [MutableStateFlow]<[PlaybackSnapshot]>，UI 只读 Flow，
 *    不直接查询 mpv，避免「UI 线程阻塞在 JNI 上」。
 * 3. **一切失败都降级成错误文案**：不抛异常、不黑屏。出错时调用方可以据此切回 Exo。
 */
class MpvPlaybackEngine(
    private val context: Context,
    private val cacheDir: File,
    private val preferHardwareDecode: Boolean = true
) : PlaybackEngine {

    override val kind: PlaybackEngineKind = PlaybackEngineKind.MPV

    private val mainHandler = Handler(Looper.getMainLooper())
    private val _snapshot = MutableStateFlow(PlaybackSnapshot())
    override val snapshot: StateFlow<PlaybackSnapshot> by lazy { _snapshot.asStateFlow() }

    /** PlaybackEngine 接口要求非挂起读取，这里给 UI 侧一个直接读取的快照。 */
    val current: PlaybackSnapshot get() = _snapshot.value

    @Volatile
    private var created = false

    @Volatile
    private var released = false

    private val fileLoaded = AtomicBoolean(false)

    private var currentUri: String? = null
    private var currentHeaders: Map<String, String> = emptyMap()

    private var pendingSeekMs: Long? = null
    private var pendingSubtitle: Pair<ExternalSubtitle, Long>? = null
    private var pendingSubtitleStyle: SubtitleStyle? = null
    private var subtitleOffsetMs: Long = 0L
    private var activeSubtitlePath: String? = null

    /**
     * 最近交给 mpv 的媒体来源。`content://` 走 `/proc/self/fd/<fd>` 时，
     * fd 必须撑到 mpv 自己完成 open 为止（mpv 用 open() 在进程内再复制一份，
     * 之后才与我们无关）。保留最近 2 个足够覆盖「replace 装载 + 上一次还在收尾」。
     */
    private val mediaSources = ArrayDeque<MpvMediaSource>()

    /** 解析媒体 URL 的线程：`content://` 可能要落盘，绝不能堵主线程。 */
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "mpv-media-resolve").apply { isDaemon = true }
    }

    /** 装载代次：快速连点两次时只让最后一次的结果生效。 */
    private val loadGeneration = AtomicInteger(0)

    /** 最近一次真正下发给 mpv 的 URL，仅用于错误文案与日志。 */
    @Volatile
    private var lastLoadUrl: String? = null

    @Volatile
    private var lastLoadScheme: String? = null

    /** 事件监听：所有回调都从原生事件线程来，统一切到主线程再处理。 */
    private val mpvListener = object : MPVLib.Listener {
        override fun onEvent(eventId: Int) {
            mainHandler.post { handleEvent(eventId) }
        }

        override fun onEndFile(reason: Int, error: Int) {
            mainHandler.post { handleEndFile(reason, error) }
        }

        override fun onProperty(name: String, value: Any?) {
            mainHandler.post { handleProperty(name, value) }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 生命周期
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * 创建并初始化 mpv 实例。必须在主线程调用。
     * @return null 表示成功，否则返回面向用户的错误文案。
     */
    fun initialize(): String? {
        if (released) return "mpv 引擎已释放"
        if (created) return null

        val hwdec = MpvOptions.decideHwdec(preferHardwareDecode)
        cacheDir.mkdirs()

        val createRet = MPVLib.createEngine(context)
        if (createRet != 0) {
            return "mpv 创建失败（code=$createRet）：${MPVLib.loadErrorMessage().orEmpty()}"
        }

        // 所有 --option 必须在 mpv_initialize() 之前设置，否则被静默忽略。
        MpvOptions.build(context, hwdec, cacheDir).forEach { (key, value) ->
            val ret = MPVLib.setOption(key, value)
            if (ret < 0) Log.w(TAG, "设置 mpv 选项 $key=$value 失败: $ret")
        }

        val initRet = MPVLib.initialize()
        if (initRet != 0) {
            MPVLib.destroyEngine()
            return "mpv 初始化失败（code=$initRet）：${MPVLib.loadErrorMessage().orEmpty()}"
        }

        MPVLib.listeners.add(mpvListener)
        observeProperties()
        created = true
        Log.i(TAG, "mpv 引擎就绪，hwdec=$hwdec")
        return null
    }

    private fun observeProperties() {
        // 与 PlaybackSnapshot 字段一一对应。用 DOUBLE 取时间属性（秒），避免 INT64
        // 在时间类属性上的单位歧义（microseconds），换算成毫秒只做一次。
        MPVLib.observe("time-pos", MPVLib.MPV_FORMAT_DOUBLE)
        MPVLib.observe("duration", MPVLib.MPV_FORMAT_DOUBLE)
        MPVLib.observe("pause", MPVLib.MPV_FORMAT_FLAG)
        MPVLib.observe("paused-for-cache", MPVLib.MPV_FORMAT_FLAG)
        MPVLib.observe("speed", MPVLib.MPV_FORMAT_DOUBLE)
        MPVLib.observe("eof-reached", MPVLib.MPV_FORMAT_FLAG)
        MPVLib.observe("width", MPVLib.MPV_FORMAT_INT64)
        MPVLib.observe("height", MPVLib.MPV_FORMAT_INT64)
        MPVLib.observe("track-list", MPVLib.MPV_FORMAT_NONE)
        MPVLib.observe("demuxer-cache-time", MPVLib.MPV_FORMAT_DOUBLE)
    }

    override fun release() {
        if (released) return
        released = true
        // 先停 LUT 线程：它跑完最后一步时还会 post 回主线程，那里有 released 检查兜底。
        lutExecutor.shutdownNow()
        ioExecutor.shutdownNow()
        synchronized(mediaSources) {
            while (mediaSources.isNotEmpty()) runCatching { mediaSources.removeFirst().close() }
        }
        mainHandler.post {
            MPVLib.listeners.remove(mpvListener)
            if (created) {
                MPVLib.destroyEngine()
                created = false
            }
            _snapshot.value = PlaybackSnapshot(playbackState = PlaybackSnapshot.STATE_IDLE)
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 装载与播放控制
    // ─────────────────────────────────────────────────────────────────────────

    override fun load(
        uri: String,
        headers: Map<String, String>,
        startPositionMs: Long,
        autoPlay: Boolean
    ) {
        if (released) return
        currentUri = uri
        currentHeaders = headers
        pendingSeekMs = startPositionMs.takeIf { it > 0L }
        fileLoaded.set(false)

        val generation = loadGeneration.incrementAndGet()
        // content:// 要取 fd（或落盘）才能交给 mpv，这一步可能在 IO 上耗时，
        // 绝不能放主线程；解析完再回主线程发 loadfile，保持原来的线程约定。
        ioExecutor.execute {
            val source = runCatching { MpvMediaSources.resolve(context, uri, cacheDir) }
                .onFailure { Log.e(TAG, "解析媒体 URL 失败：$uri", it) }
                .getOrNull()
            mainHandler.post { startLoad(generation, source, uri, headers, autoPlay) }
        }
    }

    /**
     * 真正下发 `loadfile`。
     *
     * @param source 归一化后的媒体来源；null 表示解析异常，退化为原 URI。
     */
    private fun startLoad(
        generation: Int,
        source: MpvMediaSource?,
        rawUri: String,
        headers: Map<String, String>,
        autoPlay: Boolean
    ) {
        // 快速连点/切集时旧任务可能晚到，代次对不上就丢弃。
        if (released || generation != loadGeneration.get()) return
        if (!created) {
            Log.w(TAG, "load() 时引擎未就绪，丢弃本次装载")
            return
        }

        val url = source?.url ?: rawUri
        lastLoadUrl = url
        lastLoadScheme = source?.scheme
        Log.i(TAG, "loadfile url=$url 原始 scheme=${source?.scheme ?: Uri.parse(rawUri).scheme}")

        // 请求头：exo 侧是 DefaultHttpDataSource.setDefaultRequestProperties；
        // mpv 对应 per-file 属性 http-header-fields（"Key: value,Key2: value2"）。
        applyHeaders(headers)

        MPVLib.cmd("set", "pause", if (autoPlay) "no" else "yes")
        MPVLib.cmd("loadfile", url, "replace")

        // 新的已经下发，旧的才有资格关：content:// 的 fd 要撑到 mpv 自己 open 完。
        if (source != null) retainSource(source)

        updateSnapshot { it.copy(playWhenReady = autoPlay, errorMessage = null) }
    }

    private fun retainSource(source: MpvMediaSource) {
        synchronized(mediaSources) {
            mediaSources.addLast(source)
            while (mediaSources.size > 2) {
                runCatching { mediaSources.removeFirst().close() }
            }
        }
    }

    private fun applyHeaders(headers: Map<String, String>) {
        if (headers.isEmpty()) {
            MPVLib.setString("http-header-fields", "")
            return
        }
        val userAgent = headers.entries
            .firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }
            ?.value
        if (!userAgent.isNullOrBlank()) {
            MPVLib.setString("user-agent", userAgent)
        }
        val fields = headers
            .filterKeys { !it.equals("User-Agent", ignoreCase = true) }
            .entries
            .joinToString(",") { "${it.key}: ${it.value}" }
        MPVLib.setString("http-header-fields", fields)
    }

    override fun play() = setPlayWhenReady(true)

    override fun pause() = setPlayWhenReady(false)

    override fun setPlayWhenReady(playWhenReady: Boolean) {
        if (released) return
        MPVLib.setBoolean("pause", !playWhenReady)
        updateSnapshot { it.copy(playWhenReady = playWhenReady) }
    }

    override fun seekTo(positionMs: Long) {
        if (released) return
        val seconds = (positionMs.coerceAtLeast(0L) / 1000.0)
        // hr-seek=no 时 "absolute" 即关键帧 seek，对应 exo 的 SeekParameters.CLOSEST_SYNC：
        // 只定位到最近关键帧，避免精确 seek 触发长回溯导致的卡顿。
        MPVLib.cmd("seek", String.format(java.util.Locale.US, "%.3f", seconds), "absolute")
        updateSnapshot { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    override fun seekBy(deltaMs: Long) {
        seekTo(maxOf(0L, current.positionMs + deltaMs))
    }

    override fun setSpeed(speed: Float): Float {
        if (released) return current.speed
        val clamped = speed.coerceIn(0.25f, 4f)
        MPVLib.setDouble("speed", clamped.toDouble())
        updateSnapshot { it.copy(speed = clamped) }
        return clamped
    }

    override fun selectAudioTrack(trackId: Int?) {
        if (released) return
        // mpv: aid=no 交还自动选择；exo 侧对应 clearOverridesOfType(TRACK_TYPE_AUDIO)。
        if (trackId == null) {
            MPVLib.cmd("set", "aid", "auto")
        } else {
            MPVLib.cmd("set", "aid", trackId.toString())
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 字幕
    // ─────────────────────────────────────────────────────────────────────────

    override fun setExternalSubtitle(subtitle: ExternalSubtitle, offsetMs: Long) {
        if (released) return
        subtitleOffsetMs = offsetMs
        if (!fileLoaded.get()) {
            // 媒体还没进入 file-loaded，先记住，等 FILE_LOADED 再挂（mpv 在无文件时 sub-add 会失败）
            pendingSubtitle = subtitle to offsetMs
            return
        }
        applySubtitle(subtitle)
    }

    private fun applySubtitle(subtitle: ExternalSubtitle) {
        val path = MpvSubtitleBridge.materialize(context, subtitle, cacheDir)
        if (path == null) {
            Log.e(TAG, "字幕落盘失败，无法挂载：${subtitle.name}")
            updateSnapshot { it.copy(errorMessage = "字幕无法加载：${subtitle.name}") }
            return
        }

        // 多份字幕切换时先清空，避免 mpv 叠加显示（exo 侧是 setMediaItem 重建，天然替换）。
        MPVLib.cmd("sub-remove")
        MPVLib.cmd("sub-add", path, "select")
        activeSubtitlePath = path
        applySubtitleOffset()
        pendingSubtitleStyle?.let { applySubtitleStyle(it) }
        Log.i(TAG, "字幕已挂载: $path")
    }

    override fun clearExternalSubtitle() {
        if (released) return
        pendingSubtitle = null
        activeSubtitlePath = null
        MPVLib.cmd("sub-remove")
        MPVLib.setString("sub-visibility", "no")
    }

    override fun setSubtitleOffset(offsetMs: Long) {
        subtitleOffsetMs = offsetMs
        applySubtitleOffset()
    }

    private fun applySubtitleOffset() {
        // exo 侧 offset 通过 SubtitleTimeShiftStore 重写时间轴（毫秒 → 文件内容平移）。
        // mpv 侧用 sub-delay 等值表达：sub-delay 为正表示字幕延后出现，与「正偏移=字幕推后」同向。
        val seconds = subtitleOffsetMs / 1000.0
        MPVLib.setDouble("sub-delay", seconds)
    }

    override fun setSubtitleStyle(style: SubtitleStyle) {
        pendingSubtitleStyle = style
        applySubtitleStyle(style)
    }

    private fun applySubtitleStyle(style: SubtitleStyle) {
        // exo 的 CaptionStyleCompat：白字 + 黑描边 + 半透明黑底。
        // mpv 同名语义（颜色格式为 #AARRGGBB）。
        MPVLib.setDouble("sub-font-size", style.fontSizeSp.coerceIn(10, 64).toDouble())
        // exo 的 bottomPaddingPercent 是从底部留白比例；mpv 的 sub-pos 是距底部百分比（100=贴底）。
        MPVLib.setDouble("sub-pos", (100 - style.bottomPaddingPercent.coerceIn(0, 50)).toDouble())
        val alpha = (style.backgroundAlphaPercent.coerceIn(0, 100) * 255 / 100)
        MPVLib.setString("sub-back-color", String.format(java.util.Locale.US, "#%02X000000", alpha))
        MPVLib.setString("sub-color", "#FFFFFFFF")
        MPVLib.setString("sub-border-color", "#FF000000")
        MPVLib.setDouble("sub-border-size", 2.0)
    }

    override fun setSubtitleEnabled(enabled: Boolean) {
        if (released) return
        MPVLib.setString("sub-visibility", if (enabled) "yes" else "no")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 实时调色 LUT
    // ─────────────────────────────────────────────────────────────────────────

    /** LUT 文件目录：`<cacheDir>/lut/`。与字幕缓存分开，清理时互不影响。 */
    private val lutWriter by lazy { LutFileWriter(File(cacheDir, LUT_DIR_NAME)) }

    /** 上次成功下发的签名。相同就不重复写文件与 set，避免滑杆拖动时的无谓重载。 */
    @Volatile
    private var lastLutSignature: String? = null

    /**
     * 最近一次请求下发、但可能还在队列里的签名。
     *
     * 拖动滑杆时每一次参数变化都会 [applyLut]，单线程队列会把它们全部排上。
     * 没有这个字段时，队列里前面那几次「已经不新鲜的」请求仍会各自生成一张 LUT
     * 并 `set target-lut`，白算（33³ 约 20ms/次）且中间会看到几帧过时的调色。
     * 任务真正开跑时用它复查一次，发现已被更新的请求覆盖就直接让位。
     */
    @Volatile
    private var pendingLutSignature: String? = null

    /**
     * LUT 生成线程。
     *
     * 单线程而不是 `Dispatchers.Default`：拖动滑杆会产生成串的请求，单线程天然把它们
     * 排成队，配合 [lastLutSignature] 的短路，队列里只会剩最后一个真正不同的设置被执行；
     * 多线程并发写同一个缓存目录反而要额外加锁。
     *
     * 用守护线程：进程退出时不阻塞在未完成的 LUT 生成上。
     */
    private val lutExecutor: ExecutorService = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "mpv-lut").apply { isDaemon = true }
    }

    /**
     * 下发实时调色 LUT。
     *
     * 移植自参考实现 `mpv_realtime_lut.py` 的 `_generate_and_push_lut`：生成 `.cube`
     * 文件后 `set target-lut <路径>`。参考实现每次先置空再设值（`mpv.command("set",
     * "target-lut", "")` + 0.02s + 再设），这里**不做置空**——置空那一瞬间画面会闪回
     * 原色，而 mpv 的 `target-lut` 在路径变化时会自行重新加载，不存在"必须先卸载"的
     * 约束（那是参考实现对某些版本 mpv 的兼容性写法）。
     *
     * 关闭时把 `target-lut` 设为空串，mpv 即恢复片源原色。
     *
     * @param settings 完整设置快照。调用方从 `StateFlow` 取，天然是某一时刻的一致值。
     */
    fun applyLut(settings: LutSettings) {
        if (released) return
        val signature = if (settings.shouldApply) settings.signature() else DISABLED_LUT_SIGNATURE
        if (signature == lastLutSignature) return
        // 先于入队登记：队列里的旧任务靠它判断自己是否已被更新的请求覆盖（见 [pendingLutSignature]）。
        pendingLutSignature = signature

        // LUT 生成要算 size³ 个格点、每个格点跑完整调色链：33³ 约 20ms、65³ 约 150ms。
        // 放在主线程上做，拖滑杆时会把 UI 拖到掉帧，所以生成与写文件都丢到 IO 线程。
        runCatching { lutExecutor.execute {
            if (released) return@execute
            // 入队时是新请求，但排队期间可能已经被后面的拖动覆盖；此时生成出来的是一张
            // 用不上的图，直接让位给最新那次。
            if (pendingLutSignature != signature || signature == lastLutSignature) return@execute
            val file = runCatching { lutWriter.materialize(settings) }
                .onFailure { Log.e(TAG, "生成 LUT 文件失败", it) }
                .getOrNull()

            // JNI 调用统一回主线程：与 create/init/destroy 保持同一线程，避免
            // mpv 句柄在跨线程销毁的瞬间被这里用到（那会直接 crash 在 native 层）。
            mainHandler.post {
                if (released || !created) {
                    Log.w(TAG, "LUT 生成完成但引擎已释放，丢弃本次下发")
                    return@post
                }
                // 生成期间用户可能又拖了滑杆：这一张已经是过时的，不下发，否则会覆盖掉
                // 稍后到达的新签名（两者都在主线程，后 post 的会先到，画面会闪回旧调色）。
                if (pendingLutSignature != signature) {
                    Log.d(TAG, "LUT 生成完成但已被更新的请求覆盖，丢弃本次下发")
                    return@post
                }
                if (file == null) {
                    if (settings.shouldApply) {
                        // 该生效但生成失败：保持上一张 LUT 比突然闪回原色更可预期。
                        Log.w(TAG, "LUT 生成失败，保持当前 LUT 不变")
                        return@post
                    }
                    MPVLib.setString("target-lut", "")
                    lastLutSignature = signature
                    Log.i(TAG, "实时调色已关闭，target-lut 已清空")
                    return@post
                }

                // mpv 在 Android 上以 POSIX 路径解析，正斜杠是唯一安全写法
                // （参考实现也做了 `.replace("\\", "/")`，见 mpv_realtime_lut.py:1686）。
                val path = file.absolutePath.replace('\\', '/')
                MPVLib.setString("target-lut", path)
                lastLutSignature = signature
                Log.i(TAG, "已下发 LUT：${file.name}（${file.length()} 字节）")
            }
        } }.onFailure {
            // 已 release 时线程池已 shutdown，execute 会抛 RejectedExecutionException；
            // 这属于正常竞态（用户滑完参数立刻退出播放），不该让异常冒到播放页。
            Log.d(TAG, "LUT 任务未能提交（引擎已释放）：${it.message}")
        }
    }

    /** 当前生效的 LUT 签名，供诊断与测试断言。 */
    fun currentLutSignature(): String? = lastLutSignature

    // ─────────────────────────────────────────────────────────────────────────
    // 渲染面
    // ─────────────────────────────────────────────────────────────────────────

    fun setRenderSize(width: Int, height: Int) {
        MPVLib.setSurfaceSizeSafe(width, height)
    }

    /**
     * 画面比例模式，对齐 exo 的 `PlayerView.resizeMode` 那个循环按钮。
     *
     * mpv 没有「resizeMode」这个属性，等价的实现是三个选项的组合：
     * - FIT  : keepaspect=yes + panscan=0    → 完整显示，多余留黑边
     * - FILL : keepaspect=no                 → 拉伸铺满（宽高比会变，和 media3 FILL 一致）
     * - ZOOM : keepaspect=yes + panscan=1.0  → 保持比例裁掉溢出部分
     *
     * 注意这三个都是运行期可改属性，不需要重启 mpv 实例，因此切换比例不会打断播放。
     */
    fun setVideoResizeMode(mode: VideoResizeMode) {
        if (released) return
        when (mode) {
            VideoResizeMode.FIT -> {
                MPVLib.setString("keepaspect", "yes")
                MPVLib.setDouble("panscan", 0.0)
            }
            VideoResizeMode.FILL -> {
                MPVLib.setString("keepaspect", "no")
                MPVLib.setDouble("panscan", 0.0)
            }
            VideoResizeMode.ZOOM -> {
                MPVLib.setString("keepaspect", "yes")
                MPVLib.setDouble("panscan", 1.0)
            }
        }
        currentResizeMode = mode
    }

    /** 重载/重建实例后恢复用户选择的画面比例。 */
    private var currentResizeMode: VideoResizeMode = VideoResizeMode.FIT

    /** 供切换内核时把比例一并搬运过去。 */
    fun currentVideoResizeMode(): VideoResizeMode = currentResizeMode

    // ─────────────────────────────────────────────────────────────────────────
    // 事件处理（全部在主线程）
    // ─────────────────────────────────────────────────────────────────────────

    private fun handleEvent(eventId: Int) {
        when (eventId) {
            MPVLib.MPV_EVENT_FILE_LOADED -> {
                fileLoaded.set(true)
                pendingSeekMs?.let { ms ->
                    pendingSeekMs = null
                    seekTo(ms)
                }
                pendingSubtitle?.let { (subtitle, offset) ->
                    pendingSubtitle = null
                    subtitleOffsetMs = offset
                    applySubtitle(subtitle)
                }
                updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_READY) }
            }

            MPVLib.MPV_EVENT_PLAYBACK_RESTART -> {
                updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_READY) }
            }

            MPVLib.MPV_EVENT_SHUTDOWN -> {
                Log.w(TAG, "mpv 发出 shutdown 事件")
                updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_IDLE) }
            }
        }
    }

    private fun handleEndFile(reason: Int, error: Int) {
        fileLoaded.set(false)
        when {
            error != 0 -> {
                // 带回 mpv 的符号名 + 实际下发的 URL。error=-13（LOADING_FAILED）基本都是
                // 「这个 URL mpv 打不开」，把 URL 的 scheme 一起打出来，用户贴一行日志就能定位。
                val message = "mpv 播放失败：${MPVLib.errorName(error)}（error=$error, " +
                    "reason=${MPVLib.endFileReasonName(reason)}/$reason）" + describeLoadedUrl()
                Log.e(TAG, message)
                updateSnapshot {
                    it.copy(playbackState = PlaybackSnapshot.STATE_IDLE, errorMessage = message)
                }
            }

            reason == MPVLib.MPV_END_FILE_REASON_EOF -> {
                updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_ENDED, isPlaying = false) }
            }

            else -> {
                updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_IDLE, isPlaying = false) }
            }
        }
    }

    /**
     * 错误文案里的 URL 摘要。
     *
     * http(s) 只留 scheme+host+path：直链的 query 里常带 token/签名，不进界面也不进日志。
     * `/proc/self/fd/N` 这种内部路径照原样给，用户一眼能看出是不是走了 fd 归一化。
     */
    private fun describeLoadedUrl(): String {
        val url = lastLoadUrl ?: return ""
        val scheme = lastLoadScheme.orEmpty()
        val shown = if (scheme.startsWith("http")) {
            runCatching {
                val parsed = Uri.parse(url)
                "${parsed.scheme}://${parsed.host}${parsed.path}"
            }.getOrDefault("<$scheme>")
        } else {
            url
        }
        return "，url=$shown（scheme=${scheme.ifEmpty { "?" }}）"
    }

    private fun handleProperty(name: String, value: Any?) {
        when (name) {
            "time-pos" -> {
                val seconds = (value as? Double) ?: return
                val positionMs = (seconds * 1000.0).toLong().coerceAtLeast(0L)
                updateSnapshot { it.copy(positionMs = positionMs, playbackState = snapshotStateAfterTick(it)) }
            }

            "duration" -> {
                val seconds = (value as? Double) ?: return
                updateSnapshot { it.copy(durationMs = (seconds * 1000.0).toLong().coerceAtLeast(0L)) }
            }

            "pause" -> {
                val paused = value as? Boolean ?: return
                // playWhenReady 与 isPlaying 分开维护：exo 的 playWhenReady 只表示「想不想播」，
                // 而 isPlaying 还要看缓冲。UI 的播放/暂停图标读 playWhenReady，
                // 缓冲指示读 playbackState，两者不能互相代替（否则缓冲时图标会闪成暂停）。
                updateSnapshot {
                    it.copy(
                        playWhenReady = !paused,
                        isPlaying = !paused && it.playbackState != PlaybackSnapshot.STATE_BUFFERING
                    )
                }
            }

            "paused-for-cache" -> {
                val buffering = value as? Boolean ?: return
                updateSnapshot {
                    it.copy(
                        playbackState = if (buffering) {
                            PlaybackSnapshot.STATE_BUFFERING
                        } else if (it.playbackState == PlaybackSnapshot.STATE_BUFFERING) {
                            PlaybackSnapshot.STATE_READY
                        } else {
                            it.playbackState
                        },
                        isPlaying = !buffering && it.isPlaying
                    )
                }
            }

            "speed" -> {
                val speed = (value as? Double)?.toFloat() ?: return
                updateSnapshot { it.copy(speed = speed) }
            }

            "eof-reached" -> {
                val eof = value as? Boolean ?: return
                if (eof) {
                    updateSnapshot { it.copy(playbackState = PlaybackSnapshot.STATE_ENDED, isPlaying = false) }
                }
            }

            "width" -> {
                val width = (value as? Int)?.toInt() ?: (value as? Long)?.toInt() ?: return
                updateSnapshot { it.copy(videoWidth = width) }
            }

            "height" -> {
                val height = (value as? Int)?.toInt() ?: (value as? Long)?.toInt() ?: return
                updateSnapshot { it.copy(videoHeight = height) }
            }

            "demuxer-cache-time" -> {
                val seconds = (value as? Double) ?: return
                updateSnapshot { it.copy(bufferedMs = (seconds * 1000.0).toLong().coerceAtLeast(0L)) }
            }

            "track-list" -> {
                // 轨道列表变化时通知上层刷新音轨面板（exo 侧对应 onTracksChanged）
                audioTrackListener?.invoke(readAudioTracks())
            }
        }
    }

    private fun snapshotStateAfterTick(snapshot: PlaybackSnapshot): Int =
        if (snapshot.playbackState == PlaybackSnapshot.STATE_ENDED) {
            snapshot.playbackState
        } else if (snapshot.playbackState == PlaybackSnapshot.STATE_IDLE) {
            PlaybackSnapshot.STATE_READY
        } else {
            snapshot.playbackState
        }

    private fun updateSnapshot(transform: (PlaybackSnapshot) -> PlaybackSnapshot) {
        _snapshot.value = transform(_snapshot.value)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 音轨
    // ─────────────────────────────────────────────────────────────────────────

    /** 与 PlayerUiState.audioTracks 的结构对齐；由 ViewModel 转换。 */
    data class MpvAudioTrack(val id: Int, val title: String, val language: String)

    var audioTrackListener: ((List<MpvAudioTrack>) -> Unit)? = null

    /**
     * 读取 mpv 的轨道列表。
     *
     * mpv 只在 `track-list` 变化时给一个无数据的 NONE 事件，具体内容需要按索引抓取
     * （`track-list/count` + `track-list/N/{type,id,title,lang}`），没有批量接口。
     */
    fun readAudioTracks(): List<MpvAudioTrack> {
        if (!created || released) return emptyList()
        val count = MPVLib.getInt("track-list/count") ?: return emptyList()
        val tracks = ArrayList<MpvAudioTrack>(count)
        for (i in 0 until count) {
            val type = MPVLib.getString("track-list/$i/type") ?: continue
            if (type != "audio") continue
            val id = MPVLib.getInt("track-list/$i/id") ?: continue
            val title = MPVLib.getString("track-list/$i/title").orEmpty()
            val lang = MPVLib.getString("track-list/$i/lang").orEmpty()
            tracks.add(MpvAudioTrack(id = id, title = title.ifBlank { "音轨 $id" }, language = lang))
        }
        return tracks
    }

    /**
     * 当前生效的音频轨 aid；`null` 表示 mpv 处于 `aid=auto`（自动选择）。
     *
     * 与 [readAudioTracks] 配对：它给的是轨道清单，这条给的是「清单里哪条在用」。
     * UI 需要前者渲染列表、需要后者标出选中项——mpv 的 `track-list/N` 里没有
     * `selected` 字段，只有全局的 `aid`，所以只能这样分开取。
     */
    fun currentAudioTrackId(): Int? {
        if (!created || released) return null
        return MPVLib.getInt("aid")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 截帧（自动分析调参的输入）
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * 抓一帧当前画面，给「自动分析调参」提取肤色用。
     *
     * 移植自参考实现的 `capture_mpv_frame_via_ipc`（mpv_realtime_lut.py:1631）：那条链路
     * 是往 mpv 的 IPC 端口发 `screenshot-to-file <path> video`，然后读盘。Android 上
     * 没有 IPC 端口，但同一套命令走 JNI 就能到达同一个 mpv 实例，所以直接
     * [MPVLib.cmd]。
     *
     * **为什么用 "video" 而不是 "window"**：`video` 是解码后的片源画面，不含字幕与
     * OSD；而 `target-lut` 是 vo 级的 shader，截图走的是片源帧，所以拿到的也是未调色
     * 的原片——正好是「当前画面适合什么参数」需要的输入。
     *
     * **为什么要轮询文件**：mpv 的 screenshot 命令是异步的，它会等下一帧渲染完才落盘，
     * 中途可能插入 seek。这里没有完成回调可用，就按「文件存在且非空」当完成信号，
     * 超时上限 [CAPTURE_TIMEOUT_MS]。
     *
     * 调用方应该在后台线程调用（内部会阻塞到截图完成）。
     *
     * @return 解码后的位图；引擎未就绪、超时或解码失败返回 null。
     */
    fun captureFrameForAnalysis(
        timeoutMs: Long = CAPTURE_TIMEOUT_MS,
        maxSide: Int = CAPTURE_MAX_SIDE
    ): Bitmap? {
        if (!created || released) {
            Log.w(TAG, "截帧失败：引擎未就绪")
            return null
        }
        val dir = File(cacheDir, CAPTURE_DIR_NAME)
        if (!dir.exists() && !dir.mkdirs()) {
            Log.w(TAG, "截帧失败：无法创建目录 ${dir.absolutePath}")
            return null
        }
        val file = File(dir, "frame-${System.nanoTime()}.png")
        // mpv 按 POSIX 路径解析，正斜杠是唯一安全写法（同 target-lut 的处理）。
        val posixPath = file.absolutePath.replace('\\', '/')

        // JNI 调用统一回主线程：与 create/init/destroy 同一线程，避免命令与销毁竞态。
        mainHandler.post {
            if (released || !created) return@post
            MPVLib.cmd("screenshot-to-file", posixPath, "video")
        }

        try {
            if (!awaitFile(file, timeoutMs)) {
                Log.w(TAG, "截帧超时（${timeoutMs}ms）：mpv 未产出 ${file.name}")
                return null
            }
            val bitmap = decodeScaled(file, maxSide)
            if (bitmap == null) Log.w(TAG, "截帧失败：无法解码 ${file.name}（${file.length()} 字节）")
            return bitmap
        } finally {
            // 分析只需要像素，文件用完即删：截图帧不小，攒在 cacheDir 里没人清。
            if (file.exists() && !file.delete()) Log.d(TAG, "截图临时文件未能删除：${file.name}")
        }
    }

    /** 轮询等待截图落盘。返回 false 表示超时。 */
    private fun awaitFile(file: File, timeoutMs: Long): Boolean {
        // 截图命令是 mainHandler.post 投递的，在主线程上轮询会把那条命令一起堵住：
        // 命令永远执行不到 → 文件永远不出现 → 必然等到 2s 超时并返回 null。
        // 这里挡成明确失败，而不是让调用方拿到一个总是超时的「分析没找到人脸」。
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.w(TAG, "截帧失败：captureFrameForAnalysis 必须在后台线程调用")
            return false
        }
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (released) return false
            // 命令是异步的，文件可能出现得比写满早，所以要求非空再退出等待。
            if (file.length() > 0L) {
                // 再给一点时间让最后一个块落完，否则解码会读到截断的 PNG。
                Thread.sleep(FRAME_SETTLE_MS)
                return true
            }
            Thread.sleep(CAPTURE_POLL_MS)
        }
        return false
    }

    /**
     * 按 [maxSide] 做 2 的幂次降采样解码。
     *
     * 两段式：先只解析尺寸（`inJustDecodeBounds`），算出 2 的幂次采样率，再真正解码。
     * 1080p 的帧约 8 MB 的 ARGB，直接整解再加一份 IntArray 拷给分析器，峰值会翻倍；
     * 而 [LutSkinAnalyzer.MAX_SAMPLE_DIM] 本来就是 640，多出来的像素都会被丢掉。
     *
     * 采样率取「降完不小于 [maxSide] 的最大 2 的幂」，所以长边落在
     * `[maxSide, 2 * maxSide)`——这是下限而非上限：1080p 配 [CAPTURE_MAX_SIDE] 得到
     * 960 宽，比目标 640 大一档，剩下的交给分析器里的双线性缩放（质量好于
     * `inSampleSize` 的最近邻），换掉的是多出来的半张图的内存。
     */
    private fun decodeScaled(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    companion object {
        private const val TAG = "MpvPlaybackEngine"

        /** LUT 文件子目录名（位于 [cacheDir] 下）。 */
        private const val LUT_DIR_NAME = "lut"

        /** 未启用调色时的签名占位。用它区分「没下发过」与「下发过且是关闭态」。 */
        private const val DISABLED_LUT_SIGNATURE = "__disabled__"

        /** 截图临时文件子目录名（位于 [cacheDir] 下）。 */
        private const val CAPTURE_DIR_NAME = "lut-capture"

        /** 截帧等待上限。mpv 正常在一帧时间内落盘，2 秒足够覆盖暂停时等关键帧的情况。 */
        private const val CAPTURE_TIMEOUT_MS = 2_000L

        /** 轮询截图文件的间隔。 */
        private const val CAPTURE_POLL_MS = 25L

        /** 文件出现后再等一会儿，让最后一块写完，避免解到截断的 PNG。 */
        private const val FRAME_SETTLE_MS = 30L

        /**
         * 解码时长边的下限目标。
         *
         * 与分析器的 [LutSkinAnalyzer.MAX_SAMPLE_DIM] 取同一个值：采样率只能是 2 的幂，
         * 所以实际解出来的长边是 640~1279，再由分析器用双线性缩到 640。取 1280 会让
         * 1080p 完全不采样（整幅 8 MB 解码完再一路缩到 640），纯属浪费内存。
         */
        private const val CAPTURE_MAX_SIDE = 640
    }
}
