package com.example.localmovielibrarz.ui.guangya.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

/**
 * 光鸭文件清理界面（需求 4 · 工具箱四件套之一）：
 * 进入即从当前根目录递归扫描命中文件，支持多选 / 全选后批量移入回收站（绝不永久删除）。
 * rootParentId / rootName 缺省时从根目录扫描（工具箱「文件清理」入口不传参）。
 */
@Composable
fun GuangyaFileCleanerScreen(
    viewModel: GuangyaFileCleanerViewModel,
    onBack: () -> Unit,
    rootParentId: String = "",
    rootName: String = "根目录"
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showCleanConfirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    // 进入即扫描（重进会重新触发）
    LaunchedEffect(Unit) { viewModel.startScan(rootParentId, rootName) }

    LaunchedEffect(state.message) {
        state.message?.let {
            delay(2_500)
            viewModel.clearMessage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "返回")
            }
            Text(
                text = "光鸭文件清理（$rootName）",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { viewModel.startScan(rootParentId, rootName) },
                enabled = !state.scanning && !state.cleaning
            ) {
                Text(if (state.scanning) "扫描中…" else "开始扫描")
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            state.message?.let { msg ->
                Text(text = msg, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            state.error?.let { err ->
                Text(text = "出错：$err", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            // 共享清理规则卡片（115 / 光鸭共用同一份数据）
            CleanRuleCard(viewModel = viewModel)

            if (state.scanning) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSurface)
                    Text(text = "扫描中：已命中 ${state.matches.size}", style = MaterialTheme.typography.bodySmall)
                }
            } else {
                Text(
                    text = "命中 ${state.matches.size} 项",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (state.matches.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (state.scanning) "正在扫描…" else "暂无命中项，请在上方清理规则卡片中添加关键词或后缀后重试",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.matches, key = { it.fileId }) { match ->
                        val checked = match.fileId in state.selectedIds
                        val rowBg =
                            if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg, shape = RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = match.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "路径：${match.path} · ${match.reason}",
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                match.size?.let {
                                    Text(
                                        text = formatSize(it),
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            Checkbox(checked = checked, onCheckedChange = { viewModel.toggleSelect(match.fileId) })
                        }
                    }
                }
            }
        }

        // 底部操作栏（有勾选时显示）
        if (state.selectedIds.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "已选 ${state.selectedIds.size}/${state.matches.size}",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = viewModel::selectAll) { Text("全选", style = MaterialTheme.typography.labelMedium) }
                    TextButton(
                        onClick = { showCleanConfirm = true },
                        enabled = state.selectedIds.isNotEmpty() && !state.cleaning
                    ) {
                        Text("移入回收站", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = viewModel::clearSelection) { Text("完成", style = MaterialTheme.typography.labelMedium) }
                }
            }
        }
    }

    if (showCleanConfirm) {
        AlertDialog(
            onDismissRequest = { showCleanConfirm = false },
            title = { Text("移入回收站？") },
            text = {
                Text("确定将选中的 ${state.selectedIds.size} 项移入回收站吗？回收站内可恢复，不会彻底删除。")
            },
            confirmButton = {
                Button(onClick = {
                    showCleanConfirm = false
                    viewModel.cleanSelected()
                }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showCleanConfirm = false }) { Text("取消") }
            }
        )
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024 && idx < units.size - 1) {
        value /= 1024
        idx++
    }
    return if (idx == 0) "$bytes B" else "%.1f %s".format(value, units[idx])
}

/**
 * 清理规则管理卡片（115 / 光鸭共用同一份数据）。
 * 关键词 / 后缀 / 大小阈值，修改后即时生效。
 */
@Composable
private fun CleanRuleCard(viewModel: GuangyaFileCleanerViewModel) {
    var kwInput by remember { mutableStateOf("") }
    var sxInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf(viewModel.getMaxSizeMb().toString()) }
    var refreshKey by remember { mutableStateOf(0) }
    val keywords = remember(refreshKey) { viewModel.getKeywords().toList() }
    val suffixes = remember(refreshKey) { viewModel.getSuffixes().toList() }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("清理规则（115 / 光鸭共用）", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

            // 关键词
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = kwInput,
                    onValueChange = { kwInput = it },
                    placeholder = { Text("关键词", style = MaterialTheme.typography.bodySmall) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (kwInput.isNotBlank()) {
                            viewModel.addKeyword(kwInput.trim())
                            kwInput = ""
                            refreshKey++
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) { Text("添加") }
            }
            if (keywords.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    keywords.take(6).forEach { kw ->
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(kw, style = MaterialTheme.typography.labelSmall)
                                IconButton(
                                    onClick = { viewModel.removeKeyword(kw); refreshKey++ },
                                    modifier = Modifier.size(16.dp)
                                ) {
                                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                    if (keywords.size > 6) {
                        Text(" +${keywords.size - 6}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            }

            // 后缀
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = sxInput,
                    onValueChange = { sxInput = it },
                    placeholder = { Text("后缀，如 txt", style = MaterialTheme.typography.bodySmall) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (sxInput.isNotBlank()) {
                            viewModel.addSuffix(sxInput.trim().lowercase())
                            sxInput = ""
                            refreshKey++
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) { Text("添加") }
            }
            if (suffixes.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    suffixes.take(6).forEach { sfx ->
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(".$sfx", style = MaterialTheme.typography.labelSmall)
                                IconButton(
                                    onClick = { viewModel.removeSuffix(sfx); refreshKey++ },
                                    modifier = Modifier.size(16.dp)
                                ) {
                                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                    if (suffixes.size > 6) {
                        Text(" +${suffixes.size - 6}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            }

            // 大小阈值
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = sizeInput,
                    onValueChange = { sizeInput = it.filter { c -> c.isDigit() } },
                    label = { Text("大小上限 MB（0=不限）", style = MaterialTheme.typography.labelSmall) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(
                    onClick = {
                        val mb = sizeInput.toIntOrNull() ?: 0
                        viewModel.saveMaxSizeMb(mb)
                        refreshKey++
                    },
                    shape = RoundedCornerShape(12.dp)
                ) { Text("保存", style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
}
