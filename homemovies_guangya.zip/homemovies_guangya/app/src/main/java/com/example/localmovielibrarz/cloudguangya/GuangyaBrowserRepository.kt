package com.example.localmovielibrarz.cloudguangya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 光鸭云盘浏览业务编排（镜像 Cloud115Client 薄封装）。 */
class GuangyaBrowserRepository(
    private val apiClient: GuangyaApiClient
) {
    /** parentId="" 为根目录（115 用 Long 类型的 ROOT_CID，光鸭用空串，P2-3）。 */
    suspend fun listFiles(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFiles(parentId)
    }

    /** 列出某目录下的一级子文件夹（离线下载目标文件夹选择）。 */
    suspend fun listFolders(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFolders(parentId)
    }

    /** 全局搜索文件夹（离线下载目标文件夹搜索）。 */
    suspend fun searchFolders(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFolders(keyword)
    }

    /** 需求 2：全局搜索文件+目录（列表页搜索）。 */
    suspend fun searchFiles(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFiles(keyword)
    }

    /** 批量移入回收站：分批提交 delete_file 并等待每批任务终态；部分失败聚合报错。 */
    suspend fun recycleFiles(fileIds: List<String>) {
        if (fileIds.isEmpty()) return
        var ok = 0; var fail = 0; var lastError: String? = null
        fileIds.chunked(50).forEach { batch ->
            runCatching {
                val taskId = apiClient.trashItems(batch)
                apiClient.waitTask(taskId)         // ★ 等待真正完成
            }.onSuccess { ok += batch.size }
                .onFailure { fail += batch.size; lastError = it.message }
        }
        // 改抛 GuangyaApiException——若抛 IOException，ViewModel 的错误映射
        // （is IOException -> "网络连接失败"）会把业务失败误标为网络问题
        if (fail > 0) throw GuangyaApiException("回收站部分失败：成功 $ok / 失败 $fail" +
            (lastError?.let { "（$it）" } ?: ""))
    }

    /** 批量移动：分批提交并等待终态。 */
    suspend fun moveFiles(fileIds: List<String>, targetParentId: String) {
        if (fileIds.isEmpty()) return
        fileIds.chunked(50).forEach { batch ->
            val taskId = apiClient.moveItems(batch, targetParentId)
            apiClient.waitTask(taskId)
        }
    }

    /** 重命名（同步）。 */
    suspend fun renameFile(fileId: String, newName: String) = apiClient.renameItem(fileId, newName)

    /**
     * 需求 3：批量重命名文件/目录（扩展名由调用方保留）。
     * 逐条走新 renameItem（无 clientId）；原实现调 apiClient.renameFile（本轮已删除），
     * 不补此方法直接编译失败——GuangyaBrowserViewModel.batchRenameSelected 仍在调用本方法。
     */
    suspend fun batchRenameFiles(renames: List<Pair<String, String>>) {
        renames.forEach { (fileId, newName) ->
            if (fileId.isNotBlank() && newName.isNotBlank()) apiClient.renameItem(fileId, newName)
        }
    }

    /** 解析离线下载链接（磁力链/.torrent/ed2k）。 */
    suspend fun resolveOfflineUrl(url: String) = apiClient.resolveOfflineUrl(url)

    /** 创建云下载任务（离线下载）。 */
    suspend fun createOfflineTask(url: String, parentId: String) = apiClient.createOfflineTask(url, parentId)
}
