package com.example.localmovielibrarz.ui.guangya.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

/**
 * 光鸭空文件夹清理界面（需求 4 · 工具箱四件套之一）：
 * 进入即从指定根目录递归扫描空文件夹，支持多选 / 全选后批量移入回收站。
 */
@Composable
fun GuangyaEmptyFolderCleanerScreen(
    viewModel: GuangyaEmptyFolderCleanerViewModel,
    onBack: () -> Unit,
    initialParentId: String,
    initialRootName: String
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showCleanConfirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    // 进入即扫描（重进会重新触发）
    LaunchedEffect(Unit) { viewModel.startScan(initialParentId, initialRootName) }

    LaunchedEffect(state.message) {
        state.message?.let {
            delay(2_500)
            viewModel.clearMessage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "返回")
            }
            Text(
                text = "光鸭空文件夹清理（$initialRootName）",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (state.scanning) viewModel.stopScan()
                    else viewModel.startScan(initialParentId, initialRootName)
                },
                enabled = !state.cleaning
            ) {
                Text(if (state.scanning) "停止扫描" else "开始扫描")
            }
        }

        // ★ 内容区：唯一滚动容器 = LazyColumn（去掉 verticalScroll 的 Column，修复一）
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.message?.let { msg ->
                        Text(text = msg, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                    state.error?.let { err ->
                        Text(text = "出错：$err", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                if (state.scanning) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSurface)
                        Text(text = "扫描中：已扫目录 ${state.scannedDirs} · 发现 ${state.candidates.size} 个", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Text(
                        text = "空文件夹 ${state.candidates.size} 个",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            if (state.candidates.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (state.scanning) "正在扫描…" else "暂无空文件夹",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                items(state.candidates, key = { it.folderId }) { match ->
                    val checked = match.folderId in state.selectedIds
                    val rowBg =
                        if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg, shape = RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = match.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "路径：${match.path}",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Checkbox(checked = checked, onCheckedChange = { viewModel.toggleSelect(match.folderId) })
                    }
                }
            }
        }

        // 底部操作栏（有勾选时显示）
        if (state.selectedIds.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    // 第一行：计数 + 退出（计数不参与挤压）
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "已选 ${state.selectedIds.size}/${state.candidates.size}",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            softWrap = false, // 禁止换行
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = viewModel::clearSelection,
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) {
                            Text("取消", maxLines = 1, softWrap = false)
                        }
                    }
                    // 第二行：操作按钮可横滚，永不挤压
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = viewModel::selectAll) { Text("全选", maxLines = 1, softWrap = false) }
                        TextButton(
                            onClick = { showCleanConfirm = true },
                            enabled = state.selectedIds.isNotEmpty() && !state.cleaning
                        ) {
                            Text(
                                "移入回收站",
                                maxLines = 1,
                                softWrap = false,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCleanConfirm) {
        AlertDialog(
            onDismissRequest = { showCleanConfirm = false },
            title = { Text("移入回收站？") },
            text = {
                Text("确定将选中的 ${state.selectedIds.size} 个空文件夹移入回收站吗？回收站内可恢复，不会彻底删除。")
            },
            confirmButton = {
                Button(onClick = {
                    showCleanConfirm = false
                    viewModel.cleanSelected()
                }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showCleanConfirm = false }) { Text("取消") }
            }
        )
    }
}
