package com.example.localmovielibrarz.ui.cloudclean

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.ui.settings.settingsTextFieldColors

/**
 * 共享清理名单卡片（115 / 光鸭两端的清理工具页内嵌）。
 * 同一份 SharedPreferences 数据（关键词/后缀/大小阈值 + 开关），两端修改即时互相同步。
 * 面板内不放标题——修复三的页面外层卡已有「清理名单」标题；只放开关可折叠内容。
 */
@Composable
fun CloudCleanRulePanel(
    keywords: Set<String>,
    suffixes: Set<String>,
    maxSizeMb: Int,
    keywordEnabled: Boolean,                       // ★ 新增
    suffixEnabled: Boolean,                        // ★ 新增
    onToggleKeyword: (Boolean) -> Unit,            // ★ 新增
    onToggleSuffix: (Boolean) -> Unit,             // ★ 新增
    onAddKeyword: (String) -> Unit,
    onRemoveKeyword: (String) -> Unit,
    onAddSuffix: (String) -> Unit,
    onRemoveSuffix: (String) -> Unit,
    onSaveMaxSizeMb: (Int) -> Unit
) {
    var kwInput by remember { mutableStateOf("") }
    var sxInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf(maxSizeMb.toString()) }
    Column(
        modifier = Modifier.fillMaxWidth().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 开关行：两个可点亮 FilterChip（关键词 / 后缀）
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = keywordEnabled,
                onClick = { onToggleKeyword(!keywordEnabled) },
                label = { Text("关键词", style = MaterialTheme.typography.labelSmall) },
                leadingIcon = if (keywordEnabled) {
                    { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null
            )
            FilterChip(
                selected = suffixEnabled,
                onClick = { onToggleSuffix(!suffixEnabled) },
                label = { Text("后缀", style = MaterialTheme.typography.labelSmall) },
                leadingIcon = if (suffixEnabled) {
                    { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null
            )
        }
        Text(
            "点亮生效：只按点亮的规则匹配；两项都点亮时需同时命中（大小阈值仅对后缀生效）",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )

        // 关键词
        Row(
            modifier = Modifier.alpha(if (keywordEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = kwInput,
                onValueChange = { kwInput = it },
                placeholder = { Text("关键词", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f),
                colors = settingsTextFieldColors()
            )
            Button(
                onClick = {
                    onAddKeyword(kwInput)
                    kwInput = ""
                },
                enabled = kwInput.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) { Text("添加") }
        }
        KeywordChips(
            items = keywords.toList(),
            hint = "无关键词（文件名包含即命中）",
            onRemove = onRemoveKeyword,
            dimmed = !keywordEnabled
        )

        // 后缀
        Row(
            modifier = Modifier.alpha(if (suffixEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = sxInput,
                onValueChange = { sxInput = it },
                placeholder = { Text("后缀，如 txt", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f),
                colors = settingsTextFieldColors()
            )
            Button(
                onClick = {
                    onAddSuffix(sxInput)
                    sxInput = ""
                },
                enabled = sxInput.isNotBlank(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) { Text("添加") }
        }
        KeywordChips(
            items = suffixes.toList(),
            hint = "无后缀（匹配文件扩展名）",
            onRemove = onRemoveSuffix,
            dimmed = !suffixEnabled
        )

        // 大小阈值
        Row(
            modifier = Modifier.alpha(if (suffixEnabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("小文件上限(MB)", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(
                value = sizeInput,
                onValueChange = { sizeInput = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f),
                textStyle = MaterialTheme.typography.bodySmall,
                shape = RoundedCornerShape(12.dp),
                colors = settingsTextFieldColors()
            )
            TextButton(
                onClick = {
                    val n = sizeInput.toIntOrNull()
                    if (n != null) onSaveMaxSizeMb(n) else sizeInput = maxSizeMb.toString()
                }
            ) { Text("保存") }
        }
    }
}

/** 规则项 chips（可逐个删除；熄灭组整体降透明度）。 */
@Composable
private fun KeywordChips(items: List<String>, hint: String, onRemove: (String) -> Unit, dimmed: Boolean = false) {
    if (items.isEmpty()) {
        Text(
            text = hint,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (dimmed) 0.25f else 0.5f),
            style = MaterialTheme.typography.bodySmall
        )
        return
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(items) { item ->
            Row(
                modifier = Modifier
                    .alpha(if (dimmed) 0.45f else 1f)
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(start = 10.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                IconButton(
                    onClick = { onRemove(item) },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "移除 $item",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}