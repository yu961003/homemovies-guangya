package com.example.localmovielibrarz.ui.cloudclean

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.ui.settings.settingsTextFieldColors

/**
 * 共享清理名单卡片（115 / 光鸭两端的清理工具页内嵌）。
 * 同一份 SharedPreferences 数据（关键词/后缀/大小阈值），两端修改即时互相同步。
 */
@Composable
fun CloudCleanRulePanel(
    keywords: Set<String>,
    suffixes: Set<String>,
    maxSizeMb: Int,
    onAddKeyword: (String) -> Unit,
    onRemoveKeyword: (String) -> Unit,
    onAddSuffix: (String) -> Unit,
    onRemoveSuffix: (String) -> Unit,
    onSaveMaxSizeMb: (Int) -> Unit
) {
    var kwInput by remember { mutableStateOf("") }
    var sxInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf(maxSizeMb.toString()) }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("清理名单（115 与光鸭共用）", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

            // 关键词
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = kwInput,
                    onValueChange = { kwInput = it },
                    placeholder = { Text("关键词", style = MaterialTheme.typography.bodySmall) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f),
                    colors = settingsTextFieldColors()
                )
                Button(
                    onClick = {
                        onAddKeyword(kwInput)
                        kwInput = ""
                    },
                    enabled = kwInput.isNotBlank(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) { Text("添加") }
            }
            KeywordChips(
                items = keywords.toList(),
                hint = "无关键词（文件名包含即命中）",
                onRemove = onRemoveKeyword
            )

            // 后缀
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = sxInput,
                    onValueChange = { sxInput = it },
                    placeholder = { Text("后缀，如 txt", style = MaterialTheme.typography.bodySmall) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f),
                    colors = settingsTextFieldColors()
                )
                Button(
                    onClick = {
                        onAddSuffix(sxInput)
                        sxInput = ""
                    },
                    enabled = sxInput.isNotBlank(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) { Text("添加") }
            }
            KeywordChips(
                items = suffixes.toList(),
                hint = "无后缀（匹配文件扩展名）",
                onRemove = onRemoveSuffix
            )

            // 大小阈值
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("小文件上限(MB)", style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(
                    value = sizeInput,
                    onValueChange = { sizeInput = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    textStyle = MaterialTheme.typography.bodySmall,
                    shape = RoundedCornerShape(12.dp),
                    colors = settingsTextFieldColors()
                )
                TextButton(
                    onClick = {
                        val n = sizeInput.toIntOrNull()
                        if (n != null) onSaveMaxSizeMb(n) else sizeInput = maxSizeMb.toString()
                    }
                ) { Text("保存") }
            }
        }
    }
}

/** 规则项 chips（可逐个删除）。 */
@Composable
private fun KeywordChips(items: List<String>, hint: String, onRemove: (String) -> Unit) {
    if (items.isEmpty()) {
        Text(
            text = hint,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            style = MaterialTheme.typography.bodySmall
        )
        return
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(items) { item ->
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(start = 10.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                IconButton(
                    onClick = { onRemove(item) },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "移除 $item",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}