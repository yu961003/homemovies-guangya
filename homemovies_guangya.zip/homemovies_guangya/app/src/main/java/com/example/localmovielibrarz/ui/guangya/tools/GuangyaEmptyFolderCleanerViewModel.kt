package com.example.localmovielibrarz.ui.guangya.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuangyaEmptyFolderMatch(val folderId: String, val name: String, val path: String)

data class GuangyaEmptyFolderUiState(
    val scanning: Boolean = false,
    val scannedDirs: Int = 0, // 新增：已扫目录数
    val candidates: List<GuangyaEmptyFolderMatch> = emptyList(),
    val error: String? = null,
    val message: String? = null,
    val selectionMode: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val cleaning: Boolean = false
)

/** 光鸭空文件夹清理：迭代式 DFS，子项为空 → 空候选 → 二次 listFiles 确认 → 分批移入回收站。 */
class GuangyaEmptyFolderCleanerViewModel(
    private val repository: GuangyaBrowserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GuangyaEmptyFolderUiState())

    private var scanJob: kotlinx.coroutines.Job? = null

    fun startScan(rootParentId: String, rootName: String) {
        scanJob?.cancel()
        _uiState.update { it.copy(scanning = true, candidates = emptyList(), error = null, scannedDirs = 0) }
        scanJob = viewModelScope.launch {
            val result = runCatching { scanAll(rootParentId, rootName.ifBlank { "根目录" }) }
            result.exceptionOrNull()?.let { e ->
                _uiState.update { it.copy(error = e.message ?: "扫描失败") }
            }
            _uiState.update {
                it.copy(scanning = false,
                    message = if (result.isSuccess)
                        "扫描完成：已扫目录 ${it.scannedDirs}，空文件夹 ${it.candidates.size} 个" else null)
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        _uiState.update { it.copy(scanning = false, message = "扫描已中止") }
    }

    private suspend fun scanAll(rootParentId: String, rootName: String) {
        val candidates = mutableListOf<GuangyaEmptyFolderMatch>()
        val visited = mutableSetOf<String>()
        val stack = ArrayDeque<Pair<String, String>>()
        stack.add(rootParentId to rootName)
        var dirCount = 0; var failures = 0
        val maxDirs = 5000
        while (stack.isNotEmpty()) {
            val (pid, path) = stack.removeLast()
            if (pid in visited) continue
            visited.add(pid)
            if (++dirCount > maxDirs) {
                _uiState.update { it.copy(message = "目录数达上限 $maxDirs，已停止（可进入子目录分批扫描）") }
                break
            }
            val children = runCatching { repository.listFiles(pid) }.getOrElse {
                failures++
                if (failures >= 10) throw IllegalStateException("连续 $failures 个目录读取失败：${it.message}")
                emptyList()
            }
            if (children.isEmpty()) {
                candidates += GuangyaEmptyFolderMatch(pid, path.substringAfterLast('/'), path)
            } else {
                children.filter { it.isDir && it.fileId.isNotBlank() }.forEach {
                    stack.add(it.fileId to "$path/${it.name}")
                }
            }
            if (dirCount % 25 == 0) {
                _uiState.update { it.copy(scannedDirs = dirCount, candidates = candidates.toList()) }
                kotlinx.coroutines.delay(16)
            }
        }
        // 二次确认：单目录读取失败视为「非空」剔除，不再让一个失败毁掉整个扫描
        val confirmed = candidates.filter {
            runCatching { repository.listFiles(it.folderId).isEmpty() }.getOrDefault(false)
        }
        _uiState.update { it.copy(candidates = confirmed, scannedDirs = dirCount) }
    }

    fun toggleSelect(id: String) { _uiState.update { s -> s.copy(selectedIds = if (id in s.selectedIds) s.selectedIds - id else s.selectedIds + id) } }
    fun selectAll() { _uiState.update { s -> s.copy(selectedIds = s.candidates.map { it.folderId }.toSet()) } }
    fun clearSelection() { _uiState.update { it.copy(selectionMode = false, selectedIds = emptySet()) } }

    fun cleanSelected() {
        val ids = _uiState.value.selectedIds.toList()
        if (ids.isEmpty()) { _uiState.update { it.copy(message = "请先勾选要移入回收站的空文件夹") }; return }
        _uiState.update { it.copy(cleaning = true, message = "正在移入回收站…") }
        viewModelScope.launch {
            try {
                repository.recycleFiles(ids)
                _uiState.update {
                    it.copy(message = "已移入回收站 ${ids.size} 个空文件夹", cleaning = false,
                        selectionMode = false, selectedIds = emptySet(),
                        candidates = it.candidates.filterNot { c -> c.folderId in ids })
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "移入回收站失败：${e.message}", cleaning = false) }
            }
        }
    }

    fun clearMessage() { _uiState.update { it.copy(message = null, error = null) } }

    companion object {
        fun factory(repository: GuangyaBrowserRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    GuangyaEmptyFolderCleanerViewModel(repository) as T
            }
    }
}