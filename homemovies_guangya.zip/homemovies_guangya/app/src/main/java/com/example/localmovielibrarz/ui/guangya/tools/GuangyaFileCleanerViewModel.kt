package com.example.localmovielibrarz.ui.guangya.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.cloudguangya.GuangyaBrowserRepository
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuangyaFileCleanMatch(
    val fileId: String,
    val name: String,
    val size: Long?,
    val path: String,
    val reason: String
)

data class GuangyaFileCleanUiState(
    val scanning: Boolean = false,
    val scannedDirs: Int = 0, // 新增：已扫目录数
    val scannedFiles: Int = 0, // 新增：已扫文件数
    val matches: List<GuangyaFileCleanMatch> = emptyList(),
    val error: String? = null,
    val message: String? = null,
    val selectionMode: Boolean = false,
    val selectedIds: Set<String> = emptySet(),
    val cleaning: Boolean = false
)

/** 光鸭文件清理：按共享清理名单递归扫描目录树 → 勾选 → 分批移入回收站。 */
class GuangyaFileCleanerViewModel(
    private val repository: GuangyaBrowserRepository,
    private val settingsRepository: AppSettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GuangyaFileCleanUiState())
    val uiState: StateFlow<GuangyaFileCleanUiState> = _uiState.asStateFlow()

    private var scanJob: kotlinx.coroutines.Job? = null // 新增：可取消

    fun keywords() = settingsRepository.getCloudCleanKeywords()
    fun suffixes() = settingsRepository.getCloudCleanSuffixes()
    fun maxSizeMb() = settingsRepository.getCloudCleanMaxSizeMb()
    fun addKeyword(v: String) = settingsRepository.addCloudCleanKeyword(v)
    fun removeKeyword(v: String) = settingsRepository.removeCloudCleanKeyword(v)
    fun addSuffix(v: String) = settingsRepository.addCloudCleanSuffix(v)
    fun removeSuffix(v: String) = settingsRepository.removeCloudCleanSuffix(v)
    fun saveMaxSizeMb(v: Int) = settingsRepository.saveCloudCleanMaxSizeMb(v)

    // 清理条件开关（关键词 / 后缀，双亮 = 同时命中）
    fun keywordEnabled() = settingsRepository.isCloudCleanKeywordEnabled()
    fun suffixEnabled() = settingsRepository.isCloudCleanSuffixEnabled()
    fun setKeywordEnabled(v: Boolean) = settingsRepository.saveCloudCleanKeywordEnabled(v)
    fun setSuffixEnabled(v: Boolean) = settingsRepository.saveCloudCleanSuffixEnabled(v)

    fun push(msg: String) { _uiState.update { it.copy(message = msg) } }

    fun startScan(rootParentId: String, rootName: String) {
        val kwOn = keywordEnabled(); val sfxOn = suffixEnabled()
        val kwEmpty = keywords().isEmpty(); val sfxEmpty = suffixes().isEmpty()
        val hint = when {
            !kwOn && !sfxOn -> "请至少点亮一组规则（关键词或后缀）"
            kwOn && kwEmpty -> "关键词组为空：请添加关键词，或熄灭关键词开关"
            sfxOn && sfxEmpty -> "后缀组为空：请添加后缀，或熄灭后缀开关"
            else -> null
        }
        if (hint != null) { _uiState.update { it.copy(message = hint) }; return }
        scanJob?.cancel() // 重复点击先取消旧任务
        _uiState.update {
            it.copy(scanning = true, matches = emptyList(), selectionMode = false,
                selectedIds = emptySet(), error = null, scannedDirs = 0, scannedFiles = 0)
        }
        scanJob = viewModelScope.launch {
            val result = runCatching { scanAll(rootParentId, rootName.ifBlank { "根目录" }) }
            result.exceptionOrNull()?.let { e ->
                _uiState.update { it.copy(error = e.message ?: "扫描失败") }
            }
            _uiState.update {
                it.copy(
                    scanning = false,
                    message = if (result.isSuccess)
                        "扫描完成：目录 ${it.scannedDirs}，文件 ${it.scannedFiles}，命中 ${it.matches.size}" else null
                )
            }
        }
    }

    fun stopScan() { // 新增
        scanJob?.cancel()
        _uiState.update { it.copy(scanning = false, message = "扫描已中止") }
    }

    private suspend fun scanAll(rootParentId: String, rootName: String) {
        val kw = keywords(); val sfx = suffixes()
        val kwOn = keywordEnabled(); val sfxOn = suffixEnabled()
        val maxBytes = maxSizeMb().takeIf { it > 0 }?.times(1024L * 1024L)
        val found = mutableListOf<GuangyaFileCleanMatch>()
        val visited = mutableSetOf<String>()
        val stack = ArrayDeque<Pair<String, String>>()
        stack.add(rootParentId to rootName)
        var dirs = 0; var files = 0; var failures = 0
        val maxDirs = 5000
        while (stack.isNotEmpty()) {
            val (pid, path) = stack.removeLast()
            if (pid in visited) continue
            visited.add(pid)
            if (++dirs > maxDirs) {
                _uiState.update { it.copy(message = "目录数达上限 $maxDirs，已停止展开（可进入子目录分批扫描）") }
                break
            }
            // 单目录失败跳过而非全盘中止；连续失败过多才判定为整体故障
            val children = runCatching { repository.listFiles(pid) }.getOrElse {
                failures++
                if (failures >= 10) throw IllegalStateException("连续 $failures 个目录读取失败：${it.message}")
                emptyList()
            }
            for (c in children) {
                files++
                if (c.isDir) { stack.add(c.fileId to "$path/${c.name}"); continue }
                matchReason(c.name, c.size, kw, kwOn, sfx, sfxOn, maxBytes)?.let {
                    found += GuangyaFileCleanMatch(c.fileId, c.name, c.size, path, it)
                }
            }
            if (dirs % 25 == 0) { // 进度心跳
                _uiState.update { it.copy(matches = found.toList(), scannedDirs = dirs, scannedFiles = files) }
                delay(16)
            }
        }
        _uiState.update { it.copy(matches = found.toList(), scannedDirs = dirs, scannedFiles = files) }
    }

    /** AND 感知匹配：双亮=两组同时命中；单亮=仅该组；大小阈值仅约束后缀侧。 */
    private fun matchReason(
        name: String,
        size: Long?,
        kw: Set<String>, kwEnabled: Boolean,
        sfx: Set<String>, sfxEnabled: Boolean,
        maxBytes: Long?
    ): String? {
        val kwHit = if (kwEnabled) kw.firstOrNull { name.contains(it, ignoreCase = true) } else null
        val ext = name.substringAfterLast('.', "").lowercase()
        val sfxHit = if (sfxEnabled && ext.isNotEmpty() && ext in sfx) ext else null
        val sfxOk = when {
            sfxHit == null -> false
            maxBytes == null -> true
            else -> (size ?: 0L).let { s -> s <= 0L || s <= maxBytes }   // 未知大小放行（沿原语义）
        }
        val sizeNote = if (maxBytes != null) "（≤${maxSizeMb()}MB）" else ""
        return when {
            kwEnabled && sfxEnabled ->
                if (kwHit != null && sfxHit != null && sfxOk)
                    "关键词「$kwHit」＋后缀 .$sfxHit$sizeNote" else null
            kwEnabled -> kwHit?.let { "包含关键词「$it」" }
            sfxEnabled -> if (sfxHit != null && sfxOk) "后缀 .$sfxHit$sizeNote" else null
            else -> null
        }
    }

    fun toggleSelect(id: String) {
        _uiState.update { s -> s.copy(selectedIds = if (id in s.selectedIds) s.selectedIds - id else s.selectedIds + id) }
    }

    fun selectAll() { _uiState.update { s -> s.copy(selectedIds = s.matches.map { it.fileId }.toSet()) } }

    fun clearSelection() { _uiState.update { it.copy(selectionMode = false, selectedIds = emptySet()) } }

    fun cleanSelected() {
        val ids = _uiState.value.selectedIds.toList()
        if (ids.isEmpty()) { _uiState.update { it.copy(message = "请先勾选要移入回收站的文件") }; return }
        _uiState.update { it.copy(cleaning = true, message = "正在移入回收站…") }
        viewModelScope.launch {
            try {
                repository.recycleFiles(ids)
                _uiState.update {
                    it.copy(
                        message = "已移入回收站 ${ids.size} 项",
                        cleaning = false, selectionMode = false, selectedIds = emptySet(),
                        matches = it.matches.filterNot { m -> m.fileId in ids }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "移入回收站失败：${e.message}", cleaning = false) }
            }
        }
    }

    fun clearMessage() { _uiState.update { it.copy(message = null, error = null) } }

    companion object {
        fun factory(repository: GuangyaBrowserRepository, settingsRepository: AppSettingsRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    GuangyaFileCleanerViewModel(repository, settingsRepository) as T
            }
    }
}