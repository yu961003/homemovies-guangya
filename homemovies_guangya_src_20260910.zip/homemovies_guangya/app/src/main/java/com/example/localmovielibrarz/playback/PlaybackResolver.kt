package com.example.localmovielibrarz.playback

import android.content.ContentResolver
import android.net.Uri
import com.example.localmovielibrarz.data.repository.GuangyaDirectLinkResolver
import com.example.localmovielibrarz.data.repository.DirectLinkRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Locale
import java.util.concurrent.TimeUnit
import com.example.localmovielibrarz.util.HttpClients

class PlaybackResolver(
    private val contentResolver: ContentResolver,
    private val directLinkRepository: DirectLinkRepository,
    private val guangyaDirectLinkResolver: GuangyaDirectLinkResolver,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .connectionPool(HttpClients.sharedConnectionPool)
        .dispatcher(HttpClients.sharedDispatcher)
        .build()
) {
    private val strmParser = StrmParser(contentResolver)
    private val m3uParser = M3uParser()

    suspend fun resolve(
        mediaUri: String,
        title: String?,
        fileName: String?,
        forceRefresh: Boolean = false
    ): Result<PlaybackRequest> =
        withContext(Dispatchers.IO) {
            runCatching {
                // P0-2 修正：抽出 id 后立即按 route 分流，避免光鸭被误送 115 解析器
                PickcodeExtractor.extract(mediaUri)?.let { id ->
                    when (val route = PickcodeExtractor.routeOf(mediaUri)) {
                        "guangya_res", "guangya_vod" ->
                            return@runCatching resolveGuangya(id, route == "guangya_vod", title, forceRefresh)
                        else ->
                            return@runCatching resolve115Pickcode(id, title, forceRefresh)
                    }
                }

                val isStrm = fileName?.substringAfterLast('.', "")?.equals("strm", ignoreCase = true) == true ||
                    mediaUri.substringBefore('?').lowercase(Locale.ROOT).endsWith(".strm")

                if (!isStrm) {
                    return@runCatching directRequest(mediaUri, title)
                }

                val entryUrl = strmParser.readEntryUrl(Uri.parse(mediaUri)).getOrElse { throw it }
                if (!entryUrl.isHttpUrl()) {
                    return@runCatching directRequest(entryUrl, title)
                }

                // 读取 STR M 内容后（光鸭 STRM 走这里），同样按 route 分流
                val pickcode = PickcodeExtractor.extract(entryUrl)
                if (pickcode != null) {
                    when (val route = PickcodeExtractor.routeOf(entryUrl)) {
                        ROUTE_GUANGYA_RES, ROUTE_GUANGYA_VOD ->
                            return@runCatching resolveGuangya(pickcode, route == ROUTE_GUANGYA_VOD, title, forceRefresh)
                        else ->
                            return@runCatching resolve115Pickcode(pickcode, title, forceRefresh)
                    }
                }

                resolveNetworkEntry(entryUrl, title)
            }
        }

    suspend fun invalidatePickcode(pickcode: String) {
        directLinkRepository.invalidate(pickcode)
    }

    /**
     * 按路由失效直链缓存（H 轮）：光鸭 fileId 走 [guangyaDirectLinkResolver]，115 pickcode 走
     * [directLinkRepository]。此前统一按 115 处理，光鸭 403 重试时清不掉缓存，会一直拿到旧直链。
     */
    suspend fun invalidateRoute(route: String?, pickcode: String?) {
        val id = pickcode?.takeIf { it.isNotBlank() } ?: return
        when (route) {
            ROUTE_GUANGYA_RES, ROUTE_GUANGYA_VOD -> guangyaDirectLinkResolver.invalidate(id)
            else -> directLinkRepository.invalidate(id)
        }
    }

    private suspend fun resolve115Pickcode(
        pickcode: String,
        title: String?,
        forceRefresh: Boolean
    ): PlaybackRequest {
        val directUrl = directLinkRepository.resolve(pickcode, forceRefresh)
        return PlaybackRequest(
            mediaUri = directUrl,
            title = title,
            userAgent = USER_AGENT,
            referer = null,
            cookie = null,
            pickcode = pickcode,
            headers = mapOf("User-Agent" to USER_AGENT),
            route = ROUTE_115
        )
    }

    private suspend fun resolveGuangya(
        fileId: String,
        isVod: Boolean,
        title: String?,
        forceRefresh: Boolean
    ): PlaybackRequest {
        val directUrl = guangyaDirectLinkResolver.resolve(fileId, isVod, forceRefresh)
        return PlaybackRequest(
            mediaUri = directUrl,
            title = title,
            userAgent = USER_AGENT,
            referer = null,
            cookie = null,
            // H 轮：补 pickcode（=fileId）。光鸭 STRM 记录同样以 fileId 为主键，
            // 带上它才能启用「库字幕 / 网盘字幕」能力，并让 403 重试失效到正确的缓存。
            pickcode = fileId,
            headers = mapOf("User-Agent" to USER_AGENT),
            route = if (isVod) ROUTE_GUANGYA_VOD else ROUTE_GUANGYA_RES
        )
    }

    private fun resolveNetworkEntry(entryUrl: String, title: String?): PlaybackRequest {
        val request = Request.Builder()
            .url(entryUrl)
            .header("User-Agent", DEFAULT_USER_AGENT)
            .header("Accept", "*/*")
            .header("Range", "bytes=0-262143")
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Unable to fetch playback address")

            val contentType = response.header("Content-Type").orEmpty()
            val preview = response.peekBody(256 * 1024).string()
            val looksLikeM3u = isM3uResponse(entryUrl, contentType, preview)

            if (!looksLikeM3u) {
                return directRequest(entryUrl, title)
            }

            val parsed = m3uParser.parse(preview).getOrElse {
                throw IllegalStateException(it.message ?: "No playable media URL found in M3U")
            }
            val headers = buildHeaders(parsed.userAgent, parsed.referer, parsed.cookie)
            return PlaybackRequest(
                mediaUri = parsed.mediaUrl,
                title = title,
                userAgent = parsed.userAgent,
                referer = parsed.referer,
                cookie = parsed.cookie,
                headers = headers
            )
        }
    }

    private fun directRequest(mediaUri: String, title: String?): PlaybackRequest =
        PlaybackRequest(
            mediaUri = mediaUri,
            title = title,
            userAgent = null,
            referer = null,
            cookie = null,
            headers = emptyMap()
        )

    private fun isM3uResponse(url: String, contentType: String, bodyPreview: String): Boolean {
        val lowerUrl = url.substringBefore('?').lowercase(Locale.ROOT)
        val lowerType = contentType.lowercase(Locale.ROOT)
        return lowerUrl.endsWith(".m3u") ||
            lowerUrl.endsWith(".m3u8") ||
            lowerType.contains("application/vnd.apple.mpegurl") ||
            lowerType.contains("application/x-mpegurl") ||
            lowerType.contains("audio/x-mpegurl") ||
            lowerType.contains("audio/mpegurl") ||
            lowerType.contains("text/plain") ||
            bodyPreview.trimStart().startsWith("#EXTM3U", ignoreCase = true)
    }

    private fun buildHeaders(userAgent: String?, referer: String?, cookie: String?): Map<String, String> =
        buildMap {
            userAgent?.takeIf { it.isNotBlank() }?.let { put("User-Agent", it) }
            referer?.takeIf { it.isNotBlank() }?.let { put("Referer", it) }
            cookie?.takeIf { it.isNotBlank() }?.let { put("Cookie", it) }
        }
}
