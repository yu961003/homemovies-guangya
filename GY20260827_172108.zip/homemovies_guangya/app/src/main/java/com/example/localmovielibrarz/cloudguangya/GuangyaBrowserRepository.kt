package com.example.localmovielibrarz.cloudguangya

import com.example.localmovielibrarz.ui.guangya.dedupeNameAgainst
import com.example.localmovielibrarz.ui.guangya.renameNameKey
import com.example.localmovielibrarz.ui.guangya.validateGeneratedName
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** 光鸭云盘浏览业务编排（镜像 Cloud115Client 薄封装）。 */
class GuangyaBrowserRepository(
    private val apiClient: GuangyaApiClient
) {
    /** parentId="" 为根目录（115 用 Long 类型的 ROOT_CID，光鸭用空串，P2-3）。 */
    suspend fun listFiles(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFiles(parentId)
    }

    /** 列出某目录下的一级子文件夹（离线下载目标文件夹选择）。 */
    suspend fun listFolders(parentId: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.listFolders(parentId)
    }

    /** 全局搜索文件夹（离线下载目标文件夹搜索）。 */
    suspend fun searchFolders(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFolders(keyword)
    }

    /** 需求 2：全局搜索文件+目录（列表页搜索）。 */
    suspend fun searchFiles(keyword: String): List<GuangyaFileItem> = withContext(Dispatchers.IO) {
        apiClient.searchFiles(keyword)
    }

    /**
     * 单批回收（≤50）：提交 + 等终态。供执行器与外部逐批调用。
     * 不加 withContext(Dispatchers.IO)——trashItems/waitTask 内部已通过
     * postUserres → withContext(Dispatchers.IO) 执行，不会阻塞主线程。
     */
    suspend fun trashItemsBatch(batch: List<String>) {
        val taskId = apiClient.trashItems(batch)
        apiClient.waitTask(taskId)
    }

    /** 批量移入回收站：分批提交 delete_file 并等待每批任务终态；部分失败聚合报错。 */
    suspend fun recycleFiles(fileIds: List<String>) {
        if (fileIds.isEmpty()) return
        var ok = 0; var fail = 0; var lastError: String? = null
        fileIds.chunked(50).forEach { batch ->
            runCatching { trashItemsBatch(batch) }.onSuccess { ok += batch.size }
                .onFailure { fail += batch.size; lastError = it.message }
        }
        // 改抛 GuangyaApiException——若抛 IOException，ViewModel 的错误映射
        // （is IOException -> "网络连接失败"）会把业务失败误标为网络问题
        if (fail > 0) throw GuangyaApiException("回收站部分失败：成功 $ok / 失败 $fail" +
            (lastError?.let { "（$it）" } ?: ""))
    }

    /** 批量移动：分批提交并等待终态。 */
    suspend fun moveFiles(fileIds: List<String>, targetParentId: String) {
        if (fileIds.isEmpty()) return
        fileIds.chunked(50).forEach { batch ->
            val taskId = apiClient.moveItems(batch, targetParentId)
            apiClient.waitTask(taskId)
        }
    }

    /** 重命名（同步）。 */
    suspend fun renameFile(fileId: String, newName: String) = apiClient.renameItem(fileId, newName)

    /**
     * 需求 3：批量重命名文件/目录（扩展名由调用方保留）。
     *
     * 第十二轮修复（F-1 读后校验 + 补偿重试）：
     * - code=0 只记「待确认」，用 listFiles 真实目录状态做最终裁决；未生效项自动补偿重试。
     * - 保留第十一轮 D-1（拓扑排序 + 环中转）、D-2（已存在即时重试）、
     *   第十轮 A-1（旧名腾出/失败加回）、A-3（autoSuffixed 计数）、C-2（- 开头拦截）。
     * - F-2：succeeded 只含校验确认生效项；retried 计数补偿重试生效项。
     * - F-3：校验-补偿过程 Log.i 留痕（tag GuangyaBatchRename）。
     */
    suspend fun batchRenameFiles(
        renames: List<Pair<String, String>>,
        parentId: String = ""
    ): BatchRenameResult {
        val failed = mutableListOf<BatchRenameFailure>()
        var autoSuffixed = 0

        // ---- 第 0 步：目录快照 + D-1 拓扑排序 + 环中转（第十一轮，保持不变）----
        val namesById = if (parentId.isNotBlank()) {
            runCatching { apiClient.listFiles(parentId).associate { it.fileId to it.name } }
                .getOrDefault(emptyMap())
        } else emptyMap()
        val pendingIds = renames.map { it.first }.toSet()
        val renamingOldNames = pendingIds.mapNotNull { namesById[it] }.toSet()
        val existingNames = (namesById.values - renamingOldNames).toMutableSet()

        val (orderedRenames, ringMembers) = orderRenamesByDependency(renames, namesById)

        // ① 环成员先改到互不冲突的临时名
        if (ringMembers.isNotEmpty()) {
            val occupiedKeys = mutableSetOf<String>().apply {
                addAll(existingNames.map { it.renameNameKey() })
                addAll(renames.mapNotNull { it.second.renameNameKey() })
            }
            ringMembers.forEach { (fileId, newName) ->
                val oldName = namesById[fileId] ?: return@forEach
                validateGeneratedName(newName)?.let { reason ->
                    failed.add(BatchRenameFailure(fileId, newName, reason))
                    existingNames.add(oldName)
                    return@forEach
                }
                val temp = uniqueTempName(oldName, occupiedKeys)
                runCatching { apiClient.renameItem(fileId, temp) }
                    .onSuccess {
                        occupiedKeys.add(temp.renameNameKey())
                        existingNames.add(temp)
                    }
                    .onFailure { error ->
                        existingNames.add(oldName)
                        failed.add(BatchRenameFailure(fileId, newName,
                            error.message ?: error::class.java.simpleName))
                    }
            }
        }

        // ---- 第 1 步：首轮执行——成功仅记「待确认」（★ F-1 不再直接进 succeeded）----
        val pending = mutableListOf<PendingRename>()

        val executeQueue = orderedRenames + ringMembers
        executeQueue.forEach { (fileId, newName) ->
            val oldName = namesById[fileId]
            if (failed.any { it.fileId == fileId && it.newName == newName }) return@forEach
            val skip: (String) -> Unit = { reason ->
                oldName?.let { existingNames.add(it) }
                failed.add(BatchRenameFailure(fileId, newName, reason))
            }
            if (fileId.isBlank() || newName.isBlank()) { skip("名称为空"); return@forEach }
            validateGeneratedName(newName)?.let { skip(it); return@forEach }
            val finalName = dedupeNameAgainst(newName, existingNames)
            if (finalName != newName) autoSuffixed++
            runCatching { apiClient.renameItem(fileId, finalName) }
                .onSuccess {
                    existingNames.add(finalName)
                    pending.add(PendingRename(fileId, newName, finalName))
                }
                .onFailure { error ->
                    oldName?.let { existingNames.add(it) }
                    failed.add(BatchRenameFailure(fileId, newName,
                        error.message ?: error::class.java.simpleName))
                }
        }

        // ---- 第 2 步：D-2 明确拒绝项的即时重试（保持，重试成功同样进 pending）----
        val retryables = failed.filter {
            it.reason.contains("已存在") || it.reason.contains("重名")
        }.also { failed.removeAll(it) }
        retryables.forEach { failure ->
            val finalName = dedupeNameAgainst(failure.newName, existingNames)
            if (finalName != failure.newName) autoSuffixed++
            runCatching { apiClient.renameItem(failure.fileId, finalName) }
                .onSuccess {
                    existingNames.add(finalName)
                    pending.add(PendingRename(failure.fileId, failure.newName, finalName))
                }
                .onFailure { failed.add(failure) }
        }

        // ---- 第 3 步：★ F-1 校验-补偿循环（最多 3 轮）----
        if (parentId.isBlank() || pending.isEmpty()) {
            // 无 parentId 无法校验，或无待确认项——乐观信任受理结果
            return BatchRenameResult(
                succeeded = pending.map { it.fileId to it.finalName },
                failed = failed,
                autoSuffixed = autoSuffixed,
                retried = 0
            )
        }

        val confirmed = mutableListOf<Pair<String, String>>()
        var unresolved = pending.toList()
        var retried = 0
        val maxVerifyRounds = 3

        var round = 0
        while (unresolved.isNotEmpty() && round < maxVerifyRounds) {
            round++
            delay(if (round == 1) 800L else 1_500L)

            val currentNames = runCatching {
                apiClient.listFiles(parentId).associate { it.fileId to it.name }
            }.getOrNull() ?: break // 校验读失败：乐观信任，不补偿

            val (effected, notEffected) = partitionRenameResults(unresolved, currentNames)
            confirmed += effected.map { it.fileId to it.finalName }

            if (notEffected.isEmpty()) break

            // ★ F-3：校验过程日志留痕
            Log.i("GuangyaBatchRename",
                "第 $round 轮校验：${notEffected.size} 项受理成功但未生效" +
                    "（fileId=${notEffected.map { it.fileId }}），进入补偿重试")

            // 补偿重试：用最新目录状态重建冲突集（腾名语义保持）
            val unresolvedCurrentNames = notEffected.mapNotNull { currentNames[it.fileId] }.toSet()
            val latestExisting = (currentNames.values - unresolvedCurrentNames).toMutableSet()
            val next = mutableListOf<PendingRename>()
            notEffected.forEach { p ->
                val retryFinal = dedupeNameAgainst(p.finalName, latestExisting)
                runCatching { apiClient.renameItem(p.fileId, retryFinal) }
                    .onSuccess {
                        latestExisting.add(retryFinal)
                        retried++
                        next.add(p.copy(finalName = retryFinal))
                    }
                    .onFailure { error ->
                        failed.add(BatchRenameFailure(p.fileId, p.newName,
                            "重试被拒：${error.message ?: error::class.java.simpleName}"))
                    }
            }
            unresolved = next
        }

        // 循环结束仍未确认的：受理成功但服务端始终未执行
        unresolved.forEach { p ->
            failed.add(BatchRenameFailure(p.fileId, p.newName,
                "服务端返回成功但未生效（已校验重试 $round 轮），请稍后手动重试"))
        }

        return BatchRenameResult(
            succeeded = confirmed,
            failed = failed,
            autoSuffixed = autoSuffixed,
            retried = retried
        )
    }

    /** 解析离线下载链接（磁力链/.torrent/ed2k）。 */
    suspend fun resolveOfflineUrl(url: String) = apiClient.resolveOfflineUrl(url)

    /** 创建云下载任务（离线下载）。 */
    suspend fun createOfflineTask(url: String, parentId: String) = apiClient.createOfflineTask(url, parentId)
}

/** 单条批量重命名失败信息（服务端拒绝原因透传，如「文件名不能以空格开头或结尾」）。 */
data class BatchRenameFailure(
    val fileId: String,
    val newName: String,
    val reason: String
)

/** 批量重命名整体结果：逐条容错，一条被拒不中断队列其余请求。 */
data class BatchRenameResult(
    val succeeded: List<Pair<String, String>>, // (fileId, 校验确认生效的最终名)
    val failed: List<BatchRenameFailure>,
    val autoSuffixed: Int = 0, // ★ A-3：因撞名被自动加后缀的项数
    val retried: Int = 0 // ★ F-2：经补偿重试才生效的项数
)

/**
 * F-1：校验分流——将待确认项按服务端真实目录状态分为「已生效」与「未生效」。
 * 比对用 renameNameKey（大小写/NFC 差异不算未生效）；fileId 消失归入未生效。
 */
internal data class PendingRename(val fileId: String, val newName: String, val finalName: String)

internal fun partitionRenameResults(
    pending: List<PendingRename>,
    currentNames: Map<String, String>
): Pair<List<PendingRename>, List<PendingRename>> {
    val (effected, notEffected) = pending.partition { p ->
        currentNames[p.fileId]?.let { it.renameNameKey() == p.finalName.renameNameKey() } == true
    }
    return effected to notEffected
}

/**
 * D-1：依赖拓扑排序（Kahn 贪心）。
 * 每轮挑出「目标名不占用任何待执行项旧名」的项；剩余无法挑出的即环形依赖（A↔B 互换名）。
 * 返回 (有序执行列表, 环成员)。
 */
internal fun orderRenamesByDependency(
    renames: List<Pair<String, String>>,
    namesById: Map<String, String>
): Pair<List<Pair<String, String>>, List<Pair<String, String>>> {
    val pending = renames.toMutableList()
    val ordered = mutableListOf<Pair<String, String>>()
    while (pending.isNotEmpty()) {
        val pendingOldKeys = pending.mapNotNull { (id, _) -> namesById[id]?.renameNameKey() }.toSet()
        val ready = pending.filter { (_, newName) -> newName.renameNameKey() !in pendingOldKeys }
        if (ready.isEmpty()) return ordered to pending.toList() // 剩余全为环
        ordered.addAll(ready)
        pending.removeAll(ready.toSet())
    }
    return ordered to emptyList()
}

/** D-1 临时名生成：原名 stem + "-tmp-n"，确保不撞 occupiedKeys（n 递增，上限防御）。 */
private fun uniqueTempName(oldName: String, occupiedKeys: MutableSet<String>): String {
    val ext = oldName.substringAfterLast('.', "")
    val stem = if (ext.isNotEmpty()) oldName.substringBeforeLast('.') else oldName
    var n = 1
    while (n <= 1000) {
        val next = if (ext.isNotEmpty()) "${stem}-tmp-$n.$ext" else "$stem-tmp-$n"
        if (next.renameNameKey() !in occupiedKeys) return next
        n++
    }
    return "${stem}-tmp-$n$ext"
}
