package com.example.localmovielibrarz.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * 库扫描按钮配色方案。
 *
 * 扫描中状态使用浅色背景 + 深色文字，确保禁用时仍可读。
 */
data class LibraryScanButtonPalette(
    val containerColor: Color,
    val contentColor: Color,
    val disabledContainerColor: Color,
    val disabledContentColor: Color,
)

/**
 * 库扫描按钮配色（扫描中状态使用浅色背景 + 深色文字，确保禁用时仍可读）。
 */
fun libraryScanButtonPalette(): LibraryScanButtonPalette = LibraryScanButtonPalette(
    containerColor = Color(0xFF1A73E8),
    contentColor = Color.White,
    disabledContainerColor = Color.White.copy(alpha = 0.55f),
    disabledContentColor = Color.Black.copy(alpha = 0.62f),
)

/**
 * 恢复刮削任务管线。
 *
 * 云盘视频任务与影片任务独立推进：一个卡住的持久化云盘任务不会阻塞
 * 未刮削影片的启动。两者按顺序触发，但云盘任务自行管理其协程生命周期。
 */
suspend fun resumeScrapeTaskPipelines(
    hasCloudVideoTasks: Boolean,
    startCloudVideoTasks: () -> Unit,
    startMovieTasks: () -> Unit,
) {
    if (hasCloudVideoTasks) {
        startCloudVideoTasks()
    }
    startMovieTasks()
}

/**
 * 设置页主界面。
 *
 * 问题 B 修复：已完全移除 GitHub 热更新入口，设置页仅包含本地功能入口。
 */
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateTo115Cookie: () -> Unit = {},
    onNavigateToGuangyaCloud: () -> Unit = {},
    onNavigateTo115Clean: () -> Unit = {},
    onNavigateToNumberRules: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsState()
    SettingsScreenContent(
        state = state,
        onNavigateTo115Cookie = onNavigateTo115Cookie,
        onNavigateToGuangyaCloud = onNavigateToGuangyaCloud,
        onNavigateTo115Clean = onNavigateTo115Clean,
        onNavigateToNumberRules = onNavigateToNumberRules,
        onScanLibrary = viewModel::startLibraryScan,
    )
}

@Composable
private fun SettingsScreenContent(
    state: SettingsUiState,
    onNavigateTo115Cookie: () -> Unit,
    onNavigateToGuangyaCloud: () -> Unit,
    onNavigateTo115Clean: () -> Unit,
    onNavigateToNumberRules: () -> Unit,
    onScanLibrary: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SettingsSectionTitle("库扫描")

            val palette = libraryScanButtonPalette()
            Button(
                onClick = onScanLibrary,
                enabled = !state.isScanning,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.containerColor,
                    contentColor = palette.contentColor,
                    disabledContainerColor = palette.disabledContainerColor,
                    disabledContentColor = palette.disabledContentColor,
                ),
            ) {
                if (state.isScanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = palette.disabledContentColor,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(if (state.isScanning) "扫描中…" else "扫描媒体库")
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SettingsSectionTitle("番号识别")

            SettingsEntryCard(
                title = "番号识别规则",
                subtitle = "忽略后缀 / 分段标记 / 连写前缀 / MGStage / DMM2",
                onClick = onNavigateToNumberRules,
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SettingsSectionTitle("云盘")

            SettingsEntryCard(
                title = "115 网盘 Cookie",
                subtitle = if (state.cloud115Cookie.isNotBlank()) "已配置" else "未配置",
                onClick = onNavigateTo115Cookie,
            )

            SettingsEntryCard(
                title = "光鸭云盘",
                subtitle = if (state.guangyaLoggedIn) "已登录" else "未登录",
                onClick = onNavigateToGuangyaCloud,
            )

            SettingsEntryCard(
                title = "115 清理工具",
                subtitle = "清理重复文件 / 无效条目",
                onClick = onNavigateTo115Clean,
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * 番号识别规则页。
 *
 * 仅包含可编辑的本地列表：
 * - 忽略后缀（ignoredSuffixes）
 * - 分段标记（segmentMarkers）
 * - 连写前缀（attachedLetterPrefixes）
 * - MGStage 前缀别名（mgstagePrefixAliases）
 * - DMM2 跳过前缀（dmm2SkippedPrefixes）
 *
 * 问题 B 修复：已完全移除 GitHub 热更新入口（无 onRefreshRules、
 * remoteConfigUrl、onRemoteConfigUrlChange、onRefresh、isRefreshing、
 * remotePrefixes 等参数与调用点）。
 */
@Composable
fun NumberRecognitionRulesPage(
    state: SettingsUiState,
    onIgnoredSuffixesChange: (String) -> Unit,
    onSegmentMarkersChange: (String) -> Unit,
    onAttachedLetterPrefixesChange: (String) -> Unit,
    onMgstagePrefixAliasesChange: (String) -> Unit,
    onDmm2SkippedPrefixesChange: (String) -> Unit,
    onSave: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("番号识别规则") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SettingsSectionTitle("忽略后缀")
            OutlinedTextField(
                value = state.ignoredSuffixes,
                onValueChange = onIgnoredSuffixesChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("每行一个后缀，如 .HD、.4K") },
                minLines = 3,
            )

            SettingsSectionTitle("分段标记")
            OutlinedTextField(
                value = state.segmentMarkers,
                onValueChange = onSegmentMarkersChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("每行一个标记") },
                minLines = 3,
            )

            SettingsSectionTitle("连写前缀")
            OutlinedTextField(
                value = state.attachedLetterPrefixes,
                onValueChange = onAttachedLetterPrefixesChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("每行一个前缀，字母后缀将被视为分段标记") },
                minLines = 3,
            )

            SettingsSectionTitle("MGStage 前缀别名")
            OutlinedTextField(
                value = state.mgstagePrefixAliases,
                onValueChange = onMgstagePrefixAliasesChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("每行一条，格式：前缀=搜索前缀") },
                minLines = 3,
            )

            SettingsSectionTitle("DMM2 跳过前缀")
            OutlinedTextField(
                value = state.dmm2SkippedPrefixes,
                onValueChange = onDmm2SkippedPrefixesChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("每行一个前缀") },
                minLines = 3,
            )

            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("保存规则")
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * 设置分区标题。
 */
@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 2.dp),
    )
}

/**
 * 设置条目卡片。
 */
@Composable
private fun SettingsEntryCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
        }
    }
}
