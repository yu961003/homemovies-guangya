package com.example.localmovielibrarz.cloudguangya

/**
 * 光鸭云盘常量。
 *
 * 注：已切换为短信验证码 + 扫码登录双模式。
 * 旧 device-code 流程的 verification_uri 已 404 失效，
 * 新接口使用 verification_uri_complete 字段（OAuth Device Code 标准字段）。
 */
object GuangyaConstants {
    const val API_BASE = "https://api.guangyapan.com"
    const val ACCOUNT_BASE = "https://account.guangyapan.com"

    // 官方 SDK 内置 client_id
    const val CLIENT_ID = "guangyaclient"
    const val CLIENT_VERSION = "0.0.2"

    // OAuth Device Code 端点
    const val DEVICE_CODE_PATH = "/v1/auth/device/code"
    const val TOKEN_PATH = "/v1/auth/token"

    // 短信登录端点
    const val SMS_INIT_PATH = "/v1/auth/sms/init"
    const val SMS_SEND_PATH = "/v1/auth/sms/send"
    const val SMS_VERIFY_PATH = "/v1/auth/sms/verify"
    const val SMS_SIGNIN_PATH = "/v1/auth/sms/signin"

    // 鉴权头
    const val HEADER_CLIENT_ID = "x-client-id"
    const val HEADER_DEVICE_ID = "x-device-id"
    const val HEADER_DEVICE_SIGN = "x-device-sign"
    const val HEADER_CLIENT_VERSION = "x-client-version"
    const val HEADER_PROTOCOL_VERSION = "x-protocol-version"
    const val HEADER_PROTOCOL_VERSION_VALUE = "1"

    // MediaType
    const val MEDIA_TYPE_JSON = "application/json; charset=utf-8"
    const val MEDIA_TYPE_FORM = "application/x-www-form-urlencoded"

    // 轮询间隔（秒）
    const val QR_POLL_INTERVAL_SECONDS = 5L
    const val QR_POLL_SLOWDOWN_INTERVAL_SECONDS = 10L
    const val QR_EXPIRE_SECONDS = 300L
}
