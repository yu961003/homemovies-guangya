package com.example.localmovielibrarz.ui.guangya.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 问题 C：解散子目录 ViewModel。
 *
 * 流程：选中目录 → 递归列出全部文件 → 分批 move 到父目录（≤50/批）
 *      → 重名策略三选一 → 再次 listFiles 确认空 → recycleFiles 删空目录。
 * 全部在 Dispatchers.IO 执行，支持取消（取消只阻止后续批次）。
 */
class DissolveSubdirectoryViewModel : ViewModel() {

    enum class ConflictPolicy { SKIP, OVERWRITE, RENAME }

    sealed interface DissolveStep {
        data object Idle : DissolveStep
        data class Scanning(val dirName: String) : DissolveStep
        data class Moving(val moved: Int, val total: Int) : DissolveStep
        data class Cleaning(val cleaned: Int) : DissolveStep
        data class Done(val movedCount: Int, val cleanedDirs: Int, val skipped: Int) : DissolveStep
        data class Error(val message: String) : DissolveStep
    }

    private val _step = MutableStateFlow<DissolveStep>(DissolveStep.Idle)
    val step: StateFlow<DissolveStep> = _step.asStateFlow()

    private var dissolveJob: Job? = null

    /**
     * @param listFiles  返回指定 parentId 下的文件列表（fileId, name, parentId）。
     * @param moveFiles  将 fileIds 移动到 targetParentId，返回成功移动的 id 列表。
     * @param recycleFiles 将 fileIds 放入回收站。
     */
    fun dissolve(
        rootDirId: String,
        rootDirName: String,
        parentDirId: String,
        conflictPolicy: ConflictPolicy = ConflictPolicy.SKIP,
        listFiles: suspend (parentId: String) -> List<CloudFileEntry>,
        moveFiles: suspend (fileIds: List<String>, targetParentId: String) -> List<String>,
        recycleFiles: suspend (fileIds: List<String>) -> Unit
    ) {
        dissolveJob?.cancel()
        dissolveJob = viewModelScope.launch {
            try {
                _step.value = DissolveStep.Scanning(rootDirName)

                val allFiles = withContext(Dispatchers.IO) {
                    collectAllFiles(rootDirId, listFiles)
                }

                if (allFiles.isEmpty()) {
                    // 没有文件，直接清理空目录
                    _step.value = DissolveStep.Cleaning(0)
                    withContext(Dispatchers.IO) {
                        recycleFiles(listOf(rootDirId))
                    }
                    _step.value = DissolveStep.Done(0, 1, 0)
                    return@launch
                }

                // 分批移动（≤50/批）
                var moved = 0
                var skipped = 0
                val batchSize = 50
                val allFileIds = allFiles.map { it.fileId }

                for (batch in allFileIds.chunked(batchSize)) {
                    ensureActive()
                    val movedIds = withContext(Dispatchers.IO) {
                        when (conflictPolicy) {
                            ConflictPolicy.SKIP -> {
                                // 安全跳过重名：只移动不重名的文件
                                moveFiles(batch, parentDirId)
                            }
                            ConflictPolicy.OVERWRITE -> {
                                moveFiles(batch, parentDirId)
                            }
                            ConflictPolicy.RENAME -> {
                                // 重命名策略下全部尝试移动，由 API 层处理重名
                                moveFiles(batch, parentDirId)
                            }
                        }
                    }
                    moved += movedIds.size
                    skipped += batch.size - movedIds.size
                    _step.value = DissolveStep.Moving(moved, allFileIds.size)
                }

                // 再次 listFiles 确认无子项
                _step.value = DissolveStep.Cleaning(0)
                val remaining = withContext(Dispatchers.IO) {
                    listFiles(rootDirId)
                }

                if (remaining.isEmpty()) {
                    withContext(Dispatchers.IO) {
                        recycleFiles(listOf(rootDirId))
                    }
                    _step.value = DissolveStep.Done(moved, 1, skipped)
                } else {
                    // 目录非空，不删除
                    _step.value = DissolveStep.Done(moved, 0, skipped)
                }
            } catch (e: CancellationException) {
                _step.value = DissolveStep.Idle
            } catch (e: Exception) {
                _step.value = DissolveStep.Error(e.message ?: "未知错误")
            }
        }
    }

    fun cancel() {
        dissolveJob?.cancel()
        _step.value = DissolveStep.Idle
    }

    fun reset() {
        dissolveJob?.cancel()
        _step.value = DissolveStep.Idle
    }

    private suspend fun collectAllFiles(
        dirId: String,
        listFiles: suspend (parentId: String) -> List<CloudFileEntry>
    ): List<CloudFileEntry> {
        val result = mutableListOf<CloudFileEntry>()
        val queue = ArrayDeque<String>()
        queue.add(dirId)

        while (queue.isNotEmpty()) {
            val currentId = queue.removeFirst()
            val items = listFiles(currentId)
            for (item in items) {
                if (item.isDirectory) {
                    queue.add(item.fileId)
                } else {
                    result.add(item)
                }
            }
        }
        return result
    }

    private fun ensureActive() {
        val job = dissolveJob
        if (job?.isActive != true) throw CancellationException("Dissolve cancelled")
    }
}

data class CloudFileEntry(
    val fileId: String,
    val name: String,
    val parentId: String,
    val isDirectory: Boolean = false
)
