package com.example.localmovielibrarz.ui.cloud

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.cloud115.Cloud115FileItem

/**
 * 问题 D 13.4：115 网盘列表页。
 *
 * 顶部操作栏新增「工具箱」按钮，弹 ModalBottomSheet。
 * 搜索框旁加「当前目录/全局」SingleChoiceSegmentedButtonRow。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloudBrowserScreen(
    files: List<Cloud115FileItem>,
    isLoading: Boolean,
    isSearching: Boolean,
    searchScope: CloudBrowserViewModel.SearchScope,
    currentPath: String,
    onSearch: (String) -> Unit,
    onExitSearch: () -> Unit,
    onSearchScopeChange: (CloudBrowserViewModel.SearchScope) -> Unit,
    onFileClick: (Cloud115FileItem) -> Unit,
    onToolboxClick: () -> Unit,
    onBack: () -> Unit
) {
    var searchText by remember { mutableStateOf("") }
    var showToolbox by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isSearching) "搜索结果" else currentPath,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    if (isSearching) {
                        TextButton(onClick = {
                            searchText = ""
                            onExitSearch()
                        }) { Text("取消") }
                    } else {
                        TextButton(onClick = onBack) { Text("返回") }
                    }
                },
                actions = {
                    OutlinedButton(
                        onClick = { showToolbox = true },
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("工具箱")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // 搜索栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    placeholder = { Text("搜索文件…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        imeAction = androidx.compose.ui.text.input.ImeAction.Search
                    ),
                    keyboardActions = androidx.compose.ui.text.input.KeyboardActions(
                        onSearch = { onSearch(searchText) }
                    )
                )
            }

            // 搜索范围切换
            if (isSearching || searchText.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = searchScope == CloudBrowserViewModel.SearchScope.CURRENT_DIR,
                            onClick = { onSearchScopeChange(CloudBrowserViewModel.SearchScope.CURRENT_DIR) },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) {
                            Text("当前目录")
                        }
                        SegmentedButton(
                            selected = searchScope == CloudBrowserViewModel.SearchScope.GLOBAL,
                            onClick = { onSearchScopeChange(CloudBrowserViewModel.SearchScope.GLOBAL) },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) {
                            Text("全局")
                        }
                    }
                }
            }

            // 加载指示
            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // 文件列表
            if (files.isEmpty() && !isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "暂无文件",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(files, key = { it.fileId }) { file ->
                        FileItemRow(file = file, onClick = { onFileClick(file) })
                    }
                }
            }
        }
    }

    // 工具箱 ModalBottomSheet
    if (showToolbox) {
        ModalBottomSheet(onDismissRequest = { showToolbox = false }) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "工具箱",
                    style = MaterialTheme.typography.headlineSmall
                )

                // 文件清理
                ToolCard(
                    icon = Icons.Default.CleaningServices,
                    title = "文件清理",
                    description = "按关键词/后缀扫描并清理文件",
                    onClick = {
                        showToolbox = false
                        onToolboxClick()
                    }
                )

                // 空文件夹清理
                ToolCard(
                    icon = Icons.Default.FolderOff,
                    title = "空文件夹清理",
                    description = "递归扫描空文件夹，批量移入回收站",
                    onClick = {
                        showToolbox = false
                        onToolboxClick()
                    }
                )
            }
        }
    }
}

@Composable
private fun FileItemRow(
    file: Cloud115FileItem,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = {
            Text(
                file.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        supportingContent = {
            if (!file.isDirectory && file.size > 0) {
                Text(
                    formatSize(file.size),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        leadingContent = {
            Icon(
                if (file.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                contentDescription = null,
                tint = if (file.isDirectory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun ToolCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "${bytes}B"
    if (bytes < 1024 * 1024) return "${bytes / 1024}KB"
    if (bytes < 1024 * 1024 * 1024) return "${bytes / (1024 * 1024)}MB"
    return "${bytes / (1024 * 1024 * 1024)}GB"
}
