package com.example.localmovielibrarz.ui.guangya

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.cloudguangya.GuangyaQrRenderer

/**
 * 光鸭登录面板（问题 E）。
 *
 * 顶部「短信登录 / 扫码登录」切换 Tab，两种方式共存。
 * 任一成功即进入登录态；登出同时清空两种来源令牌。
 */
@Composable
fun GuangyaLoginPanel(
    isLoggedIn: Boolean,
    phone: String,
    code: String,
    smsStep: GuangyaLoginViewModel.SmsStep,
    smsError: String?,
    codeCountdown: Int,
    qrStep: GuangyaLoginViewModel.QrStep,
    qrPayload: String?,
    qrError: String?,
    onUpdatePhone: (String) -> Unit,
    onUpdateCode: (String) -> Unit,
    onSendCode: () -> Unit,
    onLoginWithCode: () -> Unit,
    onInitQr: () -> Unit,
    onRefreshQr: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "光鸭云盘",
                style = MaterialTheme.typography.titleMedium
            )

            if (isLoggedIn) {
                // 已登录状态
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "已登录",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedButton(onClick = onLogout) {
                        Text("退出登录")
                    }
                }
            } else {
                // Tab 切换
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("短信登录") },
                        icon = { Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            if (qrStep == GuangyaLoginViewModel.QrStep.IDLE) {
                                onInitQr()
                            }
                        },
                        text = { Text("扫码登录") },
                        icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                when (selectedTab) {
                    0 -> SmsLoginTab(
                        phone = phone,
                        code = code,
                        smsStep = smsStep,
                        smsError = smsError,
                        codeCountdown = codeCountdown,
                        onUpdatePhone = onUpdatePhone,
                        onUpdateCode = onUpdateCode,
                        onSendCode = onSendCode,
                        onLoginWithCode = onLoginWithCode
                    )
                    1 -> QrLoginTab(
                        qrStep = qrStep,
                        qrPayload = qrPayload,
                        qrError = qrError,
                        onRefreshQr = onRefreshQr
                    )
                }
            }
        }
    }
}

@Composable
private fun SmsLoginTab(
    phone: String,
    code: String,
    smsStep: GuangyaLoginViewModel.SmsStep,
    smsError: String?,
    codeCountdown: Int,
    onUpdatePhone: (String) -> Unit,
    onUpdateCode: (String) -> Unit,
    onSendCode: () -> Unit,
    onLoginWithCode: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = phone,
            onValueChange = onUpdatePhone,
            label = { Text("手机号") },
            singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Next
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = code,
                onValueChange = onUpdateCode,
                label = { Text("验证码") },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = onSendCode,
                enabled = codeCountdown == 0 &&
                    phone.isNotBlank() &&
                    smsStep != GuangyaLoginViewModel.SmsStep.SENDING_CODE &&
                    smsStep != GuangyaLoginViewModel.SmsStep.LOGGING_IN
            ) {
                Text(if (codeCountdown > 0) "${codeCountdown}s" else "获取验证码")
            }
        }

        smsError?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        Button(
            onClick = onLoginWithCode,
            modifier = Modifier.fillMaxWidth(),
            enabled = phone.isNotBlank() &&
                code.isNotBlank() &&
                smsStep != GuangyaLoginViewModel.SmsStep.SENDING_CODE &&
                smsStep != GuangyaLoginViewModel.SmsStep.LOGGING_IN
        ) {
            Text(
                when (smsStep) {
                    GuangyaLoginViewModel.SmsStep.SENDING_CODE -> "发送中…"
                    GuangyaLoginViewModel.SmsStep.LOGGING_IN -> "登录中…"
                    else -> "登录"
                }
            )
        }
    }
}

@Composable
private fun QrLoginTab(
    qrStep: GuangyaLoginViewModel.QrStep,
    qrPayload: String?,
    qrError: String?,
    onRefreshQr: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        when {
            qrPayload != null && qrStep != GuangyaLoginViewModel.QrStep.EXPIRED -> {
                // 显示二维码
                val bitmap = remember(qrPayload) {
                    GuangyaQrRenderer.renderQrCode(qrPayload, 400)
                }
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "登录二维码",
                    modifier = Modifier.size(240.dp)
                )
            }
            qrStep == GuangyaLoginViewModel.QrStep.EXPIRED -> {
                Text(
                    text = "二维码已过期",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error
                )
            }
            qrStep == GuangyaLoginViewModel.QrStep.ERROR -> {
                Text(
                    text = qrError ?: "扫码暂不可用，请用短信登录",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
            else -> {
                CircularProgressIndicator(modifier = Modifier.size(48.dp))
            }
        }

        // 状态文字
        when (qrStep) {
            GuangyaLoginViewModel.QrStep.PENDING -> {
                Text(
                    "等待扫码确认…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            GuangyaLoginViewModel.QrStep.SLOW_DOWN -> {
                Text(
                    "轮询过快，自动调整中…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            GuangyaLoginViewModel.QrStep.LOGGED_IN -> {
                Text(
                    "登录成功",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            else -> {}
        }

        // 刷新按钮
        if (qrStep == GuangyaLoginViewModel.QrStep.EXPIRED ||
            qrStep == GuangyaLoginViewModel.QrStep.ERROR
        ) {
            OutlinedButton(
                onClick = onRefreshQr,
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("刷新二维码")
            }
        }
    }
}
