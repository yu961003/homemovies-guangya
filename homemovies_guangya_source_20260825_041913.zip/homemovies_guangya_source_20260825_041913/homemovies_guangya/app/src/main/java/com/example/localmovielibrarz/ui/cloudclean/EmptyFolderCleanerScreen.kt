package com.example.localmovielibrarz.ui.cloudclean

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * 问题 D 13.2：空文件夹清理页面。
 */
@Composable
fun EmptyFolderCleanerScreen(
    step: EmptyFolderCleanerViewModel.CleanStep,
    selectedIds: Set<String>,
    candidates: List<EmptyFolderCandidate>,
    onToggleSelection: (String) -> Unit,
    onSelectAll: () -> Unit,
    onSelectNone: () -> Unit,
    onScan: () -> Unit,
    onClean: () -> Unit,
    onCancelScan: () -> Unit,
    onCancelClean: () -> Unit,
    onBack: () -> Unit
) {
    var showCleanDialog by remember { mutableStateOf(false) }

    val isScanning = step is EmptyFolderCleanerViewModel.CleanStep.Scanning
    val isCleaning = step is EmptyFolderCleanerViewModel.CleanStep.Cleaning

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("空文件夹清理") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 说明
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Default.FolderOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "递归扫描指定目录下的空文件夹，" +
                            "二次确认后批量移入回收站。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // 进度
            when (step) {
                is EmptyFolderCleanerViewModel.CleanStep.Scanning -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        "已扫描 ${step.scanned} 个目录，发现 ${step.found} 个空文件夹",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is EmptyFolderCleanerViewModel.CleanStep.Cleaning -> {
                    val progress = if (step.total > 0) step.cleaned.toFloat() / step.total else 0f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "正在清理 ${step.cleaned}/${step.total}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is EmptyFolderCleanerViewModel.CleanStep.Done -> {
                    Text(
                        "清理完成：已移入回收站 ${step.cleanedCount} 个空文件夹",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                is EmptyFolderCleanerViewModel.CleanStep.Error -> {
                    Text(
                        "错误：${step.message}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> {}
            }

            // 候选列表
            if (step is EmptyFolderCleanerViewModel.CleanStep.Found && candidates.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "共 ${candidates.size} 个空文件夹",
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onSelectAll) { Text("全选") }
                    TextButton(onClick = onSelectNone) { Text("取消全选") }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(candidates, key = { it.fileId }) { candidate ->
                        val isSelected = candidate.fileId in selectedIds
                        ListItem(
                            headlineContent = {
                                Text(
                                    candidate.name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            supportingContent = {
                                Text(
                                    candidate.path,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            leadingContent = {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { onToggleSelection(candidate.fileId) }
                                )
                            }
                        )
                    }
                }

                Button(
                    onClick = { showCleanDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedIds.isNotEmpty()
                ) {
                    Text("移到回收站（${selectedIds.size}）")
                }
            } else if (step is EmptyFolderCleanerViewModel.CleanStep.Found && candidates.isEmpty()) {
                Text(
                    "未发现空文件夹",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // 操作按钮
            when {
                isScanning -> {
                    OutlinedButton(
                        onClick = onCancelScan,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("取消扫描") }
                }
                isCleaning -> {
                    OutlinedButton(
                        onClick = onCancelClean,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("停止清理") }
                }
                step !is EmptyFolderCleanerViewModel.CleanStep.Found -> {
                    Button(
                        onClick = onScan,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("开始扫描") }
                }
            }
        }
    }

    // 二次确认
    if (showCleanDialog) {
        AlertDialog(
            onDismissRequest = { showCleanDialog = false },
            title = { Text("确认清理") },
            text = {
                Text("确定将选中的 ${selectedIds.size} 个空文件夹移入回收站吗？\n" +
                    "此操作可从回收站恢复。")
            },
            confirmButton = {
                TextButton(onClick = {
                    showCleanDialog = false
                    onClean()
                }) { Text("确认移入回收站") }
            },
            dismissButton = {
                TextButton(onClick = { showCleanDialog = false }) { Text("取消") }
            }
        )
    }
}
