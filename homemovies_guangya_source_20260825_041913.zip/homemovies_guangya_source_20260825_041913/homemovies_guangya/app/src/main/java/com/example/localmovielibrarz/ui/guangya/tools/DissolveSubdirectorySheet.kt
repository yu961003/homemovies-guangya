package com.example.localmovielibrarz.ui.guangya.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * 问题 C：解散子目录 ModalBottomSheet。
 *
 * 显示选中目录名和文件数量、进度、重名策略选择、二次确认。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DissolveSubdirectorySheet(
    dirName: String,
    dirId: String,
    parentDirId: String,
    onDismiss: () -> Unit,
    onConfirm: (DissolveSubdirectoryViewModel.ConflictPolicy) -> Unit,
    step: DissolveSubdirectoryViewModel.DissolveStep,
    onCancel: () -> Unit
) {
    var showConfirmDialog by remember { mutableStateOf(false) }
    var conflictPolicy by remember {
        mutableStateOf(DissolveSubdirectoryViewModel.ConflictPolicy.SKIP)
    }

    val isRunning = step is DissolveSubdirectoryViewModel.DissolveStep.Scanning ||
        step is DissolveSubdirectoryViewModel.DissolveStep.Moving ||
        step is DissolveSubdirectoryViewModel.DissolveStep.Cleaning

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "解散子目录",
                style = MaterialTheme.typography.headlineSmall
            )

            Text(
                text = "目录：$dirName",
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "将该目录下的所有子文件移动到上级目录，" +
                    "完成后删除空目录。重名文件按所选策略处理。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // 重名策略选择
            Text(
                text = "重名处理策略",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier.selectableGroup(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DissolveSubdirectoryViewModel.ConflictPolicy.entries.forEach { policy ->
                    FilterChip(
                        selected = conflictPolicy == policy,
                        onClick = { conflictPolicy = policy },
                        label = {
                            Text(
                                when (policy) {
                                    DissolveSubdirectoryViewModel.ConflictPolicy.SKIP -> "跳过"
                                    DissolveSubdirectoryViewModel.ConflictPolicy.OVERWRITE -> "覆盖"
                                    DissolveSubdirectoryViewModel.ConflictPolicy.RENAME -> "重命名"
                                }
                            )
                        },
                        enabled = !isRunning
                    )
                }
            }

            // 进度显示
            when (step) {
                is DissolveSubdirectoryViewModel.DissolveStep.Scanning -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("正在扫描文件…", style = MaterialTheme.typography.bodySmall)
                }
                is DissolveSubdirectoryViewModel.DissolveStep.Moving -> {
                    val progress = if (step.total > 0) step.moved.toFloat() / step.total else 0f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("已移动 ${step.moved}/${step.total} 个文件", style = MaterialTheme.typography.bodySmall)
                }
                is DissolveSubdirectoryViewModel.DissolveStep.Cleaning -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("正在清理空目录…", style = MaterialTheme.typography.bodySmall)
                }
                is DissolveSubdirectoryViewModel.DissolveStep.Done -> {
                    Text(
                        text = "完成：移动 ${step.movedCount} 个文件，" +
                            "清理 ${step.cleanedDirs} 个空目录，" +
                            "跳过 ${step.skipped} 个重名文件",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                is DissolveSubdirectoryViewModel.DissolveStep.Error -> {
                    Text(
                        text = "错误：${step.message}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> {}
            }

            // 操作按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (isRunning) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消")
                    }
                } else {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("关闭")
                    }
                    if (step !is DissolveSubdirectoryViewModel.DissolveStep.Done &&
                        step !is DissolveSubdirectoryViewModel.DissolveStep.Error
                    ) {
                        Button(
                            onClick = { showConfirmDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("开始解散")
                        }
                    }
                }
            }
        }
    }

    // 二次确认对话框
    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = { Text("确认解散目录") },
            text = {
                Text("确定要将「$dirName」下的所有文件移动到上级目录并删除空目录吗？\n" +
                    "重名策略：${
                        when (conflictPolicy) {
                            DissolveSubdirectoryViewModel.ConflictPolicy.SKIP -> "跳过"
                            DissolveSubdirectoryViewModel.ConflictPolicy.OVERWRITE -> "覆盖"
                            DissolveSubdirectoryViewModel.ConflictPolicy.RENAME -> "重命名"
                        }
                    }")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmDialog = false
                        onConfirm(conflictPolicy)
                    }
                ) {
                    Text("确认解散")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
}
