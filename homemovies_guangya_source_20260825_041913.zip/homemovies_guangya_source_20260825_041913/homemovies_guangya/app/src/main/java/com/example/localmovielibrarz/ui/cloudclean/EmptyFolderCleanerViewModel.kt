package com.example.localmovielibrarz.ui.cloudclean

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 问题 D 13.2：空文件夹清理 ViewModel。
 *
 * DFS 递归 listFiles，子项为空→空候选；
 * 对候选二次 listFiles 确认无子项（防止并发修改）；
 * 批量删除进回收站（≤50/批）。
 */
class EmptyFolderCleanerViewModel : ViewModel() {

    sealed interface CleanStep {
        data object Idle : CleanStep
        data class Scanning(val scanned: Int, val found: Int) : CleanStep
        data class Found(val candidates: List<EmptyFolderCandidate>) : CleanStep
        data class Cleaning(val cleaned: Int, val total: Int) : CleanStep
        data class Done(val cleanedCount: Int) : CleanStep
        data class Error(val message: String) : CleanStep
    }

    private val _step = MutableStateFlow<CleanStep>(CleanStep.Idle)
    val step: StateFlow<CleanStep> = _step.asStateFlow()

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds.asStateFlow()

    private var scanJob: Job? = null
    private var cleanJob: Job? = null

    private var candidates: List<EmptyFolderCandidate> = emptyList()

    fun toggleSelection(fileId: String) {
        _selectedIds.value = _selectedIds.value.toMutableSet().apply {
            if (contains(fileId)) remove(fileId) else add(fileId)
        }
    }

    fun selectAll() {
        _selectedIds.value = candidates.map { it.fileId }.toSet()
    }

    fun selectNone() {
        _selectedIds.value = emptySet()
    }

    /**
     * @param listFiles 返回指定 cid 下的文件列表。
     * @param recycleFiles 将文件放入回收站。
     */
    fun scanEmptyFolders(
        rootCid: Long,
        rootName: String,
        listFiles: suspend (cid: Long) -> List<FolderEntry>,
        recycleFiles: suspend (fileIds: List<String>) -> Boolean
    ) {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            try {
                _step.value = CleanStep.Scanning(0, 0)
                val found = mutableListOf<EmptyFolderCandidate>()
                var scanned = 0
                val stack = ArrayDeque<Pair<Long, String>>()
                stack.addLast(rootCid to rootName)

                while (stack.isNotEmpty()) {
                    ensureActive()
                    val (currentCid, currentName) = stack.removeLast()
                    val items = withContext(Dispatchers.IO) { listFiles(currentCid) }
                    scanned++

                    if (items.isEmpty()) {
                        // 空候选：二次确认
                        val recheck = withContext(Dispatchers.IO) { listFiles(currentCid) }
                        if (recheck.isEmpty()) {
                            found.add(EmptyFolderCandidate(
                                fileId = currentCid.toString(),
                                name = currentName,
                                cid = currentCid,
                                path = currentName
                            ))
                        }
                    } else {
                        // 递归子目录
                        items.filter { it.isDirectory }.forEach { sub ->
                            stack.addLast(sub.cid to "$currentName/${sub.name}")
                        }
                    }

                    _step.value = CleanStep.Scanning(scanned, found.size)
                }

                candidates = found
                _step.value = CleanStep.Found(found)
            } catch (e: CancellationException) {
                _step.value = CleanStep.Idle
            } catch (e: Exception) {
                _step.value = CleanStep.Error(e.message ?: "扫描失败")
            }
        }
    }

    fun cleanSelected(
        recycleFiles: suspend (fileIds: List<String>) -> Boolean
    ) {
        val toClean = _selectedIds.value.toList()
        if (toClean.isEmpty()) return

        cleanJob?.cancel()
        cleanJob = viewModelScope.launch {
            try {
                _step.value = CleanStep.Cleaning(0, toClean.size)
                var cleaned = 0
                val batchSize = 50

                for (batch in toClean.chunked(batchSize)) {
                    ensureActive()
                    val success = withContext(Dispatchers.IO) { recycleFiles(batch) }
                    if (success) cleaned += batch.size
                    _step.value = CleanStep.Cleaning(cleaned, toClean.size)
                }

                _step.value = CleanStep.Done(cleaned)
            } catch (e: CancellationException) {
                _step.value = CleanStep.Idle
            } catch (e: Exception) {
                _step.value = CleanStep.Error(e.message ?: "清理失败")
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        _step.value = CleanStep.Idle
    }

    fun cancelClean() {
        cleanJob?.cancel()
        _step.value = CleanStep.Found(candidates)
    }

    fun reset() {
        scanJob?.cancel()
        cleanJob?.cancel()
        candidates = emptyList()
        _selectedIds.value = emptySet()
        _step.value = CleanStep.Idle
    }

    private fun ensureActive() {
        val job = scanJob ?: cleanJob
        if (job?.isActive != true) throw CancellationException("Cancelled")
    }
}

data class EmptyFolderCandidate(
    val fileId: String,
    val name: String,
    val cid: Long,
    val path: String
)

data class FolderEntry(
    val cid: Long,
    val name: String,
    val isDirectory: Boolean
)
