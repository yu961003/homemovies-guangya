package com.example.localmovielibrarz.cloudguangya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * 光鸭登录客户端。
 *
 * 包含两套登录方式：
 * 1. 短信验证码登录（smsInit → sendVerificationCode → verifyCode → signin）
 * 2. 扫码登录（qrInit → qrPoll），采用 OAuth Device Code 流程。
 *
 * 两者共存，任一成功即获得令牌，令牌共用 GuangyaTokenStore 存储。
 */
class GuangyaLoginClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    private val deviceId: String = UUID.randomUUID().toString()

    // ===== 短信登录 =====

    suspend fun smsInit(phone: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("phone", phone)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.SMS_INIT_PATH}", body)
        resp.optString("captcha_token")
    }

    suspend fun sendVerificationCode(phone: String, captchaToken: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("phone", phone)
            put("captcha_token", captchaToken)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.SMS_SEND_PATH}", body)
        resp.optString("verification_id")
    }

    suspend fun verifyCode(verificationId: String, code: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("verification_id", verificationId)
            put("code", code)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.SMS_VERIFY_PATH}", body)
        resp.optString("verification_token")
    }

    suspend fun signin(verificationToken: String): GuangyaTokenPair = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("verification_token", verificationToken)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.SMS_SIGNIN_PATH}", body)
        parseTokenPair(resp)
    }

    // ===== 扫码登录（OAuth Device Code） =====

    /**
     * 初始化扫码登录，获取设备码和二维码内容。
     *
     * POST /v1/auth/device/code
     * body: {"scope": "user", "client_id": CLIENT_ID}
     * 解析：device_code, verification_uri_complete（二维码内容）
     */
    suspend fun qrInit(): GuangyaQrSession = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("scope", "user")
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.DEVICE_CODE_PATH}", body)

        val deviceCode = resp.optString("device_code")
        val qrPayload = resp.optString("verification_uri_complete")

        if (deviceCode.isBlank() || qrPayload.isBlank()) {
            throw GuangyaLoginException("扫码初始化失败：服务端未返回 device_code 或 verification_uri_complete")
        }

        GuangyaQrSession(deviceCode = deviceCode, qrPayload = qrPayload)
    }

    /**
     * 轮询扫码登录状态。
     *
     * POST /v1/auth/token
     * body: {"grant_type": "urn:ietf:params:oauth:grant-type:device_code", "device_code": deviceCode, "client_id": CLIENT_ID}
     *
     * 返回：
     * - Success: 获得 access_token / refresh_token
     * - Pending: authorization_pending（等待确认）
     * - SlowDown: slow_down（轮询过快，需降频）
     * - Expired: expired_token（二维码过期）
     */
    suspend fun qrPoll(deviceCode: String): GuangyaQrPollResult = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
            put("device_code", deviceCode)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }

        val resp = try {
            postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.TOKEN_PATH}", body)
        } catch (e: Exception) {
            // 网络错误时返回 Pending，让调用方继续重试
            return@withContext GuangyaQrPollResult.Pending
        }

        // 检查是否有 access_token
        val accessToken = resp.optString("access_token", "")
        if (accessToken.isNotBlank()) {
            val tokenPair = parseTokenPair(resp)
            return@withContext GuangyaQrPollResult.Success(tokenPair)
        }

        // 检查错误码
        val error = resp.optString("error", "")
        when (error) {
            "authorization_pending" -> GuangyaQrPollResult.Pending
            "slow_down" -> GuangyaQrPollResult.SlowDown
            "expired_token" -> GuangyaQrPollResult.Expired
            "access_denied" -> GuangyaQrPollResult.Expired // 用户拒绝，视为过期
            else -> {
                // 未知错误，返回 Pending 继续轮询
                if (resp.optInt("code", -1) == 404 || resp.optString("message", "").contains("404")) {
                    // 新端点仍 404，降级提示
                    throw GuangyaLoginException("扫码登录暂不可用（服务端未支持），请使用短信登录")
                }
                GuangyaQrPollResult.Pending
            }
        }
    }

    // ===== 刷新令牌 =====

    suspend fun refreshToken(refreshToken: String): GuangyaTokenPair = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("grant_type", "refresh_token")
            put("refresh_token", refreshToken)
            put("client_id", GuangyaConstants.CLIENT_ID)
        }
        val resp = postJson("${GuangyaConstants.ACCOUNT_BASE}${GuangyaConstants.TOKEN_PATH}", body)
        parseTokenPair(resp)
    }

    // ===== 内部方法 =====

    private fun accountHeaders(): Map<String, String> = mapOf(
        GuangyaConstants.HEADER_CLIENT_ID to GuangyaConstants.CLIENT_ID,
        GuangyaConstants.HEADER_DEVICE_ID to deviceId,
        GuangyaConstants.HEADER_CLIENT_VERSION to GuangyaConstants.CLIENT_VERSION,
        GuangyaConstants.HEADER_PROTOCOL_VERSION to GuangyaConstants.HEADER_PROTOCOL_VERSION_VALUE,
        "Content-Type" to GuangyaConstants.MEDIA_TYPE_JSON,
        "User-Agent" to "GuangyaApp/${GuangyaConstants.CLIENT_VERSION} Android"
    )

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val requestBody = body.toString()
            .toRequestBody(GuangyaConstants.MEDIA_TYPE_JSON.toMediaType())

        val requestBuilder = Request.Builder()
            .url(url)
            .post(requestBody)

        accountHeaders().forEach { (key, value) ->
            requestBuilder.header(key, value)
        }

        val response = client.newCall(requestBuilder.build()).execute()
        val responseBody = response.body?.string()
            ?: throw GuangyaLoginException("服务端返回空响应")

        val json = JSONObject(responseBody)

        // 检查业务错误
        val code = json.optInt("code", 0)
        if (code != 0 && json.has("error")) {
            throw GuangyaLoginException(json.optString("error_description", json.optString("message", "登录失败")))
        }

        return json
    }

    private fun parseTokenPair(json: JSONObject): GuangyaTokenPair {
        val accessToken = json.optString("access_token")
        val refreshToken = json.optString("refresh_token")
        val expiresIn = json.optLong("expires_in", 3600L)
        val expiresAt = System.currentTimeMillis() / 1000 + expiresIn

        if (accessToken.isBlank()) {
            throw GuangyaLoginException("服务端未返回 access_token")
        }

        return GuangyaTokenPair(accessToken, refreshToken, expiresAt)
    }
}

// ===== 数据类 =====

data class GuangyaQrSession(
    val deviceCode: String,
    val qrPayload: String
)

sealed interface GuangyaQrPollResult {
    data class Success(val tokenPair: GuangyaTokenPair) : GuangyaQrPollResult
    data object Pending : GuangyaQrPollResult
    data object SlowDown : GuangyaQrPollResult
    data object Expired : GuangyaQrPollResult
}

class GuangyaLoginException(message: String) : Exception(message)
