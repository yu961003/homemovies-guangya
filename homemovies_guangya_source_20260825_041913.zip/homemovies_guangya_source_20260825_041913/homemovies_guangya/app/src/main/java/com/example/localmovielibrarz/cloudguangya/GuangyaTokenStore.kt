package com.example.localmovielibrarz.cloudguangya

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 光鸭令牌加密存储。
 *
 * 短信登录与扫码登录共用同一套令牌存储。
 * 使用 EncryptedSharedPreferences 加密存储，顺手修了 115 明文存 Cookie 的问题。
 */
class GuangyaTokenStore private constructor(
    private val prefs: android.content.SharedPreferences
) {
    companion object {
        private const val PREFS_NAME = "guangya_token_store"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"

        @Volatile
        private var instance: GuangyaTokenStore? = null

        fun get(context: Context): GuangyaTokenStore {
            return instance ?: synchronized(this) {
                instance ?: run {
                    val masterKey = MasterKey.Builder(context)
                        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                        .build()
                    val prefs = EncryptedSharedPreferences.create(
                        context,
                        PREFS_NAME,
                        masterKey,
                        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                    )
                    GuangyaTokenStore(prefs).also { instance = it }
                }
            }
        }
    }

    fun save(tokenPair: GuangyaTokenPair) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, tokenPair.accessToken)
            .putString(KEY_REFRESH_TOKEN, tokenPair.refreshToken)
            .putLong(KEY_EXPIRES_AT, tokenPair.expiresAt)
            .apply()
    }

    fun get(): GuangyaTokenPair? {
        val accessToken = prefs.getString(KEY_ACCESS_TOKEN, null) ?: return null
        val refreshToken = prefs.getString(KEY_REFRESH_TOKEN, null) ?: return null
        val expiresAt = prefs.getLong(KEY_EXPIRES_AT, 0L)
        return GuangyaTokenPair(accessToken, refreshToken, expiresAt)
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    fun isLoggedIn(): Boolean = get() != null
}

data class GuangyaTokenPair(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Long = System.currentTimeMillis() / 1000 + 3600L
)
