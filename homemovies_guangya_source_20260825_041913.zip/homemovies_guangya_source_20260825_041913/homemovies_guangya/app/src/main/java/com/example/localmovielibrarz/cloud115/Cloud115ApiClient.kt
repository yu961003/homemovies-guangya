package com.example.localmovielibrarz.cloud115

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * 115 网盘 API 客户端。
 *
 * 问题 D 修复：
 * - searchFiles 新增可选 cid 参数，支持「当前目录」范围搜索
 * - 保留 listFiles / moveFiles / recycleFiles / deleteFileByPickcode
 */
class Cloud115ApiClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val API_BASE = "https://proapi.115.com"
        private const val APP_BASE = "https://aps.115.com"

        // 搜索接口
        private const val SEARCH_URL = "$API_BASE/android/search.php"

        // 列目录接口
        private const val LIST_URL = "$API_BASE/android/list.php"

        // 移动文件
        private const val MOVE_URL = "$API_BASE/android/move.php"

        // 删除到回收站
        private const val RECYCLE_URL = "$APP_BASE/android/recycle.php"

        // 按 pickcode 删除
        private const val DELETE_URL = "$APP_BASE/android/delete.php"
    }

    private var cookie: String = ""

    fun setCookie(cookie: String) {
        this.cookie = cookie
    }

    fun getCookie(): String = cookie

    /**
     * 搜索文件。
     *
     * @param keyword 搜索关键词
     * @param limit 每页数量
     * @param offset 偏移量
     * @param type 文件类型（0=全部, 1=文件夹, 2=文件）
     * @param cid 目录ID，传入时限定在该目录内搜索（当前目录模式）；
     *            为 null 时全局搜索
     */
    suspend fun searchFiles(
        keyword: String,
        limit: Int = 50,
        offset: Int = 0,
        type: Int = 0,
        cid: Long? = null
    ): Cloud115SearchResult = withContext(Dispatchers.IO) {
        val params = buildString {
            append("search_value=")
            append(URLEncoder.encode(keyword, "UTF-8"))
            append("&limit=$limit")
            append("&offset=$offset")
            append("&type=$type")
            append("&format=json")
            if (cid != null) {
                append("&cid=$cid")
            }
        }
        val url = "$SEARCH_URL?$params"
        val response = fetchJson(url)
        parseSearchResult(response)
    }

    /**
     * 列出目录文件。
     */
    suspend fun listFiles(
        cid: Long,
        limit: Int = 50,
        offset: Int = 0
    ): Cloud115FileListResult = withContext(Dispatchers.IO) {
        val url = "$LIST_URL?cid=$cid&limit=$limit&offset=$offset&format=json&o=user_ptime&asc=0"
        val response = fetchJson(url)
        parseFileListResult(response)
    }

    /**
     * 移动文件到目标目录。
     */
    suspend fun moveFiles(
        fileIds: List<String>,
        targetParentId: Long
    ): List<String> = withContext(Dispatchers.IO) {
        if (fileIds.isEmpty()) return@withContext emptyList()
        val body = JSONObject().apply {
            put("pid", targetParentId.toString())
            put("fid", JSONArray(fileIds))
            put("move_pid", targetParentId.toString())
        }
        val request = Request.Builder()
            .url(MOVE_URL)
            .header("Cookie", cookie)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .post(body.toString().toRequestBody("application/x-www-form-urlencoded".toMediaType()))
            .build()

        val resp = client.newCall(request).execute()
        val json = resp.body?.string() ?: ""
        val result = JSONObject(json)
        if (result.optInt("state", 0) == 1 || result.opt("data") != null) {
            fileIds
        } else {
            emptyList()
        }
    }

    /**
     * 将文件放入回收站。
     */
    suspend fun recycleFiles(fileIds: List<String>): Boolean = withContext(Dispatchers.IO) {
        if (fileIds.isEmpty()) return@withContext false
        val body = JSONObject().apply {
            put("fid", JSONArray(fileIds))
        }
        val request = Request.Builder()
            .url(RECYCLE_URL)
            .header("Cookie", cookie)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .post(body.toString().toRequestBody("application/x-www-form-urlencoded".toMediaType()))
            .build()

        val resp = client.newCall(request).execute()
        val json = resp.body?.string() ?: ""
        JSONObject(json).optInt("state", 0) == 1
    }

    /**
     * 按 pickcode 删除文件（进回收站）。
     */
    suspend fun deleteFileByPickcode(pickcode: String): Boolean = withContext(Dispatchers.IO) {
        val url = "$DELETE_URL?pickcode=$pickcode&format=json"
        val request = Request.Builder()
            .url(url)
            .header("Cookie", cookie)
            .get()
            .build()

        val resp = client.newCall(request).execute()
        val json = resp.body?.string() ?: ""
        JSONObject(json).optInt("state", 0) == 1
    }

    private fun fetchJson(url: String): JSONObject {
        val request = Request.Builder()
            .url(url)
            .header("Cookie", cookie)
            .header("User-Agent", "115App/9.0.0")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: ""
        return JSONObject(body)
    }

    private fun parseSearchResult(json: JSONObject): Cloud115SearchResult {
        val data = json.optJSONObject("data") ?: return Cloud115SearchResult(emptyList(), 0)
        val array = data.optJSONArray("list") ?: return Cloud115SearchResult(emptyList(), 0)
        val files = (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            Cloud115FileItem(
                fileId = item.optString("fid"),
                name = item.optString("n"),
                parentId = item.optString("pid").toLongOrNull() ?: 0L,
                isDirectory = item.optInt("fc", 0) == 1 || item.optInt("file_category", 0) == 0,
                size = item.optLong("s", 0L),
                pickcode = item.optString("pc"),
                updateTime = item.optLong("te", 0L)
            )
        }
        val total = data.optInt("count", files.size)
        return Cloud115SearchResult(files, total)
    }

    private fun parseFileListResult(json: JSONObject): Cloud115FileListResult {
        val data = json.optJSONObject("data") ?: return Cloud115FileListResult(emptyList(), 0)
        val array = data.optJSONArray("list") ?: return Cloud115FileListResult(emptyList(), 0)
        val files = (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            Cloud115FileItem(
                fileId = item.optString("fid"),
                name = item.optString("n"),
                parentId = item.optString("pid").toLongOrNull() ?: 0L,
                isDirectory = item.optInt("fc", 0) == 1 || item.optInt("file_category", 0) == 0,
                size = item.optLong("s", 0L),
                pickcode = item.optString("pc"),
                updateTime = item.optLong("te", 0L)
            )
        }
        val total = data.optInt("count", files.size)
        return Cloud115FileListResult(files, total)
    }
}

data class Cloud115FileItem(
    val fileId: String,
    val name: String,
    val parentId: Long,
    val isDirectory: Boolean,
    val size: Long,
    val pickcode: String,
    val updateTime: Long
)

data class Cloud115SearchResult(
    val files: List<Cloud115FileItem>,
    val total: Int
)

data class Cloud115FileListResult(
    val files: List<Cloud115FileItem>,
    val total: Int
)
