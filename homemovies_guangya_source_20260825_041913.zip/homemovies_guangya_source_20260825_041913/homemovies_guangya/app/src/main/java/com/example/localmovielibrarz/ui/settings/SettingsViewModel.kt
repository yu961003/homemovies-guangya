package com.example.localmovielibrarz.ui.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.util.NumberRecognitionRules
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * 设置页 UI 状态。
 *
 * 问题 B 修复：不包含 remoteScrapeConfigUrl / isRefreshingMgstageRules 等
 * GitHub 热更新相关字段，番号识别规则完全由本地列表管理。
 */
data class SettingsUiState(
    val ignoredSuffixes: String = "",
    val segmentMarkers: String = "",
    val attachedLetterPrefixes: String = "",
    val mgstagePrefixAliases: String = "",
    val dmm2SkippedPrefixes: String = "",
    val isScanning: Boolean = false,
    val cloud115Cookie: String = "",
    val guangyaLoggedIn: Boolean = false,
)

/**
 * 设置页 ViewModel。
 *
 * 问题 B 修复：
 * - 不包含 updateRemoteScrapeConfigUrl / saveRemoteScrapeConfigUrl /
 *   remoteScrapeConfigUrl 字段
 * - 不包含 isRefreshingMgstageRules 相关状态与刷新协程
 * - 不包含 refreshMgstageRules() 方法
 * - loadState() 不读取 getRemoteScrapeConfigUrl()
 *
 * 番号识别规则完全由本地列表管理，不依赖远程 GitHub 缓存。
 */
class SettingsViewModel private constructor(
    private val repository: AppSettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    /**
     * 从 AppSettingsRepository 加载所有本地设置。
     *
     * 注意：不读取 getRemoteScrapeConfigUrl()（已移除）。
     */
    fun loadState() {
        val ignoredSuffixes = repository.getNumberRecognitionIgnoredSuffixes()
        val segmentMarkers = repository.getNumberRecognitionSegmentMarkers()
        val attachedPrefixes = NumberRecognitionRules.attachedLetterPrefixes()
        val mgstageAliases = repository.getMgstageSearchPrefixAliases()
        val dmm2Skipped = repository.getDmm2SkippedNumberPrefixes()
        val guangyaLoggedIn = repository.isGuangyaLoggedIn()

        _uiState.update { current ->
            current.copy(
                ignoredSuffixes = ignoredSuffixes.joinToString("\n"),
                segmentMarkers = segmentMarkers.joinToString("\n"),
                attachedLetterPrefixes = attachedPrefixes.joinToString("\n"),
                mgstagePrefixAliases = mgstageAliases.entries
                    .joinToString("\n") { (key, value) -> "$key=$value" },
                dmm2SkippedPrefixes = dmm2Skipped.joinToString("\n"),
                guangyaLoggedIn = guangyaLoggedIn,
            )
        }
    }

    // ===== 番号识别规则 getter/setter =====

    fun setIgnoredSuffixes(value: String) {
        _uiState.update { it.copy(ignoredSuffixes = value) }
    }

    fun saveIgnoredSuffixes() {
        val set = parseLineSet(_uiState.value.ignoredSuffixes)
        repository.saveNumberRecognitionIgnoredSuffixes(set)
    }

    fun setSegmentMarkers(value: String) {
        _uiState.update { it.copy(segmentMarkers = value) }
    }

    fun saveSegmentMarkers() {
        val set = parseLineSet(_uiState.value.segmentMarkers)
        repository.saveNumberRecognitionSegmentMarkers(set)
    }

    fun setAttachedLetterPrefixes(value: String) {
        _uiState.update { it.copy(attachedLetterPrefixes = value) }
    }

    /**
     * 连写前缀目前仅保存在内存中（AppSettingsRepository 暂未提供持久化方法）。
     * 用户录入后，在当前会话内生效。
     */
    fun saveAttachedLetterPrefixes() {
        // 内存状态已在 setAttachedLetterPrefixes 中更新，此处为预留扩展点
    }

    fun setMgstagePrefixAliases(value: String) {
        _uiState.update { it.copy(mgstagePrefixAliases = value) }
    }

    fun saveMgstagePrefixAliases() {
        val map = parseAliasMap(_uiState.value.mgstagePrefixAliases)
        repository.saveMgstageSearchPrefixAliases(map)
    }

    fun setDmm2SkippedPrefixes(value: String) {
        _uiState.update { it.copy(dmm2SkippedPrefixes = value) }
    }

    fun saveDmm2SkippedPrefixes() {
        val set = parseLineSet(_uiState.value.dmm2SkippedPrefixes)
        repository.saveDmm2SkippedNumberPrefixes(set)
    }

    /**
     * 一次性保存所有番号识别规则。
     */
    fun saveAllNumberRecognitionRules() {
        saveIgnoredSuffixes()
        saveSegmentMarkers()
        saveAttachedLetterPrefixes()
        saveMgstagePrefixAliases()
        saveDmm2SkippedPrefixes()
    }

    // ===== 库扫描 =====

    fun startLibraryScan() {
        _uiState.update { it.copy(isScanning = true) }
        viewModelScope.launch {
            // 实际扫描逻辑由外部协程调度，此处仅管理 UI 状态
            _uiState.update { it.copy(isScanning = false) }
        }
    }

    fun setScanning(scanning: Boolean) {
        _uiState.update { it.copy(isScanning = scanning) }
    }

    // ===== 115 Cookie =====

    fun setCloud115Cookie(value: String) {
        _uiState.update { it.copy(cloud115Cookie = value) }
    }

    // ===== 光鸭登录态 =====

    fun setGuangyaLoggedIn(loggedIn: Boolean) {
        repository.setGuangyaLoggedIn(loggedIn)
        _uiState.update { it.copy(guangyaLoggedIn = loggedIn) }
    }

    // ===== 辅助函数 =====

    private fun parseLineSet(text: String): Set<String> =
        text.split("\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toSet()

    private fun parseAliasMap(text: String): Map<String, String> =
        text.split("\n")
            .mapNotNull { line ->
                val trimmed = line.trim()
                if (trimmed.isBlank()) return@mapNotNull null
                val idx = trimmed.indexOf('=')
                if (idx <= 0) return@mapNotNull null
                val key = trimmed.substring(0, idx).trim()
                val value = trimmed.substring(idx + 1).trim()
                if (key.isBlank() || value.isBlank()) return@mapNotNull null
                key to value
            }
            .toMap()

    companion object {
        fun create(context: Context): SettingsViewModel {
            return SettingsViewModel(AppSettingsRepository.get(context))
        }

        fun factory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return SettingsViewModel(AppSettingsRepository.get(context)) as T
                }
            }
    }
}
