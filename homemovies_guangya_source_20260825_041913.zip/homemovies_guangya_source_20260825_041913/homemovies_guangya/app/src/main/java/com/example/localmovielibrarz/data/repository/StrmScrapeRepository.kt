package com.example.localmovielibrarz.data.repository

import com.example.localmovielibrarz.scraper.MovieNumberExtractor
import com.example.localmovielibrarz.scraper.MovieScraperRegistry
import com.example.localmovielibrarz.scraper.NfoWriter
import com.example.localmovielibrarz.scraper.ScrapedMovieInfo
import com.example.localmovielibrarz.scraper.ScrapeRunResult
import com.example.localmovielibrarz.scraper.ScrapeSource
import com.example.localmovielibrarz.util.NumberRecognitionRules
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File

/**
 * STRM 文件信息。
 */
data class StrmFile(
    val path: String,
    val fileName: String,
)

/**
 * 单个 STRM 文件的刮削结果。
 */
data class StrmScrapeResult(
    val file: StrmFile,
    val number: String?,
    val info: ScrapedMovieInfo?,
    val success: Boolean,
    val error: String?,
)

/**
 * 从 STRM 文件名中提取番号（仅使用本地缓存的识别规则，不依赖远程 GitHub 缓存）。
 *
 * 问题 B 修复：番号识别完全不再从远程 GitHub 拉取规则，
 * [loadCachedRules] 回调仅用于通知调用方"已加载本地缓存规则"，
 * 实际规则来自 [NumberRecognitionRules] 本地默认值。
 */
internal fun extractNumberWithCachedRules(
    values: List<String>,
    extractor: (String, Set<String>) -> String?,
    loadCachedRules: () -> Unit,
): String {
    loadCachedRules()
    val cachedSuffixes = NumberRecognitionRules.ignoredSuffixes()
    return values.firstNotNullOfOrNull { extractor(it, cachedSuffixes) }.orEmpty()
}

/**
 * STRM 文件扫描与刮削编排仓库。
 *
 * 问题 B 修复：
 * - 已移除对 syncRemoteNumberRecognitionRules() 的调用（原位于 line 217）
 * - 番号识别完全依赖本地 [NumberRecognitionRules]，不再从远程 GitHub 拉取规则缓存
 *
 * 使用 [kotlinx.coroutines] 进行并发编排，[OkHttpClient] 进行网络请求，
 * [MovieNumberExtractor] 进行番号提取。
 */
class StrmScrapeRepository(
    private val client: OkHttpClient = OkHttpClient(),
    private val registry: MovieScraperRegistry,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {

    /**
     * 扫描指定目录下的所有 .strm 文件。
     */
    suspend fun scanStrmFiles(directoryPath: String): List<StrmFile> = withContext(ioDispatcher) {
        val dir = File(directoryPath)
        if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()

        dir.walkTopDown()
            .filter { it.isFile && it.extension.equals("strm", ignoreCase = true) }
            .map { file ->
                StrmFile(
                    path = file.absolutePath,
                    fileName = file.name,
                )
            }
            .toList()
    }

    /**
     * 批量刮削 STRM 文件。
     *
     * 使用本地缓存的番号识别规则提取番号，通过 [registry] 调用刮削器获取元数据，
     * 并将结果写入 .nfo 文件。不依赖远程 GitHub 缓存。
     *
     * @param files 待刮削的 STRM 文件列表
     * @param preferredSource 首选刮削源
     * @param concurrency 并发数
     * @return 刮削汇总结果
     */
    suspend fun scrapeBatch(
        files: List<StrmFile>,
        preferredSource: ScrapeSource = ScrapeSource.Priority,
        concurrency: Int = DEFAULT_CONCURRENCY,
    ): ScrapeRunResult = coroutineScope {
        val results = files.map { file ->
            async(ioDispatcher) {
                scrapeSingle(file, preferredSource)
            }
        }.awaitAll()

        val scanned = results.size
        val success = results.count { it.success }
        val failed = results.count { !it.success && it.error != null }
        val skipped = scanned - success - failed

        ScrapeRunResult(
            scanned = scanned,
            success = success,
            skipped = skipped,
            failed = failed,
        )
    }

    /**
     * 刮削单个 STRM 文件。
     *
     * 1. 使用本地缓存的番号识别规则提取番号
     * 2. 通过 [registry] 调用刮削器获取元数据
     * 3. 写入 .nfo 文件
     */
    suspend fun scrapeSingle(
        file: StrmFile,
        preferredSource: ScrapeSource = ScrapeSource.Priority,
    ): StrmScrapeResult = withContext(ioDispatcher) {
        val number = extractNumberFromFileName(file.fileName)
        if (number.isNullOrBlank()) {
            return@withContext StrmScrapeResult(
                file = file,
                number = null,
                info = null,
                success = false,
                error = "无法从文件名提取番号：${file.fileName}",
            )
        }

        val info = runCatching {
            registry.scrape(preferredSource, number)
        }.getOrElse { error ->
            return@withContext StrmScrapeResult(
                file = file,
                number = number,
                info = null,
                success = false,
                error = error.message ?: "刮削失败：$number",
            )
        }

        runCatching {
            writeNfo(file, info)
        }.onFailure { error ->
            return@withContext StrmScrapeResult(
                file = file,
                number = number,
                info = info,
                success = false,
                error = "写入 NFO 失败：${error.message}",
            )
        }

        StrmScrapeResult(
            file = file,
            number = number,
            info = info,
            success = true,
            error = null,
        )
    }

    /**
     * 从文件名中提取番号（使用本地缓存的识别规则）。
     *
     * 不调用 syncRemoteNumberRecognitionRules()，番号识别完全依赖本地规则。
     */
    private fun extractNumberFromFileName(fileName: String): String? {
        val cachedSuffixes = NumberRecognitionRules.ignoredSuffixes()
        return MovieNumberExtractor.extract(fileName, cachedSuffixes)
    }

    /**
     * 将刮削结果写入 .nfo 文件（与 STRM 文件同目录）。
     */
    private fun writeNfo(file: StrmFile, info: ScrapedMovieInfo) {
        val nfoFile = File(file.path).let { strm ->
            File(strm.parentFile, strm.nameWithoutExtension + ".nfo")
        }
        nfoFile.writeText(NfoWriter.build(info), Charsets.UTF_8)
    }

    private companion object {
        const val DEFAULT_CONCURRENCY = 4
    }
}
