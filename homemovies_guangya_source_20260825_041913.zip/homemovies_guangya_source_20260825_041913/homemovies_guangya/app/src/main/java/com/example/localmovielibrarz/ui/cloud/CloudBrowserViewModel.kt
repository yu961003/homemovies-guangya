package com.example.localmovielibrarz.ui.cloud

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.example.localmovielibrarz.cloud115.Cloud115ApiClient
import com.example.localmovielibrarz.cloud115.Cloud115FileItem

/**
 * 问题 D 13.1：115 网盘浏览 ViewModel。
 *
 * 支持「当前目录 / 全局」搜索模式切换。
 * 退出搜索恢复原列表与滚动位置。
 */
class CloudBrowserViewModel(
    private val apiClient: Cloud115ApiClient
) : ViewModel() {

    enum class SearchScope { CURRENT_DIR, GLOBAL }

    private val _files = MutableStateFlow<List<Cloud115FileItem>>(emptyList())
    val files: StateFlow<List<Cloud115FileItem>> = _files.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchScope = MutableStateFlow(SearchScope.CURRENT_DIR)
    val searchScope: StateFlow<SearchScope> = _searchScope.asStateFlow()

    private val _currentCid = MutableStateFlow(0L)
    val currentCid: StateFlow<Long> = _currentCid.asStateFlow()

    private val _currentPath = MutableStateFlow("根目录")
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    // 退出搜索时恢复
    private var savedFiles: List<Cloud115FileItem> = emptyList()
    private var savedCid: Long = 0L
    private var savedPath: String = "根目录"

    fun setCookie(cookie: String) {
        apiClient.setCookie(cookie)
    }

    fun browseDirectory(cid: Long, path: String) {
        _currentCid.value = cid
        _currentPath.value = path
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val result = apiClient.listFiles(cid)
                _files.value = result.files
            } catch (e: Exception) {
                _files.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun setSearchScope(scope: SearchScope) {
        _searchScope.value = scope
    }

    fun searchFiles(keyword: String) {
        if (keyword.isBlank()) {
            exitSearch()
            return
        }
        // 保存当前状态
        if (!_isSearching.value) {
            savedFiles = _files.value
            savedCid = _currentCid.value
            savedPath = _currentPath.value
        }
        _isSearching.value = true
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val cid = when (_searchScope.value) {
                    SearchScope.CURRENT_DIR -> _currentCid.value
                    SearchScope.GLOBAL -> null
                }
                val result = apiClient.searchFiles(keyword, cid = cid)
                _files.value = result.files
            } catch (e: Exception) {
                _files.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun exitSearch() {
        _isSearching.value = false
        _files.value = savedFiles
        _currentCid.value = savedCid
        _currentPath.value = savedPath
    }
}
