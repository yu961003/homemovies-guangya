package com.example.localmovielibrarz.data.repository

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * 应用设置仓库。
 *
 * 问题 A 修复：所有真实敏感默认清单（MGStage 前缀别名、DMM2 跳过前缀、
 * 云盘排除视频名、云盘清理关键词）已替换为占位符或空集合。
 * 用户可在设置页录入自定义值，运行时合并逻辑保持不变。
 *
 * 问题 B 修复：GitHub 热更新相关的 KEY_REMOTE_SCRAPE_CONFIG_URL /
 * DEFAULT_REMOTE_SCRAPE_CONFIG_URL / getRemoteScrapeConfigUrl /
 * saveRemoteScrapeConfigUrl 已完全移除。
 *
 * 问题 C 修复：新增 key_naming_templates 持久化命名模板。
 */
class AppSettingsRepository private constructor(
    private val prefs: SharedPreferences
) {
    companion object {
        private const val PREFS_NAME = "app_settings"

        // --- 问题 A：占位默认值 ---
        // 占位：真实商编前缀别名（32条）已清除，由用户在设置页录入
        val DEFAULT_MGSTAGE_SEARCH_PREFIX_ALIASES = mapOf(
            "PLACEHOLDER_MG_PREFIX_1" to "100PLACEHOLDER_MG_PREFIX_1",
            "PLACEHOLDER_MG_PREFIX_2" to "200PLACEHOLDER_MG_PREFIX_2"
        )

        // 占位：真实 DMM2 跳过前缀已清除
        val DEFAULT_DMM2_SKIPPED_NUMBER_PREFIXES = setOf("PLACEHOLDER_DMM2_PREFIX")

        // 占位：真实排除视频名（20条）已清除，由用户在设置页录入
        val DEFAULT_CLOUD_EXCLUDED_VIDEO_NAMES = setOf<String>()

        // 已清空（与第4项同目录，处理一致）
        val DEFAULT_CLOUD_CLEAN_KEYWORDS = setOf<String>()

        // --- 问题 A：引用 NumberRecognitionRules 的默认值（随占位一并清空） ---
        val DEFAULT_NUMBER_RECOGNITION_IGNORED_SUFFIXES =
            com.example.localmovielibrarz.util.NumberRecognitionRules.ignoredSuffixes()
        val DEFAULT_NUMBER_RECOGNITION_SEGMENT_MARKERS =
            com.example.localmovielibrarz.util.NumberRecognitionRules.segmentMarkers()

        // --- 问题 C：命名模板 ---
        private const val KEY_NAMING_TEMPLATES = "key_naming_templates"

        // --- Keys ---
        private const val KEY_MGSTAGE_SEARCH_PREFIX_ALIASES = "mgstage_search_prefix_aliases"
        private const val KEY_DMM2_SKIPPED_PREFIXES = "dmm2_skipped_prefixes"
        private const val KEY_CLOUD_EXCLUDED_VIDEO_NAMES = "cloud_excluded_video_names"
        private const val KEY_CLOUD_CLEAN_KEYWORDS = "cloud_clean_keywords"
        private const val KEY_NUMBER_RECOGNITION_IGNORED_SUFFIXES = "number_recognition_ignored_suffixes"
        private const val KEY_NUMBER_RECOGNITION_SEGMENT_MARKERS = "number_recognition_segment_markers"
        private const val KEY_GUANGYA_LOGGED_IN = "guangya_logged_in"

        // 注意：KEY_REMOTE_SCRAPE_CONFIG_URL 已移除（问题 B）

        @Volatile
        private var instance: AppSettingsRepository? = null

        fun get(context: Context): AppSettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: AppSettingsRepository(
                    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                ).also { instance = it }
            }
        }
    }

    // ===== MGStage 搜索前缀别名（问题 A：占位 + 用户自定义合并） =====

    fun getMgstageSearchPrefixAliases(): Map<String, String> {
        val json = prefs.getString(KEY_MGSTAGE_SEARCH_PREFIX_ALIASES, null) ?: return DEFAULT_MGSTAGE_SEARCH_PREFIX_ALIASES
        return parseStringMapJson(json)
    }

    fun saveMgstageSearchPrefixAliases(aliases: Map<String, String>) {
        prefs.edit().putString(KEY_MGSTAGE_SEARCH_PREFIX_ALIASES, stringifyStringMapJson(aliases)).apply()
    }

    // ===== DMM2 跳过前缀（问题 A：占位 + 用户自定义合并） =====

    fun getDmm2SkippedNumberPrefixes(): Set<String> {
        val raw = prefs.getStringSet(KEY_DMM2_SKIPPED_PREFIXES, null) ?: return DEFAULT_DMM2_SKIPPED_NUMBER_PREFIXES
        return raw + DEFAULT_DMM2_SKIPPED_NUMBER_PREFIXES
    }

    fun saveDmm2SkippedNumberPrefixes(prefixes: Set<String>) {
        prefs.edit().putStringSet(KEY_DMM2_SKIPPED_PREFIXES, prefixes).apply()
    }

    // ===== 云盘排除视频名（问题 A：空默认 + 用户自定义合并） =====

    fun getCloudExcludedVideoNames(): Set<String> {
        val raw = prefs.getStringSet(KEY_CLOUD_EXCLUDED_VIDEO_NAMES, null) ?: return DEFAULT_CLOUD_EXCLUDED_VIDEO_NAMES
        return raw + DEFAULT_CLOUD_EXCLUDED_VIDEO_NAMES
    }

    fun saveCloudExcludedVideoNames(names: Set<String>) {
        prefs.edit().putStringSet(KEY_CLOUD_EXCLUDED_VIDEO_NAMES, names).apply()
    }

    // ===== 云盘清理关键词（问题 A：已清空） =====

    fun getCloudCleanKeywords(): Set<String> {
        return prefs.getStringSet(KEY_CLOUD_CLEAN_KEYWORDS, null) ?: DEFAULT_CLOUD_CLEAN_KEYWORDS
    }

    fun saveCloudCleanKeywords(keywords: Set<String>) {
        prefs.edit().putStringSet(KEY_CLOUD_CLEAN_KEYWORDS, keywords).apply()
    }

    // ===== 番号识别规则（问题 A：引用 NumberRecognitionRules 占位） =====

    fun getNumberRecognitionIgnoredSuffixes(): Set<String> {
        return prefs.getStringSet(KEY_NUMBER_RECOGNITION_IGNORED_SUFFIXES, null)
            ?: DEFAULT_NUMBER_RECOGNITION_IGNORED_SUFFIXES
    }

    fun saveNumberRecognitionIgnoredSuffixes(suffixes: Set<String>) {
        prefs.edit().putStringSet(KEY_NUMBER_RECOGNITION_IGNORED_SUFFIXES, suffixes).apply()
    }

    fun getNumberRecognitionSegmentMarkers(): Set<String> {
        return prefs.getStringSet(KEY_NUMBER_RECOGNITION_SEGMENT_MARKERS, null)
            ?: DEFAULT_NUMBER_RECOGNITION_SEGMENT_MARKERS
    }

    fun saveNumberRecognitionSegmentMarkers(markers: Set<String>) {
        prefs.edit().putStringSet(KEY_NUMBER_RECOGNITION_SEGMENT_MARKERS, markers).apply()
    }

    // ===== 光鸭登录态 =====

    fun isGuangyaLoggedIn(): Boolean = prefs.getBoolean(KEY_GUANGYA_LOGGED_IN, false)

    fun setGuangyaLoggedIn(loggedIn: Boolean) {
        prefs.edit().putBoolean(KEY_GUANGYA_LOGGED_IN, loggedIn).apply()
    }

    // ===== 问题 C：命名模板持久化 =====

    fun getNamingTemplates(): List<NamingTemplate> {
        val json = prefs.getString(KEY_NAMING_TEMPLATES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                NamingTemplate(
                    name = obj.optString("name"),
                    pattern = obj.optString("pattern"),
                    useNumberAsName = obj.optBoolean("useNumberAsName", false),
                    moveToSeriesFolder = obj.optBoolean("moveToSeriesFolder", false)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveNamingTemplates(templates: List<NamingTemplate>) {
        val arr = JSONArray()
        templates.forEach { t ->
            arr.put(JSONObject().apply {
                put("name", t.name)
                put("pattern", t.pattern)
                put("useNumberAsName", t.useNumberAsName)
                put("moveToSeriesFolder", t.moveToSeriesFolder)
            })
        }
        prefs.edit().putString(KEY_NAMING_TEMPLATES, arr.toString()).apply()
    }

    fun addNamingTemplate(template: NamingTemplate) {
        val current = getNamingTemplates().toMutableList()
        current.removeAll { it.name == template.name }
        current.add(template)
        saveNamingTemplates(current)
    }

    fun removeNamingTemplate(name: String) {
        val current = getNamingTemplates().toMutableList()
        current.removeAll { it.name == name }
        saveNamingTemplates(current)
    }

    // ===== JSON 辅助 =====

    private fun parseStringMapJson(json: String): Map<String, String> {
        return runCatching {
            val obj = JSONObject(json)
            val result = mutableMapOf<String, String>()
            obj.keys().forEach { key ->
                result[key] = obj.getString(key)
            }
            result
        }.getOrDefault(emptyMap())
    }

    private fun stringifyStringMapJson(map: Map<String, String>): String {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        return obj.toString()
    }
}

/**
 * 命名模板（问题 C：批量重命名保存为模板）
 */
data class NamingTemplate(
    val name: String,
    val pattern: String,
    val useNumberAsName: Boolean = false,
    val moveToSeriesFolder: Boolean = false
)
