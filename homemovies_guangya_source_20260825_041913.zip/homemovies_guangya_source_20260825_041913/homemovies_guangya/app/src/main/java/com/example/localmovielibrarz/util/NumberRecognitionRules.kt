package com.example.localmovielibrarz.util

import java.util.Locale

/**
 * 番号识别规则（占位版）。
 *
 * 所有真实默认清单已替换为占位符，用户可在设置页录入自定义规则。
 * 合并、去重、识别逻辑保持不变。
 */
object NumberRecognitionRules {

    // 占位：真实忽略后缀已清除，由用户在设置页录入
    fun ignoredSuffixes(): Set<String> = emptySet()

    // 占位：真实分段标记已清除，由用户在设置页录入
    fun segmentMarkers(): Set<String> = emptySet()

    // 占位：真实连写前缀已清除，由用户在设置页录入
    fun attachedLetterPrefixes(): Set<String> = emptySet()

    fun stripIgnoredSuffix(
        baseName: String,
        ignoredSuffixes: Set<String>
    ): StripResult {
        if (ignoredSuffixes.isEmpty()) return StripResult(baseName, false)
        var result = baseName
        var stripped = false
        for (suffix in ignoredSuffixes) {
            if (suffix.isNotBlank() && result.endsWith(suffix, ignoreCase = true)) {
                result = result.removeSuffix(suffix)
                stripped = true
                break
            }
        }
        return StripResult(result, stripped)
    }

    fun canonicalizePrefix(prefix: String): String =
        prefix.trim().uppercase(Locale.ROOT)

    fun numericPrefixAliasFor(prefix: String): String? = null

    fun normalizeDigits(
        prefix: String,
        digits: String,
        hasExplicitSeparator: Boolean,
        strippedIgnoredSuffix: Boolean
    ): String = digits

    fun isAttachedLetterSegment(prefix: String, suffix: String): Boolean = false

    data class StripResult(val baseName: String, val stripped: Boolean)
}
