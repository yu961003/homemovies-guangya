package com.example.localmovielibrarz.ui.guangya.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localmovielibrarz.data.repository.AppSettingsRepository
import com.example.localmovielibrarz.data.repository.NamingTemplate

/**
 * 问题 C：批量重命名「保存为模板 / 应用模板」Sheet。
 *
 * 保存当前命名配置为模板，或从已保存模板列表选择一键应用。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RenameTemplateSheet(
    templates: List<NamingTemplate>,
    onDismiss: () -> Unit,
    onSaveTemplate: (NamingTemplate) -> Unit,
    onApplyTemplate: (NamingTemplate) -> Unit,
    onDeleteTemplate: (String) -> Unit,
    currentPattern: String = "",
    currentUseNumberAsName: Boolean = false,
    currentMoveToSeriesFolder: Boolean = false
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var templateName by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "命名模板",
                style = MaterialTheme.typography.headlineSmall
            )

            // 保存为模板
            Button(
                onClick = { showSaveDialog = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = currentPattern.isNotBlank()
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("保存当前配置为模板")
            }

            HorizontalDivider()

            // 模板列表
            Text(
                text = "已保存模板（${templates.size}）",
                style = MaterialTheme.typography.labelLarge
            )

            if (templates.isEmpty()) {
                Text(
                    text = "暂无模板，保存后将在此显示",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(templates, key = { it.name }) { template ->
                        TemplateCard(
                            template = template,
                            onApply = { onApplyTemplate(template) },
                            onDelete = { onDeleteTemplate(template.name) }
                        )
                    }
                }
            }
        }
    }

    // 保存对话框
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = {
                showSaveDialog = false
                templateName = ""
            },
            title = { Text("保存命名模板") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = templateName,
                        onValueChange = { templateName = it },
                        label = { Text("模板名称") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "模式：$currentPattern",
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (templateName.isNotBlank()) {
                            onSaveTemplate(
                                NamingTemplate(
                                    name = templateName.trim(),
                                    pattern = currentPattern,
                                    useNumberAsName = currentUseNumberAsName,
                                    moveToSeriesFolder = currentMoveToSeriesFolder
                                )
                            )
                            showSaveDialog = false
                            templateName = ""
                        }
                    },
                    enabled = templateName.isNotBlank()
                ) {
                    Text("保存")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showSaveDialog = false
                    templateName = ""
                }) {
                    Text("取消")
                }
            }
        )
    }
}

@Composable
private fun TemplateCard(
    template: NamingTemplate,
    onApply: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = template.name,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = template.pattern,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (template.useNumberAsName || template.moveToSeriesFolder) {
                    val tags = mutableListOf<String>()
                    if (template.useNumberAsName) tags.add("番号命名")
                    if (template.moveToSeriesFolder) tags.add("移入系列文件夹")
                    Text(
                        text = tags.joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            TextButton(onClick = onApply) {
                Text("应用")
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "删除模板",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
