package com.example.localmovielibrarz.ui.guangya

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.example.localmovielibrarz.cloudguangya.GuangyaLoginClient
import com.example.localmovielibrarz.cloudguangya.GuangyaQrPollResult
import com.example.localmovielibrarz.cloudguangya.GuangyaQrSession
import com.example.localmovielibrarz.cloudguangya.GuangyaTokenPair
import com.example.localmovielibrarz.cloudguangya.GuangyaTokenStore
import com.example.localmovielibrarz.cloudguangya.GuangyaConstants
import com.example.localmovielibrarz.cloudguangya.GuangyaLoginException

/**
 * 光鸭登录 ViewModel（问题 E）。
 *
 * 包含两套登录方式：
 * 1. 短信验证码登录（phone, code, smsStep）
 * 2. 扫码登录（qrStep, qrPayload, initQr, startQrPolling, stopQrPolling, refreshQr）
 *
 * 任一成功即进入登录态；登出同时清空两种来源令牌。
 * 轮询协程挂在 viewModelScope，退出页面/登出/登录成功时 stopQrPolling() 取消，防泄漏。
 */
class GuangyaLoginViewModel(
    private val loginClient: GuangyaLoginClient,
    private val tokenStore: GuangyaTokenStore
) : ViewModel() {

    // ===== 短信登录状态 =====
    enum class SmsStep { IDLE, SENDING_CODE, WAITING_CODE, LOGGING_IN, LOGGED_IN, ERROR }

    private val _phone = MutableStateFlow("")
    val phone: StateFlow<String> = _phone.asStateFlow()

    private val _code = MutableStateFlow("")
    val code: StateFlow<String> = _code.asStateFlow()

    private val _smsStep = MutableStateFlow(SmsStep.IDLE)
    val smsStep: StateFlow<SmsStep> = _smsStep.asStateFlow()

    private val _smsError = MutableStateFlow<String?>(null)
    val smsError: StateFlow<String?> = _smsError.asStateFlow()

    private val _codeCountdown = MutableStateFlow(0)
    val codeCountdown: StateFlow<Int> = _codeCountdown.asStateFlow()

    private var captchaToken: String = ""
    private var verificationId: String = ""

    // ===== 扫码登录状态 =====
    enum class QrStep { IDLE, PENDING, LOGGED_IN, EXPIRED, SLOW_DOWN, ERROR }

    private val _qrStep = MutableStateFlow(QrStep.IDLE)
    val qrStep: StateFlow<QrStep> = _qrStep.asStateFlow()

    private val _qrPayload = MutableStateFlow<String?>(null)
    val qrPayload: StateFlow<String?> = _qrPayload.asStateFlow()

    private val _qrError = MutableStateFlow<String?>(null)
    val qrError: StateFlow<String?> = _qrError.asStateFlow()

    private var qrSession: GuangyaQrSession? = null
    private var pollJob: Job? = null

    // ===== 公共状态 =====
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    init {
        _isLoggedIn.value = tokenStore.isLoggedIn()
    }

    // ===== 短信登录 =====

    fun updatePhone(value: String) { _phone.value = value }
    fun updateCode(value: String) { _code.value = value }

    fun sendCode() {
        if (_phone.value.isBlank()) {
            _smsError.value = "请输入手机号"
            return
        }
        _smsStep.value = SmsStep.SENDING_CODE
        _smsError.value = null

        viewModelScope.launch {
            try {
                captchaToken = loginClient.smsInit(_phone.value)
                verificationId = loginClient.sendVerificationCode(_phone.value, captchaToken)
                _smsStep.value = SmsStep.WAITING_CODE
                startCountdown()
            } catch (e: Exception) {
                _smsError.value = e.message ?: "发送验证码失败"
                _smsStep.value = SmsStep.ERROR
            }
        }
    }

    fun loginWithCode() {
        if (_code.value.isBlank()) {
            _smsError.value = "请输入验证码"
            return
        }
        _smsStep.value = SmsStep.LOGGING_IN
        _smsError.value = null

        viewModelScope.launch {
            try {
                val verificationToken = loginClient.verifyCode(verificationId, _code.value)
                val tokenPair = loginClient.signin(verificationToken)
                tokenStore.save(tokenPair)
                _isLoggedIn.value = true
                _smsStep.value = SmsStep.LOGGED_IN
                stopQrPolling()
            } catch (e: Exception) {
                _smsError.value = e.message ?: "登录失败"
                _smsStep.value = SmsStep.ERROR
            }
        }
    }

    private fun startCountdown() {
        viewModelScope.launch {
            for (i in 60 downTo 1) {
                _codeCountdown.value = i
                delay(1000)
            }
            _codeCountdown.value = 0
        }
    }

    // ===== 扫码登录 =====

    fun initQr() {
        _qrStep.value = QrStep.IDLE
        _qrError.value = null

        viewModelScope.launch {
            try {
                val session = loginClient.qrInit()
                qrSession = session
                _qrPayload.value = session.qrPayload
                _qrStep.value = QrStep.PENDING
                startQrPolling()
            } catch (e: GuangyaLoginException) {
                _qrError.value = e.message
                _qrStep.value = QrStep.ERROR
            } catch (e: Exception) {
                _qrError.value = "扫码初始化失败"
                _qrStep.value = QrStep.ERROR
            }
        }
    }

    fun startQrPolling() {
        stopQrPolling()
        val session = qrSession ?: return

        pollJob = viewModelScope.launch {
            var interval = GuangyaConstants.QR_POLL_INTERVAL_SECONDS * 1000L

            while (isActive) {
                delay(interval)

                try {
                    when (val result = loginClient.qrPoll(session.deviceCode)) {
                        is GuangyaQrPollResult.Success -> {
                            tokenStore.save(result.tokenPair)
                            _isLoggedIn.value = true
                            _qrStep.value = QrStep.LOGGED_IN
                            stopQrPolling()
                            return@launch
                        }
                        GuangyaQrPollResult.Pending -> {
                            _qrStep.value = QrStep.PENDING
                        }
                        GuangyaQrPollResult.SlowDown -> {
                            _qrStep.value = QrStep.SLOW_DOWN
                            interval = GuangyaConstants.QR_POLL_SLOWDOWN_INTERVAL_SECONDS * 1000L
                        }
                        GuangyaQrPollResult.Expired -> {
                            _qrStep.value = QrStep.EXPIRED
                            stopQrPolling()
                            return@launch
                        }
                    }
                } catch (e: GuangyaLoginException) {
                    _qrError.value = e.message
                    _qrStep.value = QrStep.ERROR
                    stopQrPolling()
                    return@launch
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // 网络错误等，继续轮询
                    _qrStep.value = QrStep.PENDING
                }
            }
        }
    }

    fun stopQrPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    fun refreshQr() {
        stopQrPolling()
        initQr()
    }

    // ===== 登出 =====

    fun logout() {
        stopQrPolling()
        tokenStore.clear()
        _isLoggedIn.value = false
        _smsStep.value = SmsStep.IDLE
        _phone.value = ""
        _code.value = ""
        _qrStep.value = QrStep.IDLE
        _qrPayload.value = null
        _qrError.value = null
        _smsError.value = null
    }

    override fun onCleared() {
        super.onCleared()
        stopQrPolling()
    }

    companion object {
        fun factory(
            loginClient: GuangyaLoginClient,
            tokenStore: GuangyaTokenStore
        ) = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return GuangyaLoginViewModel(loginClient, tokenStore) as T
            }
        }
    }
}
