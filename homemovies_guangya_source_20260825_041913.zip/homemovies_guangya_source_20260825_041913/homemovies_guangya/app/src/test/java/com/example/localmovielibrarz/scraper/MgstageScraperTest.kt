package com.example.localmovielibrarz.scraper

import org.junit.Assert.assertEquals
import org.junit.Test

class MgstageScraperTest {
    @Test
    fun placeholdersDoNotMapRealPrefixes() {
        // 占位后，真实前缀不被映射，原样返回大写
        assertEquals("SHN-045", normalizeMgstageSearchNumber("SHN-045"))
        assertEquals("GANA-2556", normalizeMgstageSearchNumber("GANA-2556"))
        assertEquals("MIUM-001", normalizeMgstageSearchNumber("MIUM-001"))
    }

    @Test
    fun normalizesPlaceholderPrefixesWithCustomAliases() {
        // 用户自定义别名仍可正常映射
        assertEquals(
            "123ABC-777",
            normalizeMgstageSearchNumber("ABC-777", mapOf("ABC" to "123ABC"))
        )
    }

    @Test
    fun keepsAlreadyPrefixedMgstageSearchNumber() {
        assertEquals("300MIUM-001", normalizeMgstageSearchNumber("300MIUM-001"))
        assertEquals("229SCUTE-953", normalizeMgstageSearchNumber("229SCUTE-953"))
        assertEquals("200GANA-3403", normalizeMgstageSearchNumber("200GANA-3403"))
    }

    @Test
    fun acceptsRemoteSearchPrefixAliases() {
        assertEquals(
            "123ABC-777",
            normalizeMgstageSearchNumber("ABC-777", mapOf("ABC" to "123ABC"))
        )
    }
}
